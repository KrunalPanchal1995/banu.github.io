import asyncio
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import mqtt_proto as P  # noqa: E402
import netcalc as N  # noqa: E402
from broker import Broker  # noqa: E402
from client import MiniClient  # noqa: E402


def run(coro):
    return asyncio.run(coro)


def test_remaining_length_examples_from_the_specification():
    for n, hexs in ((0, "00"), (127, "7f"), (128, "8001"), (16383, "ff7f"), (16384, "808001"), (2097151, "ffff7f"), (2097152, "80808001"), (268435455, "ffffff7f")):
        assert P.encode_remaining_length(n).hex() == hexs
        assert P.decode_remaining_length(bytes.fromhex(hexs)) == (n, len(hexs) // 2)
    with pytest.raises(ValueError):
        P.encode_remaining_length(268435456)
    with pytest.raises(ValueError):
        P.decode_remaining_length(bytes([0x80, 0x80, 0x80, 0x80, 0x01]))


def test_packet_round_trips():
    c = P.parse_connect(P.connect_packet("node1", 30, True, ("greenhouse/zone1/node1/status", b"offline", 1, True), "u", b"p")[2:])
    assert c["client_id"] == "node1" and c["keepalive"] == 30 and c["clean"] and c["will"] == ("greenhouse/zone1/node1/status", b"offline", 1, True) and c["username"] == "u" and c["password"] == b"p"
    raw = P.publish_packet("a/b", b"xyz", 2, True, pid=7)
    assert raw[0] == 0x35 and P.parse_publish(raw[0] & 15, raw[2:]) == dict(topic="a/b", payload=b"xyz", qos=2, retain=True, dup=False, pid=7)
    assert P.subscribe_packet(10, [("a/+", 1)])[0] == 0x82 and P.ack_packet(P.PUBREL, 5)[0] == 0x62
    assert P.parse_subscribe(P.subscribe_packet(10, [("a/+", 1), ("b/#", 0)])[2:]) == (10, [("a/+", 1), ("b/#", 0)])
    assert P.pingreq_packet() == b"\xc0\x00" and P.pingresp_packet() == b"\xd0\x00" and P.disconnect_packet() == b"\xe0\x00"
    assert P.connack_packet(False, 0) == b"\x20\x02\x00\x00"


def test_topic_matching_table():
    T = P.topic_matches
    assert T("greenhouse/+/soil", "greenhouse/zone1/soil") and not T("greenhouse/+/soil", "greenhouse/zone1/sub/soil")
    assert T("sport/tennis/player1/#", "sport/tennis/player1") and T("sport/tennis/player1/#", "sport/tennis/player1/ranking/x")
    assert T("#", "a/b/c") and T("+/+", "/finance") and not T("+", "/finance") and T("/+", "/finance")
    assert not T("#", "$SYS/broker") and not T("+/monitor/Clients", "$SYS/monitor/Clients") and T("$SYS/#", "$SYS/broker/load")
    assert not T("a/b", "a") and not T("a", "a/b") and T("a/b", "a/b")
    assert P.valid_filter("a/+/#") and not P.valid_filter("a/#/b") and not P.valid_filter("a+") and not P.valid_filter("") and P.valid_topic_name("a/b") and not P.valid_topic_name("a/+")


async def _pair(**kw):
    b = await Broker(**kw).start()
    return b


def test_end_to_end_qos_wildcards_unsubscribe():
    async def go():
        b = await _pair()
        sub, pub = MiniClient("sub", 0), MiniClient("pub", 0)
        await sub.connect("127.0.0.1", b.port); await pub.connect("127.0.0.1", b.port)
        granted = await sub.subscribe([("greenhouse/+/soil", 1), ("alerts/#", 2)])
        assert granted == [1, 1]                                    # this broker grants at most QoS 1
        await pub.publish("greenhouse/zone1/soil", b"1832", 0)
        await pub.publish("greenhouse/zone2/soil", b"1900", 1)
        await pub.publish("alerts/x/y", b"hot", 2)
        got = [await sub.get() for _ in range(3)]
        assert [(m["topic"], m["payload"], m["qos"]) for m in got] == [("greenhouse/zone1/soil", b"1832", 0), ("greenhouse/zone2/soil", b"1900", 1), ("alerts/x/y", b"hot", 1)]
        await pub.publish("greenhouse/zone1/temp", b"21", 1)
        await sub.unsubscribe("greenhouse/+/soil")
        await pub.publish("greenhouse/zone3/soil", b"x", 1)
        with pytest.raises(asyncio.TimeoutError):
            await sub.get(0.3)
        await sub.disconnect(); await pub.disconnect(); await b.stop()
    run(go())


def test_qos2_inbound_exactly_once_even_if_publish_is_repeated():
    async def go():
        b = await _pair()
        sub, pub = MiniClient("s", 0), MiniClient("p", 0)
        await sub.connect("127.0.0.1", b.port); await pub.connect("127.0.0.1", b.port)
        await sub.subscribe([("t", 1)])
        pub.writer.write(P.publish_packet("t", b"once", 2, pid=9)); pub.writer.write(P.publish_packet("t", b"once", 2, dup=True, pid=9))   # duplicate while pending
        await asyncio.sleep(0.2)
        pub.writer.write(P.ack_packet(P.PUBREL, 9)); pub.writer.write(P.ack_packet(P.PUBREL, 9))      # second PUBREL: PUBCOMP again, no second delivery
        await asyncio.sleep(0.3)
        assert sub.messages.qsize() == 1
        names = [x[2] for x in b.log if x[1] == "p" and x[0] == "out"]
        assert names.count("PUBREC") == 2 and names.count("PUBCOMP") >= 2       # every PUBREL is answered (the client also auto-sends PUBREL per PUBREC); delivery stays once
        await sub.disconnect(); await pub.disconnect(); await b.stop()
    run(go())


def test_retained_messages_and_clearing():
    async def go():
        b = await _pair()
        pub = MiniClient("p", 0); await pub.connect("127.0.0.1", b.port)
        await pub.publish("greenhouse/zone1/node1/status", b"online", 1, retain=True)
        late = MiniClient("late", 0); await late.connect("127.0.0.1", b.port); await late.subscribe([("greenhouse/+/+/status", 1)])
        m = await late.get(); assert m["payload"] == b"online" and m["retain"] is True
        await pub.publish("greenhouse/zone1/node1/status", b"", 1, retain=True)      # empty retained payload clears
        late2 = MiniClient("late2", 0); await late2.connect("127.0.0.1", b.port); await late2.subscribe([("greenhouse/#", 1)])
        with pytest.raises(asyncio.TimeoutError):
            await late2.get(0.3)
        await pub.publish("live", b"x", 1)
        for c in (pub, late, late2): await c.disconnect()
        await b.stop()
    run(go())


def test_last_will_on_abort_but_not_on_clean_disconnect():
    async def go():
        b = await _pair()
        watcher = MiniClient("w", 0); await watcher.connect("127.0.0.1", b.port); await watcher.subscribe([("status/#", 1)])
        a = MiniClient("a", 0, will=("status/a", b"offline", 1, True)); await a.connect("127.0.0.1", b.port)
        a.abort()
        m = await watcher.get(); assert (m["topic"], m["payload"]) == ("status/a", b"offline")
        assert b.retained["status/a"][0] == b"offline"
        c = MiniClient("c", 0, will=("status/c", b"offline", 1, False)); await c.connect("127.0.0.1", b.port)
        await c.disconnect()
        with pytest.raises(asyncio.TimeoutError):
            await watcher.get(0.3)
        await watcher.disconnect(); await b.stop()
    run(go())


def test_keepalive_timeout_publishes_will():
    async def go():
        b = await _pair()
        w = MiniClient("w", 0); await w.connect("127.0.0.1", b.port); await w.subscribe([("lwt", 0)])
        silent = MiniClient("silent", 1, will=("lwt", b"gone", 0, False))     # keep-alive 1 s ...
        await silent.connect("127.0.0.1", b.port)
        for t in silent._tasks: t.cancel()                                     # ... but never pings (the ping loop is stopped)
        m = await w.get(timeout=3.0); assert m["payload"] == b"gone"
        await w.disconnect(); await b.stop()
    run(go())


def test_wrong_protocol_level_is_refused():
    async def go():
        b = await _pair()
        r, w = await asyncio.open_connection("127.0.0.1", b.port)
        bad = P.packet(P.CONNECT, 0, P.enc_str("MQTT") + bytes([3, 2]) + b"\x00\x3c" + P.enc_str("x"))
        w.write(bad); await w.drain()
        ptype, flags, body = await P.read_packet(r)
        assert ptype == P.CONNACK and body[1] == 1                             # 0x01: unacceptable protocol version
        w.close(); await b.stop()
    run(go())


def test_netcalc_sizes_and_formulas():
    assert N.mqtt_publish_bytes("greenhouse/zone1/soil", b"1832", 0) == 29 and N.mqtt_publish_bytes("greenhouse/zone1/soil", b"1832", 1) == 31
    assert len(N.coap_post("greenhouse/zone1/soil", b"1832")) == 32
    assert N.wire_mqtt_persistent("greenhouse/zone1/soil", b"1832", 1) == (40 + 31) + (40 + 4)
    assert abs(N.fspl_db(1000, 2.4e9) - 100.05) < 0.05 and abs(N.max_range_m(N.fspl_db(1000, 2.4e9), 2.4e9) - 1000) < 1e-6
    for p in (0.1, 0.3):
        assert abs(N.qos_expected_packets(p, 1) - N.qos_simulate(p, 1, 30000, 1)["packets"]) < 0.05 * N.qos_expected_packets(p, 1)
        assert abs(N.qos_expected_packets(p, 2) - N.qos_simulate(p, 2, 30000, 2)["packets"]) < 0.05 * N.qos_expected_packets(p, 2)
        assert abs(N.qos_simulate(p, 1, 30000, 3)["duplicates"] - p / (1 - p)) < 0.05
        assert N.qos_simulate(p, 2, 30000, 4)["duplicates"] == 0 and N.qos_simulate(p, 2, 5000, 5)["delivered"] == 1.0
    assert N.qos_expected_packets(0.0, 0) == 1 and N.qos_expected_packets(0.0, 1) == 2 and N.qos_expected_packets(0.0, 2) == 4
