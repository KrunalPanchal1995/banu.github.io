"""mqtt_mini: facade re-exporting the pieces (mqtt_proto, broker, client, netcalc). See README.md."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from broker import Broker  # noqa: E402,F401
from client import MiniClient  # noqa: E402,F401
import mqtt_proto  # noqa: E402,F401
import netcalc  # noqa: E402,F401


def main():
    print("remaining length 16384 ->", mqtt_proto.encode_remaining_length(16384).hex())
    print("PUBLISH bytes (QoS 0, 21-char topic, 4-byte payload):", netcalc.mqtt_publish_bytes("greenhouse/zone1/soil", b"1832"))


if __name__ == "__main__":
    main()
