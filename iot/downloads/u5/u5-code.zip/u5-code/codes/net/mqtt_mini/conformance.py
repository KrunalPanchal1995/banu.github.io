"""Independent conformance checks (needs `pip install paho-mqtt amqtt` in a throwaway venv; NOT part of the pytest suite).

Part A: the real paho-mqtt client talks to OUR broker (mqtt_mini.Broker).
Part B: OUR client (mqtt_mini.MiniClient) talks to a real broker implementation (amqtt).
Run:  python conformance.py        Prints one PASS/FAIL line per check and a summary.
"""
import asyncio
import os
import queue
import socket
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import paho.mqtt.client as mqtt  # noqa: E402
from broker import Broker  # noqa: E402
from client import MiniClient  # noqa: E402

RESULTS = []


def check(name, ok, detail=""):
    RESULTS.append(bool(ok))
    print(("PASS " if ok else "FAIL ") + name + ((" :: " + str(detail)) if detail != "" else ""), flush=True)


# ---------------------------------------------------------------- Part A: paho -> our broker
class BrokerThread:
    def __init__(self):
        self.loop = asyncio.new_event_loop()
        self.broker = None
        self.ready = threading.Event()
        self.t = threading.Thread(target=self._run, daemon=True)
        self.t.start()
        self.ready.wait(5)

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.broker = Broker()
        self.loop.run_until_complete(self.broker.start())
        self.ready.set()
        self.loop.run_forever()


def paho_client(cid, port, will=None, keepalive=30):
    q, granted, connected = queue.Queue(), [], threading.Event()
    c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=cid, protocol=mqtt.MQTTv311)
    if will:
        c.will_set(*will[:2], qos=will[2], retain=will[3])
    c.on_connect = lambda cl, ud, flags, rc, props: (connected.set() if rc.value == 0 else None)
    c.on_message = lambda cl, ud, msg: q.put((msg.topic, bytes(msg.payload), msg.qos, bool(msg.retain)))
    c.on_subscribe = lambda cl, ud, mid, rcs, props: granted.append([r.value for r in rcs])
    c.connect("127.0.0.1", port, keepalive=keepalive)
    c.loop_start()
    connected.wait(5)
    return c, q, granted, connected


def drain(q, n, timeout=2.0):
    out = []
    t0 = time.time()
    while len(out) < n and time.time() - t0 < timeout:
        try:
            out.append(q.get(timeout=0.1))
        except queue.Empty:
            pass
    return out


def part_a():
    bt = BrokerThread()
    port = bt.broker.port
    sub, sq, granted, ok = paho_client("paho-sub", port)
    check("A1 paho CONNECT accepted by our broker (CONNACK rc 0)", ok.is_set())
    sub.subscribe([("greenhouse/+/soil", 2), ("alerts/#", 1)])
    time.sleep(0.4)
    check("A2 SUBACK granted QoS (requested 2 and 1; our broker caps at 1)", granted and granted[-1] == [1, 1], granted)
    pub, pq, _, _ = paho_client("paho-pub", port)
    infos = [pub.publish("greenhouse/zone1/soil", b"1832", qos=q) for q in (0, 1, 2)]
    done = [i.wait_for_publish(3) is None and i.is_published() for i in infos]
    check("A3 QoS 0, 1, 2 publishes complete at paho (PUBACK / PUBREC-PUBREL-PUBCOMP handled by our broker)", all(done), done)
    got = drain(sq, 3)
    check("A4 subscriber receives all three (QoS delivered 0, 1, 1 because our grant is capped at 1)", [(t, p, q) for t, p, q, r in got] == [("greenhouse/zone1/soil", b"1832", 0), ("greenhouse/zone1/soil", b"1832", 1), ("greenhouse/zone1/soil", b"1832", 1)], got)
    pub.publish("greenhouse/zone1/sub/soil", b"x", qos=1).wait_for_publish(2); pub.publish("alerts/a/b/c", b"hot", qos=1).wait_for_publish(2)
    got = drain(sq, 2, 1.0)
    check("A5 wildcards: '+' is one level only, '#' is multi-level", [t for t, *_ in got] == ["alerts/a/b/c"], got)
    pub.publish("greenhouse/zone9/node1/status", b"online", qos=1, retain=True).wait_for_publish(2)
    late, lq, g2, _ = paho_client("paho-late", port); late.subscribe("greenhouse/+/+/status", 1); time.sleep(0.4)
    got = drain(lq, 1)
    check("A6 retained message delivered to a late subscriber with the RETAIN flag set", got == [("greenhouse/zone9/node1/status", b"online", 1, True)], got)
    pub.publish("greenhouse/zone9/node1/status", b"", qos=1, retain=True).wait_for_publish(2)
    late2, lq2, _, _ = paho_client("paho-late2", port); late2.subscribe("greenhouse/#", 1); time.sleep(0.5)
    got = drain(lq2, 1, 0.7)
    check("A7 empty retained payload clears the retained message", got == [], got)
    lw, lwq, _, _ = paho_client("paho-will", port, will=("status/paho-will", b"offline", 1, True))
    w2, w2q, _, _ = paho_client("paho-watch", port); w2.subscribe("status/#", 1); time.sleep(0.4)
    try:
        lw.socket().shutdown(socket.SHUT_RDWR)
    except Exception:
        pass
    lw.loop_stop()
    got = drain(w2q, 1, 3.0)
    check("A8 last will published when the client vanishes without DISCONNECT", got and got[0][:2] == ("status/paho-will", b"offline"), got)
    clean, cq, _, _ = paho_client("paho-clean", port, will=("status/paho-clean", b"offline", 1, False)); time.sleep(0.2); clean.disconnect(); clean.loop_stop()
    got = drain(w2q, 1, 0.8)
    check("A9 no will after a clean DISCONNECT", got == [], got)
    ka, kq, _, _ = paho_client("paho-ka", port, keepalive=1); ka.subscribe("ka/x", 0); time.sleep(3.2)
    pub.publish("ka/x", b"still here", qos=0).wait_for_publish(2); got = drain(kq, 1, 1.5)
    check("A10 keep-alive: 1 s keep-alive survives 3 s idle thanks to PINGREQ/PINGRESP", got and got[0][1] == b"still here", got)
    for c in (sub, pub, late, late2, w2, ka):
        c.disconnect(); c.loop_stop()


# ---------------------------------------------------------------- Part B: our client -> amqtt broker
async def part_b():
    from amqtt.broker import Broker as AmqttBroker
    cfg = {"listeners": {"default": {"type": "tcp", "bind": "127.0.0.1:18831"}}, "plugins": {"amqtt.plugins.authentication.AnonymousAuthPlugin": {"allow_anonymous": True}}}
    b = AmqttBroker(cfg)
    await b.start()
    await asyncio.sleep(0.5)
    try:
        c = MiniClient("ours-1", 5); await c.connect("127.0.0.1", 18831)
        check("B1 our CONNECT accepted by amqtt", True)
        granted = await c.subscribe([("greenhouse/+/soil", 2)])
        check("B2 amqtt grants QoS 2 to our SUBSCRIBE", granted == [2], granted)
        await c.publish("greenhouse/zone1/soil", b"q0", 0); await c.publish("greenhouse/zone1/soil", b"q1", 1); await c.publish("greenhouse/zone1/soil", b"q2", 2)
        got = [await c.get(3) for _ in range(3)]
        pay = [(m["payload"]) for m in got]; qs = [m["qos"] for m in got]
        check("B3 QoS 0/1/2 publishes acknowledged by amqtt and all three delivered back to us (our inbound QoS-2 handshake completes)", pay == [b"q0", b"q1", b"q2"], (pay, qs))
        note = "amqtt delivered at the subscription's QoS %r; MQTT 3.1.1 section 3.8.4 requires min(published, granted) = [0, 1, 2]" % (qs,)
        print("NOTE B3b amqtt deviation (confirmed with paho as an independent client): " + note, flush=True)
        await c.publish("greenhouse/zone1/sub/soil", b"no", 1)
        try:
            await c.get(0.5); nomatch = False
        except asyncio.TimeoutError:
            nomatch = True
        check("B4 non-matching topic not delivered", nomatch)
        await c.publish("greenhouse/zone5/node1/status", b"online", 1, retain=True)
        d = MiniClient("ours-2", 5); await d.connect("127.0.0.1", 18831); await d.subscribe([("greenhouse/+/+/status", 1)])
        m = await d.get(3)
        check("B5 retained message from amqtt carries the RETAIN flag", m["payload"] == b"online" and m["retain"], m)
        w = MiniClient("ours-w", 5); await w.connect("127.0.0.1", 18831); await w.subscribe([("status/#", 1)])
        k = MiniClient("ours-will", 5, will=("status/ours-will", b"offline", 1, False)); await k.connect("127.0.0.1", 18831)
        k.abort()
        seen = []
        for _ in range(3):
            m = await w.get(5); seen.append((m["topic"], m["payload"], m["retain"]))
            if m["topic"] == "status/ours-will":
                break
        check("B6 amqtt publishes our last will after we vanish", seen[-1][:2] == ("status/ours-will", b"offline"), seen)
        if len(seen) > 1:
            print("NOTE B6b amqtt deviation (confirmed with paho): a non-matching retained message %r was delivered to a 'status/#' subscriber after another client had subscribed with a matching filter" % (seen[0],), flush=True)
        await c.unsubscribe("greenhouse/+/soil")
        await c.publish("greenhouse/zone1/soil", b"after", 1)
        try:
            await c.get(0.5); gone = False
        except asyncio.TimeoutError:
            gone = True
        check("B7 UNSUBSCRIBE stops delivery", gone)
        for x in (c, d, w):
            await x.disconnect()
    finally:
        await b.shutdown()


if __name__ == "__main__":
    import paho.mqtt
    print("paho-mqtt", paho.mqtt.__version__ if hasattr(paho.mqtt, "__version__") else "(installed)")
    part_a()
    asyncio.run(part_b())
    print("SUMMARY: %d/%d checks passed" % (sum(RESULTS), len(RESULTS)))
    sys.exit(0 if all(RESULTS) else 1)
