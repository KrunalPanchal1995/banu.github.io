"""Message-size, link-budget and QoS-cost calculators for Unit 5 (pure Python + random). See README.md.

Wire-size model (SIMPLIFIED, stated in the Unit): every application message is one IP packet with 40 bytes of IPv4+TCP
header (28 for IPv4+UDP); no TCP options, no TLS, no link-layer framing; a TCP handshake is 3 packets and a close is 4.
"""
import math
import random

import mqtt_proto as P

IP_TCP, IP_UDP = 40, 28


def mqtt_publish_bytes(topic, payload, qos=0):
    return len(P.publish_packet(topic, payload, qos, pid=1 if qos else None))


def mqtt_connect_bytes(client_id, keepalive=60, will=None):
    return len(P.connect_packet(client_id, keepalive, True, will))


def http_post_request(path, host, body, content_type="text/plain"):
    head = "POST %s HTTP/1.1\r\nHost: %s\r\nContent-Type: %s\r\nContent-Length: %d\r\n\r\n" % (path, host, content_type, len(body))
    return head.encode() + body


def http_response_minimal():
    return b"HTTP/1.1 204 No Content\r\nConnection: close\r\n\r\n"


def _coap_opt(prev, num, value):
    delta, ln = num - prev, len(value)

    def ext(x):
        if x < 13:
            return x, b""
        if x < 269:
            return 13, bytes([x - 13])
        return 14, (x - 269).to_bytes(2, "big")
    d, de = ext(delta)
    l, le = ext(ln)
    return bytes([(d << 4) | l]) + de + le + value


def coap_post(path, payload, msg_id=1, token=b"", confirmable=True, content_format=0):
    """CoAP POST as I remember RFC 7252 (header 4 bytes; options delta-encoded: Uri-Path = 11, one per path segment;
    Content-Format = 12; 0xFF payload marker). UNVERIFIED against the RFC text: used only to estimate sizes."""
    ver_t_tkl = (1 << 6) | ((0 if confirmable else 1) << 4) | len(token)
    out = bytes([ver_t_tkl, 0x02]) + msg_id.to_bytes(2, "big") + token
    prev = 0
    for seg in path.strip("/").split("/"):
        out += _coap_opt(prev, 11, seg.encode())
        prev = 11
    cf = b"" if content_format == 0 else content_format.to_bytes((content_format.bit_length() + 7) // 8, "big")
    out += _coap_opt(prev, 12, cf)
    return out + b"\xff" + payload


def wire_http_fresh(req, resp):
    """HTTP/1.1 over a new TCP connection per reading: handshake 3, request, response, close 4 (all with 40 B headers)."""
    return 3 * IP_TCP + (IP_TCP + len(req)) + (IP_TCP + len(resp)) + 4 * IP_TCP


def wire_mqtt_fresh(topic, payload, client_id, qos=1, keepalive=60):
    """MQTT over a new TCP connection per wake-up: handshake, CONNECT, CONNACK, PUBLISH, [PUBACK], DISCONNECT, close 4."""
    n = 3 * IP_TCP + (IP_TCP + mqtt_connect_bytes(client_id, keepalive)) + (IP_TCP + 4)
    n += IP_TCP + mqtt_publish_bytes(topic, payload, qos)
    if qos == 1:
        n += IP_TCP + 4
    elif qos == 2:
        n += 3 * (IP_TCP + 4)
    return n + (IP_TCP + 2) + 4 * IP_TCP


def wire_mqtt_persistent(topic, payload, qos=1):
    """MQTT on an already-open connection: just the PUBLISH (and acknowledgements)."""
    n = IP_TCP + mqtt_publish_bytes(topic, payload, qos)
    if qos == 1:
        n += IP_TCP + 4
    elif qos == 2:
        n += 3 * (IP_TCP + 4)
    return n


def wire_coap_con(path, payload):
    """CoAP confirmable POST over UDP with a piggybacked empty-ACK style reply (4 bytes)."""
    return IP_UDP + len(coap_post(path, payload)) + IP_UDP + 4


def fspl_db(d_m, f_hz):
    """Free-space path loss: 20 log10(d) + 20 log10(f) + 20 log10(4 pi / c)."""
    return 20 * math.log10(d_m) + 20 * math.log10(f_hz) + 20 * math.log10(4 * math.pi / 299792458.0)


def max_range_m(budget_db, f_hz):
    """Distance at which free-space loss equals the link budget (TX power minus receiver sensitivity)."""
    return 10 ** ((budget_db - 20 * math.log10(f_hz) - 20 * math.log10(4 * math.pi / 299792458.0)) / 20.0)


def qos_expected_packets(p, qos):
    """Expected packets on the wire (both directions) per message with unlimited retries and independent loss p per packet."""
    if qos == 0:
        return 1.0
    phase = 1.0 / (1 - p) ** 2 + 1.0 / (1 - p)
    return phase if qos == 1 else 2 * phase


def qos_simulate(p, qos, n=20000, seed=0, max_attempts=None):
    """Monte-Carlo of the QoS handshakes under loss p per packet. Returns dict(packets, delivered, duplicates)."""
    rng = random.Random(seed)
    cap = max_attempts or 10 ** 5
    pk = dl = dup = 0
    for _ in range(n):
        if qos == 0:
            pk += 1
            dl += rng.random() >= p
            continue
        arrivals = 0
        done = False
        for _ in range(cap):                               # phase 1: PUBLISH until the ack (PUBACK / PUBREC) is received
            pk += 1
            if rng.random() >= p:
                arrivals += 1
                pk += 1
                if rng.random() >= p:
                    done = True
                    break
        if qos == 1:
            dl += arrivals > 0
            dup += max(arrivals - 1, 0)
            continue
        if not done:
            dl += 0
            continue
        released = False
        for _ in range(cap):                               # phase 2: PUBREL until PUBCOMP is received
            pk += 1
            if rng.random() >= p:
                released = True
                pk += 1
                if rng.random() >= p:
                    break
        dl += released                                     # delivered to the application exactly once, on the first PUBREL
    return dict(packets=pk / n, delivered=dl / n, duplicates=dup / n)
