"""A small MQTT 3.1.1 broker on asyncio. Supports CONNECT, PUBLISH QoS 0/1/2 (inbound), SUBSCRIBE (granted QoS capped at
`grant_max_qos`, default 1), UNSUBSCRIBE, retained messages, last will, keep-alive (1.5 x), PING, DISCONNECT, wildcards.

Deliberate limits (see README): clean sessions only, no persistent sessions, no authentication, no resend of unacknowledged
QoS 1 messages to subscribers, QoS 2 only on the publisher side (subscribers get QoS 0 or 1), no $SYS topics.
"""
import asyncio
import itertools
import time

import mqtt_proto as P


class Session:
    def __init__(self, client_id, writer, keepalive, will):
        self.client_id, self.writer, self.keepalive, self.will = client_id, writer, keepalive, will
        self.subs = {}
        self.pending_qos2 = {}
        self.graceful = False
        self._pid = itertools.count(1)

    def next_pid(self):
        return next(self._pid) % 65535 + 1


class Broker:
    def __init__(self, host="127.0.0.1", port=0, grant_max_qos=1, auth=None, acl=None):
        """auth(client_id, username, password) -> bool and acl(client_id, action, topic_or_filter) -> bool (action 'pub' or 'sub') are optional
        hooks (Unit 7). A refused CONNECT gets CONNACK code 5; a refused PUBLISH is acknowledged but dropped; a refused SUBSCRIBE gets 0x80 in the SUBACK."""
        self.host, self.port, self.grant_max_qos = host, port, grant_max_qos
        self.auth, self.acl = auth, acl
        self.denied = []                 # (client_id, action, topic) log of refused operations
        self.sessions, self.retained = {}, {}
        self.server = None
        self.log = []                  # (direction, client_id, packet name) for tests and for counting packets
        self._anon = itertools.count(1)

    async def start(self):
        self.server = await asyncio.start_server(self._handle, self.host, self.port)
        self.port = self.server.sockets[0].getsockname()[1]
        return self

    async def stop(self):
        for s in list(self.sessions.values()):
            s.writer.close()
        self.server.close()
        await self.server.wait_closed()

    # -------------------------------------------------------------- connection handling
    async def _handle(self, reader, writer):
        sess = None
        try:
            ptype, flags, body = await asyncio.wait_for(P.read_packet(reader), 10)
            if ptype != P.CONNECT:
                return
            c = P.parse_connect(body)
            if c["proto"] != "MQTT" or c["level"] != 4:
                writer.write(P.connack_packet(False, 1))
                await writer.drain()
                return
            cid = c["client_id"]
            if not cid:
                if not c["clean"]:
                    writer.write(P.connack_packet(False, 2))
                    await writer.drain()
                    return
                cid = "auto-%d" % next(self._anon)
            if self.auth is not None and not self.auth(cid, c["username"], c["password"]):
                self.denied.append((cid, "connect", ""))
                writer.write(P.connack_packet(False, 5))
                await writer.drain()
                return
            old = self.sessions.get(cid)
            if old is not None:                          # same client id: the old connection is closed (its will is published)
                old.writer.close()
            sess = Session(cid, writer, c["keepalive"], c["will"])
            self.sessions[cid] = sess
            self.log.append(("in", cid, "CONNECT"))
            writer.write(P.connack_packet(False, 0))
            timeout = c["keepalive"] * 1.5 if c["keepalive"] else None
            while True:
                ptype, flags, body = await asyncio.wait_for(P.read_packet(reader), timeout)
                self.log.append(("in", cid, P.NAMES.get(ptype, str(ptype))))
                if not await self._dispatch(sess, ptype, flags, body):
                    break
        except (asyncio.IncompleteReadError, ConnectionError, ValueError, asyncio.TimeoutError, IndexError):
            pass
        finally:
            if sess is not None and self.sessions.get(sess.client_id) is sess:
                del self.sessions[sess.client_id]
                if not sess.graceful and sess.will:
                    wt, wm, wq, wr = sess.will
                    self._publish_internal(wt, wm, wq, wr)
            elif sess is not None and not sess.graceful and sess.will and self.sessions.get(sess.client_id) is not sess:
                wt, wm, wq, wr = sess.will           # taken over: still a connection closed without DISCONNECT
                self._publish_internal(wt, wm, wq, wr)
            try:
                writer.close()
            except Exception:
                pass

    def _send(self, sess, data, name):
        self.log.append(("out", sess.client_id, name))
        try:
            sess.writer.write(data)
        except Exception:
            pass

    async def _dispatch(self, sess, ptype, flags, body):
        if ptype == P.PUBLISH:
            m = P.parse_publish(flags, body)
            if not P.valid_topic_name(m["topic"]):
                return False
            if self.acl is not None and not self.acl(sess.client_id, "pub", m["topic"]):
                self.denied.append((sess.client_id, "pub", m["topic"]))
                if m["qos"] == 1:
                    self._send(sess, P.ack_packet(P.PUBACK, m["pid"]), "PUBACK")
                elif m["qos"] == 2:
                    sess.pending_qos2[m["pid"]] = None
                    self._send(sess, P.ack_packet(P.PUBREC, m["pid"]), "PUBREC")
                return True
            if m["qos"] == 0:
                self._publish_internal(m["topic"], m["payload"], 0, m["retain"])
            elif m["qos"] == 1:
                self._publish_internal(m["topic"], m["payload"], 1, m["retain"])
                self._send(sess, P.ack_packet(P.PUBACK, m["pid"]), "PUBACK")
            else:                                          # QoS 2: store, answer PUBREC, deliver once on PUBREL
                sess.pending_qos2.setdefault(m["pid"], (m["topic"], m["payload"], m["retain"]))
                self._send(sess, P.ack_packet(P.PUBREC, m["pid"]), "PUBREC")
        elif ptype == P.PUBREL:
            pid = P.parse_pid(body)
            item = sess.pending_qos2.pop(pid, None)
            if item is not None:                       # (None marks a QoS 2 message refused by the ACL: acknowledged, never delivered)
                self._publish_internal(item[0], item[1], 2, item[2])
            self._send(sess, P.ack_packet(P.PUBCOMP, pid), "PUBCOMP")
        elif ptype == P.SUBSCRIBE:
            pid, flts = P.parse_subscribe(body)
            codes = []
            for f, q in flts:
                if not P.valid_filter(f) or (self.acl is not None and not self.acl(sess.client_id, "sub", f)):
                    if P.valid_filter(f):
                        self.denied.append((sess.client_id, "sub", f))
                    codes.append(0x80)
                    continue
                g = min(q, self.grant_max_qos)
                sess.subs[f] = g
                codes.append(g)
            self._send(sess, P.suback_packet(pid, codes), "SUBACK")
            for f, q in flts:
                if f in sess.subs:
                    for t, (payload, rq) in list(self.retained.items()):
                        if P.topic_matches(f, t):
                            dq = min(rq, sess.subs[f])
                            self._send(sess, P.publish_packet(t, payload, dq, True, pid=sess.next_pid() if dq else None), "PUBLISH")
        elif ptype == P.UNSUBSCRIBE:
            pid, flts = P.parse_unsubscribe(body)
            for f in flts:
                sess.subs.pop(f, None)
            self._send(sess, P.unsuback_packet(pid), "UNSUBACK")
        elif ptype == P.PINGREQ:
            self._send(sess, P.pingresp_packet(), "PINGRESP")
        elif ptype in (P.PUBACK, P.PUBREC, P.PUBCOMP):
            pass                                            # acknowledgements of what we sent: nothing to resend in this broker
        elif ptype == P.DISCONNECT:
            sess.graceful = True
            return False
        else:
            return False
        return True

    # -------------------------------------------------------------- routing
    def _publish_internal(self, topic, payload, qos, retain):
        if retain:
            if payload:
                self.retained[topic] = (payload, qos)
            else:
                self.retained.pop(topic, None)
        for s in list(self.sessions.values()):
            best = -1
            for f, q in s.subs.items():
                if P.topic_matches(f, topic):
                    best = max(best, q)
            if best < 0:
                continue
            dq = min(qos, best)
            self._send(s, P.publish_packet(topic, payload, dq, False, pid=s.next_pid() if dq else None), "PUBLISH")
