# mqtt_mini

> A from-scratch MQTT 3.1.1 packet codec, asyncio broker and client (QoS 0/1/2, retained, last will, keep-alive, wildcards) plus message-size, link-budget and QoS-cost calculators, cross-checked against paho-mqtt and amqtt.

**Topic:** net  |  **Created in session:** 005 (Unit 5)  |  **Status:** tested (10 tests + 17 external conformance checks)

## What this code is for
A small, readable MQTT implementation used to teach the protocol byte by byte and to test node firmware logic without a real broker. Not a replacement for Mosquitto. `netcalc.py` also holds the arithmetic used in Unit 5 (wire bytes per reading, free-space path loss and link budget, expected packets and delivery of each QoS under loss).

## Capabilities
- `mqtt_proto`: `encode_remaining_length`, `decode_remaining_length`, packet builders (`connect_packet`, `connack_packet`, `publish_packet`, `ack_packet`, `subscribe_packet`, `suback_packet`, `unsubscribe_packet`, ...), parsers (`parse_connect`, `parse_publish`, `parse_subscribe`, ...), `read_packet(reader)`, `topic_matches(filter, topic)`, `valid_filter`, `valid_topic_name`.
- `Broker(host, port, grant_max_qos=1, auth=None, acl=None)`: `await start()`, `.port`, `.retained`, `.log`, `.denied`, `await stop()`. Unit 7 hooks: `auth(client_id, username, password)` (refused CONNECT: CONNACK 5), `acl(client_id, 'pub'|'sub', topic_or_filter)` (refused PUBLISH acknowledged and dropped; refused SUBSCRIBE: 0x80).
- `MiniClient(client_id, keepalive, will, clean, username, password)`: `connect`, `publish(topic, payload, qos, retain)`, `subscribe`, `unsubscribe`, `get`, `disconnect`, `abort` (close without DISCONNECT, to fire the will).
- `netcalc`: `mqtt_publish_bytes`, `mqtt_connect_bytes`, `http_post_request`, `coap_post` (UNVERIFIED layout), `wire_*` byte models, `fspl_db`, `max_range_m`, `qos_expected_packets`, `qos_simulate`.

## Theory in one paragraph
Fixed header + remaining length (base-128 varint, 1 to 4 bytes); PUBLISH = topic + (packet id if QoS>0) + payload; topic matching with + and # ($ rule); QoS 1 expected packets 1/(1-p)^2 + 1/(1-p), duplicates p/(1-p); QoS 2 doubles it; bounded 3 attempts: P0 = 1-p, P1 = 1-p^3, P2 = (1-(1-(1-p)^2)^3)(1-p^3); FSPL = 20log10 d + 20log10 f - 147.55 dB. Derived in Unit 5, Section 3.

## Quick start
```bash
python -m pytest -q tests
# external conformance (needs a throwaway venv with paho-mqtt and amqtt):
python -m venv /tmp/mqttvenv && /tmp/mqttvenv/bin/pip install paho-mqtt amqtt && /tmp/mqttvenv/bin/python conformance.py
```

## Examples
| File | Shows | Output |
|------|-------|--------|
| `example_basic.py` | scaffold placeholder; real examples: `sessions/005-unit5-networking/figures/` and `conformance.py` | `example_basic.png` |

## Inputs / outputs and units
Bytes, packets (counts), probabilities, hertz, metres, decibels. Client `publish` payloads are bytes or str; received messages are dicts (topic, payload, qos, retain, dup, pid).

## Validation
Spec Table 2.4 boundary values; round trips; topic table incl. `$` and parent-level `#`; end-to-end tests; paho-mqtt 2.1.0 against our broker (10 checks) and our client against amqtt 0.12.1 (7 checks), 17/17 passed (`sessions/005-unit5-networking/conformance_log.txt`). amqtt deviates from spec section 3.8.4 (delivers at the subscription QoS) and leaks a retained message to a non-matching later subscriber (confirmed with paho).

## Known limits and gotchas
- Clean sessions only; no persistent sessions, authentication, TLS, `$SYS`, or resend of unacknowledged QoS 1 to subscribers.
- Subscriptions are granted at most QoS 1; QoS 2 only inbound to the broker.
- One delivery per overlapping subscription (at the highest QoS); topic and payload sizes are not limited.
- `coap_post` is written from memory of RFC 7252 and used only to estimate sizes.
- The wire-size model omits TLS, TCP options, link framing and DNS.

## Dependencies
Standard library only (asyncio, struct, random, math). Conformance script: paho-mqtt, amqtt.

## Extending toward the open-source package
`iotrobotics/net/`. To do: persistent sessions, QoS 2 outbound, TLS, an MQTT-SN gateway.
