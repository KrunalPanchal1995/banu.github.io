"""MQTT 3.1.1 packet encoding and decoding, topic matching. Pure Python, no dependencies. See README.md.

Packet layout (MQTT 3.1.1): a fixed header (one byte: packet type in the high 4 bits, flags in the low 4 bits; then the
'remaining length' as a variable-length integer of 1 to 4 bytes), then a variable header and payload.
"""
import asyncio
import struct

CONNECT, CONNACK, PUBLISH, PUBACK, PUBREC, PUBREL, PUBCOMP, SUBSCRIBE, SUBACK, UNSUBSCRIBE, UNSUBACK, PINGREQ, PINGRESP, DISCONNECT = range(1, 15)
NAMES = {1: "CONNECT", 2: "CONNACK", 3: "PUBLISH", 4: "PUBACK", 5: "PUBREC", 6: "PUBREL", 7: "PUBCOMP", 8: "SUBSCRIBE",
         9: "SUBACK", 10: "UNSUBSCRIBE", 11: "UNSUBACK", 12: "PINGREQ", 13: "PINGRESP", 14: "DISCONNECT"}
MAX_REMAINING = 268435455


def encode_remaining_length(n):
    if n < 0 or n > MAX_REMAINING:
        raise ValueError("remaining length out of range")
    out = bytearray()
    while True:
        digit, n = n % 128, n // 128
        if n:
            digit |= 0x80
        out.append(digit)
        if not n:
            return bytes(out)


def decode_remaining_length(buf, pos=0):
    """Return (value, next_position). Raises ValueError if malformed (more than 4 bytes) or IndexError if truncated."""
    mult, value = 1, 0
    for i in range(4):
        d = buf[pos + i]
        value += (d & 0x7F) * mult
        if not d & 0x80:
            return value, pos + i + 1
        mult *= 128
    raise ValueError("malformed remaining length")


def enc_bytes(b):
    return struct.pack("!H", len(b)) + b


def enc_str(s):
    return enc_bytes(s.encode("utf-8"))


def dec_bytes(buf, pos):
    n = struct.unpack_from("!H", buf, pos)[0]
    return bytes(buf[pos + 2: pos + 2 + n]), pos + 2 + n


def dec_str(buf, pos):
    b, p = dec_bytes(buf, pos)
    return b.decode("utf-8"), p


def packet(ptype, flags, body=b""):
    return bytes([(ptype << 4) | flags]) + encode_remaining_length(len(body)) + body


# ------------------------------------------------------------------ builders
def connect_packet(client_id, keepalive=60, clean=True, will=None, username=None, password=None):
    """will = (topic, payload_bytes, qos, retain) or None."""
    flags = 0x02 if clean else 0
    payload = enc_str(client_id)
    if will:
        wt, wm, wq, wr = will
        flags |= 0x04 | (wq << 3) | (0x20 if wr else 0)
        payload += enc_str(wt) + enc_bytes(wm)
    if username is not None:
        flags |= 0x80
        payload += enc_str(username)
    if password is not None:
        flags |= 0x40
        payload += enc_bytes(password if isinstance(password, bytes) else password.encode())
    var = enc_str("MQTT") + bytes([4, flags]) + struct.pack("!H", keepalive)
    return packet(CONNECT, 0, var + payload)


def connack_packet(session_present, rc):
    return packet(CONNACK, 0, bytes([1 if session_present else 0, rc]))


def publish_packet(topic, payload, qos=0, retain=False, dup=False, pid=None):
    flags = (8 if dup else 0) | (qos << 1) | (1 if retain else 0)
    body = enc_str(topic)
    if qos > 0:
        body += struct.pack("!H", pid)
    return packet(PUBLISH, flags, body + bytes(payload))


def ack_packet(ptype, pid):
    return packet(ptype, 0b0010 if ptype == PUBREL else 0, struct.pack("!H", pid))


def subscribe_packet(pid, filters):
    body = struct.pack("!H", pid) + b"".join(enc_str(f) + bytes([q]) for f, q in filters)
    return packet(SUBSCRIBE, 0b0010, body)


def suback_packet(pid, codes):
    return packet(SUBACK, 0, struct.pack("!H", pid) + bytes(codes))


def unsubscribe_packet(pid, filters):
    return packet(UNSUBSCRIBE, 0b0010, struct.pack("!H", pid) + b"".join(enc_str(f) for f in filters))


def unsuback_packet(pid):
    return packet(UNSUBACK, 0, struct.pack("!H", pid))


def pingreq_packet():
    return packet(PINGREQ, 0)


def pingresp_packet():
    return packet(PINGRESP, 0)


def disconnect_packet():
    return packet(DISCONNECT, 0)


# ------------------------------------------------------------------ parsers (body = bytes after the fixed header)
def parse_connect(body):
    proto, p = dec_str(body, 0)
    level, flags = body[p], body[p + 1]
    keepalive = struct.unpack_from("!H", body, p + 2)[0]
    p += 4
    cid, p = dec_str(body, p)
    out = dict(proto=proto, level=level, clean=bool(flags & 0x02), keepalive=keepalive, client_id=cid, will=None, username=None, password=None)
    if flags & 0x04:
        wt, p = dec_str(body, p)
        wm, p = dec_bytes(body, p)
        out["will"] = (wt, wm, (flags >> 3) & 3, bool(flags & 0x20))
    if flags & 0x80:
        out["username"], p = dec_str(body, p)
    if flags & 0x40:
        out["password"], p = dec_bytes(body, p)
    return out


def parse_publish(flags, body):
    qos = (flags >> 1) & 3
    topic, p = dec_str(body, 0)
    pid = None
    if qos > 0:
        pid = struct.unpack_from("!H", body, p)[0]
        p += 2
    return dict(topic=topic, payload=bytes(body[p:]), qos=qos, retain=bool(flags & 1), dup=bool(flags & 8), pid=pid)


def parse_pid(body):
    return struct.unpack_from("!H", body, 0)[0]


def parse_subscribe(body):
    pid = parse_pid(body)
    p, out = 2, []
    while p < len(body):
        f, p = dec_str(body, p)
        out.append((f, body[p] & 3))
        p += 1
    return pid, out


def parse_unsubscribe(body):
    pid = parse_pid(body)
    p, out = 2, []
    while p < len(body):
        f, p = dec_str(body, p)
        out.append(f)
    return pid, out


async def read_packet(reader):
    """Read one packet from an asyncio StreamReader: returns (ptype, flags, body). Raises IncompleteReadError at EOF."""
    b1 = (await reader.readexactly(1))[0]
    mult, n = 1, 0
    for _ in range(4):
        d = (await reader.readexactly(1))[0]
        n += (d & 0x7F) * mult
        if not d & 0x80:
            break
        mult *= 128
    else:
        raise ValueError("malformed remaining length")
    body = await reader.readexactly(n) if n else b""
    return b1 >> 4, b1 & 0x0F, body


# ------------------------------------------------------------------ topics
def valid_topic_name(t):
    return bool(t) and "+" not in t and "#" not in t and "\x00" not in t


def valid_filter(f):
    if not f or "\x00" in f:
        return False
    parts = f.split("/")
    for i, lv in enumerate(parts):
        if "#" in lv and (lv != "#" or i != len(parts) - 1):
            return False
        if "+" in lv and lv != "+":
            return False
    return True


def topic_matches(flt, topic):
    """MQTT 3.1.1 matching: '+' is exactly one level (may be empty), '#' is any number of levels including the parent;
    a topic starting with '$' is not matched by a filter whose first level is a wildcard."""
    if topic.startswith("$") and (flt.startswith("+") or flt.startswith("#")):
        return False
    f, t = flt.split("/"), topic.split("/")
    for i, lv in enumerate(f):
        if lv == "#":
            return True
        if i >= len(t):
            return False
        if lv != "+" and lv != t[i]:
            return False
    return len(f) == len(t)
