"""A small asyncio MQTT 3.1.1 client: connect (with will), publish QoS 0/1/2, subscribe, unsubscribe, keep-alive pings,
receive queue. See README.md."""
import asyncio
import itertools

import mqtt_proto as P


class MiniClient:
    def __init__(self, client_id="", keepalive=60, will=None, clean=True, username=None, password=None):
        self.client_id, self.keepalive, self.will, self.clean = client_id, keepalive, will, clean
        self.username, self.password = username, password
        self.messages = asyncio.Queue()
        self.reader = self.writer = None
        self._pid = itertools.count(1)
        self._wait = {}                  # (kind, pid) -> future
        self._in_qos2 = {}
        self._tasks = []
        self.session_present = False

    def _next_pid(self):
        return next(self._pid) % 65535 + 1

    async def connect(self, host, port, timeout=5.0):
        self.reader, self.writer = await asyncio.open_connection(host, port)
        self.writer.write(P.connect_packet(self.client_id, self.keepalive, self.clean, self.will, self.username, self.password))
        await self.writer.drain()
        ptype, flags, body = await asyncio.wait_for(P.read_packet(self.reader), timeout)
        if ptype != P.CONNACK or body[1] != 0:
            raise ConnectionError("CONNACK refused: %r" % (body,))
        self.session_present = bool(body[0] & 1)
        self._tasks.append(asyncio.ensure_future(self._reader_loop()))
        if self.keepalive:
            self._tasks.append(asyncio.ensure_future(self._ping_loop()))

    async def _ping_loop(self):
        while True:
            await asyncio.sleep(self.keepalive / 2.0)
            self.writer.write(P.pingreq_packet())

    def _future(self, kind, pid):
        f = asyncio.get_event_loop().create_future()
        self._wait[(kind, pid)] = f
        return f

    def _resolve(self, kind, pid, value=None):
        f = self._wait.pop((kind, pid), None)
        if f is not None and not f.done():
            f.set_result(value)

    async def _reader_loop(self):
        try:
            while True:
                ptype, flags, body = await P.read_packet(self.reader)
                if ptype == P.PUBLISH:
                    m = P.parse_publish(flags, body)
                    if m["qos"] == 0:
                        self.messages.put_nowait(m)
                    elif m["qos"] == 1:
                        self.writer.write(P.ack_packet(P.PUBACK, m["pid"]))
                        self.messages.put_nowait(m)
                    else:
                        self._in_qos2[m["pid"]] = m
                        self.writer.write(P.ack_packet(P.PUBREC, m["pid"]))
                elif ptype == P.PUBREL:
                    pid = P.parse_pid(body)
                    m = self._in_qos2.pop(pid, None)
                    if m is not None:
                        self.messages.put_nowait(m)
                    self.writer.write(P.ack_packet(P.PUBCOMP, pid))
                elif ptype == P.PUBACK:
                    self._resolve("puback", P.parse_pid(body))
                elif ptype == P.PUBREC:
                    pid = P.parse_pid(body)
                    self.writer.write(P.ack_packet(P.PUBREL, pid))
                    self._resolve("pubrec", pid)
                elif ptype == P.PUBCOMP:
                    self._resolve("pubcomp", P.parse_pid(body))
                elif ptype == P.SUBACK:
                    self._resolve("suback", P.parse_pid(body[:2]), list(body[2:]))
                elif ptype == P.UNSUBACK:
                    self._resolve("unsuback", P.parse_pid(body))
        except (asyncio.IncompleteReadError, ConnectionError, ValueError):
            pass
        finally:
            for f in self._wait.values():
                if not f.done():
                    f.set_exception(ConnectionError("connection closed"))

    async def publish(self, topic, payload, qos=0, retain=False, timeout=5.0):
        payload = payload.encode() if isinstance(payload, str) else bytes(payload)
        if qos == 0:
            self.writer.write(P.publish_packet(topic, payload, 0, retain))
            await self.writer.drain()
            return
        pid = self._next_pid()
        if qos == 1:
            f = self._future("puback", pid)
            self.writer.write(P.publish_packet(topic, payload, 1, retain, pid=pid))
            await asyncio.wait_for(f, timeout)
        else:
            f1, f2 = self._future("pubrec", pid), self._future("pubcomp", pid)
            self.writer.write(P.publish_packet(topic, payload, 2, retain, pid=pid))
            await asyncio.wait_for(f1, timeout)
            await asyncio.wait_for(f2, timeout)

    async def subscribe(self, filters, timeout=5.0):
        if isinstance(filters, str):
            filters = [(filters, 0)]
        pid = self._next_pid()
        f = self._future("suback", pid)
        self.writer.write(P.subscribe_packet(pid, filters))
        return await asyncio.wait_for(f, timeout)

    async def unsubscribe(self, filters, timeout=5.0):
        if isinstance(filters, str):
            filters = [filters]
        pid = self._next_pid()
        f = self._future("unsuback", pid)
        self.writer.write(P.unsubscribe_packet(pid, filters))
        await asyncio.wait_for(f, timeout)

    async def get(self, timeout=2.0):
        return await asyncio.wait_for(self.messages.get(), timeout)

    async def disconnect(self):
        try:
            self.writer.write(P.disconnect_packet())
            await self.writer.drain()
        except Exception:
            pass
        self.abort()

    def abort(self):
        """Close the socket WITHOUT sending DISCONNECT (so the broker publishes the will)."""
        for t in self._tasks:
            t.cancel()
        try:
            self.writer.close()
        except Exception:
            pass
