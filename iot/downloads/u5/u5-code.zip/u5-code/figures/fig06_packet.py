"""Fig 6: the bytes of one MQTT PUBLISH (QoS 1) for topic greenhouse/zone1/soil and payload 1832, drawn byte by byte."""
from _common import *
use_code("net/mqtt_mini")
import mqtt_proto as P

pk = P.publish_packet("greenhouse/zone1/soil", b"1832", 1, pid=1)
fields = [(0, 1, "type 3 + flags\n(QoS 1)", PAL["red"]), (1, 2, "remaining\nlength 29", PAL["orange"]), (2, 4, "topic\nlength 21", PAL["sky"]), (4, 25, "topic: greenhouse/zone1/soil (21 bytes)", PAL["blue"]), (25, 27, "packet id 1", PAL["purple"]), (27, 31, "payload\n1832", PAL["green"])]
print(len(pk), pk.hex(), [(a, b, n.replace(chr(10), " ")) for a, b, n, _ in fields])
fig, ax = plt.subplots(figsize=(7.9, 3.0)); ax.axis("off"); ax.grid(False); ax.set_xlim(0, 31); ax.set_ylim(-3.6, 2.8)
for a_, b_, name, col in fields:
    for i in range(a_, b_):
        ax.add_patch(plt.Rectangle((i, 0), 1, 1.2, fc=col, ec="white", alpha=0.45)); ax.text(i + 0.5, 0.6, f"{pk[i]:02x}", ha="center", va="center", fontsize=6.3)
    ax.plot([a_ + 0.1, b_ - 0.1], [-0.2, -0.2], color=col, lw=2)
    ax.text((a_ + b_) / 2, -0.55 if (b_ - a_) > 3 else -0.6 - 0.9 * (fields.index((a_, b_, name, col)) % 2), name, ha="center", va="top", fontsize=7)
ax.text(0, 2.0, "31 bytes in total: 25 bytes of protocol around a 4-byte payload", fontsize=8.5)
save(fig, out("fig06_packet.png"))
