"""Fig 2: bytes for one 4-byte reading. Left: application message sizes. Right: total wire bytes per reading under the simplified model (40 B IP+TCP per packet, 28 B IP+UDP; no TLS)."""
from _common import *
from viz_style import CYCLE
use_code("net/mqtt_mini")
import netcalc as N

T, PAY, CID = "greenhouse/zone1/soil", b"1832", "node1"
req = N.http_post_request("/api/v1/greenhouse/zone1/soil", "iot.example.org", PAY); resp = N.http_response_minimal()
app = [("HTTP\nPOST", len(req)), ("MQTT\nQoS 0", N.mqtt_publish_bytes(T, PAY, 0)), ("MQTT\nQoS 1", N.mqtt_publish_bytes(T, PAY, 1)), ("CoAP\nPOST", len(N.coap_post(T, PAY)))]
wire = [("HTTP,\nnew TCP", N.wire_http_fresh(req, resp)), ("MQTT QoS 1,\nnew TCP", N.wire_mqtt_fresh(T, PAY, CID, 1)), ("MQTT QoS 1,\nkept open", N.wire_mqtt_persistent(T, PAY, 1)), ("CoAP,\nUDP", N.wire_coap_con(T[:], PAY))]
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.bar(range(4), [v for _, v in app], color=[PAL["red"], PAL["blue"], PAL["blue"], PAL["green"]]); a.axhline(4, color=PAL["black"], ls=":", lw=0.8); a.text(3.4, 8, "payload: 4 bytes", fontsize=7.5, ha="right")
for i, (_, v) in enumerate(app): a.text(i, v + 2, str(v), ha="center", fontsize=8.5)
a.set(xticks=range(4), xticklabels=[n for n, _ in app], ylabel="application message (bytes)", title="One message"); a.tick_params(axis="x", labelsize=7.5)
b.bar(range(4), [v for _, v in wire], color=[PAL["red"], PAL["blue"], PAL["blue"], PAL["green"]])
for i, (_, v) in enumerate(wire): b.text(i, v + 8, str(v), ha="center", fontsize=8.5)
b.set(xticks=range(4), xticklabels=[n for n, _ in wire], ylabel="bytes on the wire per reading", title="Whole exchange"); b.tick_params(axis="x", labelsize=7)
save(fig, out("fig02_bytes.png"))
print(app, wire)
