"""Fig 1: the protocol stack as seen from an IoT node, with where each protocol lives (diagram)."""
from _common import *
from matplotlib.patches import FancyBboxPatch

fig, ax = plt.subplots(figsize=(7.8, 4.3)); ax.set_xlim(0, 13); ax.set_ylim(0, 7); ax.axis("off"); ax.grid(False)
rows = [("Application", "MQTT, HTTP, CoAP (and your payload: JSON, bytes)", PAL["green"], 5.6),
        ("Transport", "TCP (reliable stream, handshake)    UDP (single datagrams)", PAL["orange"], 4.3),
        ("Network", "IP: addresses and routing (IPv4 header 20 bytes)", PAL["blue"], 3.0),
        ("Link / radio", "Wi-Fi, BLE, Zigbee, LoRa, NB-IoT, Ethernet", PAL["purple"], 1.7)]
for name, what, col, y in rows:
    ax.add_patch(FancyBboxPatch((0.3, y), 8.3, 1.0, boxstyle="round,pad=0.03,rounding_size=0.12", fc=col, ec="none", alpha=0.22))
    ax.text(0.55, y + 0.65, name, fontsize=11, fontweight="bold", color=col, va="center"); ax.text(0.55, y + 0.28, what, fontsize=8.3, va="center")
notes = [("MQTT: over TCP\nCoAP: over UDP\nHTTP: over TCP", 5.6), ("TCP: +20 B header per packet,\n3-packet handshake, 4 to close\nUDP: +8 B header", 4.3), ("IP: +20 B per packet", 3.0), ("range, rate and power\nare set here (Section 3.3)", 1.7)]
for t, y in notes: ax.text(8.9, y + 0.5, t, fontsize=7.8, va="center", color=PAL["grey"])
ax.text(0.3, 0.7, "A message travels DOWN the stack at the sender (each layer adds a header) and UP at the receiver.", fontsize=8.3)
ax.annotate("", xy=(12.6, 1.7), xytext=(12.6, 6.6), arrowprops=dict(arrowstyle="<->", color=PAL["grey"])); ax.text(12.4, 4.2, "headers added going down", rotation=90, fontsize=7.5, color=PAL["grey"], ha="right", va="center")
save(fig, out("fig01_stack.png"))
