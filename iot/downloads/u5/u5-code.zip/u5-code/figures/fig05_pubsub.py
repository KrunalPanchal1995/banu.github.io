"""Fig 5: publish/subscribe on the greenhouse (diagram): nodes publish to topics, the broker routes by topic filter, keeps retained values and publishes the last will."""
from _common import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(7.9, 4.5)); ax.set_xlim(0, 13); ax.set_ylim(0, 7.4); ax.axis("off"); ax.grid(False)
def box(x, y, w, h, t, col, fs=8.5):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.03,rounding_size=0.12", fc=col, ec="none", alpha=0.25)); ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs)
def arr(p, q, lab, ox=0, oy=0.0, col=PAL["black"], ls="-"):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=11, color=col, lw=1.1, ls=ls)); ax.text((p[0] + q[0]) / 2 + ox, (p[1] + q[1]) / 2 + oy, lab, fontsize=7, ha="center", va="center", bbox=dict(fc="white", ec="none", pad=0.4, alpha=0.9))
box(0.2, 5.2, 3.0, 1.2, "soil node 1\nPUBLISH greenhouse/zone1/soil", PAL["blue"], 7.8); box(0.2, 3.2, 3.0, 1.2, "soil node 2\nPUBLISH greenhouse/zone2/soil", PAL["blue"], 7.8); box(0.2, 1.2, 3.0, 1.2, "rover\nPUBLISH greenhouse/rover/pose", PAL["green"], 7.8)
box(5.0, 2.4, 3.0, 2.6, "BROKER\nroutes by topic filter\nretained store:\ngreenhouse/zone1/node1/status = online\nlast will on silent loss", PAL["orange"], 7.6)
box(9.8, 5.2, 3.0, 1.2, "dashboard\nSUBSCRIBE greenhouse/+/soil", PAL["purple"], 7.8); box(9.8, 3.2, 3.0, 1.2, "alert service\nSUBSCRIBE greenhouse/#", PAL["purple"], 7.8); box(9.8, 1.2, 3.0, 1.2, "rover\nSUBSCRIBE greenhouse/rover/cmd", PAL["green"], 7.8)
arr((3.2, 5.8), (5.0, 4.6), "QoS 0"); arr((3.2, 3.8), (5.0, 3.8), "QoS 1"); arr((3.2, 1.8), (5.0, 3.0), "QoS 0")
arr((8.0, 4.6), (9.8, 5.8), "+ : one level"); arr((8.0, 3.8), (9.8, 3.8), "# : all below"); arr((9.8, 1.8), (8.0, 3.0), "commands, QoS 1", ox=0.1, oy=-0.35)
ax.text(6.5, 6.9, "Publishers and subscribers never meet: they share only topic names.", fontsize=8.5, ha="center")
save(fig, out("fig05_pubsub.png"))
