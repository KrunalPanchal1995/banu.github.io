"""Fig 3: wireless options. Left: free-space path loss against distance with each technology's allowed loss (TX power minus sensitivity). Right: simplified airtime energy for 100 bytes.
ALL TX POWERS, SENSITIVITIES, RATES AND CURRENTS ARE ASSUMED TYPICAL VALUES; free-space distances are ceilings, real ranges are much shorter."""
from _common import *
use_code("net/mqtt_mini")
import netcalc as N

techs = [("Wi-Fi 2.4 GHz", 2.4e9, 20, -90, 6e6, 200, PAL["blue"]), ("BLE", 2.4e9, 0, -95, 1e6, 10, PAL["green"]), ("Zigbee", 2.4e9, 0, -100, 250e3, 25, PAL["orange"]), ("LoRa SF7", 868e6, 14, -123, 5470, 40, PAL["purple"]), ("LoRa SF12", 868e6, 14, -137, 293, 40, PAL["red"])]
d = np.logspace(0, 4, 200)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
for f, col, lab in ((2.4e9, PAL["grey"], "FSPL 2.4 GHz"), (868e6, PAL["black"], "FSPL 868 MHz")):
    a.semilogx(d, [N.fspl_db(x, f) for x in d], color=col, lw=1.4, label=lab)
for n, f, tx, sens, rate, itx, col in techs:
    a.axhline(tx - sens, color=col, lw=0.9, ls="--"); a.text(1.1, tx - sens + 1.2, f"{n}: {tx-sens} dB", fontsize=7, color=col)
a.set(xlabel="distance (m, log scale)", ylabel="path loss / allowed loss (dB)", title="Link budget (free space)", ylim=(30, 160)); a.legend(fontsize=7.5, loc="lower right")
e = [itx * 3.3 * (800 / rate) for _, _, _, _, rate, itx, _ in techs]
b.bar(range(5), e, color=[t[-1] for t in techs]); b.set_yscale("log")
for i, v in enumerate(e): b.text(i, v * 1.15, f"{v:.2g}", ha="center", fontsize=8)
b.set(xticks=range(5), xticklabels=[t[0].replace(" 2.4 GHz", "").replace("LoRa ", "LoRa\n") for t in techs], ylabel="energy to send 100 bytes (mJ, log)", title="Slow links cost energy (simplified)"); b.tick_params(axis="x", labelsize=7.5)
save(fig, out("fig03_wireless.png"))
