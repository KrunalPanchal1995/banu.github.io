"""Unit 5 numbers quoted in the text: message sizes, wire bytes, round trips, link budget, airtime and energy, QoS costs. ASSUMED values are marked."""
from _common import *
use_code("net/mqtt_mini")
import mqtt_proto as P, netcalc as N, math

TOPIC, PAY, CID = "greenhouse/zone1/soil", b"1832", "node1"
print("-- application message sizes (bytes)")
pub0, pub1, pub2 = (N.mqtt_publish_bytes(TOPIC, PAY, q) for q in (0, 1, 2)); print("MQTT PUBLISH qos0/1/2:", pub0, pub1, pub2, "; CONNECT:", N.mqtt_connect_bytes(CID), "; CONNACK 4, PUBACK 4, DISCONNECT 2, PINGREQ 2")
req = N.http_post_request("/api/v1/greenhouse/zone1/soil", "iot.example.org", PAY); resp = N.http_response_minimal(); print("HTTP request:", len(req), "response:", len(resp), "(minimal headers)")
co = N.coap_post("greenhouse/zone1/soil", PAY); print("CoAP POST:", len(co), "bytes; hex", co.hex())
print("overhead bytes beyond the 4-byte payload: HTTP", len(req) - 4, " MQTT qos0", pub0 - 4, " CoAP", len(co) - 4)
print("-- wire bytes per reading (40 B IP+TCP per packet, 28 B IP+UDP; no TLS)")
w = dict(http_fresh=N.wire_http_fresh(req, resp), mqtt_fresh_q0=N.wire_mqtt_fresh(TOPIC, PAY, CID, 0), mqtt_fresh_q1=N.wire_mqtt_fresh(TOPIC, PAY, CID, 1), mqtt_fresh_q2=N.wire_mqtt_fresh(TOPIC, PAY, CID, 2), mqtt_persistent_q1=N.wire_mqtt_persistent(TOPIC, PAY, 1), mqtt_persistent_q0=N.wire_mqtt_persistent(TOPIC, PAY, 0), coap=N.wire_coap_con("greenhouse/zone1/soil", PAY))
for k, v in w.items(): print(f"{k:22s} {v:5d} B   per day at 1/min: {v*1440/1e3:8.1f} kB   payload share {4/v*100:.2f} percent")
print("MQTT persistent keep-alive: PINGREQ+PINGRESP", 2 * (40 + 2), "B per 60 s =", 2 * 42 * 1440 / 1e3, "kB/day")
print("-- round trips (RTT 40 ms ASSUMED): http fresh 2 (TCP 1 + request 1), mqtt fresh qos1 3 (TCP 1 + CONNECT 1 + PUBLISH 1), coap 1; times ms:", 2 * 40, 3 * 40, 40)
print("-- link budget (free space). ASSUMED TX power dBm / sensitivity dBm / rate / TX current mA")
techs = [("Wi-Fi 2.4 GHz", 2.4e9, 20, -90, 6e6, 200), ("BLE 1 Mb/s", 2.4e9, 0, -95, 1e6, 10), ("Zigbee 250 kb/s", 2.4e9, 0, -100, 250e3, 25), ("LoRa SF7 868 MHz", 868e6, 14, -123, 5470, 40), ("LoRa SF12 868 MHz", 868e6, 14, -137, 293, 40)]
for n, f, tx, sens, rate, itx in techs:
    bud = tx - sens; r = N.max_range_m(bud, f); t = 100 * 8 / rate; e = itx * 3.3 * t  # mW * s = mJ
    print(f"{n:20s} budget {bud:4d} dB  free-space range {r/1e3:9.2f} km  FSPL at 50 m {N.fspl_db(50, f):6.1f} dB  100 B simplified airtime {t*1e3:9.2f} ms  energy {e:9.2f} mJ")
print("FSPL 2.4 GHz at 50 m:", round(N.fspl_db(50, 2.4e9), 1), " 868 MHz at 5 km:", round(N.fspl_db(5000, 868e6), 1))
print("-- QoS cost vs loss (unlimited retries, expected packets per message; QoS1 duplicates p/(1-p))")
for p in (0.0, 0.1, 0.3, 0.5):
    e0, e1, e2 = (N.qos_expected_packets(p, q) for q in (0, 1, 2)); s1 = N.qos_simulate(p, 1, 40000, 1); s2 = N.qos_simulate(p, 2, 40000, 2)
    print(f"p={p}: expected {e0:.2f} {e1:.2f} {e2:.2f} | simulated qos1 {s1['packets']:.2f} qos2 {s2['packets']:.2f} | qos1 duplicates {s1['duplicates']:.3f} (theory {p/(1-p) if p<1 else 0:.3f}) qos2 duplicates {s2['duplicates']:.3f}")
print("-- delivery with at most 3 attempts per phase")
for p in (0.1, 0.3, 0.5):
    d0 = N.qos_simulate(p, 0, 40000, 3)["delivered"]; d1 = N.qos_simulate(p, 1, 40000, 3, 3)["delivered"]; d2 = N.qos_simulate(p, 2, 40000, 3, 3)["delivered"]
    print(f"p={p}: delivered qos0 {d0:.3f} qos1 {d1:.3f} qos2 {d2:.3f}; packets qos1 {N.qos_simulate(p,1,40000,3,3)['packets']:.2f} qos2 {N.qos_simulate(p,2,40000,3,3)['packets']:.2f}")
