"""Fig 4: the cost and benefit of MQTT QoS levels under packet loss p (independent loss per packet)."""
from _common import *
use_code("net/mqtt_mini")
import netcalc as N

ps = np.linspace(0, 0.6, 61)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
for q, col in ((0, PAL["green"]), (1, PAL["blue"]), (2, PAL["red"])):
    a.plot(ps, [N.qos_expected_packets(p, q) for p in ps], color=col, label=f"QoS {q} (formula)")
    pts = [0.1, 0.3, 0.5]; a.plot(pts, [N.qos_simulate(p, q, 20000, 1)["packets"] for p in pts], "o", color=col, ms=5)
a.set(xlabel="loss probability per packet p", ylabel="packets on the wire per message", title="Reliability costs packets (retry forever)"); a.legend(fontsize=8)
pp = np.array([0.0, 0.1, 0.2, 0.3, 0.4, 0.5])
for q, col, mk in ((0, PAL["green"], "o"), (1, PAL["blue"], "s"), (2, PAL["red"], "^")):
    b.plot(pp, [N.qos_simulate(p, q, 30000, 3, 3)["delivered"] * 100 for p in pp], mk + "-", color=col, label=f"QoS {q}, at most 3 attempts")
b.set(xlabel="loss probability per packet p", ylabel="messages delivered (percent)", title="Bounded retries"); b.legend(fontsize=8, loc="lower left")
for p in (0.3,): print("delivered at p=0.3:", [round(N.qos_simulate(p, q, 30000, 3, 3)["delivered"], 3) for q in (0, 1, 2)])
save(fig, out("fig04_qos.png"))
