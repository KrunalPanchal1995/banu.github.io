import math
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import kinematics_np as K  # noqa: E402


def test_se2_properties():
    T = K.se2(2.0, 1.0, math.radians(30))
    assert np.allclose(T @ K.se2_inv(T), np.eye(3)) and np.allclose(K.rot2(0.7).T @ K.rot2(0.7), np.eye(2)) and abs(np.linalg.det(K.rot2(1.1)) - 1) < 1e-12
    p = K.transform_point(K.se2(2, 1, math.pi / 2), (1, 0))
    assert np.allclose(p, (2, 2))
    chain = K.se2(2, 1, 0.3) @ K.se2(0.1, 0, 0)
    assert np.allclose(chain[:2, 2], K.se2(2, 1, 0.3)[:2, :2] @ np.array([0.1, 0]) + np.array([2, 1]))


def test_ik_fk_round_trip_both_elbows_and_unreachable():
    rng = np.random.default_rng(0)
    l1, l2 = 0.3, 0.2
    for _ in range(500):
        r, a = rng.uniform(abs(l1 - l2), l1 + l2), rng.uniform(-math.pi, math.pi)
        x, y = r * math.cos(a), r * math.sin(a)
        for e in ("up", "down"):
            q = K.ik_2link(x, y, l1, l2, e)
            assert np.allclose(K.fk_2link(q, l1, l2), (x, y), atol=1e-12)
        qu, qd = K.ik_2link(x, y, l1, l2, "up"), K.ik_2link(x, y, l1, l2, "down")
        assert qu[1] >= 0 >= qd[1]
    assert K.ik_2link(0.6, 0, l1, l2) is None and K.ik_2link(0.05, 0, l1, l2) is None and K.reachable_2link(0.5, 0, l1, l2) and not K.reachable_2link(0.51, 0, l1, l2)


def test_jacobian_matches_finite_differences_and_determinant():
    l1, l2 = 0.3, 0.2
    rng = np.random.default_rng(1)
    for _ in range(50):
        q = rng.uniform(-3, 3, 2); J = K.jacobian_2link(q, l1, l2); h = 1e-6
        Jn = np.column_stack([(K.fk_2link(q + h * e, l1, l2) - K.fk_2link(q - h * e, l1, l2)) / (2 * h) for e in np.eye(2)])
        assert np.allclose(J, Jn, atol=1e-8) and abs(np.linalg.det(J) - l1 * l2 * math.sin(q[1])) < 1e-12
    with pytest.raises(np.linalg.LinAlgError):
        K.joint_rates((0.3, 0.0), (0.0, 0.1), l1, l2)                 # fully stretched: singular
    q = (0.4, 0.9); dq = K.joint_rates(q, (0.05, -0.02), l1, l2)
    assert np.allclose(K.jacobian_2link(q, l1, l2) @ dq, (0.05, -0.02))


def test_diffdrive_conversions_and_feasibility():
    v, w = K.wheel_to_body(0.4, 0.6, 0.16)
    assert abs(v - 0.5) < 1e-12 and abs(w - 1.25) < 1e-12 and np.allclose(K.body_to_wheel(v, w, 0.16), (0.4, 0.6))
    assert K.feasible_vw(0.5, 1.0, 0.69, 0.16) and not K.feasible_vw(0.69, 0.1, 0.69, 0.16) and abs(2 * 0.69 / 0.16 - 8.625) < 1e-12 and K.feasible_vw(0, 8.625, 0.69, 0.16)


def test_exact_arc_returns_to_start_euler_does_not():
    pose = np.array([0.0, 0.0, 0.0]); v, w, dt = 0.5, 0.5, 0.1                  # a circle of radius 1 m
    n = int(round(2 * math.pi / w / dt))
    ex = pose.copy(); eu = pose.copy()
    for _ in range(n):
        ex = K.arc_pose(ex, (v - 0.08 * w) * dt, (v + 0.08 * w) * dt, 0.16); eu = K.euler_pose(eu, v, w, dt)
    assert np.hypot(*ex[:2]) < 0.07 and np.hypot(*eu[:2]) > np.hypot(*ex[:2])    # n is rounded, so a small residual remains; Euler is worse
    full = K.arc_pose(np.array([0, 0, 0.0]), 2 * math.pi * 0.92, 2 * math.pi * 1.08, 0.16)
    assert np.allclose(full[:2], (0, 0), atol=1e-9)                              # one exact full circle: (R=1, 2 pi) closes exactly


def test_rover_ideal_odometry_matches_truth_within_quantisation():
    r = K.Rover(); r.drive(0.5, 0.0, 10.0); r.drive(0.3, 0.6, 5.0)
    assert r.position_error() < 0.002 and abs(r.pose[2] - r.odom[2]) < 0.01
    with pytest.raises(ValueError):
        K.Rover().drive(0.68, 0.5, 1.0)


def test_systematic_drift_matches_closed_form():
    eps, s, L = 0.005, 20.0, 0.16
    r = K.Rover(eps_r=eps); r.drive(0.5, 0.0, s / 0.5, dt=0.02)
    x, y, th = K.radius_mismatch_arc(eps, s, L)
    assert np.allclose(r.pose[:2], (x, y), rtol=0.01, atol=0.02) and abs(r.odom[0] - s) < 0.01 and abs(r.odom[1]) < 0.01


def test_random_slip_lateral_std_matches_formula():
    q, s, L = 4e-6, 20.0, 0.16
    ys = []
    for seed in range(120):
        r = K.Rover(slip_q=q, seed=seed); r.drive(0.5, 0.0, s / 0.5, dt=0.05); ys.append(r.pose[1] - r.odom[1])
    assert abs(np.std(ys) - K.random_slip_lateral_std(q, s, L)) < 0.2 * K.random_slip_lateral_std(q, s, L)
