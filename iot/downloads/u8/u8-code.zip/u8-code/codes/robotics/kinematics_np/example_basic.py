"""Minimal runnable example for kinematics_np. Run: python example_basic.py  (writes example_basic.png)."""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import kinematics_np  # noqa: F401


def main():
    fig, ax = plt.subplots()
    ax.set(title="kinematics_np example")
    fig.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), "example_basic.png"), dpi=150)


if __name__ == "__main__":
    main()
