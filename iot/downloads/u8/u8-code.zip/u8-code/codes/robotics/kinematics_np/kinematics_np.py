"""Planar robot kinematics (numpy): SE(2) transforms, a 2-link arm (forward and inverse kinematics, Jacobian), the differential-drive model with exact arc
integration, and the shared Smart Greenhouse Rover simulator (encoders, wheel errors, slip, odometry) that Units 9 to 11 extend. See README.md.

Conventions: angles in radians, counter-clockwise positive; world frame x forward/east, y left/north; body frame x forward, y left; lengths in metres.
"""
import math
from dataclasses import dataclass

import numpy as np


# ------------------------------------------------------------------ SE(2): rotations and homogeneous transforms
def rot2(theta):
    c, s = math.cos(theta), math.sin(theta)
    return np.array([[c, -s], [s, c]])


def se2(x, y, theta):
    """3x3 homogeneous transform of a frame at (x, y) rotated by theta, expressed in its parent frame."""
    T = np.eye(3)
    T[:2, :2] = rot2(theta)
    T[:2, 2] = (x, y)
    return T


def se2_inv(T):
    R, t = T[:2, :2], T[:2, 2]
    Ti = np.eye(3)
    Ti[:2, :2] = R.T
    Ti[:2, 2] = -R.T @ t
    return Ti


def transform_point(T, p):
    q = T @ np.array([p[0], p[1], 1.0])
    return q[:2]


def wrap_angle(a):
    """Wrap to (-pi, pi]."""
    return math.atan2(math.sin(a), math.cos(a))


# ------------------------------------------------------------------ 2-link planar arm
def fk_2link(q, l1, l2):
    """Tool position (x, y) of a 2-link arm with joint angles q = (q1, q2): q1 from the x axis, q2 relative to link 1."""
    q1, q2 = q
    return np.array([l1 * math.cos(q1) + l2 * math.cos(q1 + q2), l1 * math.sin(q1) + l2 * math.sin(q1 + q2)])


def elbow_2link(q, l1):
    return np.array([l1 * math.cos(q[0]), l1 * math.sin(q[0])])


def reachable_2link(x, y, l1, l2):
    r = math.hypot(x, y)
    return abs(l1 - l2) <= r <= l1 + l2


def ik_2link(x, y, l1, l2, elbow="up"):
    """Closed-form inverse kinematics by the law of cosines. elbow="up" gives q2 > 0, "down" gives q2 < 0 (books differ on which one they call elbow-up).
    Returns (q1, q2) or None if the point is outside the workspace."""
    r2 = x * x + y * y
    c2 = (r2 - l1 * l1 - l2 * l2) / (2 * l1 * l2)
    if c2 < -1 - 1e-12 or c2 > 1 + 1e-12:
        return None
    c2 = max(-1.0, min(1.0, c2))
    q2 = math.acos(c2) * (1 if elbow == "up" else -1)
    q1 = math.atan2(y, x) - math.atan2(l2 * math.sin(q2), l1 + l2 * math.cos(q2))
    return q1, q2


def jacobian_2link(q, l1, l2):
    """J(q) with d(tool)/dt = J dq/dt."""
    q1, q2 = q
    s1, c1, s12, c12 = math.sin(q1), math.cos(q1), math.sin(q1 + q2), math.cos(q1 + q2)
    return np.array([[-l1 * s1 - l2 * s12, -l2 * s12], [l1 * c1 + l2 * c12, l2 * c12]])


def joint_rates(q, tool_velocity, l1, l2):
    """Joint rates that give the tool velocity (solves J dq = v); raises numpy.linalg.LinAlgError at a singularity."""
    return np.linalg.solve(jacobian_2link(q, l1, l2), np.asarray(tool_velocity, float))


# ------------------------------------------------------------------ differential drive
def wheel_to_body(vl, vr, track):
    """Wheel linear speeds -> (forward speed v, turn rate w): v = (vr + vl)/2, w = (vr - vl)/track."""
    return 0.5 * (vr + vl), (vr - vl) / track


def body_to_wheel(v, w, track):
    return v - 0.5 * track * w, v + 0.5 * track * w


def feasible_vw(v, w, v_wheel_max, track):
    """True if both wheel speeds stay within +-v_wheel_max: |v| + track |w| / 2 <= v_wheel_max."""
    return abs(v) + 0.5 * track * abs(w) <= v_wheel_max + 1e-12


def arc_pose(pose, dsl, dsr, track):
    """Exact pose update for left and right wheel travels (dsl, dsr) over a short interval at constant wheel speeds: a circular arc (or a straight line)."""
    x, y, th = pose
    ds, dth = 0.5 * (dsr + dsl), (dsr - dsl) / track
    if abs(dth) < 1e-12:
        return np.array([x + ds * math.cos(th), y + ds * math.sin(th), th])
    R = ds / dth
    return np.array([x + R * (math.sin(th + dth) - math.sin(th)), y - R * (math.cos(th + dth) - math.cos(th)), th + dth])


def euler_pose(pose, v, w, dt):
    x, y, th = pose
    return np.array([x + v * math.cos(th) * dt, y + v * math.sin(th) * dt, th + w * dt])


# ------------------------------------------------------------------ the shared rover simulator
@dataclass
class RoverParams:
    """The Smart Greenhouse Rover, shared by Units 8 to 11. ASSUMED round numbers (mass, wheel radius, encoder as in Units 2 and 3; track width new in Unit 8)."""
    mass: float = 1.5            # kg
    wheel_r: float = 0.033       # m
    track: float = 0.16          # m, distance between wheel contact points
    cpr: int = 1320              # encoder counts per wheel revolution (11 pulses x4 x 30:1 gearbox)
    v_nominal: float = 0.5       # m/s cruise speed
    w_noload: float = 20.944     # rad/s motor no-load speed (200 rpm at 6 V, Unit 2)

    @property
    def dist_per_count(self):
        return 2 * math.pi * self.wheel_r / self.cpr

    @property
    def v_wheel_max(self):
        return self.w_noload * self.wheel_r


class Rover:
    """True motion plus encoder-based odometry. Wheel speeds follow the commands instantly (Unit 9 adds motor dynamics).
    eps_l, eps_r: relative errors of the true wheel radii (the odometry assumes the nominal radius); slip_q: variance of wheel travel noise per metre (m^2/m);
    track_err: relative error of the true track width. Encoders count wheel rotation (so slip does not appear in them)."""

    def __init__(self, params=None, pose=(0.0, 0.0, 0.0), eps_l=0.0, eps_r=0.0, slip_q=0.0, track_err=0.0, seed=0):
        self.p = params or RoverParams()
        self.pose = np.array(pose, float)             # true pose
        self.odom = np.array(pose, float)             # estimate from the encoders
        self.eps_l, self.eps_r, self.slip_q, self.track_err = eps_l, eps_r, slip_q, track_err
        self.rng = np.random.default_rng(seed)
        self.rev = [0.0, 0.0]                         # accumulated wheel revolutions (left, right)
        self.counts = [0, 0]
        self.path_true, self.path_odom = [self.pose.copy()], [self.odom.copy()]
        self.distance = 0.0

    def step(self, wl, wr, dt):
        """Advance by dt seconds with wheel angular speeds wl, wr (rad/s). Returns the encoder count increments (left, right)."""
        p = self.p
        rot = (wl * dt, wr * dt)                       # wheel rotation in radians
        ds = []
        for i, (r_err, a) in enumerate(((self.eps_l, rot[0]), (self.eps_r, rot[1]))):
            s = p.wheel_r * (1 + r_err) * a
            if self.slip_q > 0 and s != 0:
                s += self.rng.normal(0.0, math.sqrt(self.slip_q * abs(s)))
            ds.append(s)
        self.pose = arc_pose(self.pose, ds[0], ds[1], p.track * (1 + self.track_err))
        self.distance += abs(0.5 * (ds[0] + ds[1]))
        d_counts = []
        for i, a in enumerate(rot):
            self.rev[i] += a / (2 * math.pi)
            new = int(math.floor(self.rev[i] * p.cpr)) if self.rev[i] >= 0 else -int(math.floor(-self.rev[i] * p.cpr))
            d_counts.append(new - self.counts[i]); self.counts[i] = new
        self.odom = arc_pose(self.odom, d_counts[0] * p.dist_per_count, d_counts[1] * p.dist_per_count, p.track)
        self.path_true.append(self.pose.copy()); self.path_odom.append(self.odom.copy())
        return tuple(d_counts)

    def drive(self, v, w, t, dt=0.01):
        """Drive at body speed v (m/s) and turn rate w (rad/s) for t seconds (wheel speeds from the model; raises ValueError if infeasible)."""
        vl, vr = body_to_wheel(v, w, self.p.track)
        if max(abs(vl), abs(vr)) > self.p.v_wheel_max + 1e-9:
            raise ValueError("wheel speed beyond the motor's no-load speed")
        for _ in range(int(round(t / dt))):
            self.step(vl / self.p.wheel_r, vr / self.p.wheel_r, dt)

    def position_error(self):
        return float(np.hypot(*(self.pose[:2] - self.odom[:2])))


# ------------------------------------------------------------------ closed forms for the drift analysis
def radius_mismatch_arc(eps, s, track):
    """True end pose of a rover that the odometry believes drove straight for distance s (the left wheel travels s, the right (1+eps) s).
    Returns (x, y, heading) of the true end point; the odometry says (s, 0, 0)."""
    sl, sr = s, (1 + eps) * s
    return arc_pose((0.0, 0.0, 0.0), sl, sr, track)


def random_slip_lateral_std(q, s, track):
    """Standard deviation of the lateral position error after distance s straight when each wheel's travel has variance q per metre: sqrt(2 q s^3 / (3 L^2))."""
    return math.sqrt(2.0 * q * s ** 3 / (3.0 * track ** 2))


def random_slip_heading_std(q, s, track):
    return math.sqrt(2.0 * q * s) / track


def main():
    p = RoverParams()
    print("distance per count (mm):", round(p.dist_per_count * 1e3, 4), " max wheel speed (m/s):", round(p.v_wheel_max, 3))


if __name__ == "__main__":
    main()
