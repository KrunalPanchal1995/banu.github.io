# kinematics_np

> Planar robot kinematics: SE(2) transforms, 2-link arm forward/inverse kinematics and Jacobian, differential-drive model with exact arc integration, and the shared Smart Greenhouse Rover simulator with encoders, wheel errors, slip and odometry.

**Topic:** robotics  |  **Created in session:** 008 (Unit 8)  |  **Status:** tested (8 tests); base of the rover simulator for Units 9 to 11

## What this code is for
The geometry layer of the rover and its nozzle arm, and the shared `Rover` simulator that later units extend (motor dynamics in Unit 9, sensors and filters in Unit 10, planning in Unit 11). A future AI can use it to check frame transforms, IK/FK, drift budgets and wheel-speed limits.

## Capabilities
- `rot2`, `se2`, `se2_inv`, `transform_point`, `wrap_angle`.
- `fk_2link`, `elbow_2link`, `ik_2link(x, y, l1, l2, elbow)` (q2>0 for 'up', q2<0 for 'down'; None if unreachable), `reachable_2link`, `jacobian_2link`, `joint_rates` (raises LinAlgError at a singularity).
- `wheel_to_body`, `body_to_wheel`, `feasible_vw` (|v| + L|w|/2 <= v_wheel_max), `arc_pose` (exact), `euler_pose`.
- `RoverParams` (mass 1.5 kg, wheel_r 0.033 m, track 0.16 m, cpr 1320, v_nominal 0.5 m/s, w_noload 20.944 rad/s; `.dist_per_count`, `.v_wheel_max`), `Rover(params, pose, eps_l, eps_r, slip_q, track_err, seed)` with `.step(wl, wr, dt)`, `.drive(v, w, t, dt)`, `.pose` (true), `.odom` (from encoder counts), `.position_error()`, `.path_true/.path_odom`.
- Drift formulas: `radius_mismatch_arc(eps, s, track)`, `random_slip_lateral_std(q, s, track)`, `random_slip_heading_std`.

## Theory in one paragraph
Transform p' = R p + t, inverse (R^T, -R^T t). 2-link: x = l1 c1 + l2 c12, cos q2 = (r^2 - l1^2 - l2^2)/(2 l1 l2), det J = l1 l2 sin q2. Diff drive: v = (vR+vL)/2, w = (vR-vL)/L; exact arc update. Drift: heading eps s/L, lateral eps s^2/(2L) for a radius mismatch; random slip variance 2 q s^3/(3 L^2). Derived in Unit 8, Section 3.

## Quick start
```bash
python -m pytest -q tests
python kinematics_np.py
```
```python
import kinematics_np as K
r = K.Rover(eps_r=0.005); r.drive(0.5, 0.0, 40.0); print(r.pose, r.odom, r.position_error())
```

## Examples
| File | Shows | Output |
|------|-------|--------|
| `example_basic.py` | scaffold placeholder; real examples: `sessions/008-unit8-kinematics/figures/` | `example_basic.png` |

## Inputs / outputs and units
Metres, radians, seconds; wheel angular speeds in rad/s; counts are integers; poses are numpy arrays (x, y, theta).

## Validation
Orthogonality and inverse of SE(2); 500 random IK/FK round trips (1e-12 m); Jacobian vs finite differences (1e-8) and sympy (determinant, r^2 identity); exact arc vs Euler (error proportional to dt); ideal odometry within 2 mm / 0.01 rad; systematic drift vs closed form (1%); random drift vs formula (20% tolerance, 9 to 12% below in the figure run).

## Known limits and gotchas
- Wheels follow commands instantly (no motor dynamics until Unit 9); no wheel-ground dynamics, no acceleration limits, no collisions.
- Slip model: variance proportional to distance, independent per wheel; real slip is partly systematic.
- Arm and track width are assumed round numbers; no joint limits.
- The Rover's odometry assumes the nominal radius and track; `track_err` changes only the true track.

## Dependencies
numpy (standard library otherwise)

## Extending toward the open-source package
`iotrobotics/kinematics.py`. To do: motor dynamics (Unit 9), sensors (Unit 10), planners (Unit 11), joint limits and 3-D rotations.
