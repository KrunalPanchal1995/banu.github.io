"""Fig 3: singularities of the 2-link arm. Left: |det J| = l1 l2 |sin q2|. Right: joint speed needed to move the tool 0.1 m/s radially, against the tool's distance from the base."""
from _common import *
use_code("robotics/kinematics_np")
import kinematics_np as K, math

L1, L2 = 0.30, 0.20
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
q2 = np.linspace(-math.pi, math.pi, 400); a.plot(np.degrees(q2), L1 * L2 * np.abs(np.sin(q2)) * 1e4, color=PAL["blue"])
for d in (0, 180, -180): a.axvline(d, color=PAL["red"], ls=":", lw=1)
a.text(5, 4, "stretched\n(q2 = 0)", color=PAL["red"], fontsize=7.5); a.text(-175, 4, "folded\n(q2 = 180)", color=PAL["red"], fontsize=7.5)
a.set(xlabel="elbow angle q2 (deg)", ylabel="|det J| (cm squared)", title="Manipulability vanishes at the ends"); a.set_xticks([-180, -90, 0, 90, 180])
rs = np.linspace(0.105, 0.4985, 300); speeds = []
for r in rs:
    q = K.ik_2link(r, 0.0, L1, L2, "up"); dq = K.joint_rates(q, (0.1, 0.0), L1, L2); speeds.append(np.hypot(*dq))
b.semilogy(rs, speeds, color=PAL["orange"]); b.set(xlabel="tool distance from the base r (m)", ylabel="joint-rate norm for 0.1 m/s (rad/s)", title="Near the edge the joints must race"); b.axvline(0.5, color=PAL["red"], ls=":"); b.axvline(0.1, color=PAL["red"], ls=":")
print("joint rate norm for 0.1 m/s radial motion at r =", {r: round(float(np.hypot(*K.joint_rates(K.ik_2link(r, 0, L1, L2, 'up'), (0.1, 0), L1, L2))), 3) for r in (0.15, 0.3, 0.45, 0.49, 0.499)})
print("det J at q2 = 90 deg (cm^2):", L1 * L2 * 1e4, " at q2 = 5 deg:", round(L1 * L2 * math.sin(math.radians(5)) * 1e4, 3))
save(fig, out("fig03_jacobian.png"))
