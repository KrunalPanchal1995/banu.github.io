"""Fig 6: two ways the model can be wrong by itself. Left: Euler integration against the exact arc, one lap of a 1 m circle, against the time step. Right: heading error after a commanded 360 degree spin when the track width is wrong."""
from _common import *
use_code("robotics/kinematics_np")
import kinematics_np as K, math

fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
v, w = 0.5, 0.5; R = v / w; lap = 2 * math.pi / w; errs_e, errs_x = [], []
ns = np.array([12, 24, 48, 100, 200, 500, 1000]); dts = lap / ns                       # n steps per lap; we integrate a quarter lap (n/4 steps)
for n, dt in zip(ns, dts):
    pe = np.array([0.0, 0.0, 0.0]); px = pe.copy()
    for _ in range(n // 4 if n % 4 == 0 else int(round(n / 4))):
        pe = K.euler_pose(pe, v, w, dt); px = K.arc_pose(px, (v - 0.08 * w) * dt, (v + 0.08 * w) * dt, 0.16)
    k = n // 4 if n % 4 == 0 else int(round(n / 4)); ang = k * dt * w; target = np.array([R * math.sin(ang), R * (1 - math.cos(ang))])
    errs_e.append(math.hypot(*(pe[:2] - target))); errs_x.append(math.hypot(*(px[:2] - target)))
a.loglog(dts, errs_e, "o-", color=PAL["red"], label="Euler: error proportional to dt"); a.loglog(dts, np.maximum(errs_x, 1e-17), "s-", color=PAL["blue"], label="exact arc (rounding only)")
for n, dt, e1, e2 in zip(ns, dts, errs_e, errs_x): print(f"n {n:5d} dt {dt:7.4f} s: quarter-lap end-point error: Euler {e1:.5f} m, exact arc {e2:.2e} m")
print("polygon radius ratio for Euler at n = 12:", round((w * dts[0] / 2) / math.sin(w * dts[0] / 2), 5), "(circumradius of the regular polygon / true radius)")
a.set(xlabel="time step dt (s)", ylabel="end-point error after a quarter lap (m)", title="Euler error shrinks with dt; the arc is exact"); a.legend(fontsize=7.5)
errs = [0.0, 0.01, 0.02, 0.05, 0.1]; got = []
for e in errs:
    r = K.Rover(track_err=e); w_spin = 1.0
    while abs(r.odom[2]) < 2 * math.pi - 1e-9:
        r.step(-0.5 * w_spin * r.p.track / r.p.wheel_r * 0.01 / 0.01, 0.5 * w_spin * r.p.track / r.p.wheel_r, 0.01)
    got.append(math.degrees(abs(r.pose[2]) - abs(r.odom[2])))
    print(f"track error {e*100:4.0f} percent: odometry says {math.degrees(r.odom[2]):.2f} deg, true rotation {math.degrees(r.pose[2]):.2f} deg, error {got[-1]:.2f} deg (formula {360*(1/(1+e)-1):.2f})")
b.bar(range(5), got, color=PAL["orange"]); b.set(xticks=range(5), xticklabels=[f"{e*100:.0f}%" for e in errs], xlabel="error of the assumed track width", ylabel="heading error after a commanded 360 deg spin (deg)", title="Turns need the right track width")
for i, g in enumerate(got): b.text(i, g - 1.2 if g < 0 else g + 0.3, f"{g:.1f}", ha="center", fontsize=8)
save(fig, out("fig06_integration.png"))
