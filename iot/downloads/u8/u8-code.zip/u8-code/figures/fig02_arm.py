"""Fig 2: the nozzle arm (ASSUMED links 0.30 m and 0.20 m): workspace and the two inverse-kinematics solutions for a target."""
from _common import *
use_code("robotics/kinematics_np")
import kinematics_np as K, math

L1, L2 = 0.30, 0.20
tgt = (0.35, 0.25)
qu, qd = K.ik_2link(*tgt, L1, L2, "up"), K.ik_2link(*tgt, L1, L2, "down")
print("target", tgt, "r =", round(math.hypot(*tgt), 4), " up: q =", [round(math.degrees(a), 2) for a in qu], "deg ; down: q =", [round(math.degrees(a), 2) for a in qd], "deg")
print("check FK:", np.round(K.fk_2link(qu, L1, L2), 10), np.round(K.fk_2link(qd, L1, L2), 10))
print("workspace: inner radius", abs(L1 - L2), "outer", L1 + L2, " area m^2:", round(math.pi * ((L1 + L2) ** 2 - (L1 - L2) ** 2), 4), "(full circle of angles q1)")
fig, ax = plt.subplots(figsize=(6.0, 4.9))
th = np.linspace(0, 2 * np.pi, 400)
ax.fill(np.r_[(L1 + L2) * np.cos(th), (L1 - L2) * np.cos(th[::-1])], np.r_[(L1 + L2) * np.sin(th), (L1 - L2) * np.sin(th[::-1])], color=PAL["sky"], alpha=0.25, label="workspace (0.10 to 0.50 m)")
for q, col, lab in ((qu, PAL["blue"], "q2 > 0"), (qd, PAL["orange"], "q2 < 0")):
    e = K.elbow_2link(q, L1); t = K.fk_2link(q, L1, L2); ax.plot([0, e[0], t[0]], [0, e[1], t[1]], "o-", color=col, lw=2.5, label=f"{lab}: q1 = {math.degrees(q[0]):.1f}, q2 = {math.degrees(q[1]):.1f} deg")
ax.plot(*tgt, "*", color=PAL["red"], ms=14, label="target (0.35, 0.25)")
for r in (L1 + L2, abs(L1 - L2)): ax.plot(r * np.cos(th), r * np.sin(th), color=PAL["grey"], lw=0.8, ls="--")
ax.set(xlim=(-0.55, 0.6), ylim=(-0.55, 0.55), aspect="equal", xlabel="x (m)", ylabel="y (m)", title="Two postures reach the same point"); ax.legend(fontsize=7, loc="lower left")
save(fig, out("fig02_arm.png"))
