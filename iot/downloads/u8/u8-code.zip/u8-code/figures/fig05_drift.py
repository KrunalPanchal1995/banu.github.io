"""Fig 5: odometry drift. Left: true and odometry paths for a 20 m straight patrol with a 0.5 percent right-wheel radius error. Right: position error against distance for systematic and random errors.
ASSUMED: radius error 0.5 percent; random wheel travel variance q = 4e-6 m^2 per metre (about 2 mm standard deviation per metre)."""
from _common import *
use_code("robotics/kinematics_np")
import kinematics_np as K, math

P = K.RoverParams(); EPS, Q, S = 0.005, 4e-6, 20.0
r = K.Rover(eps_r=EPS); r.drive(0.5, 0.0, S / 0.5, dt=0.02)
pt, po = np.array(r.path_true), np.array(r.path_odom)
x, y, th = K.radius_mismatch_arc(EPS, S, P.track); print("systematic: true end", np.round(r.pose, 3), "closed form", round(x, 3), round(y, 3), round(th, 3), "; odometry end", np.round(r.odom, 3), "; position error", round(r.position_error(), 3), "m =", round(r.position_error() / S * 100, 1), "percent of distance; heading error", round(math.degrees(r.pose[2] - r.odom[2]), 2), "deg")
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1, 1.05]))
a.plot(po[:, 0], po[:, 1], color=PAL["blue"], label="odometry: straight"); a.plot(pt[:, 0], pt[:, 1], color=PAL["red"], label="true path"); a.plot(*pt[-1, :2], "o", color=PAL["red"]); a.plot(*po[-1, :2], "o", color=PAL["blue"])
a.annotate(f"error {r.position_error():.2f} m", (pt[-1, 0], pt[-1, 1]), (8.5, 2.2), arrowprops=dict(arrowstyle="->"), fontsize=8); a.set(xlabel="x (m)", ylabel="y (m)", title="20 m with a 0.5 percent radius error", aspect="equal"); a.legend(fontsize=7.5, loc="center left")
ss = np.array([1, 2, 5, 10, 15, 20.0])
sys_err = []; rnd_meas = []; rnd_form = []
for s in ss:
    x, y, th = K.radius_mismatch_arc(EPS, s, P.track); sys_err.append(math.hypot(x - s, y))
    ys = []
    for seed in range(60):
        rr = K.Rover(slip_q=Q, seed=seed); rr.drive(0.5, 0.0, s / 0.5, dt=0.05); ys.append(np.hypot(*(rr.pose[:2] - rr.odom[:2])))
    rnd_meas.append(float(np.sqrt(np.mean(np.square(ys))))); rnd_form.append(K.random_slip_lateral_std(Q, s, P.track))
    print(f"s = {s:4.0f} m: systematic error {sys_err[-1]:6.3f} m ({sys_err[-1]/s*100:5.1f} percent) | random: simulated rms {rnd_meas[-1]:.3f} m, lateral formula {rnd_form[-1]:.3f} m ({rnd_meas[-1]/s*100:.1f} percent)")
b.loglog(ss, sys_err, "o-", color=PAL["red"], label="systematic (0.5% radius): grows as s^2"); b.loglog(ss, rnd_meas, "s-", color=PAL["blue"], label="random slip (simulated rms): s^1.5"); b.loglog(ss, rnd_form, "--", color=PAL["grey"], label="formula sqrt(2 q s^3 / 3 L^2)")
b.axhline(0.1 * 20, color=PAL["black"], ls=":", lw=0.8); b.text(1.05, 2.1, "10 percent of 20 m", fontsize=7.5)
b.set(xlabel="distance driven s (m)", ylabel="position error (m)", title="Two kinds of drift"); b.legend(fontsize=6.8, loc="lower right")
save(fig, out("fig05_drift.png"))
# calibration experiment idea: lateral error y at distance s gives eps = 2 L y / s^2 (small-angle)
x, y, th = K.radius_mismatch_arc(EPS, 5.0, P.track); print("calibration: lateral error after 5 m straight:", round(y, 4), "m  ->  eps estimate", round(2 * P.track * y / 25.0, 5), "(true", EPS, ")")
