"""Fig 1: frames and transforms. World frame, rover frame at pose (2.0, 1.0, 30 deg), a sensor frame mounted 0.10 m ahead, and an obstacle 0.80 m in front of the sensor."""
from _common import *
use_code("robotics/kinematics_np")
import kinematics_np as K, math

Tw = K.se2(2.0, 1.0, math.radians(30)); Ts = K.se2(0.10, 0.0, 0.0)
obst_s = (0.80, 0.0); obst_r = K.transform_point(Ts, obst_s); obst_w = K.transform_point(Tw @ Ts, obst_s)
print("obstacle in sensor frame", obst_s, " in rover frame", np.round(obst_r, 4), " in world frame", np.round(obst_w, 4))
back = K.transform_point(K.se2_inv(Tw), obst_w); print("world -> rover again:", np.round(back, 4))
fig, ax = plt.subplots(figsize=(6.2, 4.6))
def frame(T, name, col, L=0.35):
    o = T[:2, 2]; ex = T[:2, :2] @ np.array([L, 0]); ey = T[:2, :2] @ np.array([0, L])
    ax.annotate("", xy=o + ex, xytext=o, arrowprops=dict(arrowstyle="-|>", color=col, lw=1.6)); ax.annotate("", xy=o + ey, xytext=o, arrowprops=dict(arrowstyle="-|>", color=col, lw=1.6, ls="--"))
    ax.text(*(o + ex * 1.12), "x", color=col, fontsize=8); ax.text(*(o + ey * 1.12), "y", color=col, fontsize=8); ax.text(*(o - np.array([0.12, 0.22])), name, color=col, fontsize=9, fontweight="bold")
frame(np.eye(3), "world", PAL["black"], 0.5); frame(Tw, "rover", PAL["blue"]); frame(Tw @ Ts, "sensor", PAL["orange"], 0.25)
body = np.array([[-0.12, -0.08], [0.18, -0.08], [0.18, 0.08], [-0.12, 0.08], [-0.12, -0.08]]); bw = (Tw[:2, :2] @ body.T).T + Tw[:2, 2]; ax.plot(bw[:, 0], bw[:, 1], color=PAL["blue"], lw=1)
ax.plot([*(Tw @ Ts)[:2, 2][:1], obst_w[0]], [*(Tw @ Ts)[:2, 2][1:], obst_w[1]], ":", color=PAL["orange"]); ax.plot(*obst_w, "s", color=PAL["red"], ms=9); ax.text(obst_w[0] + 0.05, obst_w[1] - 0.18, f"obstacle\nworld ({obst_w[0]:.3f}, {obst_w[1]:.3f})", color=PAL["red"], fontsize=8)
ax.set(xlim=(-0.3, 3.4), ylim=(-0.3, 2.6), xlabel="world x (m)", ylabel="world y (m)", aspect="equal", title="world <- rover <- sensor: T = T_wr T_rs, obstacle at 0.80 m"); ax.grid(True)
save(fig, out("fig01_frames.png"))
