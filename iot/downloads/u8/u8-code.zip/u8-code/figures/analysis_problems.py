"""Numbers for the worked problems and extra figures of Unit 8."""
from _common import *
use_code("robotics/kinematics_np")
import kinematics_np as K, math
print("P1: body point (0.5, 0.2) at pose (1, 2, 90 deg) ->", np.round(K.transform_point(K.se2(1, 2, math.pi / 2), (0.5, 0.2)), 4))
q = K.ik_2link(0.1, 0.4, 0.3, 0.2, "up"); qd = K.ik_2link(0.1, 0.4, 0.3, 0.2, "down")
print("P2: IK (0.1, 0.4): r", round(math.hypot(0.1, 0.4), 4), "q(up) deg", [round(math.degrees(a), 2) for a in q], " q(down) deg", [round(math.degrees(a), 2) for a in qd], " FK check", np.round(K.fk_2link(q, 0.3, 0.2), 6), np.round(K.fk_2link(qd, 0.3, 0.2), 6))
vl, vr = K.body_to_wheel(0.3, 1.5, 0.16); print("P3: wheel speeds m/s", vl, vr, " rad/s", round(vl / 0.033, 3), round(vr / 0.033, 3), " feasible", K.feasible_vw(0.3, 1.5, 0.6912, 0.16))
x, y, th = K.radius_mismatch_arc(0.002, 10.0, 0.16); print("P4: eps 0.2 percent over 10 m: true end", round(x, 3), round(y, 3), " heading deg", round(math.degrees(th), 2), " small-angle heading", round(0.002 * 10 / 0.16, 4), "rad, lateral", round(0.002 * 100 / 0.32, 4), " position error", round(math.hypot(x - 10, y), 4))
p = K.RoverParams(); d = 2000 * p.dist_per_count; print("P5: 2000 counts =", round(d * 1000, 1), "mm; heading change if only one wheel moves", round(d / p.track, 3), "rad =", round(math.degrees(d / p.track), 1), "deg")
print("resolution: distance per count mm", round(p.dist_per_count * 1e3, 4), " heading per count (one wheel) mrad", round(p.dist_per_count / p.track * 1e3, 3), "deg", round(math.degrees(p.dist_per_count / p.track), 3), " both wheels opposite: ", round(2 * p.dist_per_count / p.track * 1e3, 3), "mrad per count pair")
e = 0.005; s = 20.0; sys_err = math.hypot(*(K.radius_mismatch_arc(e, s, 0.16)[:2] - np.array([s, 0])))
print("R5 budget: random rms at 20 m (simulated) 0.831 m; allowed 2.0 m; systematic allowed sqrt(2.0^2-0.831^2) =", round(math.sqrt(4 - 0.831 ** 2), 3), "m -> eps <=", round(math.sqrt(4 - 0.831 ** 2) / sys_err * 0.5, 3), "percent")
print("calibration resolution: dy = 1 cm over 5 m -> d eps =", 2 * 0.16 * 0.01 / 25, "(", 2 * 0.16 * 0.01 / 25 * 100, "percent )")
print("usable workspace: joint rate for 0.1 m/s under 1.0 rad/s for r between", end=" ")
rs = np.linspace(0.105, 0.4985, 4000); ok = [r for r in rs if np.hypot(*K.joint_rates(K.ik_2link(r, 0, 0.3, 0.2, "up"), (0.1, 0), 0.3, 0.2)) <= 1.0]; print(round(min(ok), 3), "and", round(max(ok), 3), "m")
