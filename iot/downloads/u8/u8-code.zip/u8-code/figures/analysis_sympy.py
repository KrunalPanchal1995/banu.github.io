"""Symbolic checks for Unit 8: the Jacobian of the 2-link arm, its determinant, and the inverse-kinematics identity."""
import sympy as sp
q1, q2, l1, l2 = sp.symbols("q1 q2 l1 l2", positive=True)
x = l1 * sp.cos(q1) + l2 * sp.cos(q1 + q2); y = l1 * sp.sin(q1) + l2 * sp.sin(q1 + q2)
J = sp.Matrix([x, y]).jacobian([q1, q2])
print("J =", sp.simplify(J))
print("det J simplifies to:", sp.simplify(J.det()), " (expected l1 l2 sin q2)", sp.simplify(J.det() - l1 * l2 * sp.sin(q2)) == 0)
r2 = sp.simplify(sp.expand(x ** 2 + y ** 2)); print("x^2+y^2 =", sp.simplify(sp.trigsimp(r2)), "  -> cos q2 = (x^2+y^2-l1^2-l2^2)/(2 l1 l2):", sp.simplify(sp.trigsimp(r2) - (l1 ** 2 + l2 ** 2 + 2 * l1 * l2 * sp.cos(q2))) == 0)
Jinv = sp.simplify(J.inv()); print("J^-1 =", Jinv)
print("norm of J^-1 column growth: 1/|sin q2| factor:", sp.simplify(Jinv[0, 0] * l1 * l2 * sp.sin(q2)))
