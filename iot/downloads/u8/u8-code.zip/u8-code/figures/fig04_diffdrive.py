"""Fig 4: what the differential-drive rover can do. Left: feasible (v, w) region from the motor's no-load speed (Unit 2) and example arcs. Right: paths for four (v, w) choices over 4 s."""
from _common import *
use_code("robotics/kinematics_np")
import kinematics_np as K, math

P = K.RoverParams(); vmax = P.v_wheel_max; L = P.track
print("wheel speed limit v_wheel_max = w_noload r =", round(vmax, 4), "m/s ; track", L, "m")
print("max in-place turn rate", round(2 * vmax / L, 3), "rad/s =", round(math.degrees(2 * vmax / L), 1), "deg/s ; at v = 0.5 m/s: w_max =", round(2 * (vmax - 0.5) / L, 3), "rad/s, min turning radius", round(0.5 / (2 * (vmax - 0.5) / L), 3), "m")
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.fill([vmax, 0, -vmax, 0], [0, 2 * vmax / L, 0, -2 * vmax / L], color=PAL["sky"], alpha=0.35); a.plot([vmax, 0, -vmax, 0, vmax], [0, 2 * vmax / L, 0, -2 * vmax / L, 0], color=PAL["blue"])
a.plot(0.5, 0, "o", color=PAL["red"]); a.text(0.52, 0.3, "cruise 0.5 m/s", fontsize=7.5, color=PAL["red"]); a.plot(0, 2 * vmax / L, "s", color=PAL["green"]); a.text(0.03, 8.4, f"spin in place: {2*vmax/L:.2f} rad/s", fontsize=7.5, color=PAL["green"])
a.plot([0.5, 0.5], [-2 * (vmax - 0.5) / L, 2 * (vmax - 0.5) / L], "-", color=PAL["red"], lw=3); a.text(0.52, 2.6, f"at 0.5 m/s: |w| <= {2*(vmax-0.5)/L:.2f}", fontsize=7.5, color=PAL["red"])
a.set(xlabel="forward speed v (m/s)", ylabel="turn rate w (rad/s)", title="Feasible (v, w): |v| + (L/2)|w| <= v_wheel_max")
for v, w, col, lab in ((0.5, 0.0, PAL["blue"], "v=0.5, w=0"), (0.4, 1.0, PAL["orange"], "v=0.4, w=1"), (0.2, 2.0, PAL["green"], "v=0.2, w=2"), (0.0, 3.0, PAL["red"], "v=0, w=3 (spin)")):
    r = K.Rover(); r.drive(v, w, 4.0, dt=0.01); path = np.array(r.path_true); b.plot(path[:, 0], path[:, 1], color=col, label=lab); b.plot(*path[-1, :2], "o", color=col, ms=4)
b.set(xlabel="x (m)", ylabel="y (m)", aspect="equal", title="Paths over 4 s"); b.legend(fontsize=7)
print("turning radius v/w:", {(v, w): round(v / w, 3) for v, w in ((0.4, 1.0), (0.2, 2.0))})
save(fig, out("fig04_diffdrive.png"))
