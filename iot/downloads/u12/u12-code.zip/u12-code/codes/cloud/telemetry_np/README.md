# telemetry_np

> Telemetry payload codecs (JSON, packed binary, a small CBOR), time-series store and downsampling, threshold / z-score / EWMA / CUSUM anomaly detectors, edge-vs-cloud arithmetic, and a Flask dashboard fed by MQTT.

**Topic:** cloud  |  **Created in session:** 006 (Unit 6)  |  **Status:** tested (10 tests); CBOR cross-checked against cbor2

## What this code is for
The data side of the greenhouse system: write a reading as bytes, reduce a series at the edge without hiding spikes, detect faults with simple streaming detectors or a model residual, and show everything on a dashboard. A future AI can reuse the detectors and the CBOR codec as small, dependency-light building blocks.

## Capabilities
- `encode_json`, `pack_reading` / `unpack_reading` (7 or 11 bytes; temperature 0.01 degC, battery 1 mV), `cbor_encode` / `cbor_decode` (int, float64, str, bytes, bool, None, list, dict; decodes half/single floats).
- `TimeSeries.append/range/last`; `downsample(t, v, window) -> dict(t, mean, min, max, count)`.
- Detectors with `update(x) -> bool`: `ThresholdDetector(lo, hi, hysteresis)`, `ZScoreDetector(window, k)`, `EwmaDetector(mu0, sigma, lam, L)`, `CusumDetector(mu0, k, h)`; `run_detector`, `detection_stats(make_detector, make_series, n_runs)` (detected fraction, mean delay, false alarms per 1000).
- `daily_bytes`, `edge_aggregated_bytes`.
- `dashboard.Store` (ingest, alerts, latest with stale flag), `create_app(store)` (Flask: `/`, `/api/latest`, `/api/series`, `/api/alerts`, `POST /api/ingest`), `mqtt_ingest(store, host, port)` (uses `net/mqtt_mini` client).

## Theory in one paragraph
CBOR head = major type (3 bits) + argument (5 bits, or 1/2/4/8 following bytes); aggregation keeps mean, min, max, count; EWMA limit L sigma sqrt(lam/(2-lam)(1-(1-lam)^(2t))); CUSUM S+ = max(0, S+ + (x-mu0) - k); twin residual shift (p-1) k tau (1 - exp(-dt/tau)); false alarms per day = P(|Z|>k) x samples per day. Derived in Unit 6, Section 3.

## Quick start
```bash
python -m pytest -q tests
python dashboard.py           # http://127.0.0.1:5000  (feed it with POST /api/ingest or mqtt_ingest)
# CBOR cross-check (throwaway venv with cbor2 and numpy): python cbor_crosscheck.py
```

## Examples
| File | Shows | Output |
|------|-------|--------|
| `example_basic.py` | scaffold placeholder; real examples: `sessions/006-unit6-data-cloud-edge/figures/` | `example_basic.png` |

## Inputs / outputs and units
Times in seconds (dashboard) or samples (detectors); values in the sensor's unit; bytes for sizes.

## Validation
25 RFC 8949 Appendix A style encodings (from memory, each agreeing with cbor2); 2000/2000 random structures byte-identical with cbor2 6.1.5 (`sessions/006-unit6-data-cloud-edge/cbor_crosscheck_log.txt`); detector and twin behaviour against closed forms (step delay 5.4 vs 5.8, false alarms ~3 per 1000 vs 2.7); dashboard via Flask test client and through the Unit 5 broker.

## Known limits and gotchas
- Detectors assume independent Gaussian noise and (EWMA, CUSUM, fixed limit) a known baseline; z-score learns the baseline and so absorbs drifts.
- `cbor_encode` writes floats as 64-bit only; no tags, no indefinite lengths, dict keys must be encodable.
- The dashboard is an in-memory demo: no persistence, authentication or TLS; the detectors do not know about commands (watering outliers are false alarms).
- The residual of a controller-chosen subset has a selection bias (see Unit 6); calibrate the baseline.

## Dependencies
numpy, Flask; `mqtt_ingest` needs `codes/net/mqtt_mini` on the path. CBOR cross-check: cbor2.

## Extending toward the open-source package
`iotrobotics/telemetry.py`. To do: persistence, seasonal baselines, command-aware alerts, CBOR floats of 16/32 bits.
