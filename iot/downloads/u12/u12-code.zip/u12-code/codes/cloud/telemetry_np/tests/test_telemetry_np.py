import asyncio
import math
import os
import sys

import numpy as np
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "..", "..", "net", "mqtt_mini"))
import telemetry_np as T  # noqa: E402
import dashboard as D  # noqa: E402


def test_cbor_rfc8949_appendix_a_examples():
    cases = [(0, "00"), (1, "01"), (10, "0a"), (23, "17"), (24, "1818"), (25, "1819"), (100, "1864"), (1000, "1903e8"), (1000000, "1a000f4240"),
             (-1, "20"), (-10, "29"), (-100, "3863"), (-1000, "3903e7"), ("", "60"), ("a", "6161"), ("IETF", "6449455446"), ([], "80"), ([1, 2, 3], "83010203"),
             ({}, "a0"), ({1: 2, 3: 4}, "a201020304"), ({"a": 1, "b": [2, 3]}, "a26161016162820203"), (False, "f4"), (True, "f5"), (None, "f6"), (1.1, "fb3ff199999999999a")]
    for v, hx in cases:
        assert T.cbor_encode(v).hex() == hx, (v, hx)
        assert T.cbor_decode(bytes.fromhex(hx)) == v
    assert T.cbor_decode(bytes.fromhex("f93e00")) == 1.5 and T.cbor_decode(bytes.fromhex("fa47c35000")) == 100000.0     # half and single floats decode


def test_cbor_roundtrip_random():
    rng = np.random.default_rng(0)
    def rand(d=0):
        k = int(rng.integers(0, 6 if d < 3 else 4))
        if k == 0: return int(rng.integers(-10 ** 9, 10 ** 9))
        if k == 1: return float(rng.normal())
        if k == 2: return "".join(chr(int(c)) for c in rng.integers(32, 127, int(rng.integers(0, 30))))
        if k == 3: return bool(rng.integers(0, 2))
        if k == 4: return [rand(d + 1) for _ in range(int(rng.integers(0, 4)))]
        return {"k%d" % i: rand(d + 1) for i in range(int(rng.integers(0, 4)))}
    for _ in range(300):
        v = rand()
        assert T.cbor_decode(T.cbor_encode(v)) == v


def test_packed_reading_roundtrip_and_sizes():
    r = dict(zone=1, soil_raw=1832, temp_c=21.5, batt_v=3.71)
    b = T.pack_reading(1, 1832, 21.5, 3.71)
    assert len(b) == 7 and T.unpack_reading(b) == dict(zone=1, soil_raw=1832, temp_c=21.5, batt_v=3.71)
    assert len(T.pack_reading(1, 1832, 21.5, 3.71, ts=1760000000)) == 11 and T.unpack_reading(T.pack_reading(1, 1832, 21.5, 3.71, ts=1760000000))["ts"] == 1760000000
    assert abs(T.unpack_reading(T.pack_reading(1, 1, 21.4999, 3.7149))["temp_c"] - 21.4999) <= 0.005 + 1e-9
    assert len(T.cbor_encode(r)) < len(T.encode_json(r)) and len(b) < len(T.cbor_encode(r))


def test_timeseries_and_downsample():
    ts = T.TimeSeries()
    for i in range(120):
        ts.append(i * 60.0, float(i % 10))
    t, v = ts.range(600, 1200)
    assert len(t) == 10 and t[0] == 600
    d = T.downsample(*ts.range(), 600.0)
    assert len(d["t"]) == 12 and np.allclose(d["mean"], 4.5) and np.all(d["min"] == 0) and np.all(d["max"] == 9) and np.all(d["count"] == 10)
    with pytest.raises(ValueError):
        ts.append(0.0, 1.0)


def test_detectors_basic_behaviour():
    th = T.ThresholdDetector(10, 20, hysteresis=1)
    assert [th.update(x) for x in (15, 21, 19.5, 18.9, 15)] == [False, True, True, False, False]
    z = T.ZScoreDetector(50, 3.0)
    rng = np.random.default_rng(1); x = rng.normal(0, 1, 400); x[300] += 8
    a = T.run_detector(z, x)
    assert a[300] and a[:50].sum() == 0
    e = T.EwmaDetector(0.0, 1.0, 0.1, 3.0)
    assert not e.update(0.0) and abs(e.limit() - 3 * math.sqrt(0.1 / 1.9 * (1 - 0.9 ** 2))) < 1e-12
    big = T.run_detector(T.EwmaDetector(0.0, 1.0, 0.1, 3.0), np.full(40, 1.5))
    assert big.any() and big.argmax() < 8


def test_ewma_beats_zscore_on_small_step_and_zscore_beats_ewma_on_spike():
    base = lambda rng: rng.normal(0, 1, 600)
    def step(rng):
        x = base(rng); x[300:] += 1.5; return x, 300
    def spike(rng):
        x = base(rng); x[300] += 7; return x, 300
    ew = lambda: T.EwmaDetector(0.0, 1.0, 0.1, 3.0); zs = lambda: T.ZScoreDetector(60, 3.0)
    s_e, s_z = T.detection_stats(ew, step, 200, seed=1), T.detection_stats(zs, step, 200, seed=1)
    assert s_e["detected"] > 0.95 and s_e["mean_delay"] < s_z["mean_delay"] if s_z["detected"] > 0 else True
    p_e, p_z = T.detection_stats(ew, spike, 200, seed=2), T.detection_stats(zs, spike, 200, seed=2)
    assert p_z["detected"] > 0.95 and p_z["detected"] > p_e["detected"]


def test_cusum_detects_small_shift_and_has_a_low_false_alarm_rate():
    rng = np.random.default_rng(5)
    quiet = T.run_detector(T.CusumDetector(0.0, 0.5, 5.0), rng.normal(0, 1, 20000))
    assert quiet.mean() < 0.01                                      # with k=0.5, h=5 the in-control average run length is several hundred samples
    delays = []
    for s in range(100):
        x = np.random.default_rng(100 + s).normal(0, 1, 300); x[100:] -= 1.0       # a shift of one standard deviation
        hit = np.where(T.run_detector(T.CusumDetector(0.0, 0.5, 5.0), x)[100:])[0]
        delays.append(hit[0] if len(hit) else 200)
    assert np.mean(delays) < 15                                     # theory: roughly h / (shift - k) = 10 samples


def test_edge_arithmetic():
    assert T.daily_bytes(50, 60, 540) == 50 * 1440 * 540
    assert T.edge_aggregated_bytes(50, 60, 600, 8, 4) == 50 * 144 * 32


def test_dashboard_api_and_alerts_and_stale():
    now = [1000.0]
    store = D.Store(now=lambda: now[0], period_s=60, stale_periods=3)
    app = D.create_app(store); c = app.test_client()
    assert c.get("/").status_code == 200 and b"Greenhouse" in c.get("/").data
    for i in range(70):
        assert c.post("/api/ingest", json=dict(topic="greenhouse/zone1/temp", value=21.0 + 0.1 * math.sin(i), t=1000.0 + i)).status_code == 200
    c.post("/api/ingest", json=dict(topic="greenhouse/zone1/temp", value=45.0, t=1071.0))             # beyond the 40 degC limit and an outlier
    kinds = {a["kind"] for a in c.get("/api/alerts").get_json()}
    assert kinds == {"limit", "outlier"}
    now[0] = 1071.0 + 100.0
    L = c.get("/api/latest").get_json()["greenhouse/zone1/temp"]
    assert L["value"] == 45.0 and L["stale"] is False
    now[0] = 1071.0 + 200.0
    assert c.get("/api/latest").get_json()["greenhouse/zone1/temp"]["stale"] is True
    assert c.get("/api/series?topic=nope").status_code == 404 and len(c.get("/api/series?topic=greenhouse/zone1/temp&since=1060").get_json()["v"]) == 11
    assert c.post("/api/ingest", json=dict(topic="x")).status_code == 400


def test_mqtt_ingest_end_to_end():
    from broker import Broker
    from client import MiniClient
    async def go():
        b = await Broker().start(); store = D.Store(now=lambda: 5.0)
        stop = asyncio.Event(); task = asyncio.ensure_future(D.mqtt_ingest(store, "127.0.0.1", b.port, stop=stop))
        await asyncio.sleep(0.3)
        p = MiniClient("node1", 0); await p.connect("127.0.0.1", b.port)
        await p.publish("greenhouse/zone1/soil", b"1832", 1); await p.publish("greenhouse/zone1/temp", b'{"v": 21.5}', 1); await p.publish("greenhouse/zone1/soil", b"junk", 1)
        await asyncio.sleep(0.4); stop.set(); await task; await p.disconnect(); await b.stop()
        return store
    s = asyncio.run(go())
    assert s.series["greenhouse/zone1/soil"].last()[1] == 1832.0 and s.series["greenhouse/zone1/temp"].last()[1] == 21.5 and len(s.series["greenhouse/zone1/soil"]) == 1
