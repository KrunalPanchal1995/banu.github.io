"""Cross-check telemetry_np's CBOR encoder/decoder against the independent cbor2 library (needs `pip install cbor2` in a throwaway venv).
Byte-for-byte equality on random structures (int, float64, str, bool, None, list, dict) and decode of cbor2's output."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cbor2  # noqa: E402
import telemetry_np as T  # noqa: E402

rng = np.random.default_rng(42)


def rand(d=0):
    k = int(rng.integers(0, 6 if d < 3 else 4))
    if k == 0:
        return int(rng.choice([0, 1, 23, 24, 255, 256, 65535, 65536, 2 ** 32 - 1, 2 ** 32, 2 ** 63, -1, -24, -25, -256, -257, -65537, -2 ** 40])) if rng.random() < 0.5 else int(rng.integers(-10 ** 12, 10 ** 12))
    if k == 1:
        return float(rng.normal(0, 100))
    if k == 2:
        return "".join(chr(int(c)) for c in rng.integers(32, 0x3000, int(rng.integers(0, 40)))) if rng.random() < 0.3 else "".join(chr(int(c)) for c in rng.integers(32, 127, int(rng.integers(0, 40))))
    if k == 3:
        return [True, False, None][int(rng.integers(0, 3))]
    if k == 4:
        return [rand(d + 1) for _ in range(int(rng.integers(0, 30 if d == 0 and rng.random() < 0.1 else 4)))]
    return {"k%d" % i: rand(d + 1) for i in range(int(rng.integers(0, 4)))}


n_eq = n_dec = 0
N = 2000
for _ in range(N):
    v = rand()
    mine = T.cbor_encode(v)
    ref = cbor2.dumps(v)
    assert mine == ref, (v, mine.hex(), ref.hex())
    n_eq += 1
    assert T.cbor_decode(ref) == v == cbor2.loads(mine)
    n_dec += 1
print("cbor2 %s: %d/%d random structures encode to identical bytes; %d/%d decode and cross-decode equal" % (cbor2.__version__ if hasattr(cbor2, "__version__") else "?", n_eq, N, n_dec, N))
