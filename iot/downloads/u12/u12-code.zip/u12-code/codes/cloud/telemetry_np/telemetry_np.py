"""Telemetry toolbox (numpy): payload codecs, time-series store with downsampling, streaming anomaly detectors and edge-vs-cloud
arithmetic. See README.md and the Unit 6 document."""
import json
import math
import struct
from collections import deque

import numpy as np


# ------------------------------------------------------------------ payload codecs
def encode_json(obj):
    return json.dumps(obj, separators=(",", ":")).encode()


def pack_reading(zone, soil_raw, temp_c, batt_v, ts=None):
    """Packed binary: zone u8, soil raw u16 (0..65535), temperature int16 in 0.01 degC, battery u16 in mV, [timestamp u32 s]."""
    body = struct.pack("<BHhH", zone, soil_raw, int(round(temp_c * 100)), int(round(batt_v * 1000)))
    return body + (struct.pack("<I", ts) if ts is not None else b"")


def unpack_reading(b):
    zone, soil, t100, mv = struct.unpack_from("<BHhH", b, 0)
    out = dict(zone=zone, soil_raw=soil, temp_c=t100 / 100.0, batt_v=mv / 1000.0)
    if len(b) >= 11:
        out["ts"] = struct.unpack_from("<I", b, 7)[0]
    return out


def _cbor_head(major, n):
    if n < 24:
        return bytes([(major << 5) | n])
    for ai, size in ((24, 1), (25, 2), (26, 4), (27, 8)):
        if n < 1 << (8 * size):
            return bytes([(major << 5) | ai]) + n.to_bytes(size, "big")
    raise ValueError("integer too large for CBOR head")


def cbor_encode(x):
    """A small CBOR (RFC 8949) encoder: int, float (always 64-bit), str, bytes, bool, None, list, dict. Deterministic length-minimal heads."""
    if x is None:
        return b"\xf6"
    if x is True:
        return b"\xf5"
    if x is False:
        return b"\xf4"
    if isinstance(x, int):
        return _cbor_head(0, x) if x >= 0 else _cbor_head(1, -1 - x)
    if isinstance(x, float):
        return b"\xfb" + struct.pack(">d", x)
    if isinstance(x, bytes):
        return _cbor_head(2, len(x)) + x
    if isinstance(x, str):
        b = x.encode("utf-8")
        return _cbor_head(3, len(b)) + b
    if isinstance(x, (list, tuple)):
        return _cbor_head(4, len(x)) + b"".join(cbor_encode(i) for i in x)
    if isinstance(x, dict):
        return _cbor_head(5, len(x)) + b"".join(cbor_encode(k) + cbor_encode(v) for k, v in x.items())
    raise TypeError("cannot encode %r" % type(x))


def cbor_decode(b):
    """Decode one CBOR item (the subset above, plus 16/32-bit floats). Returns the value; raises ValueError on trailing bytes."""
    val, pos = _cbor_item(b, 0)
    if pos != len(b):
        raise ValueError("trailing bytes")
    return val


def _cbor_arg(b, pos, ai):
    if ai < 24:
        return ai, pos
    size = {24: 1, 25: 2, 26: 4, 27: 8}[ai]
    return int.from_bytes(b[pos:pos + size], "big"), pos + size


def _cbor_item(b, pos):
    ib = b[pos]
    major, ai = ib >> 5, ib & 31
    pos += 1
    if major == 7:
        if ai == 20: return False, pos
        if ai == 21: return True, pos
        if ai == 22: return None, pos
        if ai == 25: return float(np.frombuffer(b[pos:pos + 2], dtype=">f2")[0]), pos + 2
        if ai == 26: return struct.unpack(">f", b[pos:pos + 4])[0], pos + 4
        if ai == 27: return struct.unpack(">d", b[pos:pos + 8])[0], pos + 8
        raise ValueError("unsupported simple value")
    n, pos = _cbor_arg(b, pos, ai)
    if major == 0: return n, pos
    if major == 1: return -1 - n, pos
    if major == 2: return bytes(b[pos:pos + n]), pos + n
    if major == 3: return bytes(b[pos:pos + n]).decode("utf-8"), pos + n
    if major == 4:
        out = []
        for _ in range(n):
            v, pos = _cbor_item(b, pos); out.append(v)
        return out, pos
    if major == 5:
        out = {}
        for _ in range(n):
            k, pos = _cbor_item(b, pos); v, pos = _cbor_item(b, pos); out[k] = v
        return out, pos
    raise ValueError("unsupported major type %d" % major)


# ------------------------------------------------------------------ time series
class TimeSeries:
    """Append-only (time, value) series with range queries and bucketed downsampling."""

    def __init__(self):
        self.t, self.v = [], []

    def append(self, t, v):
        if self.t and t < self.t[-1]:
            raise ValueError("timestamps must not go backwards")
        self.t.append(float(t)); self.v.append(float(v))

    def __len__(self):
        return len(self.t)

    def range(self, t0=-math.inf, t1=math.inf):
        t, v = np.asarray(self.t), np.asarray(self.v)
        m = (t >= t0) & (t < t1)
        return t[m], v[m]

    def last(self):
        return (self.t[-1], self.v[-1]) if self.t else None


def downsample(t, v, window):
    """Bucket by floor(t / window): returns dict(t=bucket start, mean, min, max, count) as arrays (empty buckets dropped)."""
    t, v = np.asarray(t, float), np.asarray(v, float)
    idx = np.floor(t / window).astype(int)
    uniq, inv = np.unique(idx, return_inverse=True)
    cnt = np.bincount(inv)
    mean = np.bincount(inv, weights=v) / cnt
    mn = np.full(len(uniq), np.inf); mx = np.full(len(uniq), -np.inf)
    np.minimum.at(mn, inv, v); np.maximum.at(mx, inv, v)
    return dict(t=uniq * window, mean=mean, min=mn, max=mx, count=cnt)


# ------------------------------------------------------------------ streaming anomaly detectors (update(x) -> bool alarm)
class ThresholdDetector:
    """Alarm when x leaves [lo, hi]; with hysteresis h the alarm clears only after x re-enters [lo + h, hi - h]."""

    def __init__(self, lo, hi, hysteresis=0.0):
        self.lo, self.hi, self.h, self.on = lo, hi, hysteresis, False

    def update(self, x):
        if x < self.lo or x > self.hi:
            self.on = True
        elif self.lo + self.h <= x <= self.hi - self.h:
            self.on = False
        return self.on


class ZScoreDetector:
    """Alarm when |x - mean| > k std of the previous `window` samples (the current sample is excluded from its own statistics)."""

    def __init__(self, window=60, k=3.0):
        self.w, self.k = window, k
        self.buf = deque(); self.s = 0.0; self.s2 = 0.0

    def update(self, x):
        alarm = False
        n = len(self.buf)
        if n >= self.w:
            mean = self.s / n
            var = max(self.s2 / n - mean * mean, 0.0)
            sd = math.sqrt(var)
            alarm = sd > 0 and abs(x - mean) > self.k * sd
        self.buf.append(x); self.s += x; self.s2 += x * x
        if len(self.buf) > self.w:
            y = self.buf.popleft(); self.s -= y; self.s2 -= y * y
        return alarm


class EwmaDetector:
    """EWMA control chart: z_t = lam x_t + (1-lam) z_(t-1), z_0 = mu0; alarm when |z_t - mu0| > L sigma sqrt(lam/(2-lam) (1-(1-lam)^(2t)))."""

    def __init__(self, mu0, sigma, lam=0.1, L=3.0):
        self.mu0, self.sigma, self.lam, self.L = mu0, sigma, lam, L
        self.z, self.t = mu0, 0

    def limit(self):
        return self.L * self.sigma * math.sqrt(self.lam / (2 - self.lam) * (1 - (1 - self.lam) ** (2 * self.t)))

    def update(self, x):
        self.t += 1
        self.z = self.lam * x + (1 - self.lam) * self.z
        return abs(self.z - self.mu0) > self.limit()


class CusumDetector:
    """Two-sided CUSUM for a mean shift: S+ = max(0, S+ + (x - mu0) - k), S- = max(0, S- - (x - mu0) - k); alarm when either exceeds h.
    k is the allowance (about half the shift to detect), h the decision limit. Alarm latches until reset()."""

    def __init__(self, mu0, k, h):
        self.mu0, self.k, self.h = mu0, k, h
        self.sp = self.sn = 0.0

    def update(self, x):
        self.sp = max(0.0, self.sp + (x - self.mu0) - self.k)
        self.sn = max(0.0, self.sn - (x - self.mu0) - self.k)
        return self.sp > self.h or self.sn > self.h

    def reset(self):
        self.sp = self.sn = 0.0


def run_detector(det, x):
    return np.array([det.update(float(v)) for v in x])


def detection_stats(make_detector, make_series, n_runs=200, t0=300, length=600, seed=0):
    """Monte-Carlo: make_series(rng) -> (series, t0); returns dict(detected, mean_delay, false_alarms_per_1000) over n_runs."""
    rng = np.random.default_rng(seed)
    delays, fa, pre = [], 0, 0
    for _ in range(n_runs):
        x, start = make_series(rng)
        a = run_detector(make_detector(), x)
        fa += int(a[:start].sum()); pre += start
        hit = np.where(a[start:])[0]
        delays.append(hit[0] if len(hit) else None)
    ok = [d for d in delays if d is not None]
    return dict(detected=len(ok) / n_runs, mean_delay=float(np.mean(ok)) if ok else float("nan"), false_alarms_per_1000=1000.0 * fa / pre)


# ------------------------------------------------------------------ edge versus cloud arithmetic
def daily_bytes(n_nodes, period_s, bytes_per_msg):
    return n_nodes * 86400.0 / period_s * bytes_per_msg


def edge_aggregated_bytes(n_nodes, period_s, window_s, bytes_per_msg, stats=4):
    """Bytes per day if each node's readings are reduced at the edge to `stats` numbers (mean, min, max, count) per `window_s`
    and sent as one message of bytes_per_msg * stats / 1 (an upper estimate: one value-size per statistic)."""
    return n_nodes * 86400.0 / window_s * bytes_per_msg * stats


def main():
    r = dict(zone=1, soil_raw=1832, temp_c=21.5, batt_v=3.71)
    print(len(encode_json(r)), len(cbor_encode(r)), len(pack_reading(1, 1832, 21.5, 3.71)))


if __name__ == "__main__":
    main()
