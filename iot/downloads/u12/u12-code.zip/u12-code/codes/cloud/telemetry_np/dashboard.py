"""A small Flask dashboard for the greenhouse: in-memory store, per-topic alerts and stale detection, a JSON API, a one-page HTML view
(no external libraries) and an MQTT ingest coroutine built on mqtt_mini.MiniClient. See README.md."""
import asyncio
import json
import os
import sys
import time

from flask import Flask, jsonify, request, Response

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from telemetry_np import TimeSeries, ThresholdDetector, ZScoreDetector  # noqa: E402

LIMITS = {"soil": (5.0, 60.0), "temp": (5.0, 40.0), "batt": (3.0, 4.2)}      # alarm limits per quantity (assumed)


class Store:
    def __init__(self, now=time.time, period_s=60.0, stale_periods=3):
        self.now, self.period, self.stale_periods = now, period_s, stale_periods
        self.series, self.alerts, self.dets = {}, [], {}

    @staticmethod
    def quantity(topic):
        return topic.rsplit("/", 1)[-1]

    def ingest(self, topic, value, t=None):
        t = self.now() if t is None else t
        self.series.setdefault(topic, TimeSeries()).append(t, value)
        q = self.quantity(topic)
        if topic not in self.dets:
            lo, hi = LIMITS.get(q, (-1e9, 1e9))
            self.dets[topic] = (ThresholdDetector(lo, hi), ZScoreDetector(60, 4.0))
        thr, zs = self.dets[topic]
        if thr.update(value):
            self.alerts.append(dict(t=t, topic=topic, kind="limit", value=value))
        if zs.update(value):
            self.alerts.append(dict(t=t, topic=topic, kind="outlier", value=value))

    def latest(self):
        now = self.now()
        out = {}
        for topic, ts in self.series.items():
            t, v = ts.last()
            age = now - t
            out[topic] = dict(t=t, value=v, age_s=age, stale=age > self.stale_periods * self.period)
        return out


def parse_payload(raw):
    """Plain number ('1832'), or JSON number, or JSON object with a 'v' field."""
    s = raw.decode() if isinstance(raw, (bytes, bytearray)) else str(raw)
    x = json.loads(s)
    return float(x["v"] if isinstance(x, dict) else x)


PAGE = """<!doctype html><html><head><meta charset="utf-8"><title>Greenhouse dashboard</title>
<style>body{font:15px system-ui;margin:1.2rem;max-width:760px}table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #ccc;padding:.3rem .5rem;text-align:left}
.stale{color:#b00}.ok{color:#070}svg{width:100%;height:60px}</style></head><body><h1>Greenhouse dashboard</h1>
<h2>Latest readings</h2><table id="t"><tr><th>topic</th><th>value</th><th>age (s)</th><th>status</th></tr></table>
<h2>Alerts</h2><ul id="a"></ul><script>
async function tick(){const L=await (await fetch('/api/latest')).json();let h='<tr><th>topic</th><th>value</th><th>age (s)</th><th>status</th></tr>';
for(const k in L){h+=`<tr><td>${k}</td><td>${L[k].value}</td><td>${L[k].age_s.toFixed(0)}</td><td class="${L[k].stale?'stale':'ok'}">${L[k].stale?'stale':'fresh'}</td></tr>`}
document.getElementById('t').innerHTML=h;const A=await (await fetch('/api/alerts')).json();
document.getElementById('a').innerHTML=A.slice(-10).reverse().map(a=>`<li>${a.kind}: ${a.topic} = ${a.value}</li>`).join('')}
tick();setInterval(tick,5000)</script></body></html>"""


def create_app(store=None):
    store = store or Store()
    app = Flask(__name__)
    app.store = store

    @app.get("/")
    def index():
        return Response(PAGE, mimetype="text/html")

    @app.get("/api/latest")
    def latest():
        return jsonify(store.latest())

    @app.get("/api/series")
    def series():
        topic = request.args.get("topic", "")
        since = float(request.args.get("since", "-inf"))
        if topic not in store.series:
            return jsonify(error="unknown topic"), 404
        t, v = store.series[topic].range(since)
        return jsonify(topic=topic, t=t.tolist(), v=v.tolist())

    @app.get("/api/alerts")
    def alerts():
        return jsonify(store.alerts)

    @app.post("/api/ingest")
    def ingest():
        d = request.get_json(force=True)
        try:
            store.ingest(d["topic"], float(d["value"]), d.get("t"))
        except (KeyError, ValueError, TypeError) as e:
            return jsonify(error=str(e)), 400
        return jsonify(ok=True)

    return app


async def mqtt_ingest(store, host, port, filters=("greenhouse/+/soil", "greenhouse/+/temp"), client_id="dashboard", stop=None):
    """Subscribe to the filters on an MQTT broker and feed every message to store.ingest until `stop` (an asyncio.Event) is set."""
    from client import MiniClient                                        # mqtt_mini's client; path is added by the caller
    c = MiniClient(client_id, 30)
    await c.connect(host, port)
    await c.subscribe([(f, 1) for f in filters])
    try:
        while stop is None or not stop.is_set():
            try:
                m = await c.get(0.2)
            except asyncio.TimeoutError:
                continue
            try:
                store.ingest(m["topic"], parse_payload(m["payload"]))
            except (ValueError, KeyError, json.JSONDecodeError):
                pass
    finally:
        await c.disconnect()


if __name__ == "__main__":
    create_app().run(port=5000)
