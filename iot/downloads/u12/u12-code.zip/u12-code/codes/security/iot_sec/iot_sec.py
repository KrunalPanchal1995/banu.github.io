"""IoT security toolkit for Unit 7. Standard library, plus the optional `cryptography` package for Ed25519 (OTA) and certificates (TLS meter).

Contents: password entropy and dictionary-attack arithmetic; per-device keys and HMAC-authenticated commands with replay protection;
Ed25519-signed OTA manifests; MQTT topic ACLs (wildcard-aware coverage of subscription filters); an in-memory TLS handshake meter. See README.md.
"""
import hashlib
import hmac
import math
import os
import re
import struct
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "net", "mqtt_mini"))
import mqtt_proto as P  # noqa: E402  (topic matching shared with the broker)

try:
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.exceptions import InvalidSignature
    HAVE_CRYPTO = True
except Exception:                                   # pragma: no cover
    HAVE_CRYPTO = False


# ------------------------------------------------------------------ passwords
def password_entropy_bits(length, alphabet_size):
    """Entropy in bits of a password of `length` symbols drawn uniformly at random from an alphabet."""
    return length * math.log2(alphabet_size)


def expected_guesses(bits):
    """Average number of guesses to find a secret of `bits` bits of entropy by exhaustive search: 2^(bits-1)."""
    return 2.0 ** (bits - 1)


def time_to_crack_s(bits, guesses_per_s):
    return expected_guesses(bits) / guesses_per_s


def zipf_weights(n, s=1.0):
    w = [1.0 / (r ** s) for r in range(1, n + 1)]
    t = sum(w)
    return [x / t for x in w]


def dictionary_coverage(dict_size, n_creds=200, s=1.0):
    """Fraction of default-credential devices that an attacker's dictionary of the `dict_size` most popular credentials covers,
    when device credentials are drawn from a Zipf(s) popularity over `n_creds` possible defaults (ASSUMED popularity model)."""
    return sum(zipf_weights(n_creds, s)[:dict_size])


# ------------------------------------------------------------------ authenticated commands
def derive_key(master, device_id):
    """Per-device key: HMAC-SHA256(master, 'device-key|' + id). Compromise of one device key reveals nothing about another."""
    return hmac.new(master, b"device-key|" + device_id.encode(), hashlib.sha256).digest()


def sign_command(key, counter, cmd, tag_len=8):
    """Envelope = counter (4 bytes, big-endian) + command bytes + truncated HMAC-SHA256 tag over (counter + command)."""
    body = struct.pack(">I", counter) + cmd
    return body + hmac.new(key, body, hashlib.sha256).digest()[:tag_len]


def verify_command(key, envelope, last_counter, tag_len=8):
    """Returns (ok, reason, command, new_counter). reason in {'ok','short','bad_tag','replay'}. The counter must be strictly greater than the last accepted one."""
    if len(envelope) < 4 + tag_len:
        return False, "short", None, last_counter
    body, tag = envelope[:-tag_len], envelope[-tag_len:]
    if not hmac.compare_digest(hmac.new(key, body, hashlib.sha256).digest()[:tag_len], tag):
        return False, "bad_tag", None, last_counter
    counter = struct.unpack(">I", body[:4])[0]
    if counter <= last_counter:
        return False, "replay", None, last_counter
    return True, "ok", body[4:], counter


def forgery_probability(tag_bytes):
    """Probability that one random guess of a t-byte tag is accepted: 2^(-8 t)."""
    return 2.0 ** (-8 * tag_bytes)


# ------------------------------------------------------------------ signed OTA manifests (Ed25519)
def _need_crypto():
    if not HAVE_CRYPTO:
        raise RuntimeError("the 'cryptography' package is required for OTA signing")


def make_keypair():
    _need_crypto()
    sk = ed25519.Ed25519PrivateKey.generate()
    return sk, sk.public_key()


def make_manifest(version, image, sk):
    """Manifest = version (4 bytes) + length (4 bytes) + SHA-256 of the image (32 bytes) + Ed25519 signature (64 bytes) over the first 40 bytes."""
    _need_crypto()
    head = struct.pack(">II", version, len(image)) + hashlib.sha256(image).digest()
    return head + sk.sign(head)


def verify_ota(manifest, image, pk, current_version):
    """Checks, in this order: manifest size, signature, version strictly newer (anti-rollback), length, image hash. Returns (ok, reason)."""
    _need_crypto()
    if len(manifest) != 104:
        return False, "bad_manifest"
    head, sig = manifest[:40], manifest[40:]
    try:
        pk.verify(sig, head)
    except InvalidSignature:
        return False, "bad_signature"
    version, length = struct.unpack(">II", head[:8])
    if version <= current_version:
        return False, "rollback"
    if length != len(image):
        return False, "bad_length"
    if hashlib.sha256(image).digest() != head[8:]:
        return False, "bad_hash"
    return True, "ok"


# ------------------------------------------------------------------ MQTT ACL
def filter_covered(requested, allowed):
    """True if every topic matched by the requested filter is also matched by the allowed filter."""
    r, a = requested.split("/"), allowed.split("/")
    for i, al in enumerate(a):
        if al == "#":
            return True
        if i >= len(r):
            return False
        rl = r[i]
        if rl == "#":
            return False
        if al == "+":
            continue
        if rl == "+" or rl != al:
            return False
    return len(r) == len(a)


class Acl:
    """Allow-list of (client regex, action, topic filter). Publishing is allowed if the topic matches an allowed filter; subscribing if the
    requested filter is covered by one. Anything not listed is denied (least privilege)."""

    def __init__(self, rules):
        self.rules = [(re.compile(c), act, f) for c, act, f in rules]

    def __call__(self, client_id, action, topic):
        for cre, act, flt in self.rules:
            if act != action or not cre.fullmatch(client_id):
                continue
            if action == "pub" and P.topic_matches(flt, topic):
                return True
            if action == "sub" and filter_covered(topic, flt):
                return True
        return False


def main():
    print("12 random alphanumeric characters:", round(password_entropy_bits(12, 62), 1), "bits")
    print("coverage of a 62-credential dictionary:", round(dictionary_coverage(62), 3))


if __name__ == "__main__":
    main()
