import asyncio
import math
import os
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(HERE, "..", "..", "..", "net", "mqtt_mini"))
import iot_sec as S  # noqa: E402
import mqtt_proto as P  # noqa: E402

needs_crypto = pytest.mark.skipif(not S.HAVE_CRYPTO, reason="cryptography not installed")


def test_password_arithmetic():
    assert abs(S.password_entropy_bits(4, 10) - 13.2877) < 1e-3 and abs(S.password_entropy_bits(12, 62) - 71.45) < 0.01
    assert S.expected_guesses(10) == 512 and abs(S.time_to_crack_s(40, 1e6) - 2 ** 39 / 1e6) < 1e-6
    assert abs(S.dictionary_coverage(200) - 1.0) < 1e-12 and S.dictionary_coverage(1) < S.dictionary_coverage(62) < 1.0


def test_hmac_accepts_good_rejects_forged_tampered_replayed_and_short():
    key = S.derive_key(b"master", "rover1")
    env = S.sign_command(key, 5, b"goto plant7")
    ok, why, cmd, ctr = S.verify_command(key, env, 4)
    assert (ok, why, cmd, ctr) == (True, "ok", b"goto plant7", 5)
    assert S.verify_command(key, env, 5)[:2] == (False, "replay") and S.verify_command(key, env, 9)[:2] == (False, "replay")
    assert S.verify_command(S.derive_key(b"master", "node1"), env, 4)[:2] == (False, "bad_tag")      # another device's key
    assert S.verify_command(key, env[:3], 0)[:2] == (False, "short")
    for i in range(len(env) * 8):                                                                     # every single-bit flip is rejected
        bad = bytearray(env); bad[i // 8] ^= 1 << (i % 8)
        assert not S.verify_command(key, bytes(bad), 0)[0]
    assert S.derive_key(b"master", "a") != S.derive_key(b"master", "b") and len(S.derive_key(b"m", "a")) == 32
    assert S.forgery_probability(8) == 2.0 ** -64 and len(env) == 4 + len(b"goto plant7") + 8


@needs_crypto
def test_ota_verification_catches_each_attack():
    sk, pk = S.make_keypair(); sk2, pk2 = S.make_keypair()
    img = os.urandom(5000); man = S.make_manifest(7, img, sk)
    assert len(man) == 104 and S.verify_ota(man, img, pk, 6) == (True, "ok")
    assert S.verify_ota(man, img[:-1] + bytes([img[-1] ^ 1]), pk, 6) == (False, "bad_hash")
    assert S.verify_ota(man, img + b"x", pk, 6) == (False, "bad_length")
    assert S.verify_ota(man, img, pk2, 6) == (False, "bad_signature")
    assert S.verify_ota(S.make_manifest(5, img, sk), img, pk, 6) == (False, "rollback") and S.verify_ota(man, img, pk, 7) == (False, "rollback")
    t = bytearray(man); t[3] ^= 1
    assert S.verify_ota(bytes(t), img, pk, 6) == (False, "bad_signature") and S.verify_ota(man[:-1], img, pk, 6) == (False, "bad_manifest")


def test_acl_coverage_and_rules():
    C = S.filter_covered
    assert C("greenhouse/zone1/soil", "greenhouse/zone1/#") and C("greenhouse/+/soil", "greenhouse/#") and not C("greenhouse/#", "greenhouse/zone1/#")
    assert C("a/b", "a/+") and not C("a/+", "a/b") and not C("#", "a/#") and C("a/#", "a/#") and not C("a", "a/b") and C("a/b/c", "+/b/+")
    acl = S.Acl([(r"node\d+", "pub", "greenhouse/+/soil"), (r"node\d+", "pub", "greenhouse/+/temp"), ("dashboard", "sub", "greenhouse/#"), ("rover", "sub", "greenhouse/rover/cmd"), ("rover", "pub", "greenhouse/rover/pose")])
    assert acl("node1", "pub", "greenhouse/zone1/soil") and not acl("node1", "pub", "greenhouse/rover/cmd") and not acl("node1", "sub", "greenhouse/#")
    assert acl("dashboard", "sub", "greenhouse/+/soil") and not acl("dashboard", "pub", "greenhouse/rover/cmd") and acl("rover", "sub", "greenhouse/rover/cmd") and not acl("rover", "sub", "greenhouse/#")
    assert not acl("stranger", "pub", "greenhouse/zone1/soil")


def test_broker_hooks_auth_and_acl_end_to_end():
    from broker import Broker
    from client import MiniClient
    users = {"node1": "s3cret-node1", "rover": "s3cret-rover", "dashboard": "s3cret-dash"}
    acl = S.Acl([("node1", "pub", "greenhouse/+/soil"), ("dashboard", "sub", "greenhouse/#"), ("rover", "sub", "greenhouse/rover/cmd"), ("dashboard", "pub", "greenhouse/rover/cmd")])
    async def go():
        b = await Broker(auth=lambda cid, u, p: users.get(cid) == (p.decode() if p else None), acl=acl).start()
        bad = MiniClient("node1", 0, username="node1", password="admin")
        with pytest.raises(ConnectionError):
            await bad.connect("127.0.0.1", b.port)
        dash = MiniClient("dashboard", 0, username="dashboard", password="s3cret-dash"); await dash.connect("127.0.0.1", b.port)
        assert await dash.subscribe([("greenhouse/#", 1)]) == [1]
        node = MiniClient("node1", 0, username="node1", password="s3cret-node1"); await node.connect("127.0.0.1", b.port)
        assert await node.subscribe([("greenhouse/#", 1)]) == [0x80]                         # a node may not read everything
        await node.publish("greenhouse/zone1/soil", b"1832", 1)
        m = await dash.get(); assert m["payload"] == b"1832"
        await node.publish("greenhouse/rover/cmd", b"forged", 1)                              # a compromised node tries to command the rover
        with pytest.raises(asyncio.TimeoutError):
            await dash.get(0.4)
        assert ("node1", "pub", "greenhouse/rover/cmd") in b.denied and ("node1", "sub", "greenhouse/#") in b.denied
        for c in (dash, node): await c.disconnect()
        await b.stop()
    asyncio.run(go())


@needs_crypto
def test_tls_meter_runs_and_resumption_is_smaller():
    import tls_cost as T
    r13 = T.measure("ec", "1.3"); r12 = T.measure("rsa", "1.2")
    for r in (r13, r12):
        assert r["full"]["c2s"] > 100 and r["full"]["s2c"] > 300 and r["full"]["flights"] >= 2
        assert r["resumed"]["reused"] and r["resumed"]["s2c"] < r["full"]["s2c"]
    assert r12["cert_der"] > r13["cert_der"] and r13["full"]["rtt_to_app"] == 1 and r12["full"]["rtt_to_app"] == 2
