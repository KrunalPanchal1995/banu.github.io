# iot_sec

> IoT security toolkit: password entropy and dictionary coverage, per-device keys and HMAC-authenticated commands with replay protection, Ed25519-signed OTA manifests, MQTT topic ACLs, and an in-memory TLS handshake cost meter.

**Topic:** security  |  **Created in session:** 007 (Unit 7)  |  **Status:** tested (6 tests + extended broker tests)

## What this code is for
Small, readable implementations of the security patterns of the greenhouse system, built on standard primitives (Python `hmac`/`hashlib`, the `cryptography` package for Ed25519 and certificates). It teaches the protocol around the primitives (envelope, counter, manifest checks, ACL coverage) and measures real TLS handshake sizes. It does NOT implement cryptographic primitives and has not been security-audited.

## Capabilities
- `password_entropy_bits(length, alphabet)`, `expected_guesses(bits)` = 2^(bits-1), `time_to_crack_s(bits, rate)`, `zipf_weights`, `dictionary_coverage(D, n_creds, s)` (assumed popularity model).
- `derive_key(master, device_id)`; `sign_command(key, counter, cmd, tag_len=8)` -> counter(4) + cmd + truncated HMAC-SHA256 tag; `verify_command(key, envelope, last_counter, tag_len)` -> (ok, reason in {ok, short, bad_tag, replay}, cmd, new_counter); `forgery_probability(tag_bytes)`.
- `make_keypair()`, `make_manifest(version, image, sk)` (104 bytes), `verify_ota(manifest, image, pk, current_version)` -> (ok, reason in {ok, bad_manifest, bad_signature, rollback, bad_length, bad_hash}).
- `filter_covered(requested, allowed)`; `Acl(rules)` callable `(client_id, action 'pub'|'sub', topic_or_filter) -> bool`, usable as the broker's `acl` hook.
- `tls_cost.measure(kind 'ec'|'rsa', version '1.3'|'1.2')` -> dict(cert_der, full, resumed) with bytes client-to-server, server-to-client, round trips to the first data byte, record overhead.

## Theory in one paragraph
Entropy H = log2 N, expected guesses 2^(H-1). HMAC tag of t bytes: forgery probability 2^(-8t) per guess; a strictly increasing counter defeats replay; per-device key = HMAC(master, id). Signed OTA: Ed25519 over version + length + SHA-256(image), then version-newer, length and hash checks. ACL coverage: a requested filter is allowed if every topic it matches is matched by an allowed filter. Derived in Unit 7, Section 3.

## Quick start
```bash
python -m pytest -q tests          # the OTA and TLS tests are skipped without the cryptography package
python ../../../sessions/007-unit7-security/figures/analysis_numbers.py
```
```python
import iot_sec as S
key = S.derive_key(b"master", "rover1"); env = S.sign_command(key, 10, b"goto plant7")
print(S.verify_command(key, env, 9))
```

## Examples
| File | Shows | Output |
|------|-------|--------|
| `example_basic.py` | scaffold placeholder; real examples: `sessions/007-unit7-security/figures/` and `analysis_log.txt` | `example_basic.png` |

## Inputs / outputs and units
Bytes, counters (integers), probabilities, bits, seconds. Commands are bytes; keys are 32-byte HMAC outputs.

## Validation
Every single-bit flip of a 23-byte envelope refused; 100,000 random envelopes accepted 0; six OTA attacks refused; ACL coverage table; broker hooks end to end (refused password, refused subscribe 0x80, dropped forged publish, denial log); TLS meter reproduces 1 round trip (TLS 1.3) vs 2 (TLS 1.2) and smaller resumed handshakes.

## Known limits and gotchas
- Not audited; do not use as a production security layer. No encryption of the command, no persistent counter store, no replay window, no key revocation.
- The counter must survive restarts (non-volatile) at both ends.
- TLS numbers are for one small self-signed certificate and OpenSSL 3.4.0; ECDSA signature length varies by a byte or two; no microcontroller timings.
- Zipf popularity and guessing rates are assumptions.

## Dependencies
Standard library; `cryptography` (OTA, TLS meter); `codes/net/mqtt_mini` (topic matching, broker hooks).

## Extending toward the open-source package
`iotrobotics/security.py`. To do: replay window, authenticated encryption, key rotation and revocation, rate limiting.
