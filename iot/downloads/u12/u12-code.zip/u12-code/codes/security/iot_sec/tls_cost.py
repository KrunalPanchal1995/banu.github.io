"""Measure the bytes and flights of a real TLS handshake in memory (ssl.MemoryBIO), for RSA-2048 or ECDSA P-256 certificates, TLS 1.2 or 1.3,
full or resumed. Needs the `cryptography` package (certificates) and Python's ssl. No sockets, no network. See README.md."""
import datetime
import os
import ssl
import tempfile

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from cryptography.x509.oid import NameOID


def make_cert(kind="ec"):
    """Self-signed certificate for 'localhost' (DNS SAN). kind: 'ec' (P-256) or 'rsa' (2048). Returns (key_pem, cert_pem, cert_der_length)."""
    key = ec.generate_private_key(ec.SECP256R1()) if kind == "ec" else rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost")])
    now = datetime.datetime(2026, 1, 1)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now).not_valid_after(now + datetime.timedelta(days=3650))
            .add_extension(x509.SubjectAlternativeName([x509.DNSName("localhost")]), critical=False).sign(key, hashes.SHA256()))
    key_pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    return key_pem, cert.public_bytes(serialization.Encoding.PEM), len(cert.public_bytes(serialization.Encoding.DER))


def _contexts(kind, version):
    key_pem, cert_pem, der = make_cert(kind)
    d = tempfile.mkdtemp()
    kp, cp = os.path.join(d, "k.pem"), os.path.join(d, "c.pem")
    open(kp, "wb").write(key_pem); open(cp, "wb").write(cert_pem)
    sctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); sctx.load_cert_chain(cp, kp)
    cctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT); cctx.load_verify_locations(cadata=cert_pem.decode())
    for ctx in (sctx, cctx):
        ctx.minimum_version = ctx.maximum_version = ssl.TLSVersion.TLSv1_3 if version == "1.3" else ssl.TLSVersion.TLSv1_2
    return sctx, cctx, der


def _handshake(sctx, cctx, session=None, app=b"x" * 31):
    """Run one handshake plus one application record each way; returns dict(c2s, s2c, flights, rtt_to_app, app_overhead, session, reused).
    rtt_to_app = server flights received before the client can send application data (TLS 1.3: 1, TLS 1.2: 2); flights also counts TLS 1.3 session tickets."""
    cin, cout, sin, sout = (ssl.MemoryBIO() for _ in range(4))
    c = cctx.wrap_bio(cin, cout, server_hostname="localhost", session=session)
    s = sctx.wrap_bio(sin, sout, server_side=True)
    c2s = s2c = flights = sflights = 0
    rtt_to_app = None
    last = None
    c_done = s_done = False
    for _ in range(50):
        for side, ssl_obj, out_bio, in_bio, name in ((0, c, cout, sin, "c"), (1, s, sout, cin, "s")):
            done = c_done if side == 0 else s_done
            if not done:
                try:
                    ssl_obj.do_handshake()
                    if side == 0:
                        c_done = True; rtt_to_app = sflights
                    else: s_done = True
                except ssl.SSLWantReadError:
                    pass
            data = out_bio.read()
            if data:
                if name == "c": c2s += len(data)
                else: s2c += len(data)
                if last != name:
                    flights += 1; last = name
                    if name == "s":
                        sflights += 1
                in_bio.write(data)
        if c_done and s_done:
            break
    # application data each way (also delivers the TLS 1.3 session ticket to the client)
    c.write(app); data = cout.read(); app_overhead = len(data) - len(app); sin.write(data); s.read(len(app))
    s.write(b"ok"); sdata = sout.read(); cin.write(sdata)
    try:
        c.read(2)
    except ssl.SSLWantReadError:
        pass
    return dict(c2s=c2s, s2c=s2c, flights=flights, rtt_to_app=rtt_to_app, app_overhead=app_overhead, session=c.session, reused=c.session_reused)


def measure(kind="ec", version="1.3"):
    """Full handshake and a resumed one for the given certificate kind and TLS version."""
    sctx, cctx, der = _contexts(kind, version)
    full = _handshake(sctx, cctx)
    resumed = _handshake(sctx, cctx, session=full["session"])
    return dict(cert_der=der, full=full, resumed=resumed)
