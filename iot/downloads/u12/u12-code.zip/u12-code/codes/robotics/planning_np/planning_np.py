"""Path planning and navigation for the Smart Greenhouse Rover (Unit 11): grid planners (BFS, Dijkstra, A*), obstacle inflation, line-of-sight smoothing,
pure-pursuit path following, visiting order of several goals, braking and watchdog budgets, and a miniature ROS-style node graph with a tf tree.

Grids are boolean arrays [row, col] with True = occupied, cell size `res` metres, cell (r, c) centred at ((c + 0.5) res, (r + 0.5) res).
See README.md. Depends on kinematics_np (Unit 8): se2, se2_inv, RoverParams, Rover.
"""
import heapq
import itertools
import math
import os
import sys
from collections import deque

import numpy as np
from scipy.ndimage import distance_transform_edt

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "kinematics_np"))
from kinematics_np import Rover, RoverParams, se2, se2_inv, wrap_angle  # noqa: E402

SQ2 = math.sqrt(2.0)
N8 = [(-1, 0, 1.0), (1, 0, 1.0), (0, -1, 1.0), (0, 1, 1.0), (-1, -1, SQ2), (-1, 1, SQ2), (1, -1, SQ2), (1, 1, SQ2)]
N4 = N8[:4]


def cell_center(rc, res):
    return ((rc[1] + 0.5) * res, (rc[0] + 0.5) * res)


def to_cell(x, y, res):
    return (int(math.floor(y / res)), int(math.floor(x / res)))


# ------------------------------------------------------------------ inflation
def clearance_map(occ, res):
    """Distance (m) from each cell centre to the nearest occupied cell centre (large where there is none)."""
    return distance_transform_edt(~occ) * res


def inflate(occ, radius, res):
    """Occupied grid grown by `radius` metres (the rover's radius plus a margin): cells whose centre is closer than `radius` to an occupied cell centre."""
    return clearance_map(occ, res) < radius


def disc_collides(occ, xy, radius, res):
    """True if a disc of `radius` metres at the point xy (m) overlaps an occupied cell (cell squares, not just centres) or leaves the grid."""
    x, y = xy
    r0, r1 = int(math.floor((y - radius) / res)), int(math.floor((y + radius) / res))
    c0, c1 = int(math.floor((x - radius) / res)), int(math.floor((x + radius) / res))
    if r0 < 0 or c0 < 0 or r1 >= occ.shape[0] or c1 >= occ.shape[1]:
        return True
    for r in range(r0, r1 + 1):
        for c in range(c0, c1 + 1):
            if occ[r, c]:
                nx_, ny_ = min(max(x, c * res), (c + 1) * res), min(max(y, r * res), (r + 1) * res)
                if (nx_ - x) ** 2 + (ny_ - y) ** 2 < radius ** 2:
                    return True
    return False


def path_collisions(occ, path_xy, radius, res, step=None):
    """Number of sample points along a polyline (spacing `step`, default res/2) at which the rover's disc touches an obstacle."""
    step = step or res / 2
    n = 0
    for a, b in zip(path_xy[:-1], path_xy[1:]):
        d = math.hypot(b[0] - a[0], b[1] - a[1]); k = max(1, int(d / step))
        for i in range(k):
            t = i / k
            n += disc_collides(occ, (a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])), radius, res)
    return n


# ------------------------------------------------------------------ graph search on the grid
def _neighbours(blocked, rc, conn):
    r, c = rc
    for dr, dc, w in (N8 if conn == 8 else N4):
        rr, cc = r + dr, c + dc
        if 0 <= rr < blocked.shape[0] and 0 <= cc < blocked.shape[1] and not blocked[rr, cc]:
            if dr != 0 and dc != 0 and (blocked[r + dr, c] or blocked[r, c + dc]):
                continue                                           # no corner cutting
            yield (rr, cc), w


def _path(parent, goal):
    p = [goal]
    while parent[p[-1]] is not None:
        p.append(parent[p[-1]])
    return p[::-1]


def path_length(path, res):
    return sum(math.hypot(b[0] - a[0], b[1] - a[1]) for a, b in zip(path[:-1], path[1:])) * res


def bfs(blocked, start, goal, conn=8):
    """Breadth-first search: the path with the fewest steps (each step costs 1, diagonal or not). Returns dict(path, cost (m-free steps), expanded) or path=None."""
    q = deque([start]); parent = {start: None}; exp = 0; seen = []
    while q:
        u = q.popleft(); exp += 1; seen.append(u)
        if u == goal:
            p = _path(parent, goal); return dict(path=p, steps=len(p) - 1, expanded=exp, closed=seen)
        for v, _ in _neighbours(blocked, u, conn):
            if v not in parent:
                parent[v] = u; q.append(v)
    return dict(path=None, steps=None, expanded=exp, closed=seen)


def octile(a, b):
    dx, dy = abs(a[0] - b[0]), abs(a[1] - b[1])
    return (dx + dy) + (SQ2 - 2.0) * min(dx, dy)


def euclid(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def astar(blocked, start, goal, conn=8, h=octile, weight=1.0):
    """A*: expand the node with the smallest g + weight*h. With h = 0 this is Dijkstra. Costs are in cells (1 or sqrt 2 per move). Returns dict(path, cost, expanded)."""
    hf = (lambda a, b: 0.0) if h in (None, "zero") else h
    g = {start: 0.0}; parent = {start: None}; heap = [(weight * hf(start, goal), 0.0, start)]; closed = set(); exp = 0
    while heap:
        f, gu, u = heapq.heappop(heap)
        if u in closed:
            continue
        closed.add(u); exp += 1
        if u == goal:
            return dict(path=_path(parent, goal), cost=gu, expanded=exp, closed=closed)
        for v, w in _neighbours(blocked, u, conn):
            ng = gu + w
            if ng < g.get(v, 1e18):
                g[v] = ng; parent[v] = u; heapq.heappush(heap, (ng + weight * hf(v, goal), ng, v))
    return dict(path=None, cost=None, expanded=exp, closed=closed)


def dijkstra(blocked, start, goal, conn=8):
    return astar(blocked, start, goal, conn, h=None)


def line_free(blocked, a, b):
    """True if the straight segment between cells a and b passes only through free cells (supercover sampling at a quarter-cell step)."""
    n = int(max(abs(a[0] - b[0]), abs(a[1] - b[1])) * 4) + 1
    for i in range(n + 1):
        t = i / n
        r = int(math.floor(a[0] + 0.5 + t * (b[0] - a[0]))); c = int(math.floor(a[1] + 0.5 + t * (b[1] - a[1])))
        if blocked[r, c]:
            return False
    return True


def shortcut(blocked, path):
    """Line-of-sight smoothing: from each waypoint jump to the farthest later waypoint that is visible."""
    out = [path[0]]; i = 0
    while i < len(path) - 1:
        j = len(path) - 1
        while j > i + 1 and not line_free(blocked, path[i], path[j]):
            j -= 1
        out.append(path[j]); i = j
    return out


# ------------------------------------------------------------------ visiting several goals
def visit_orders(dist, start=0):
    """dist: (n, n) matrix of path lengths, node `start` first. Returns (nearest_neighbour_order, nn_length, best_order, best_length) (best by brute force)."""
    n = len(dist); left = set(range(n)) - {start}; order = [start]; tot = 0.0
    while left:
        j = min(left, key=lambda k: dist[order[-1]][k]); tot += dist[order[-1]][j]; order.append(j); left.remove(j)
    best, bl = None, 1e18
    for perm in itertools.permutations(sorted(set(range(n)) - {start})):
        L = dist[start][perm[0]] + sum(dist[a][b] for a, b in zip(perm[:-1], perm[1:]))
        if L < bl:
            bl, best = L, [start, *perm]
    return order, tot, best, bl


# ------------------------------------------------------------------ pure pursuit
def pure_pursuit_target(path_xy, pose, lookahead, start_idx=0):
    """First point of the polyline (beyond the closest segment) at distance >= lookahead from the rover, interpolated on the segment. Returns (point, index of that segment)."""
    px, py = pose[0], pose[1]
    best_i = start_idx
    dmin = 1e18
    for i in range(start_idx, min(len(path_xy) - 1, start_idx + 60)):
        a, b = np.array(path_xy[i]), np.array(path_xy[i + 1]); ab = b - a; t = np.clip(((px - a[0]) * ab[0] + (py - a[1]) * ab[1]) / max(ab @ ab, 1e-12), 0, 1)
        d = math.hypot(px - (a + t * ab)[0], py - (a + t * ab)[1])
        if d < dmin - 1e-12:
            dmin, best_i = d, i
    for i in range(best_i, len(path_xy) - 1):
        a, b = np.array(path_xy[i], float), np.array(path_xy[i + 1], float)
        if math.hypot(b[0] - px, b[1] - py) >= lookahead:
            f = a - np.array([px, py]); d = b - a; A = d @ d; B = 2 * f @ d; C = f @ f - lookahead ** 2
            disc = B * B - 4 * A * C
            if disc >= 0 and A > 0:
                t = (-B + math.sqrt(disc)) / (2 * A)
                if 0 <= t <= 1:
                    return a + t * d, best_i
                return b, i
            return b, i
    return np.array(path_xy[-1], float), len(path_xy) - 2


def curvature_to_target(pose, target):
    """Pure-pursuit curvature kappa = 2 y_r / L^2, with y_r the target's lateral offset in the rover frame and L its distance."""
    dx, dy = target[0] - pose[0], target[1] - pose[1]
    c, s = math.cos(pose[2]), math.sin(pose[2])
    yr = -s * dx + c * dy
    L2 = dx * dx + dy * dy
    return 2.0 * yr / max(L2, 1e-12)


def cross_track(path_xy, p):
    best = 1e18
    for a, b in zip(path_xy[:-1], path_xy[1:]):
        a, b = np.array(a), np.array(b); ab = b - a; t = np.clip(((p[0] - a[0]) * ab[0] + (p[1] - a[1]) * ab[1]) / max(ab @ ab, 1e-12), 0, 1)
        best = min(best, math.hypot(p[0] - (a + t * ab)[0], p[1] - (a + t * ab)[1]))
    return best


def follow_path(path_xy, lookahead=0.4, v_nominal=0.5, dt=0.02, lag=0.03, start_pose=None, goal_tol=0.05, t_max=120.0, params=None, w_noise=0.0, seed=0):
    """Drive the shared Rover along a polyline with pure pursuit. The commanded turn rate passes through a first-order lag (default 30 ms, the closed wheel loops of Unit 9).
    Speed is reduced so that the wheels stay within the motor limit. Returns dict(pose (n,3), t, max_xte, rms_xte, finished, time)."""
    p = params or RoverParams()
    pose0 = start_pose if start_pose is not None else (path_xy[0][0], path_xy[0][1], math.atan2(path_xy[1][1] - path_xy[0][1], path_xy[1][0] - path_xy[0][0]))
    rv = Rover(p, pose=pose0); rng = np.random.default_rng(seed)
    w_cmd_filt = 0.0; idx = 0; poses = [rv.pose.copy()]; ts = [0.0]; xte = []; t = 0.0; finished = False
    while t < t_max:
        tgt, idx = pure_pursuit_target(path_xy, rv.pose, lookahead, idx)
        if math.hypot(path_xy[-1][0] - rv.pose[0], path_xy[-1][1] - rv.pose[1]) < goal_tol:
            finished = True; break
        kap = curvature_to_target(rv.pose, tgt)
        v = v_nominal
        vmax = p.v_wheel_max
        if abs(kap) * p.track / 2 * v + v > vmax:                  # keep the outer wheel within the motor limit
            v = max(0.05, vmax / (1 + abs(kap) * p.track / 2))
        if math.hypot(path_xy[-1][0] - rv.pose[0], path_xy[-1][1] - rv.pose[1]) < 2 * lookahead:
            v = max(0.1, min(v, 1.0 * math.hypot(path_xy[-1][0] - rv.pose[0], path_xy[-1][1] - rv.pose[1])))
        w_cmd = v * kap
        w_cmd_filt += (w_cmd - w_cmd_filt) * (1 - math.exp(-dt / lag)) if lag > 0 else w_cmd - w_cmd_filt
        w = w_cmd_filt + (rng.normal(0, w_noise) if w_noise else 0.0)
        vl, vr = v - 0.5 * w * p.track, v + 0.5 * w * p.track
        rv.step(vl / p.wheel_r, vr / p.wheel_r, dt)
        t += dt; poses.append(rv.pose.copy()); ts.append(t); xte.append(cross_track(path_xy, rv.pose))
    xte = np.array(xte) if xte else np.zeros(1)
    return dict(pose=np.array(poses), t=np.array(ts), max_xte=float(xte.max()), rms_xte=float(np.sqrt(np.mean(xte ** 2))), finished=finished, time=t)


# ------------------------------------------------------------------ braking, latency and watchdog budgets (closes R3 and S1)
G = 9.81


def braking_distance(v, mu=0.6):
    return v * v / (2 * mu * G)


def stopping_distance(v, latency, mu=0.6):
    return v * latency + braking_distance(v, mu)


def max_safe_speed(room, latency, mu=0.6):
    """Largest speed v with v*latency + v^2/(2 mu g) <= room (positive root of the quadratic)."""
    a = 1.0 / (2 * mu * G)
    return (-latency + math.sqrt(latency ** 2 + 4 * a * room)) / (2 * a)


def max_ping_period(v, stop_limit, edge_latency, mu=0.6):
    """Longest sensor period T such that the worst-case latency T + edge_latency still stops within stop_limit (m)."""
    return (stop_limit - braking_distance(v, mu)) / v - edge_latency


def simulate_stop(v, obstacle_distance, ping_period, edge_latency, mu=0.6, phase=0.0, dt=0.0005):
    """Rover at speed v, an obstacle that becomes detectable at `obstacle_distance` ahead. The next ping (after the obstacle appears) comes `phase` * ping_period later;
    the command takes effect `edge_latency` after the ping; then it brakes at mu g. Returns the remaining gap (m) (negative = collision)."""
    t_detect = phase * ping_period + edge_latency
    x = 0.0; vel = v; t = 0.0
    while vel > 0:
        if t >= t_detect:
            vel = max(0.0, vel - mu * G * dt)
        x += vel * dt; t += dt
    return obstacle_distance - x


def watchdog_stop_distance(v, timeout, edge_latency=0.015, mu=0.6):
    """Distance travelled after the last good command when the rover stops on a command timeout: v (timeout + edge_latency) + braking."""
    return stopping_distance(v, timeout + edge_latency, mu)


# ------------------------------------------------------------------ a miniature ROS-style graph (concepts only: not ROS)
class Bus:
    """Named topics with typed messages (publish/subscribe), services (request/response) and a clock. Nodes are plain callables registered by name."""

    def __init__(self):
        self.subs, self.types, self.services, self.log, self.t = {}, {}, {}, [], 0.0

    def advertise(self, topic, msg_type):
        self.types[topic] = msg_type; self.subs.setdefault(topic, [])

    def subscribe(self, topic, callback):
        self.subs.setdefault(topic, []).append(callback)

    def publish(self, topic, msg):
        if topic in self.types and not isinstance(msg, self.types[topic]):
            raise TypeError(f"topic {topic} carries {self.types[topic].__name__}, got {type(msg).__name__}")
        self.log.append((self.t, topic))
        for cb in self.subs.get(topic, []):
            cb(msg)

    def add_service(self, name, fn):
        self.services[name] = fn

    def call(self, name, request):
        return self.services[name](request)


class TFTree:
    """A tree of coordinate frames with SE(2) transforms (Unit 8). set(parent, child, (x, y, theta)); lookup(a, b) returns the pose of frame b expressed in frame a."""

    def __init__(self):
        self.parent, self.T = {}, {}

    def set(self, parent, child, pose):
        self.parent[child] = parent; self.T[child] = se2(*pose)

    def _to_root(self, f):
        T = np.eye(3)
        while f in self.parent:
            T = self.T[f] @ T; f = self.parent[f]
        return f, T

    def lookup(self, a, b):
        ra, Ta = self._to_root(a); rb, Tb = self._to_root(b)
        if ra != rb:
            raise KeyError(f"frames {a} and {b} are not connected")
        return se2_inv(Ta) @ Tb


def main():
    occ = np.zeros((60, 100), bool); occ[:, 0] = occ[:, -1] = occ[0, :] = occ[-1, :] = True; occ[10:50, 40:44] = True
    a = astar(occ, (5, 5), (55, 95)); b = dijkstra(occ, (5, 5), (55, 95))
    print("A* cost", round(a["cost"], 3), "expanded", a["expanded"], "| Dijkstra cost", round(b["cost"], 3), "expanded", b["expanded"])


if __name__ == "__main__":
    main()
