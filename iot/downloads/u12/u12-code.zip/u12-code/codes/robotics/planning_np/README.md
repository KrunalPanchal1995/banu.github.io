# planning_np

> Grid planners (BFS, Dijkstra, A* with weights), obstacle inflation, line-of-sight smoothing, pure-pursuit path following on the shared rover, visiting order, stopping and watchdog budgets, and a miniature ROS-style Bus and TFTree.

**Topic:** robotics  |  **Created in session:** 011 (Unit 11)  |  **Status:** tested (8 tests; planners cross-checked with networkx); simulation only, ROS 2 not run

## What this code is for
Plans and follows paths for the Smart Greenhouse Rover on a boolean occupancy grid (True = occupied), and answers the budget questions of Unit 11 (sensor ping period, command timeout). Use it to compare planners by cells expanded, to see what inflation does, or to size a stop. Assumed: body circle 0.13 m, margin 2 cm, mu 0.6.

## Capabilities
- `bfs(blocked, start, goal, conn=8)`, `dijkstra(...)`, `astar(blocked, start, goal, conn=8, h=octile, weight=1.0)` -> dict(path, cost (cells), expanded, closed).
- `octile`, `euclid`; `path_length(path, res)`; `line_free`, `shortcut(blocked, path)`.
- `clearance_map`, `inflate(occ, radius, res)`, `disc_collides`, `path_collisions`.
- `pure_pursuit_target`, `curvature_to_target`, `follow_path(path_xy, lookahead, v_nominal, lag=0.03, ...)` -> dict(pose, max_xte, rms_xte, finished, time).
- `visit_orders(dist)` -> (nearest-neighbour order, length, best order, length).
- `braking_distance`, `stopping_distance`, `max_safe_speed`, `max_ping_period`, `simulate_stop`, `watchdog_stop_distance`.
- `Bus` (typed topics, services), `TFTree` (SE(2) frames, `lookup(a, b)`).

## Theory in one paragraph
A*: order by g + w h; admissible octile h = (D1+D2) + (sqrt2 - 2) min(D1, D2). Inflation radius = body radius + half a cell + margin. Pure pursuit kappa = 2y/L^2, error dynamics e'' + (2v/Ld) e' + (2v^2/Ld^2) e = 0. Stop: s = v (T_ping + t_edge) + v^2/(2 mu g). Derived in Unit 11 Sections 3.1 to 3.4.

## Quick start
```bash
python -m pytest tests -q
```
```python
import planning_np as P
r = P.astar(infl, (11, 11), (100, 120)); print(r["cost"] * 0.05, r["expanded"])
print(P.max_ping_period(0.5, 0.05, 0.015))   # 0.0425 s
```

## Tests
8 tests in `tests/test_planning_np.py` (networkx cross-checks, weights, BFS, corners, inflation, pure pursuit, budgets, visiting order, tf and bus).
