import math
import os
import sys

import networkx as nx
import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import planning_np as P  # noqa: E402


def random_grid(seed, n=30, density=0.25):
    rng = np.random.default_rng(seed)
    g = rng.random((n, n)) < density
    g[0, 0] = g[-1, -1] = False
    return g


def nx_cost(occ, s, t, conn=8):
    G = nx.Graph()
    R, C = occ.shape
    for r in range(R):
        for c in range(C):
            if occ[r, c]:
                continue
            for dr, dc, w in (P.N8 if conn == 8 else P.N4):
                rr, cc = r + dr, c + dc
                if 0 <= rr < R and 0 <= cc < C and not occ[rr, cc] and not (dr and dc and (occ[r + dr, c] or occ[r, c + dc])):
                    G.add_edge((r, c), (rr, cc), weight=w)
    try:
        return nx.shortest_path_length(G, s, t, weight="weight")
    except (nx.NetworkXNoPath, nx.NodeNotFound):
        return None


def test_astar_and_dijkstra_match_networkx():
    for seed in range(8):
        g = random_grid(seed)
        s, t = (0, 0), (29, 29)
        ref = nx_cost(g, s, t)
        a, d = P.astar(g, s, t), P.dijkstra(g, s, t)
        if ref is None:
            assert a["path"] is None and d["path"] is None
        else:
            assert abs(a["cost"] - ref) < 1e-9 and abs(d["cost"] - ref) < 1e-9
            assert a["expanded"] <= d["expanded"]


def test_weighted_astar_bound_and_inadmissible_heuristic():
    g = random_grid(3, 40, 0.2)
    s, t = (0, 0), (39, 39)
    opt = P.astar(g, s, t)["cost"]
    w2 = P.astar(g, s, t, weight=2.0)
    assert opt <= w2["cost"] <= 2.0 * opt + 1e-9 and w2["expanded"] <= P.astar(g, s, t)["expanded"]
    # a heuristic that overestimates (x3) can return a longer path in an open field with a wall to go around
    g = np.zeros((40, 40), bool); g[5:35, 20] = True
    s, t = (20, 5), (20, 35)
    assert P.astar(g, s, t, h=lambda a, b: 3 * P.octile(a, b))["cost"] >= P.astar(g, s, t)["cost"] - 1e-9


def test_bfs_minimises_steps_not_length():
    g = random_grid(5)
    r = P.bfs(g, (0, 0), (29, 29))
    if r["path"] is not None:
        G = nx.Graph()
        assert r["steps"] == nx.shortest_path_length(_unweighted(g), (0, 0), (29, 29))


def _unweighted(occ):
    G = nx.Graph()
    R, C = occ.shape
    for r in range(R):
        for c in range(C):
            if occ[r, c]:
                continue
            for dr, dc, w in P.N8:
                rr, cc = r + dr, c + dc
                if 0 <= rr < R and 0 <= cc < C and not occ[rr, cc] and not (dr and dc and (occ[r + dr, c] or occ[r, c + dc])):
                    G.add_edge((r, c), (rr, cc))
    return G


def test_no_corner_cutting():
    g = np.zeros((3, 3), bool); g[0, 1] = g[1, 0] = True
    assert P.astar(g, (0, 0), (1, 1))["path"] is None


def test_inflation_and_disc_collision():
    occ = np.zeros((40, 40), bool); occ[20, 20] = True
    inf = P.inflate(occ, 0.16, 0.05)
    assert inf[20, 23] and inf[23, 20] and not inf[20, 24] and inf[22, 22] and not inf[23, 23]
    assert P.disc_collides(occ, (1.025, 1.025), 0.05, 0.05) and not P.disc_collides(occ, (0.5, 0.5), 0.05, 0.05)
    assert P.disc_collides(occ, (0.02, 1.0), 0.05, 0.05)       # leaves the grid


def test_pure_pursuit_tracks_a_line_and_a_circle():
    line = [(0.0, 0.0), (5.0, 0.0)]
    r = P.follow_path(line, 0.4, 0.5, start_pose=(0, 0.05, 0.0))
    assert r["finished"] and r["max_xte"] < 0.06
    th = np.linspace(0, math.pi, 120); arc = [(1.0 * math.sin(a), 1.0 - math.cos(a)) for a in th]
    r = P.follow_path(arc, 0.3, 0.3)
    assert r["finished"] and r["max_xte"] < 0.05


def test_stop_budgets():
    for lat in (0.015, 0.1, 0.15):
        v = P.max_safe_speed(1.0, lat)
        assert abs(P.stopping_distance(v, lat) - 1.0) < 1e-9
    gap = P.simulate_stop(0.5, 1.0, 0.0, 0.075)
    assert abs(gap - (1.0 - P.stopping_distance(0.5, 0.075))) < 2e-3
    T = P.max_ping_period(0.5, 0.05, 0.015)
    assert abs(P.stopping_distance(0.5, T + 0.015) - 0.05) < 1e-9


def test_visit_orders_and_tf_and_bus():
    d = np.array([[0, 2, 9, 10], [2, 0, 6, 4], [9, 6, 0, 3], [10, 4, 3, 0]], float)
    nn, nl, best, bl = P.visit_orders(d)
    assert bl <= nl + 1e-12 and sorted(best) == [0, 1, 2, 3]
    tf = P.TFTree(); tf.set("map", "odom", (1.0, 2.0, math.pi / 2)); tf.set("odom", "base", (1.0, 0.0, 0.0)); tf.set("base", "sensor", (0.1, 0.0, 0.0))
    T = tf.lookup("map", "sensor")
    assert np.allclose(T[:2, 2], [1.0, 3.1]) and np.allclose(tf.lookup("sensor", "map") @ T, np.eye(3))
    bus = P.Bus(); bus.advertise("/range", float); got = []
    bus.subscribe("/range", got.append); bus.publish("/range", 1.5); assert got == [1.5]
    with pytest.raises(TypeError):
        bus.publish("/range", "far")
    bus.add_service("/reset", lambda req: req + 1); assert bus.call("/reset", 1) == 2
