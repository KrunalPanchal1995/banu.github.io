import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import control_np as C  # noqa: E402


def test_motor_matches_unit2_noload_speed_and_first_order_response():
    m = C.WheelMotor()
    assert abs(m.K * 6.0 - 20.944) < 0.01                                   # 6 V gives the 200 rpm no-load speed of Unit 2
    assert abs(m.tau - m.J * m.R / (m.k ** 2 + m.b * m.R)) < 1e-12 and 0.10 < m.tau < 0.12
    t = 0.0; dt = 0.001
    while m.w < 0.632 * m.K * 6.0:
        m.step(6.0, dt); t += dt
    assert abs(t - m.tau) < 0.003                                            # 63.2 percent at one time constant


def test_step_metrics_on_first_order_response():
    tau = 0.1; t = np.arange(0, 2, 0.0005); y = 1 - np.exp(-t / tau)
    s = C.step_metrics(t, y, 1.0)
    assert abs(s["rise"] - tau * math.log(9)) < 0.002 and s["overshoot"] == 0 and abs(s["settle"] - tau * math.log(50)) < 0.003


def test_settling_time_is_measured_from_the_start_of_the_data():
    tau = 0.1; t = np.arange(0, 2, 0.0005) + 5.0; y = 1 - np.exp(-(t - 5.0) / tau)
    assert abs(C.step_metrics(t, y, 1.0)["settle"] - tau * math.log(50)) < 0.003


def test_p_only_has_the_predicted_steady_state_error_and_pi_removes_it():
    m = C.WheelMotor(); kp = 1.0
    out = C.simulate_speed_loop(C.PID(kp, 0, 0, windup="none"), m, 10.0, 3.0, quantise=False)
    err = (10.0 - out["w"][-1]) / 10.0
    assert abs(err - C.p_only_steady_error(m.K, kp)) < 0.01
    m2 = C.WheelMotor(); kp2, ti = C.lambda_pi(m2.K, m2.tau, 0.03)
    out2 = C.simulate_speed_loop(C.PID(kp2, kp2 / ti), m2, 10.0, 3.0, quantise=False)
    assert abs(out2["w"][-1] - 10.0) < 0.02


def test_lambda_tuned_loop_has_the_designed_time_constant():
    m = C.WheelMotor(); tau_c = 0.05; kp, ti = C.lambda_pi(m.K, m.tau, tau_c)
    out = C.simulate_speed_loop(C.PID(kp, kp / ti, ts=0.001), m, 10.0, 1.0, ts=0.001, delay_samples=0, quantise=False)
    t63 = out["t"][np.where(out["w"] >= 0.632 * 10.0)[0][0]]
    assert abs(t63 - tau_c) < 0.1 * tau_c and C.step_metrics(out["t"], out["w"], 10.0)["overshoot"] < 2.0


def test_anti_windup_removes_the_post_stall_surge():
    kp, ti = C.lambda_pi(C.WheelMotor().K, C.WheelMotor().tau, 0.03); res = {}
    for mode in ("none", "clamp", "backcalc"):
        m = C.WheelMotor()
        out = C.simulate_speed_loop(C.PID(kp, kp / ti, windup=mode), m, 15.0, 6.0, quantise=False, blocked=lambda t: 1.0 <= t < 2.0)
        res[mode] = out["w"][int(2.0 / 0.01):].max()
    assert res["none"] > 20 and res["clamp"] < 16 and res["backcalc"] < 18


def test_zn_formulas_and_ultimate_gain_exact_and_confirmed_by_simulation():
    assert C.zn_pid(10, 2) == (6.0, 1.0, 0.25)
    m = C.WheelMotor(); a = math.exp(-0.01 / m.tau); b = m.K * (1 - a)
    ku1, tu1 = C.ultimate_gain(m, 0.01, 1)
    assert abs(ku1 - 1.0 / b) < 1e-6 and abs(tu1 - 2 * math.pi * 0.01 / math.acos(a / 2)) < 1e-6          # d = 1: product of the roots b kp = 1, cos(phi) = a/2
    ku0, tu0 = C.ultimate_gain(m, 0.01, 0)
    assert abs(ku0 - (1 + a) / b) < 1e-6 and abs(tu0 - 0.02) < 1e-9                                         # d = 0: root a - b kp = -1, period two samples
    ku2, _ = C.ultimate_gain(m, 0.01, 2); assert ku0 > ku1 > ku2                                              # more delay, less gain tolerated
    for d in (0, 1, 2):
        ku, _ = C.ultimate_gain(m, 0.01, d)
        assert C.oscillation_growth(C.WheelMotor, 0.9 * ku, 0.01, d) < 1.0 < C.oscillation_growth(C.WheelMotor, 1.1 * ku, 0.01, d)


def test_stopping_distance():
    assert abs(C.stopping_distance(0.5, 0.015) - (0.5 * 0.015 + 0.25 / (2 * 0.6 * 9.81))) < 1e-12
    assert C.stopping_distance(0.5, 0.150) > C.stopping_distance(0.5, 0.015)


def test_line_following_converges_and_delay_margin_matches_theory():
    ok = C.simulate_line_following(sensor_delay_s=0.0, t_end=8.0)
    assert abs(ok["y"][-1]) < 0.01 and np.abs(ok["y"]).max() < 0.35
    dm = C.line_delay_margin(8.0, 2.8, 0.5)
    assert abs(dm - 0.877) < 0.005                                              # closed form
    good = C.simulate_line_following(sensor_delay_s=0.6, t_end=20.0)["y"]
    bad = C.simulate_line_following(sensor_delay_s=1.0, t_end=20.0)["y"]
    assert np.abs(good[-400:]).max() < 0.02 and np.abs(bad[-400:]).max() > 0.2     # decays below the margin, rings above it


def test_dynamic_rover_tracks_body_command():
    d = C.DynamicRover(); d.set_body(0.5, 0.0); d.run(3.0)
    assert abs(d.motors[0].w * 0.033 - 0.5) < 0.01 and abs(d.rover.pose[0] - 1.4) < 0.4 and abs(d.rover.pose[1]) < 0.02
