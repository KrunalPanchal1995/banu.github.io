# control_np

> Wheel-motor dynamics, discrete PID with anti-windup, step metrics, lambda and Ziegler-Nichols tuning, line following with delay, stopping distance, and a DynamicRover that puts motor loops under the shared Rover of Unit 8.

**Topic:** robotics  |  **Created in session:** 009 (Unit 9)  |  **Status:** tested (10 tests); simulation only, no real wheel measured

## What this code is for
Shows how a DC motor is a first-order plant (tau = J/(b+k^2/R), K = (k/R)/(b+k^2/R)) and how P, PI and PID loops behave on it once sampling, delay, a 7 V limit and encoder quantisation are included. Use it to tune a wheel-speed loop, find a sampled loop's exact ultimate gain, test windup, size a stop, or run a rover with realistic wheel dynamics. Assumed (not measured): J = 1e-3 kg m^2, mu = 0.6.

## Capabilities
- `WheelMotor(...)`: `.tau`, `.K`, exact zero-order-hold `.step(u, load, ts)`.
- `PID(kp, ki, ts, kd=0, windup="clamp"|"backcalc"|"none", u_min, u_max)`: discrete PID, derivative on measurement, filtered.
- `lambda_pi(K, tau, tau_c)` -> (kp, Ti); `zn_pid(Ku, Tu)` -> (kp, Ti, Td).
- `simulate_speed_loop(pid, motor, setpoint, ...)` -> dict t, y, w, u, r, i; `step_metrics(t, y, r)` -> rise, overshoot, settle, sse.
- `ultimate_gain(motor, ts, delay_samples)` -> (Ku, Tu) exact from z^(d+1) - a z^d + b kp = 0; `oscillation_growth`, `p_only_steady_error`.
- `stopping_distance(v, t_react, mu)`; `simulate_line_following(...)`; `line_delay_margin(k1, k2, v)`.
- `DynamicRover`: `.set_body(v, w)`, `.run(t)`; wheel loops under `kinematics_np.Rover`.

## Theory in one paragraph
Motor: tau w' + w = K u - tau_L/d. P error = 1/(1+K kp). Lambda: Ti = tau, kp = tau/(K tau_c). Line: y'' + k2 y' + v k1 y = 0, delay margin from the phase crossover. Stop: s = v t + v^2/(2 mu g). Derived in Unit 9 Sections 3.2 to 3.4.

## Quick start
```bash
python -m pytest tests -q
```
```python
import control_np as C
m = C.WheelMotor(); kp, ti = C.lambda_pi(m.K, m.tau, 0.03)
print(C.ultimate_gain(m, 0.01, delay_samples=1))   # (3.3675, 0.0573)
```

## Tests
10 tests in `tests/test_control_np.py` (first-order response, metrics, P error, windup, Ku vs closed forms, stopping, delay margin, DynamicRover).
