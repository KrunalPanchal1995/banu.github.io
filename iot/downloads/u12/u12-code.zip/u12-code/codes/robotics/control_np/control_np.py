"""Control of the rover's wheels and heading (numpy). A first-order wheel-motor model built from the Unit 2 motor, a discrete PID with filtered
derivative and anti-windup, step-response metrics, lambda and Ziegler-Nichols tuning, a line-following loop with delay, braking distance, and
DynamicRover (motor loops added to the shared Rover of Unit 8). See README.md.

Units: volts, rad/s, N m, seconds, metres. All motor/inertia numbers are ASSUMED (Unit 2 motor; reflected inertia J chosen in this Unit).
"""
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "electronics", "circuits_np"))
sys.path.insert(0, os.path.join(HERE, "..", "kinematics_np"))
import circuits_np as C  # noqa: E402
import kinematics_np as K  # noqa: E402


# ------------------------------------------------------------------ wheel motor with dynamics
class WheelMotor:
    """Geared DC motor + reflected load, electrical dynamics neglected: J dw/dt = k (u - k w)/R - b w - tau_load.
    Parameters from the Unit 2 DCMotor (k, R, no-load speed and current); viscous friction b is chosen so that the no-load current at rated voltage is the catalogue i0.
    J is the inertia reflected to the output shaft (rotor through the gearbox plus half the rover's mass: (m/2) r^2 + rotor), ASSUMED 1.0e-3 kg m^2.
    First-order: time constant tau = J / (b + k^2/R), voltage-to-speed gain K = (k/R) / (b + k^2/R)."""

    def __init__(self, J=1.0e-3, v_rated=6.0, i_stall=0.8, i_noload=0.15, rpm_noload=200.0, u_max=7.0, cpr=1320):
        m = C.DCMotor(v_rated, i_stall, i_noload, rpm_noload)
        self.k, self.R, self.J = m.k, m.R, J
        self.b = m.k * i_noload / m.w0                    # viscous friction giving the no-load current at no-load speed
        self.den = self.b + self.k ** 2 / self.R
        self.tau = J / self.den
        self.K = (self.k / self.R) / self.den
        self.u_max, self.cpr = u_max, cpr
        self.w = 0.0
        self.rev = 0.0
        self.counts = 0

    def step(self, u, dt, tau_load=0.0, blocked=False, decel_limit=None):
        """Advance dt seconds with constant voltage u (clipped to +-u_max). Returns the encoder count increment. `blocked` holds the wheel still (stall).
        decel_limit (rad/s^2, positive) bounds braking (traction)."""
        u = max(-self.u_max, min(self.u_max, u))
        w0 = self.w
        w_inf = self.K * u - tau_load / self.den
        w1 = w_inf + (w0 - w_inf) * math.exp(-dt / self.tau)
        if decel_limit is not None and (w1 - w0) / dt < -decel_limit:
            w1 = w0 - decel_limit * dt
        if blocked:
            w1 = 0.0
        self.w = w1
        self.rev += 0.5 * (w0 + w1) * dt / (2 * math.pi)
        new = int(math.floor(self.rev * self.cpr)) if self.rev >= 0 else -int(math.floor(-self.rev * self.cpr))
        d, self.counts = new - self.counts, new
        return d


# ------------------------------------------------------------------ discrete PID
class PID:
    """u = kp e + I + D with e = r - y. I accumulates ki e Ts. D acts on the measurement through a first-order filter (N): D_k = a D_(k-1) - (kp Td N / (Td + N Ts)) (y_k - y_(k-1)), a = Td/(Td + N Ts), Td = kd/kp.
    Output clipped to [u_min, u_max]. windup: 'none', 'clamp' (stop integrating while saturated and the error pushes further) or 'backcalc' (I += kb (u_sat - u) Ts)."""

    def __init__(self, kp, ki=0.0, kd=0.0, ts=0.01, u_min=-7.0, u_max=7.0, n=10.0, windup="clamp", kb=None):
        self.kp, self.ki, self.kd, self.ts, self.u_min, self.u_max, self.n, self.windup = kp, ki, kd, ts, u_min, u_max, n, windup
        self.kb = kb if kb is not None else (ki / kp if kp and ki else 1.0 / ts)
        self.i = 0.0
        self.d = 0.0
        self.prev_y = None

    def update(self, r, y):
        e = r - y
        p = self.kp * e
        if self.kd and self.kp:
            td = self.kd / self.kp
            a = td / (td + self.n * self.ts)
            dy = 0.0 if self.prev_y is None else y - self.prev_y
            self.d = a * self.d - (self.kp * td * self.n / (td + self.n * self.ts)) * dy
        self.prev_y = y
        u_raw = p + self.i + self.d
        u = max(self.u_min, min(self.u_max, u_raw))
        if self.windup == "none":
            self.i += self.ki * e * self.ts
        elif self.windup == "clamp":
            if u == u_raw or (u_raw > self.u_max and e < 0) or (u_raw < self.u_min and e > 0):
                self.i += self.ki * e * self.ts
        else:                                                  # back-calculation
            self.i += (self.ki * e + self.kb * (u - u_raw)) * self.ts
        return u


def lambda_pi(K_dc, tau, tau_c):
    """Pole-zero cancelling PI for a first-order plant: Ti = tau, kp = tau / (K tau_c): the closed loop is first-order with time constant tau_c."""
    return tau / (K_dc * tau_c), tau


def zn_pid(Ku, Tu):
    """Ziegler-Nichols classic PID from the ultimate gain and period: kp = 0.6 Ku, Ti = 0.5 Tu, Td = 0.125 Tu (returns kp, ti, td)."""
    return 0.6 * Ku, 0.5 * Tu, 0.125 * Tu


def gains_from(kp, ti=None, td=None):
    return kp, (kp / ti if ti else 0.0), (kp * td if td else 0.0)


# ------------------------------------------------------------------ speed-loop simulation and step-response metrics
def simulate_speed_loop(pid, motor, setpoint, t_end=2.0, ts=0.01, delay_samples=1, quantise=True, load=None, blocked=None, decel_limit=None):
    """Closed loop at sample period ts. The speed measurement is the encoder-count difference over the last interval (quantised, or exact if quantise=False);
    the voltage computed at sample k is applied delay_samples samples later (default 1: computation plus zero-order hold). setpoint: float or f(t).
    Returns dict(t, y_meas, w_true, u, r, i)."""
    n = int(round(t_end / ts))
    sp = setpoint if callable(setpoint) else (lambda t: setpoint)
    t = np.arange(n) * ts
    y_meas, w_true, u_out, r_out, i_out = (np.zeros(n) for _ in range(5))
    pending = [0.0] * delay_samples
    last_counts = motor.counts
    meas = 0.0
    dcount = 2 * math.pi / motor.cpr
    for k in range(n):
        if quantise:
            meas = (motor.counts - last_counts) * dcount / ts
            last_counts = motor.counts
        else:
            meas = motor.w
        r = sp(t[k])
        u = pid.update(r, meas)
        pending.append(u)
        u_apply = pending.pop(0)
        tl = load(t[k]) if load else 0.0
        bl = blocked(t[k]) if blocked else False
        motor.step(u_apply, ts, tau_load=tl, blocked=bl, decel_limit=decel_limit)
        y_meas[k], w_true[k], u_out[k], r_out[k], i_out[k] = meas, motor.w, u, r, pid.i
    return dict(t=t, y=y_meas, w=w_true, u=u_out, r=r_out, i=i_out)


def step_metrics(t, y, r, tol=0.02):
    """Rise time (10 to 90 percent), overshoot (percent of the step), settling time (time from the first sample until the response last leaves +-tol of the target; pass data that starts at the step) and steady-state error."""
    y = np.asarray(y, float)
    y0, span = y[0], r - y[0]
    f = (y - y0) / span
    def first(level):
        idx = np.where(f >= level)[0]
        return t[idx[0]] if len(idx) else float("nan")
    rise = first(0.9) - first(0.1)
    over = max(0.0, (f.max() - 1.0)) * 100.0
    outside = np.where(np.abs(f - 1.0) > tol)[0]
    settle = (t[outside[-1]] - t[0]) if len(outside) else 0.0
    if len(outside) and outside[-1] == len(f) - 1:
        settle = float("nan")
    sse = (r - y[-1])
    return dict(rise=rise, overshoot=over, settle=settle, sse=sse)


def ultimate_gain(motor, ts=0.01, delay_samples=1):
    """Ultimate gain Ku and period Tu of a P loop around the sampled motor (Ziegler-Nichols closed-loop experiment, exact for the linear model).
    With a = exp(-ts/tau), b = K (1 - a) and the voltage applied delay_samples samples late, the loop w[k+1] = a w[k] + b kp (r - w[k-d]) has the characteristic
    polynomial z^(d+1) - a z^d + b kp: Ku is the first gain with a root on the unit circle, and the root's angle phi gives Tu = 2 pi ts / phi."""
    a = math.exp(-ts / motor.tau)
    b = motor.K * (1 - a)
    d = delay_samples

    def worst(kp):
        coef = np.zeros(d + 2); coef[0] = 1.0; coef[1] = -a; coef[-1] += b * kp
        r = np.roots(coef)
        return max(abs(r)), r
    lo, hi = 1e-6, 1.0
    while worst(hi)[0] < 1.0:
        hi *= 2
        if hi > 1e6:
            return None, None
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if worst(mid)[0] < 1.0:
            lo = mid
        else:
            hi = mid
    ku = 0.5 * (lo + hi)
    r = worst(ku)[1]
    root = r[np.argmax(abs(r))]
    phi = abs(math.atan2(root.imag, root.real))
    return ku, 2 * math.pi * ts / phi


def oscillation_growth(motor_factory, kp, ts=0.01, delay_samples=1, t_end=2.0):
    """Simulate the linear P loop (no saturation, exact speed) and return the ratio of the late to the earlier oscillation envelope (> 1 grows, < 1 decays)."""
    m = motor_factory(); m.u_max = 1e12                       # linear check: no voltage limit
    out = simulate_speed_loop(PID(kp, 0, 0, ts, u_min=-1e12, u_max=1e12, windup="none"), m, lambda t: 1.0 if t > 0.05 else 0.0, t_end, ts, delay_samples, False)
    y_inf = m.K * kp / (1.0 + m.K * kp)
    dev = np.abs(out["w"] - y_inf); n = len(dev)
    e1, e2 = dev[int(0.5 * n):int(0.75 * n)].max(), dev[int(0.75 * n):].max()
    return e2 / e1 if e1 > 1e-9 else 0.0                       # an envelope that has vanished counts as decaying


# ------------------------------------------------------------------ closed-form checks
def p_only_steady_error(K_dc, kp):
    """Steady-state error fraction of a P-controlled first-order plant: 1/(1 + K kp)."""
    return 1.0 / (1.0 + K_dc * kp)


def stopping_distance(v0, latency_s, mu=0.6, g=9.81):
    """Distance travelled from the moment an obstacle is detected: v0 * latency during the reaction, then braking at the traction limit mu g."""
    return v0 * latency_s + v0 ** 2 / (2 * mu * g)


# ------------------------------------------------------------------ dynamic rover: motor loops under the shared Rover
class DynamicRover:
    """Two wheel-speed PI loops (one per wheel) driving the shared Rover of Unit 8. Command with set_body(v, w); advance with step(dt = ts)."""

    def __init__(self, rover=None, ts=0.01, kp=1.07, ti=0.112, windup="clamp", delay_samples=1, **rover_kw):
        self.rover = rover or K.Rover(**rover_kw)
        self.ts = ts
        self.motors = [WheelMotor(cpr=self.rover.p.cpr), WheelMotor(cpr=self.rover.p.cpr)]
        self.pids = [PID(kp, kp / ti, 0.0, ts, windup=windup) for _ in range(2)]
        self.targets = (0.0, 0.0)
        self.pending = [[0.0, 0.0] for _ in range(delay_samples)]
        self.last_counts = [0, 0]
        self.meas = [0.0, 0.0]

    def set_body(self, v, w):
        vl, vr = K.body_to_wheel(v, w, self.rover.p.track)
        self.targets = (vl / self.rover.p.wheel_r, vr / self.rover.p.wheel_r)

    def step(self):
        dcount = 2 * math.pi / self.rover.p.cpr
        us = []
        for i in range(2):
            self.meas[i] = (self.motors[i].counts - self.last_counts[i]) * dcount / self.ts
            self.last_counts[i] = self.motors[i].counts
            us.append(self.pids[i].update(self.targets[i], self.meas[i]))
        self.pending.append(us)
        applied = self.pending.pop(0)
        for i in range(2):
            self.motors[i].step(applied[i], self.ts)
        self.rover.step(self.motors[0].w, self.motors[1].w, self.ts)

    def run(self, t):
        for _ in range(int(round(t / self.ts))):
            self.step()


# ------------------------------------------------------------------ line following
def simulate_line_following(k1=8.0, k2=2.8, v=0.5, y0=0.3, th0=0.0, t_end=8.0, ts=0.01, sensor_delay_s=0.0, motor_loops=True, seed=0):
    """Follow the line y = 0 at constant speed v with w = -k1 y - k2 theta (heading from odometry/gyro, lateral error from a sensor delayed by sensor_delay_s).
    With motor_loops the wheel-speed PI loops and motor dynamics sit between the command and the motion. Returns dict(t, y, theta, w_cmd)."""
    dr = DynamicRover(ts=ts, pose=(0.0, y0, th0)) if motor_loops else None
    pose = np.array([0.0, y0, th0])
    n = int(round(t_end / ts)); nd = int(round(sensor_delay_s / ts))
    hist_y = [y0] * (nd + 1)
    t = np.arange(n) * ts; ys, ths, ws = np.zeros(n), np.zeros(n), np.zeros(n)
    track = K.RoverParams().track
    for k in range(n):
        cur = dr.rover.pose if motor_loops else pose
        hist_y.append(cur[1]); y_meas = hist_y[-1 - nd]
        w = -k1 * y_meas - k2 * cur[2]
        w = max(-2.389, min(2.389, w))                            # turn-rate limit at 0.5 m/s (Unit 8)
        if motor_loops:
            dr.set_body(v, w); dr.step(); cur = dr.rover.pose
        else:
            pose = K.arc_pose(pose, (v - 0.5 * track * w) * ts, (v + 0.5 * track * w) * ts, track); cur = pose
        ys[k], ths[k], ws[k] = cur[1], cur[2], w
    return dict(t=t, y=ys, theta=ths, w=ws)


def line_delay_margin(k1, k2, v):
    """Largest sensor delay (s) the line follower w = -k1 y - k2 theta tolerates in the ideal model y' = v theta, theta' = w: from the open loop
    L(jw) = v k1 exp(-jwd) / (jw (jw + k2)): crossover w_c with w_c sqrt(w_c^2 + k2^2) = v k1, delay margin (pi/2 - atan(w_c/k2)) / w_c."""
    a = k2 * k2
    wc2 = (-a + math.sqrt(a * a + 4 * (v * k1) ** 2)) / 2.0
    wc = math.sqrt(wc2)
    return (math.pi / 2 - math.atan(wc / k2)) / wc


def main():
    m = WheelMotor()
    print("tau (ms):", round(m.tau * 1e3, 1), " K (rad/s per V):", round(m.K, 3))


if __name__ == "__main__":
    main()
