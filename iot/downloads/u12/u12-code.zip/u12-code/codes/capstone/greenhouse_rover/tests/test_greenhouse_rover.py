import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import greenhouse_rover as G  # noqa: E402

LEGS = G.plan_legs()


def test_cruise_current_and_payloads():
    assert abs(G.cruise_battery_current() - 0.1273) < 0.002
    s = G.payload_sizes()
    assert s["packed"] == 7 and s["json"] > s["cbor"] > s["packed"]


def test_legs_are_planned_and_collision_free():
    assert len(LEGS) == 20
    for (i, j), leg in LEGS.items():
        assert abs(leg["length"] - LEGS[(j, i)]["length"]) < 0.25
        assert G.P.path_collisions(G.make_world(), leg["path_xy"], G.ROVER_R, G.RES) == 0


def test_odometry_steering_fails_where_ekf_succeeds():
    path = LEGS[(0, 4)]["path_xy"]
    o = G.run_leg(path, "odom", seed=0); e = G.run_leg(path, "ekf", seed=0)
    assert o["collided"] or o["arrival_error"] > 0.3
    assert e["finished"] and not e["collided"] and e["arrival_error"] < 0.10


def test_qos1_delivery_statistics():
    rng = np.random.default_rng(1); p = 0.3
    res = [G.send_qos1(rng, p) for _ in range(20000)]
    lost = 1 - np.mean([r[0] for r in res])
    assert abs(lost - p ** 5) < 0.002
    att = np.mean([r[2] for r in res if r[0]])
    assert 1.3 < att < 1.6


def test_security_test():
    r = G.security_test(500)
    assert r["genuine_accepted"] and r["replay_reason"] == "replay" and r["forged_accepted"] == 0


def test_day_simulation_properties():
    a = G.simulate_day("event", 3, LEGS); b = G.simulate_day("event", 3, LEGS)
    assert a["waterings"] == b["waterings"] and a["energy_mAh"] == b["energy_mAh"]
    assert a["served"] <= a["events"] and a["energy_mAh"] > 0 and a["msgs"] > 100
    lossy = G.simulate_day("event", 3, LEGS, p_loss=0.9)
    assert lossy["lost"] > a["lost"] and lossy["dry_h"] >= a["dry_h"] - 1e-9
    slow = G.simulate_day("timer", 3, LEGS, timer_period_h=6.0); fast = G.simulate_day("timer", 3, LEGS, timer_period_h=1.0)
    assert slow["dry_h"] > fast["dry_h"] and slow["litres"] < fast["litres"]
