"""Smart Greenhouse Rover: the capstone system simulator (Unit 12).

Integrates the layers of Units 1 to 11 in one model: soil nodes (sensing, calibration noise, EMA, packed payloads), a lossy MQTT-style link with QoS 1 retries, a cloud
detector with hysteresis, HMAC-signed commands, a planner (A* on an inflated grid, best visiting order), a path follower on the simulated rover with a pose estimate
(encoder odometry or EKF-quality), motor and computer energy, and a timer baseline. All parameters marked ASSUMED are round numbers of the right order, not measurements.
Units: seconds, metres, amperes, litres. See README.md.
"""
import math
import os
import sys

import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))
for rel in ("robotics/planning_np", "robotics/kinematics_np", "robotics/control_np", "cloud/telemetry_np", "security/iot_sec", "net/mqtt_mini"):
    sys.path.insert(0, os.path.join(_here, "..", "..", rel))
import planning_np as P                      # noqa: E402
import control_np as C                       # noqa: E402
import telemetry_np as T                     # noqa: E402
import iot_sec as S                          # noqa: E402
import netcalc as NC                         # noqa: E402
from kinematics_np import Rover, RoverParams, wrap_angle   # noqa: E402

RES = 0.05
ROVER_R = 0.13                               # ASSUMED body circle (m)
INFL = ROVER_R + RES / 2 + 0.02              # 0.175 m
START = (0.6, 0.6)
PLANTS = {"P1": (5.0, 0.9), "P2": (9.2, 2.8), "P3": (3.0, 2.8), "P4": (6.0, 5.0)}
NAMES = ["dock"] + list(PLANTS)
POINTS = [START] + list(PLANTS.values())


def make_world():
    w = np.zeros((int(6 / RES), int(10 / RES)), bool)
    w[0, :] = w[-1, :] = w[:, 0] = w[:, -1] = True
    def box(x0, x1, y0, y1): w[int(round(y0 / RES)):int(round(y1 / RES)), int(round(x0 / RES)):int(round(x1 / RES))] = True
    box(2.0, 8.0, 1.4, 2.0); box(2.0, 6.0, 3.6, 4.2); box(6.2, 9.95, 3.6, 4.2)
    return w


def cell(p):
    return (int(p[1] / RES), int(p[0] / RES))


# ------------------------------------------------------------------ energy (Unit 2 pack, Unit 9 motor)
BATT_V, BATT_MAH, USABLE = 7.4, 2600.0, 0.8     # Unit 2 pack
I_COMPUTER = 0.375                               # A at the battery, Unit 2 (edge computer, 5 V 0.5 A, 90% regulator)
I_PUMP = 0.30                                    # A while watering (ASSUMED)
I_IDLE_LISTEN = 0.015                            # A at the dock with the computer asleep and the radio in power save (ASSUMED)
I_IDLE_TIMER = 0.010                             # A at the dock with a timer wake-up only (ASSUMED)


def cruise_battery_current(v=0.5, params=None):
    """Battery current of the two motors at steady speed v on the flat, from the Unit 9 motor model (voltage = w / K, current = (u - k w)/R, power = u i)."""
    p = params or RoverParams(); m = C.WheelMotor(); w = v / p.wheel_r
    u = w / m.K; i = (u - m.k * w) / m.R
    return 2.0 * u * i / BATT_V


# ------------------------------------------------------------------ paths and legs
def plan_legs(world=None):
    """A* + line-of-sight smoothing for every ordered pair among the dock and the plants. Returns dict[(i, j)] -> dict(path_xy, length, cells)."""
    world = make_world() if world is None else world
    infl = P.inflate(world, INFL, RES)
    legs = {}
    for i in range(len(POINTS)):
        for j in range(len(POINTS)):
            if i == j:
                continue
            r = P.astar(infl, cell(POINTS[i]), cell(POINTS[j]))
            sm = P.shortcut(infl, r["path"])
            xy = [P.cell_center(c, RES) for c in sm]
            xy[0], xy[-1] = POINTS[i], POINTS[j]
            legs[(i, j)] = dict(path_xy=xy, length=P.path_length(sm, RES), expanded=r["expanded"])
    return legs


def run_leg(path_xy, mode="ekf", seed=0, lookahead=0.2, v=0.5, dt=0.02, lag=0.03, eps_r=0.005, slip_q=4e-6, world=None, t_max=120.0, pose_sigma=(0.02, 0.02, math.radians(0.5))):
    """Drive the simulated rover (right wheel eps_r large, random slip) along path_xy with pure pursuit steering on a pose ESTIMATE.
    mode: 'odom' (encoder odometry), 'ekf' (true pose plus EKF-quality noise, ASSUMED sigma 2 cm, 2 cm, 0.5 deg: what Unit 10 achieved beside walls), 'oracle' (true pose).
    Returns dict(time, arrival_error, max_xte, collided, finished)."""
    world = make_world() if world is None else world
    p = RoverParams(); rng = np.random.default_rng(seed)
    th0 = math.atan2(path_xy[1][1] - path_xy[0][1], path_xy[1][0] - path_xy[0][0])
    rv = Rover(p, pose=(path_xy[0][0], path_xy[0][1], th0), eps_r=eps_r, slip_q=slip_q, seed=seed)
    wf = 0.0; idx = 0; t = 0.0; xte = 0.0; collided = False; finished = False
    goal = path_xy[-1]
    while t < t_max:
        if mode == "odom": est = rv.odom.copy()
        elif mode == "ekf": est = rv.pose + rng.normal(0, 1, 3) * np.array(pose_sigma)
        else: est = rv.pose.copy()
        if math.hypot(goal[0] - est[0], goal[1] - est[1]) < 0.05:
            finished = True; break
        tgt, idx = P.pure_pursuit_target(path_xy, est, lookahead, idx)
        kap = P.curvature_to_target(est, tgt); vv = v
        d_goal = math.hypot(goal[0] - est[0], goal[1] - est[1])
        if d_goal < 2 * lookahead: vv = max(0.1, min(vv, d_goal))
        if abs(kap) * p.track / 2 * vv + vv > p.v_wheel_max: vv = max(0.05, p.v_wheel_max / (1 + abs(kap) * p.track / 2))
        wf += (vv * kap - wf) * (1 - math.exp(-dt / lag))
        rv.step((vv - 0.5 * wf * p.track) / p.wheel_r, (vv + 0.5 * wf * p.track) / p.wheel_r, dt)
        t += dt; xte = max(xte, P.cross_track(path_xy, rv.pose))
        if not collided and P.disc_collides(world, rv.pose[:2], ROVER_R, RES): collided = True
    err = math.hypot(goal[0] - rv.pose[0], goal[1] - rv.pose[1])
    return dict(time=t, arrival_error=err, max_xte=xte, collided=collided, finished=finished)


def leg_reliability(legs, mode, n=20, tol=0.10, **kw):
    """Monte Carlo over n seeds for every leg: mean time, probability of success (finished, no collision, arrival error under tol), mean arrival error."""
    world = make_world(); out = {}
    for key, leg in legs.items():
        rs = [run_leg(leg["path_xy"], mode, seed=s, world=world, **kw) for s in range(n)]
        out[key] = dict(time=float(np.mean([r["time"] for r in rs])), p_ok=float(np.mean([(r["finished"] and not r["collided"] and r["arrival_error"] < tol) for r in rs])),
                        err=float(np.mean([r["arrival_error"] for r in rs])), collided=float(np.mean([r["collided"] for r in rs])))
    return out


# ------------------------------------------------------------------ link and messages
def send_qos1(rng, p_loss, retry_s=1.0, max_attempts=5, base=0.080, jitter=0.100):
    """Delivery of one QoS 1 message: the PUBLISH is retried every retry_s; delivery happens at the first PUBLISH that is not lost.
    One-way latency base + Exp(jitter) seconds. Returns (delivered, latency_s, attempts)."""
    for k in range(1, max_attempts + 1):
        if rng.random() >= p_loss:
            return True, (k - 1) * retry_s + base + rng.exponential(jitter), k
    return False, float("nan"), max_attempts


def payload_sizes():
    r = dict(zone=1, soil_raw=1832, temp_c=21.5, batt_v=3.71)
    return dict(json=len(T.encode_json(r)), cbor=len(T.cbor_encode(r)), packed=len(T.pack_reading(1, 1832, 21.5, 3.71)))


# ------------------------------------------------------------------ one day
def simulate_day(strategy="event", seed=0, legs=None, rel=None, hours=12.0, step=60.0, sample_period=600.0, p_loss=0.10, taus_h=(3.0, 4.0, 5.0, 6.0), m_water=0.5,
                 m_dry=0.30, m_wilt=0.20, m_floor=0.10, noise=0.02, ema_alpha=0.4, deadline=1800.0, dwell=20.0, timer_period_h=2.0, litres=0.25, tag_len=8, trace=False, detect_lo=None, retry_s=1.0):
    """Simulate one working day. strategy 'event' (sensor nodes, cloud detector, signed commands, rover trips to the dry plants only) or 'timer' (rover visits every plant every timer_period_h).
    Soil moisture m decays exponentially toward m_floor with time constant taus_h[i] hours. detect_lo is the detector's threshold on the filtered reading (default m_dry); raising it trades water for earlier action. Returns a dict of metrics."""
    rng = np.random.default_rng(seed)
    legs = legs or plan_legs(); rel = rel or {k: dict(time=legs[k]["length"] / 0.5 + 1.0, p_ok=1.0) for k in legs}
    n = len(PLANTS); taus = np.array(taus_h) * 3600.0 * rng.uniform(0.9, 1.1, n)
    m = rng.uniform(0.35, 0.50, n); detector = [T.ThresholdDetector(m_dry if detect_lo is None else detect_lo, 2.0, 0.05) for _ in range(n)]
    ema = m.copy(); flagged = np.zeros(n, bool); pending_cmd = None
    key = S.derive_key(b"greenhouse-master", "rover-1"); counter = 0; last_ctr = 0
    crossed = [None] * n; events = []; stress_s = np.zeros(n); dry_s = np.zeros(n); lat_up, lat_cmd = [], []
    msgs = lost = 0; bytes_up = 0; sz = payload_sizes()
    busy_until = 0.0; trips = 0; waterings = 0; e_mAh = 0.0; moving_s = dwell_s = 0.0; fails = 0
    I_move = cruise_battery_current() + I_COMPUTER; I_dwell = I_COMPUTER + I_PUMP
    t = 0.0; next_sample = rng.uniform(0, sample_period); next_timer = timer_period_h * 3600.0; rover_ops = []   # (finish_time, [(plant_idx, arrival_time)])
    total = hours * 3600.0; rejected = 0; tr_t, tr_m = [], []; trips_log = []
    while t < total:
        # soil dynamics over one step
        m = m_floor + (m - m_floor) * np.exp(-step / taus)
        for i in range(n):
            if m[i] < m_dry and crossed[i] is None: crossed[i] = t
            if m[i] < m_wilt: stress_s[i] += step
            if m[i] < m_dry: dry_s[i] += step
        # rover trip bookkeeping: waterings happen at arrival times inside the step
        for op in list(rover_ops):
            fin, visits = op
            for (i, ta) in list(visits):
                if ta <= t + step:
                    m[i] = m_water; waterings += 1; visits.remove((i, ta))
                    if crossed[i] is not None:
                        events.append(dict(plant=i, wait=ta - crossed[i], served=(ta - crossed[i]) <= deadline)); crossed[i] = None
                    flagged[i] = False; ema[i] = m_water; detector[i].on = False
            if fin <= t + step and not visits: rover_ops.remove(op)
        if strategy == "event":
            while next_sample <= t + step and next_sample < total:
                ts = next_sample; next_sample += sample_period
                for i in range(n):
                    z = m[i] + rng.normal(0, noise); ok, lat, att = send_qos1(rng, p_loss, retry_s=retry_s); msgs += 1; bytes_up += att * NC.mqtt_publish_bytes("gh/p%d/soil" % (i + 1), bytes(sz["packed"]), qos=1)
                    if not ok: lost += 1; continue
                    lat_up.append(lat); ema[i] = ema[i] + ema_alpha * (z - ema[i])
                    if detector[i].update(ema[i]) and not flagged[i]: flagged[i] = True
                if flagged.any() and busy_until <= ts + 1e-9 and pending_cmd is None:
                    todo = [i for i in range(n) if flagged[i]]
                    counter += 1; env = S.sign_command(key, counter, ("water " + ",".join(str(i) for i in todo)).encode(), tag_len)
                    ok, lat, att = send_qos1(rng, p_loss, retry_s=retry_s); msgs += 1; bytes_up += att * NC.mqtt_publish_bytes("gh/rover/cmd", env, qos=1)
                    if ok:
                        okv, why, cmd, last_ctr = S.verify_command(key, env, last_ctr, tag_len); assert okv
                        lat_cmd.append(lat); t_start = ts + lat + 0.03                         # plus A* planning time, about 30 ms on the rover
                        sub = [0] + [i + 1 for i in todo]; dm = np.array([[0.0 if x == y else legs[(x, y)]["length"] for y in sub] for x in sub])
                        order_nodes = [sub[k] for k in P.visit_orders(dm)[2]]
                        t_cur = t_start; visits = []; prev = 0; fine = True
                        for node in order_nodes[1:]:
                            leg = rel[(prev, node)]; t_cur += leg["time"]; moving_s += leg["time"]
                            if rng.random() > leg["p_ok"]: fine = False; fails += 1; break
                            visits.append((node - 1, t_cur)); t_cur += dwell; dwell_s += dwell; prev = node
                        if fine:
                            leg = rel[(prev, 0)]; t_cur += leg["time"]; moving_s += leg["time"]
                        busy_until = t_cur; trips += 1; rover_ops.append((t_cur, visits)); trips_log.append((t_start, t_cur))
        else:
            if next_timer <= t + step:
                t_cur = next_timer; prev = 0; visits = []; fine = True
                for node in P.visit_orders(np.array([[0.0 if a == b else legs[(a, b)]["length"] for b in range(n + 1)] for a in range(n + 1)]))[2][1:]:
                    leg = rel[(prev, node)]; t_cur += leg["time"]; moving_s += leg["time"]
                    if rng.random() > leg["p_ok"]: fine = False; fails += 1; break
                    visits.append((node - 1, t_cur)); t_cur += dwell; dwell_s += dwell; prev = node
                if fine:
                    leg = rel[(prev, 0)]; t_cur += leg["time"]; moving_s += leg["time"]
                busy_until = t_cur; trips += 1; rover_ops.append((t_cur, visits)); trips_log.append((next_timer, t_cur)); next_timer += timer_period_h * 3600.0
        if trace: tr_t.append(t); tr_m.append(m.copy())
        t += step
    # events still waiting at the end of the day count as unserved
    for i in range(n):
        if crossed[i] is not None: events.append(dict(plant=i, wait=total - crossed[i], served=False))
    idle_s = max(0.0, total - moving_s - dwell_s); i_idle = I_IDLE_LISTEN if strategy == "event" else I_IDLE_TIMER
    e_mAh = (I_move * moving_s + I_dwell * dwell_s + i_idle * idle_s) / 3.6
    ev = len(events); served = sum(e["served"] for e in events)
    return dict(strategy=strategy, events=ev, served=served, success=(served / ev if ev else 1.0), stress_h=float(stress_s.sum() / 3600.0), dry_h=float(dry_s.sum() / 3600.0), waterings=waterings, litres=waterings * litres,
                trips=trips, energy_mAh=e_mAh, moving_s=moving_s, dwell_s=dwell_s, msgs=msgs, lost=lost, bytes_up=bytes_up, lat_up=lat_up, lat_cmd=lat_cmd, leg_failures=fails, trace_t=np.array(tr_t), trace_m=np.array(tr_m), trips_log=trips_log, wait_mean=float(np.mean([e["wait"] for e in events])) if events else 0.0)


# ------------------------------------------------------------------ security test
def security_test(n=2000, seed=0, tag_len=8):
    """Forged and replayed commands against the rover's verifier. Returns counts accepted."""
    rng = np.random.default_rng(seed)
    key = S.derive_key(b"greenhouse-master", "rover-1"); good = S.sign_command(key, 5, b"water 0,2", tag_len)
    ok0 = S.verify_command(key, good, 4, tag_len)[0]; replay = S.verify_command(key, good, 5, tag_len)[1]
    forged = 0
    for _ in range(n):
        env = (int(rng.integers(6, 10 ** 6))).to_bytes(4, "big") + b"water 0,1,2,3" + bytes(rng.integers(0, 256, tag_len, dtype=np.uint8))
        forged += S.verify_command(key, env, 5, tag_len)[0]
    return dict(genuine_accepted=bool(ok0), replay_reason=replay, forged_sent=n, forged_accepted=int(forged), forgery_probability=S.forgery_probability(tag_len))


def percentiles(x, q=(50, 95, 99)):
    x = np.asarray(x, float)
    return {f"p{k}": float(np.percentile(x, k)) for k in q} if len(x) else {}


def main():
    legs = plan_legs()
    for s in ("event", "timer"):
        r = simulate_day(s, 0, legs)
        print(s, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items() if k not in ("lat_up", "lat_cmd")})


if __name__ == "__main__":
    main()
