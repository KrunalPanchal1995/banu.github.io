# greenhouse_rover

> The capstone simulator of the Smart Greenhouse Rover: soil nodes, a lossy MQTT link, a cloud detector, HMAC-signed commands, planning and path following on the shared rover, energy, and a timer baseline.

**Topic:** capstone  |  **Created in session:** 012 (Unit 12)  |  **Status:** tested (6 tests); simulation only, nothing on hardware

## What this code is for
Runs the whole loop of the course for a 12 h working day and reports task success, coverage (dry plant-hours), water, trips, battery charge, message latency and loss, against a timer baseline. Use it to compare designs, run ablations and find composition flaws. Assumed (not measured): the greenhouse, soil time constants 3 to 6 h, thresholds, link model, pump and idle currents, and the EKF-quality pose noise (2 cm, 2 cm, 0.5 degree).

## Capabilities
- `plan_legs()` -> dict[(i, j)] of A* + smoothed paths between the dock and four plants (inflation 0.175 m).
- `run_leg(path_xy, mode="odom"|"ekf"|"oracle", seed)` -> time, arrival error, max cross-track error, collided; `leg_reliability(legs, mode, n)` Monte Carlo per leg.
- `send_qos1(rng, p_loss, retry_s, max_attempts)` -> (delivered, latency, attempts).
- `simulate_day(strategy="event"|"timer", seed, legs, rel, p_loss, sample_period, detect_lo, retry_s, timer_period_h, trace)` -> metrics dict (success, dry_h, litres, trips, energy_mAh, msgs, lost, bytes_up, lat_up, lat_cmd, ...).
- `security_test(n, tag_len)`; `cruise_battery_current()`; `payload_sizes()`; `percentiles(x)`.

## Theory in one paragraph
Moisture m' = -(m - 0.10)/tau; a dry event is m < 0.30; success = watered within 30 min. QoS 1 delivery fails with probability p^5. Detector lead from a threshold m2 over m1: tau ln((m2 - mf)/(m1 - mf)). Energy = sum of current x time over moving (502 mA), watering (675 mA) and idle (15 mA). Derived in Unit 12 Sections 3.1 to 3.4.

## Quick start
```bash
python -m pytest tests -q
python greenhouse_rover.py
```
```python
import greenhouse_rover as G
legs = G.plan_legs(); d = G.simulate_day("event", 3, legs, detect_lo=0.33); print(d["success"], d["dry_h"])
```

## Tests
6 tests in `tests/test_greenhouse_rover.py` (currents and payloads, legs collision-free, odometry fails vs EKF-quality, QoS 1 loss statistics, security test, day-simulation properties).
