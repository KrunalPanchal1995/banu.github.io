"""Fig 6: energy and security in the system. Battery charge by activity (moving, watering, idle at the dock) for the event-driven and timer (2 h) strategies; and a forged-command attack on the rover's HMAC verifier."""
from _cap import *
legs = G.plan_legs(); rel = load_rel("ekf"); N = 40
ev = [G.simulate_day("event", s, legs, rel, **DESIGN) for s in range(N)]; tm = [G.simulate_day("timer", s, legs, rel, timer_period_h=2.0) for s in range(N)]
Im = G.cruise_battery_current() + G.I_COMPUTER; Id = G.I_COMPUTER + G.I_PUMP
print(f"currents: moving {Im*1000:.0f} mA (motors {G.cruise_battery_current()*1000:.0f} + computer {G.I_COMPUTER*1000:.0f}); watering {Id*1000:.0f} mA; idle listening {G.I_IDLE_LISTEN*1000:.0f} mA; idle timer {G.I_IDLE_TIMER*1000:.0f} mA; usable pack {G.BATT_MAH*G.USABLE:.0f} mAh")
parts = {}
for nm, d, ii in (("event", ev, G.I_IDLE_LISTEN), ("timer 2 h", tm, G.I_IDLE_TIMER), ("event, no sleep", ev, G.I_COMPUTER)):
    mv = np.mean([r["moving_s"] for r in d]); dw = np.mean([r["dwell_s"] for r in d]); idle = 12 * 3600 - mv - dw
    parts[nm] = [Im * mv / 3.6, Id * dw / 3.6, ii * idle / 3.6]; print(f"{nm:10s}: moving {mv:.0f} s -> {parts[nm][0]:.1f} mAh ; watering {dw:.0f} s -> {parts[nm][1]:.1f} mAh ; idle {idle/3600:.2f} h -> {parts[nm][2]:.1f} mAh ; total {sum(parts[nm]):.1f} mAh = {sum(parts[nm])/(G.BATT_MAH*G.USABLE)*100:.1f}% of the usable pack")
print("computer left on all day while docked (no sleep): ", round(G.I_COMPUTER * 12 * 1000, 0), "mAh per 12 h, i.e.", round(G.I_COMPUTER * 12 * 1000 / (G.BATT_MAH * G.USABLE) * 100), "% of the usable pack")
print("days of operation per charge, event / timer:", round(G.BATT_MAH * G.USABLE / sum(parts["event"]), 1), "/", round(G.BATT_MAH * G.USABLE / sum(parts["timer 2 h"]), 1))
sec = G.security_test(5000); print("security:", sec)
sec4 = G.security_test(5000, tag_len=1); print("with a 1-byte tag (for comparison): forged accepted", sec4["forged_accepted"], "of", sec4["forged_sent"], "; probability per guess", sec4["forgery_probability"])
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
labs = ["moving", "watering", "idle"]; bot = np.zeros(3)
for k, (lab, c) in enumerate(zip(labs, (PAL["blue"], PAL["green"], PAL["grey"]))):
    v = np.array([parts["event"][k], parts["timer 2 h"][k], parts["event, no sleep"][k]]); a.bar(["event", "timer 2 h", "event, computer\nnever sleeps"], v, bottom=bot, color=c, label=lab); bot += v
a.axhline(G.BATT_MAH * G.USABLE, color=PAL["red"], ls=":"); a.text(-0.4, G.BATT_MAH * G.USABLE * 0.93, "usable pack 2080 mAh", fontsize=7.5, color=PAL["red"]); a.set(ylabel="battery charge per 12 h day (mAh)", title="Where the rover's charge goes"); a.legend(fontsize=7.5, loc="upper left", bbox_to_anchor=(0.0, 0.8))
b.axis("off"); b.set_title("Security test of the command channel", fontsize=9)
txt = [f"genuine signed command accepted: {sec['genuine_accepted']}", f"replay of the same command: rejected ({sec['replay_reason']})", f"forged commands with random tags (8-byte tag): {sec['forged_accepted']} of {sec['forged_sent']} accepted", f"probability per guess: 2^-64 = {sec['forgery_probability']:.1e}", "", f"for comparison, a 1-byte tag: {sec4['forged_accepted']} of {sec4['forged_sent']} accepted", f"(expected {sec4['forged_sent']/256:.0f}: probability per guess 1/256)"]
for i, t in enumerate(txt): b.text(0.0, 0.9 - i * 0.12, t, fontsize=7.2, transform=b.transAxes)
save(fig, out("fig06_energy_security.png"))
