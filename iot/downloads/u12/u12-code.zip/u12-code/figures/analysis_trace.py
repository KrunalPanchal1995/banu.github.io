"""Requirement trace numbers for Unit 12: what the integrated system gives for the requirements that were waiting for a system test (R1, R2, R4, R6, R14) plus an end-to-end check of the sampling period."""
from _cap import *
use_code("electronics/circuits_np"); import circuits_np as CE
legs = G.plan_legs(); rel = load_rel("ekf"); N = 40
states = lambda T: [("wake+read", 50, 0.2), ("wifi connect", 100, 1.3), ("mqtt publish", 140, 0.3), ("shutdown", 50, 0.2), ("deep sleep", 0.01, T - 2.0)]
print("R4 node battery life (U2 power budget, 2000 mAh, 80% usable) by sampling period:")
for T in (60, 120, 300, 600, 1800):
    avg, _, sh = CE.power_budget(states(T)); print(f"  period {T:5d} s: average {avg:.3f} mA, life {CE.battery_life_days(2000, avg):6.1f} days, share of charge in the 2 s awake: {(1 - sh['deep sleep'])*100:.1f}%")
print("ABLATION on the sampling period, tuned detector (threshold 0.33), p_loss 0.10, 40 days each:")
for sp in (60, 120, 300, 600, 1800):
    d = [G.simulate_day("event", s, legs, rel, sample_period=sp, **DESIGN) for s in range(N)]
    lu = np.concatenate([r["lat_up"] for r in d]); pc = G.percentiles(lu)
    print(f"  period {sp:5d} s: success {np.mean([r['success'] for r in d])*100:5.1f}%  dry plant-h {np.mean([r['dry_h'] for r in d]):5.2f}  litres {np.mean([r['litres'] for r in d]):5.2f}  messages/day {np.mean([r['msgs'] for r in d]):6.0f}  bytes/day {np.mean([r['bytes_up'] for r in d]):7.0f}  uplink p95 {pc['p95']:.2f} s")
d = [G.simulate_day("event", s, legs, rel, **DESIGN) for s in range(N)]
tot = sum(r["msgs"] for r in d); lost = sum(r["lost"] for r in d); lu = np.concatenate([r["lat_up"] for r in d]); lc = np.concatenate([r["lat_cmd"] for r in d])
print(f"R14 delivered fraction at p = 0.10 with QoS 1 (5 attempts): {(1 - lost / tot) * 100:.3f}% of {tot} messages; theory 1 - p^5 = {(1 - 0.1 ** 5) * 100:.3f}%; QoS 0 would give {(1 - 0.1) * 100:.1f}%")
print("R2 sensor to cloud latency (s):", {k: round(v, 3) for k, v in G.percentiles(lu, (50, 95, 99, 99.9)).items()}, "; command latency (s):", {k: round(v, 3) for k, v in G.percentiles(lc, (50, 95, 99)).items()}, "; share of uplink messages over 2 s:", round(float(np.mean(lu > 2.0)) * 100, 3), "%")
for p in (0.1, 0.3, 0.5):
    dd = [G.simulate_day("event", s, legs, rel, p_loss=p, **DESIGN) for s in range(N)]; l = np.concatenate([r["lat_up"] for r in dd]); print(f"  loss {p}: share of delivered uplink messages over 2 s {np.mean(l > 2.0)*100:.2f}%  p99 {np.percentile(l, 99):.2f} s")
print("R6 plants watered when dry: success", round(float(np.mean([r['success'] for r in d])) * 100, 1), "% within 30 min; dry plant-hours per day", round(float(np.mean([r['dry_h'] for r in d])), 2), "; events per day", round(float(np.mean([r['events'] for r in d])), 2), "; legs failed per day", round(float(np.mean([r['leg_failures'] for r in d])), 3))
# odometry-only navigation inside the system
print("R2 retry timer sweep at p = 0.10 (QoS 1 retry interval): share of uplink messages over 2 s, p95, p99:")
for rt in (1.0, 0.5, 0.3, 0.2):
    dd = [G.simulate_day("event", s, legs, rel, retry_s=rt, **DESIGN) for s in range(N)]; l = np.concatenate([r["lat_up"] for r in dd]); print(f"  retry {rt} s: over 2 s {np.mean(l > 2.0)*100:.3f}%  p95 {np.percentile(l, 95):.3f} s  p99 {np.percentile(l, 99):.3f} s ; bytes per message {np.mean([r['bytes_up'] for r in dd]) / np.mean([r['msgs'] for r in dd]):.1f} B")
for p_ in (0.3, 0.5):
    dd = [G.simulate_day("event", s, legs, rel, retry_s=0.3, p_loss=p_, **DESIGN) for s in range(N)]; l = np.concatenate([r["lat_up"] for r in dd]); print(f"  retry 0.3 s at loss {p_}: over 2 s {np.mean(l > 2.0)*100:.2f}%  p99 {np.percentile(l, 99):.2f} s")
rel_o = load_rel("odom")
do = [G.simulate_day("event", s, legs, rel_o, **DESIGN) for s in range(N)]
print(f"ODOMETRY-ONLY navigation inside the system: success {np.mean([r['success'] for r in do])*100:.1f}%, dry plant-h {np.mean([r['dry_h'] for r in do]):.2f}, leg failures per day {np.mean([r['leg_failures'] for r in do]):.1f}, trips {np.mean([r['trips'] for r in do]):.1f}, energy {np.mean([r['energy_mAh'] for r in do]):.0f} mAh = {np.mean([r['energy_mAh'] for r in do])/(G.BATT_MAH*G.USABLE)*100:.0f}% of the usable pack")
dn = [G.simulate_day("event", s, legs, rel, **DESIGN) for s in range(N)]
print(f"EKF-quality navigation: success {np.mean([r['success'] for r in dn])*100:.1f}%, dry plant-h {np.mean([r['dry_h'] for r in dn]):.2f}, leg failures per day {np.mean([r['leg_failures'] for r in dn]):.3f}")
print("rover battery: days per charge with the event system", round(G.BATT_MAH * G.USABLE / np.mean([r['energy_mAh'] for r in dn]), 1), "; energy per watering", round(float(np.mean([r['energy_mAh'] for r in dn]) / np.mean([r['waterings'] for r in dn])), 2), "mAh")
