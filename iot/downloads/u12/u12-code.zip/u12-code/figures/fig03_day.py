"""Fig 3: one simulated working day (12 h) of the event-driven system. Soil moisture of the four plants (decay time constants 3, 4, 5, 6 h, ASSUMED), the dry threshold 0.30, the rover's trips."""
from _cap import *
legs = G.plan_legs(); rel = load_rel("ekf")
seed = 3; r = G.simulate_day("event", seed, legs, rel, trace=True, **DESIGN)
print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items() if k not in ("lat_up", "lat_cmd", "trace_t", "trace_m", "trips_log")})
print("trips (start s, end s):", [(round(a), round(b)) for a, b in r["trips_log"]])
print("uplink latency percentiles (s):", {k: round(v, 3) for k, v in G.percentiles(r["lat_up"]).items()}, " command latency percentiles (s):", {k: round(v, 3) for k, v in G.percentiles(r["lat_cmd"]).items()})
fig, ax = plt.subplots(figsize=(FIG["panel2"][0], 3.4))
for i, c in enumerate((PAL["blue"], PAL["orange"], PAL["green"], PAL["red"])): ax.plot(r["trace_t"] / 3600, r["trace_m"][:, i], color=c, lw=1.1, label=f"P{i+1}")
for a, b in r["trips_log"]: ax.axvspan(a / 3600, b / 3600, color=PAL["grey"], alpha=0.35, lw=0)
ax.axhline(0.30, color=PAL["black"], ls=":", lw=0.9); ax.text(0.1, 0.305, "dry threshold 0.30", fontsize=7.5); ax.axhline(0.20, color=PAL["red"], ls=":", lw=0.9); ax.text(0.1, 0.205, "wilting 0.20", fontsize=7.5, color=PAL["red"])
ax.set(xlabel="time of the working day (h)", ylabel="soil moisture (fraction)", title="One day: each plant is watered when it first turns dry (grey: rover on a trip)", ylim=(0.1, 0.55)); ax.legend(fontsize=7.5, ncol=4, loc="upper right")
save(fig, out("fig03_day.png"))
