"""Fig 2: the navigation layer in the system. All 20 legs between the dock and the four plants are driven 30 times with three pose sources: encoder odometry, an EKF-quality estimate
(ASSUMED noise 2 cm, 2 cm, 0.5 degree, what Unit 10 reached beside walls) and the true pose (oracle). Right wheel 0.5% large, slip variance 4e-6 m^2/m (Unit 8), lookahead 0.2 m."""
from _common import *
use_code("capstone/greenhouse_rover")
import greenhouse_rover as G, json, time, os

legs = G.plan_legs(); res = {}
for mode in ("odom", "ekf", "oracle"):
    t0 = time.time(); res[mode] = G.leg_reliability(legs, mode, n=30) if not os.path.exists(out("leg_reliability.json")) else {tuple(int(x) for x in k.split("-")): v for k, v in json.load(open(out("leg_reliability.json")))[mode].items()}; r = res[mode]
    print(f"{mode:6s}: mean success over the 20 legs {np.mean([v['p_ok'] for v in r.values()]):.3f}; mean arrival error {np.mean([v['err'] for v in r.values()])*100:.1f} cm; legs with success below 0.9: {sum(v['p_ok'] < 0.9 for v in r.values())}; collision probability averaged {np.mean([v['collided'] for v in r.values()]):.3f}; mean leg time {np.mean([v['time'] for v in r.values()]):.2f} s  ({time.time()-t0:.0f} s to compute)")
json.dump({m: {f"{k[0]}-{k[1]}": v for k, v in r.items()} for m, r in res.items()}, open(out("leg_reliability.json"), "w"), indent=1)
print("planned leg lengths (m):", {f"{NAMES}": 0} if False else {f"{G.NAMES[k[0]]}->{G.NAMES[k[1]]}": round(v['length'], 2) for k, v in legs.items() if k[0] < k[1]})
for k in ((0, 4), (3, 4), (1, 2)):
    print(f"leg {G.NAMES[k[0]]}->{G.NAMES[k[1]]} ({legs[k]['length']:.2f} m): success odom {res['odom'][k]['p_ok']:.2f}, ekf {res['ekf'][k]['p_ok']:.2f}, oracle {res['oracle'][k]['p_ok']:.2f}; arrival error odom {res['odom'][k]['err']*100:.1f} cm, ekf {res['ekf'][k]['err']*100:.1f} cm, oracle {res['oracle'][k]['err']*100:.1f} cm; time {res['ekf'][k]['time']:.1f} s")
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
keys = sorted(legs); x = np.arange(len(keys)); w = 0.27
for i, (m, c) in enumerate((("odom", PAL["red"]), ("ekf", PAL["blue"]), ("oracle", PAL["green"]))): a.bar(x + (i - 1) * w, [res[m][k]["err"] * 100 for k in keys], w, color=c, label=m)
a.axhline(10, color=PAL["black"], ls=":", lw=0.9); a.text(0.2, 11, "10 cm tolerance", fontsize=7.5)
a.set(xticks=x, xticklabels=[f"{G.NAMES[k[0]][-2:]}-{G.NAMES[k[1]][-2:]}" for k in keys], yscale="log", ylabel="arrival error (cm, mean of 30 runs)", title="Per-leg arrival error by pose source"); a.tick_params(axis="x", labelrotation=90, labelsize=6.5); a.legend(fontsize=7.5, loc="upper right")
world = G.make_world(); b.imshow(np.where(world, 0.0, 1.0), origin="lower", extent=(0, 10, 0, 6), cmap="gray", vmin=0, vmax=1); path = legs[(0, 4)]["path_xy"]
for mode, col in (("odom", PAL["red"]), ("ekf", PAL["blue"])):
    for s in range(5):
        p = G.P.follow_path(path, 0.2, 0.5) if False else None
pp = np.array(path); b.plot(pp[:, 0], pp[:, 1], "k--", lw=0.8, label="planned (dock to P4)")
import math
for mode, col in (("odom", PAL["red"]), ("ekf", PAL["blue"])):
    for s in range(4):
        rng = np.random.default_rng(s); rv = G.Rover(G.RoverParams(), pose=(path[0][0], path[0][1], math.atan2(path[1][1] - path[0][1], path[1][0] - path[0][0])), eps_r=0.005, slip_q=4e-6, seed=s)
        wf = 0.0; idx = 0; pts = []
        for _ in range(int(25 / 0.02)):
            est = rv.odom.copy() if mode == "odom" else rv.pose + rng.normal(0, 1, 3) * np.array([0.02, 0.02, math.radians(0.5)])
            if math.hypot(path[-1][0] - est[0], path[-1][1] - est[1]) < 0.05: break
            tgt, idx = G.P.pure_pursuit_target(path, est, 0.2, idx); kap = G.P.curvature_to_target(est, tgt); vv = 0.5
            dg = math.hypot(path[-1][0] - est[0], path[-1][1] - est[1]); vv = max(0.1, min(vv, dg)) if dg < 0.4 else vv
            wf += (vv * kap - wf) * (1 - math.exp(-0.02 / 0.03)); rv.step((vv - 0.5 * wf * 0.16) / 0.033, (vv + 0.5 * wf * 0.16) / 0.033, 0.02); pts.append(rv.pose[:2].copy())
            if G.P.disc_collides(world, rv.pose[:2], G.ROVER_R, G.RES): break
        pts = np.array(pts); b.plot(pts[:, 0], pts[:, 1], color=col, lw=0.9, label=("odometry steering" if mode == "odom" and s == 0 else "EKF-quality steering" if s == 0 else None))
b.set(xlim=(0, 10), ylim=(0, 6), title="Dock to P4: four runs each"); b.legend(fontsize=7, loc="lower right")
save(fig, out("fig02_legs.png"))
