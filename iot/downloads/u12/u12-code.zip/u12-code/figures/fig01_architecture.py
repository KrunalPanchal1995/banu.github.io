"""Fig 1: the whole system, with the numbers each layer contributes (all computed here from the modules of Units 1 to 11)."""
from _cap import *
import math
from matplotlib.patches import FancyBboxPatch
legs = G.plan_legs(); sz = G.payload_sizes(); P_ = G.P
stop = P_.stopping_distance(0.5, 0.0425 + 0.015, 0.6) * 100; wd = P_.watchdog_stop_distance(0.5, 0.2) * 100
print("payload bytes json/cbor/packed:", sz, "; MQTT PUBLISH (QoS 1, 7 B payload):", G.NC.mqtt_publish_bytes("gh/p1/soil", bytes(7), qos=1), "B")
print("longest leg:", max((k for k in legs), key=lambda k: legs[k]['length']), round(max(l['length'] for l in legs.values()), 2), "m ; dock to P4:", round(legs[(0, 4)]['length'], 2), "m ; cells expanded dock to P4:", legs[(0, 4)]['expanded'])
print("ping budget stop (42.5 ms ping + 15 ms edge):", round(stop, 2), "cm ; watchdog 0.2 s:", round(wd, 1), "cm ; cruise battery current motors:", round(G.cruise_battery_current() * 1000, 1), "mA")
print("forgery probability (8-byte tag):", G.S.forgery_probability(8))
fig, ax = plt.subplots(figsize=(FIG["panel2"][0], 4.0)); ax.axis("off"); ax.set(xlim=(0, 1), ylim=(0, 1))
layers = [("DEVICE: 4 soil nodes (U2-U4)", f"read every 10 min, noise 0.02, packed reading {sz['packed']} B (JSON {sz['json']} B)", 0.08, 0.66, "#dbe9f6", PAL["blue"]),
          ("NETWORK: MQTT QoS 1 (U5)", f"PUBLISH 23 B; loss p -> lost p^5; retry 1 s, 5 attempts", 0.08, 0.40, "#e7f5e1", PAL["green"]),
          ("CLOUD / EDGE: detector, signer (U6-U7)", f"EMA 0.4, threshold 0.33, HMAC 8-byte tag (forgery 2^-64)", 0.08, 0.14, "#fdf0d5", PAL["orange"]),
          ("ROVER: estimate, plan, follow, stop (U8-U11)", f"A*, inflation 0.175 m, pure pursuit 0.2 m;\nstop {stop:.1f} cm; watchdog {wd:.0f} cm", 0.52, 0.40, "#f6dfe0", PAL["red"]),
          ("ACTUATORS (U9)", f"wheel PI 10 ms, pump; motors {G.cruise_battery_current()*1000:.0f} mA at 0.5 m/s", 0.52, 0.14, "#ece4f3", PAL["purple"])]
for t, sub, x, y, fc, ec in layers:
    w = 0.40; ax.add_patch(FancyBboxPatch((x, y), w, 0.20, boxstyle="round,pad=0.008", fc=fc, ec=ec)); ax.text(x + w / 2, y + 0.145, t, ha="center", fontsize=8, weight="bold"); ax.text(x + w / 2, y + 0.06, sub, ha="center", fontsize=6.6, linespacing=1.3)
def arr(x1, y1, x2, y2, lab=""): ax.annotate("", (x2, y2), (x1, y1), arrowprops=dict(arrowstyle="->", lw=1.2)); ax.text((x1 + x2) / 2 + 0.01, (y1 + y2) / 2, lab, fontsize=6.5)
arr(0.28, 0.66, 0.28, 0.60, "reading"); arr(0.28, 0.40, 0.28, 0.34, "uplink"); arr(0.48, 0.28, 0.54, 0.40, "signed command"); arr(0.72, 0.40, 0.72, 0.34, "cmd_vel")
ax.text(0.5, 0.97, "Smart Greenhouse Rover: one loop from soil to water", ha="center", fontsize=9, weight="bold")
ax.text(0.5, 0.05, "Requirements R1 to R42 trace through these boxes; the capstone measures success, coverage, energy, latency and loss end to end.", ha="center", fontsize=7.2)
save(fig, out("fig01_architecture.png"))
