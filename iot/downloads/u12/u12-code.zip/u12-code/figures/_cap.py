import json, os
from _common import *
use_code("capstone/greenhouse_rover")
import greenhouse_rover as G

def load_rel(mode="ekf"):
    d = json.load(open(out("leg_reliability.json")))[mode]
    return {tuple(int(x) for x in k.split("-")): v for k, v in d.items()}

def mean_ci(x):
    x = np.asarray(x, float); return float(x.mean()), float(1.96 * x.std(ddof=1) / np.sqrt(len(x))) if len(x) > 1 else 0.0

DESIGN = dict(detect_lo=0.33)      # tuned detector threshold (Section 3.3.3 of Unit 12); the naive design uses 0.30 = the dry threshold
