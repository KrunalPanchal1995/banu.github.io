"""Fig 5: the network layer in the system. Packet loss p (per packet, ASSUMED 10% baseline) swept from 0 to 0.7 with MQTT QoS 1 retries (1 s, up to 5 attempts, one-way latency 80 ms + Exp(100 ms)); 30 days each."""
from _cap import *
legs = G.plan_legs(); rel = load_rel("ekf"); N = 30; P_ = (0.0, 0.1, 0.3, 0.5, 0.7); R = {}
print("payload sizes (bytes) JSON / CBOR / packed:", G.payload_sizes())
for p in P_:
    d = [G.simulate_day("event", s, legs, rel, p_loss=p, **DESIGN) for s in range(N)]; R[p] = d
    lu = np.concatenate([r["lat_up"] for r in d]); lc = np.concatenate([r["lat_cmd"] for r in d]) if any(len(r["lat_cmd"]) for r in d) else np.array([])
    msgs = sum(r["msgs"] for r in d); lost = sum(r["lost"] for r in d)
    pu, pc = G.percentiles(lu), G.percentiles(lc)
    print(f"loss {p:.1f}: messages/day {msgs/N:.0f}, lost {lost/msgs*100:.3f}% (theory p^5 = {p**5*100:.3f}%), uplink latency p50/p95/p99 {pu['p50']:.2f}/{pu['p95']:.2f}/{pu['p99']:.2f} s, command p95 {pc.get('p95', float('nan')):.2f} s, success {np.mean([r['success'] for r in d])*100:.1f}%, dry plant-h {np.mean([r['dry_h'] for r in d]):.2f}, bytes/day {np.mean([r['bytes_up'] for r in d]):.0f}")
b = R[0.1]; import netcalc as NC
NCJ = NC.mqtt_publish_bytes("gh/p1/soil", bytes(54), qos=1)
print("MQTT PUBLISH sizes with a 10-byte topic, QoS 1: packed 7-byte payload", NC.mqtt_publish_bytes("gh/p1/soil", bytes(7), qos=1), "B; CBOR 51 B", NC.mqtt_publish_bytes("gh/p1/soil", bytes(51), qos=1), "B; JSON 54 B", NCJ, "B (application layer only, retransmissions counted, no TCP/IP headers)")
print("per PUBLISH, JSON / packed =", round(NCJ / NC.mqtt_publish_bytes("gh/p1/soil", bytes(7), qos=1), 2), "times the bytes: about", round(float(np.mean([r["bytes_up"] for r in R[0.1]])) * NCJ / 23), "bytes/day at 10% loss if readings were JSON, against", round(float(np.mean([r["bytes_up"] for r in R[0.1]]))), "packed (command messages included in both)")
fig, (a, c) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.plot(P_, [np.mean([r["success"] for r in R[p]]) * 100 for p in P_], "o-", color=PAL["blue"], label="events served within 30 min (%)"); a.set(xlabel="packet loss probability", ylabel="served within 30 min (%)", title="The system degrades gracefully", ylim=(0, 105))
a2 = a.twinx(); a2.plot(P_, [np.mean([r["dry_h"] for r in R[p]]) for p in P_], "s--", color=PAL["orange"]); a2.set_ylabel("dry plant-hours per day", color=PAL["orange"])
for q, col in (("p50", PAL["green"]), ("p95", PAL["orange"]), ("p99", PAL["red"])): c.plot(P_, [G.percentiles(np.concatenate([r["lat_up"] for r in R[p]]))[q] for p in P_], "o-", color=col, label=f"uplink {q}")
c.set(xlabel="packet loss probability", ylabel="sensor-to-cloud latency (s)", yscale="log", title="Latency tail grows with loss"); c.legend(fontsize=7.5)
save(fig, out("fig05_network.png"))
