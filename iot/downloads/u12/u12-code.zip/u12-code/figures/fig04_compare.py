"""Fig 4: the event-driven system against a timer baseline over 40 simulated days (seeds 0..39). Timer: the rover visits all four plants every N hours whether they need water or not (no sensors).
Metrics: success = dry events (moisture first below 0.30) watered within 30 minutes; dry plant-hours below 0.30; litres (0.25 L per watering); rover trips; battery charge."""
from _cap import *
import json
legs = G.plan_legs(); rel = load_rel("ekf"); N = 40
def run(strategy, **kw): return [G.simulate_day(strategy, s, legs, rel, **kw) for s in range(N)]
rows = {}
rows["event naive"] = run("event")
rows["event"] = run("event", **DESIGN)
for h in (1.0, 2.0, 3.0, 4.0, 6.0): rows[f"timer {h:g} h"] = run("timer", timer_period_h=h)
print(f"{'strategy':10s} {'success':>14s} {'dry plant-h':>14s} {'litres':>12s} {'trips':>8s} {'energy mAh':>14s} {'% of usable pack':>17s}")
summ = {}
for k, v in rows.items():
    suc = mean_ci([r["success"] for r in v]); dry = mean_ci([r["dry_h"] for r in v]); lit = mean_ci([r["litres"] for r in v]); trp = mean_ci([r["trips"] for r in v]); en = mean_ci([r["energy_mAh"] for r in v])
    ev = mean_ci([r["events"] for r in v]); summ[k] = dict(success=suc, dry=dry, litres=lit, trips=trp, energy=en, events=ev)
    print(f"{k:10s} {suc[0]*100:6.1f} +- {suc[1]*100:4.1f}% {dry[0]:7.2f} +- {dry[1]:4.2f} {lit[0]:6.2f} +- {lit[1]:4.2f} {trp[0]:6.1f} {en[0]:7.1f} +- {en[1]:5.1f} {en[0]/(G.BATT_MAH*G.USABLE)*100:12.1f}%")
print("ABLATION (event design, 40 days each): sample period, detector threshold")
for sp in (600, 300, 120):
    for dl in (0.30, 0.33, 0.36):
        d = run("event", sample_period=sp, detect_lo=dl); print(f"  sample {sp:4d} s, detect below {dl:.2f}: success {np.mean([r['success'] for r in d])*100:5.1f}%  dry plant-h {np.mean([r['dry_h'] for r in d]):5.2f}  litres {np.mean([r['litres'] for r in d]):5.2f}  trips {np.mean([r['trips'] for r in d]):5.1f}  energy {np.mean([r['energy_mAh'] for r in d]):6.1f} mAh  messages {np.mean([r['msgs'] for r in d]):5.0f}")
print("dry events per day (event run):", round(summ["event"]["events"][0], 2), "; mean wait of served+unserved events (s):", round(float(np.mean([r["wait_mean"] for r in rows["event"]])), 0))
ev_ = rows["event"]; print("event system: unserved events per day", round(float(np.mean([r["events"] - r["served"] for r in ev_])), 2), "; leg failures per day", round(float(np.mean([r["leg_failures"] for r in ev_])), 3))
json.dump({k: {m: list(map(float, vv)) if isinstance(vv, (tuple, list)) else float(vv) for m, vv in v.items()} for k, v in summ.items()}, open(out("compare_results.json"), "w"), indent=1)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
tim = [k for k in rows if k.startswith("timer")]
a.errorbar([summ[k]["litres"][0] for k in tim], [summ[k]["dry"][0] for k in tim], xerr=[summ[k]["litres"][1] for k in tim], yerr=[summ[k]["dry"][1] for k in tim], fmt="o-", color=PAL["orange"], label="timer baseline (1, 2, 3, 4, 6 h)", ms=4)
for k in tim: a.annotate(k.split()[1] + " h", (summ[k]["litres"][0], summ[k]["dry"][0]), (4, 4), textcoords="offset points", fontsize=7)
for k, c, mk, lab in (("event naive", PAL["purple"], "D", "event-driven, detector at 0.30"), ("event", PAL["blue"], "*", "event-driven, detector at 0.33")):
    a.errorbar([summ[k]["litres"][0]], [summ[k]["dry"][0]], xerr=[summ[k]["litres"][1]], yerr=[summ[k]["dry"][1]], fmt=mk, color=c, ms=10 if mk == "*" else 6, label=lab)
a.set(xlabel="water used per day (litres)", ylabel="plant-hours below the dry threshold (per day)", title="Water against dryness"); a.legend(fontsize=7.5)
names = ["event naive", "event"] + tim; vals = [summ[k]["energy"][0] for k in names]
b.bar(range(len(names)), vals, color=[PAL["purple"], PAL["blue"]] + [PAL["orange"]] * len(tim), yerr=[summ[k]["energy"][1] for k in names]); b.axhline(G.BATT_MAH * G.USABLE, color=PAL["red"], ls=":"); b.text(0.1, G.BATT_MAH * G.USABLE * 0.9, "usable pack 2080 mAh", fontsize=7.5, color=PAL["red"])
b.set(xticks=range(len(names)), xticklabels=[n.replace("timer ", "T ").replace("event naive", "ev 0.30").replace("event", "ev 0.33") if n != "event naive" else "ev 0.30" for n in names], ylabel="battery charge used per day (mAh)", title="Rover energy per 12 h day"); b.tick_params(axis="x", labelsize=7)
save(fig, out("fig04_compare.png"))
