"""Fig 5: edge versus cloud. Left: data sent to the cloud per day for 100 nodes against the edge aggregation window. Right: alert latency (ASSUMED stage times of Unit 1) for an edge and a cloud decision.
ASSUMED: 540 B on the wire per raw reading (Unit 5, fresh MQTT QoS 1), cloud price 0.09 per GB and 1.00 per million messages (illustrative units)."""
from _common import *
use_code("cloud/telemetry_np")
import telemetry_np as T

N_NODES, RAW = 100, 540
raw_day = T.daily_bytes(N_NODES, 60, RAW)
wins = np.array([60, 300, 600, 1800, 3600])
# the gateway sends one batch message per window on a persistent connection: 100 nodes x 4 statistics x 8 bytes + 40 B IP/TCP + 4 B MQTT fixed + 40 B topic and framing (assumed)
batch_bytes = lambda w: N_NODES * 4 * 8 + 84
agg_day = np.array([86400.0 / w * batch_bytes(w) for w in wins])
price_gb, price_m = 0.09, 1.00
cost = lambda bytes_day, msgs_day: 30 * (bytes_day / 1e9 * price_gb + msgs_day / 1e6 * price_m)
print("raw: bytes/day", raw_day, "MB/day", round(raw_day / 1e6, 2), "GB/month", round(30 * raw_day / 1e9, 2), "msgs/month", N_NODES * 1440 * 30, "cost/month", round(cost(raw_day, N_NODES * 1440), 2))
for w, b in zip(wins, agg_day): print("window", w, "s: bytes/day", round(b), "MB/day", round(b / 1e6, 3), "msgs/month", int(86400 / w * 30), "cost/month", round(cost(b, 86400 / w), 4), "reduction x", round(raw_day / b, 1))
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.semilogy(wins / 60, agg_day / 1e6, "o-", color=PAL["blue"], label="edge-aggregated")
a.axhline(raw_day / 1e6, color=PAL["red"], ls="--", label="every reading to the cloud"); a.set(xlabel="aggregation window at the edge (min)", ylabel="data to the cloud (MB per day, log)", title="100 nodes, one reading per minute"); a.legend(fontsize=8)
stages_edge = {"sensor": 5, "rover": 5, "motor": 5}; stages_cloud = {"sensor": 5, "uplink": 60, "cloud": 20, "downlink": 60, "motor": 5}
for k, (n, st) in enumerate([("edge", stages_edge), ("cloud", stages_cloud)]):
    left = 0
    for j, (s, v) in enumerate(st.items()):
        b.barh(k, v, left=left, color=[PAL["blue"], PAL["orange"], PAL["green"], PAL["red"], PAL["purple"]][j], edgecolor="white"); left += v
    b.text(left + 3, k, f"{left} ms", va="center", fontsize=9)
b.set(yticks=[0, 1], yticklabels=["edge", "cloud"], xlabel="latency of an alert or command (ms, assumed)", xlim=(0, 190), title="Where a decision runs")
save(fig, out("fig05_edge.png"))
