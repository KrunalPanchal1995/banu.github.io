"""Fig 3: three streaming detectors on a unit-variance signal with three kinds of anomaly starting at sample 300: a one-sample spike (+7), a step (+1.5) and a drift (0.02 per sample).
Left: the step case with each detector's alarms. Right: mean detection delay (samples); an X marks a case detected in under 95 percent of runs."""
from _common import *
use_code("cloud/telemetry_np")
import telemetry_np as T

def mk(kind):
    def f(rng):
        x = rng.normal(0, 1, 600)
        if kind == "spike": x[300] += 7
        elif kind == "step": x[300:] += 1.5
        else: x[300:] += 0.02 * np.arange(300)
        return x, 300
    return f
dets = {"fixed limit +-3": lambda: T.ThresholdDetector(-3, 3), "z-score (60, 3)": lambda: T.ZScoreDetector(60, 3.0), "EWMA (0.1, 3)": lambda: T.EwmaDetector(0.0, 1.0, 0.1, 3.0)}
kinds = ["spike", "step", "drift"]
res = {(dn, k): T.detection_stats(df, mk(k), 300, seed=11) for dn, df in dets.items() for k in kinds}
for k in kinds:
    for dn in dets: r = res[(dn, k)]; print(f"{k:6s} {dn:16s} detected {r['detected']*100:5.1f}%  mean delay {r['mean_delay']:7.1f}  false alarms/1000 {r['false_alarms_per_1000']:6.2f}")
x, _ = mk("step")(np.random.default_rng(4))
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1.25, 1]))
a.plot(x, color=PAL["grey"], lw=0.6); a.axvline(300, color=PAL["black"], ls=":", lw=0.8); a.text(305, 3.2, "step +1.5", fontsize=8)
for k, ((dn, df), col) in enumerate(zip(dets.items(), (PAL["red"], PAL["orange"], PAL["blue"]))):
    al = T.run_detector(df(), x); idx = np.where(al)[0]; a.plot(idx, np.full(len(idx), -3.6 - 0.45 * k), "|", color=col, ms=6, label=dn)
a.set(xlabel="sample", ylabel="reading (std units)", title="Alarms on a step (rows below the trace)"); a.legend(fontsize=7, loc="upper left", ncol=1)
wd = 0.26
for i, (dn, col) in enumerate(zip(dets, (PAL["red"], PAL["orange"], PAL["blue"]))):
    for j, k in enumerate(kinds):
        r = res[(dn, k)]; val = r["mean_delay"] if r["detected"] >= 0.95 else 0.0
        b.bar(j + (i - 1) * wd, val, wd, color=col, label=dn if j == 0 else None)
        if r["detected"] < 0.95: b.plot(j + (i - 1) * wd, 2, "x", color=col, ms=8, mew=2); b.text(j + (i - 1) * wd, 5, f"{r['detected']*100:.0f}%", ha="center", fontsize=6.5, color=col)
        else: b.text(j + (i - 1) * wd, val + 1, f"{val:.0f}", ha="center", fontsize=7, color=col)
b.set(xticks=range(3), xticklabels=kinds, ylabel="mean detection delay (samples)", title="Which detector for which fault"); b.legend(fontsize=7)
save(fig, out("fig03_detectors.png"))
