"""Fig 4: a digital twin (the Unit 1 room model) finds a hidden heater fault that statistics on the temperature cannot see.
Fault: from minute 180 the heater delivers 70 percent of its power; the thermostat still holds 21 C by running longer. The twin predicts the next temperature from the commanded heater state; a CUSUM on its residual (on-minutes only) detects the fault."""
from _common import *
use_code("foundations/sense_think_act"); use_code("cloud/telemetry_np")
import sense_think_act as S, telemetry_np as T

TOUT, TAU, K, SIG = 5.0, 60.0, 0.5, 0.2
def run(seed, power_after, t_fault=180, n=480):
    rng = np.random.default_rng(seed); room = S.Room(21.0, TOUT, TAU, K); ctrl = S.BangBang(21.0, 0.5)
    y = np.zeros(n); u = np.zeros(n, int); T_true = np.zeros(n)
    for k in range(n):
        y[k] = room.T + rng.normal(0, SIG); u[k] = ctrl(y[k]); T_true[k] = room.T
        room.k = K * (power_after if k >= t_fault else 1.0); room.step(u[k], 1.0)
    return y, u, T_true
def twin_pred(yk, uk):
    r = S.Room(yk, TOUT, TAU, K); return r.step(uk, 1.0)
def residuals(y, u):
    return np.array([y[k + 1] - twin_pred(y[k], u[k]) for k in range(len(y) - 1)])
# calibrate sigma of the raw temperature and of the residual from a fault-free run
y0, u0, _ = run(0, 1.0); r0 = residuals(y0, u0); on0 = u0[:-1] == 1
sd_T, sd_r = float(np.std(y0[60:])), float(np.std(r0[on0][10:])); mu_r = float(r0[on0][10:].mean())
print("fault-free: std of temperature", round(sd_T, 3), " std of residual on on-minutes", round(sd_r, 3), " mean residual on on-minutes", round(float(r0[on0].mean()), 4))
print("expected residual per on-minute under 70 percent heater:", round(-(K * 0.3) * TAU * (1 - np.exp(-1 / TAU)), 4))
def detect_stat(y, t_fault):
    d = T.EwmaDetector(21.0, sd_T, 0.1, 3.0); a = T.run_detector(d, y); return a
def detect_twin(y, u):
    r = residuals(y, u); cs = T.CusumDetector(mu_r, 0.075, 2.3); a = np.zeros(len(r), bool)
    for k in range(len(r)):
        if u[k] == 1:
            a[k] = cs.update(r[k])
        else:
            a[k] = a[k - 1] if k else False
    return a
res = {"stat": [], "twin": []}; fa = {"stat": 0, "twin": 0}; tot = 0
ff_alarm_runs = 0; ff_on = 0; ff_alarm_min = 0
for s_ in range(100):
    yy, uu, _ = run(5000 + s_, 1.0); aa = detect_twin(yy, uu); ff_alarm_runs += int(aa.any()); ff_on += int((uu[:-1] == 1).sum()); ff_alarm_min += int(aa.sum())
print('fault-free 480-min runs with a twin alarm:', ff_alarm_runs, 'of 100')
for s in range(100):
    y, u, _ = run(1000 + s, 0.7)
    a_s, a_t = detect_stat(y, 180), detect_twin(y, u)
    fa["stat"] += int(a_s[:180].sum() > 0); fa["twin"] += int(a_t[:180].sum() > 0)
    for nm, a in (("stat", a_s), ("twin", a_t)):
        hit = np.where(a[180:])[0]; res[nm].append(hit[0] if len(hit) else None)
for nm in res:
    ok = [d for d in res[nm] if d is not None]; print(nm, "detected", len(ok), "of 100, mean delay (min)", round(float(np.mean(ok)), 1) if ok else None, "; runs with a false alarm before the fault:", fa[nm])
y, u, Tt = run(1000, 0.7); r = residuals(y, u); a_t = detect_twin(y, u); a_s = detect_stat(y, 180)
fig, axs = plt.subplots(3, 1, figsize=(7.2, 6.0), sharex=True, gridspec_kw=dict(height_ratios=[2, 2, 1]))
axs[0].plot(y, color=PAL["blue"], lw=0.7); axs[0].axvline(180, color=PAL["red"], ls="--", lw=1); axs[0].text(185, 22.0, "heater drops to 70 percent", color=PAL["red"], fontsize=8)
axs[0].set(ylabel="measured temperature (C)", title="The thermostat hides the fault: the temperature stays in its usual band"); axs[0].set_ylim(19.5, 22.6)
ia = np.where(a_s)[0]; axs[0].plot(ia, np.full(len(ia), 19.7), "|", color=PAL["orange"], ms=6, label="EWMA on temperature alarms"); axs[0].legend(fontsize=7.5, loc="lower left")
axs[1].plot(np.where(u[:-1] == 1)[0], r[u[:-1] == 1], ".", color=PAL["grey"], ms=2.5, label="twin residual (heater on)"); axs[1].axhline(0, color=PAL["black"], lw=0.5); axs[1].axvline(180, color=PAL["red"], ls="--", lw=1)
axs[1].axhline(-(K * 0.3) * TAU * (1 - np.exp(-1 / TAU)), color=PAL["red"], ls=":", lw=0.9); axs[1].text(5, -0.2, "expected fault shift -0.149 per on-minute", fontsize=7.5, color=PAL["red"])
axs[1].set(ylabel="measured minus predicted (C)"); axs[1].legend(fontsize=7.5, loc="upper left")
ib = np.where(a_t)[0]; axs[2].plot(ib, np.ones(len(ib)), "|", color=PAL["blue"], ms=10); axs[2].set(yticks=[1], yticklabels=["CUSUM\nalarm"], xlabel="time (min)", ylim=(0.5, 1.5))
save(fig, out("fig04_twin.png"))
print("example run: first twin alarm minute", int(np.where(a_t[180:])[0][0]) + 180 if a_t[180:].any() else None, " first stat alarm", int(np.where(a_s[180:])[0][0]) + 180 if a_s[180:].any() else None)
