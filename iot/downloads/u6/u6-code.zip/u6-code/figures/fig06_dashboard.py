"""Fig 6: the dashboard, drawn from the real Flask API. Three zones, 6 hours of data, an injected glitch and one silent node."""
from _common import *
use_code("cloud/telemetry_np")
import json, math, dashboard as D

now = [0.0]; store = D.Store(now=lambda: now[0], period_s=60, stale_periods=3)
app = D.create_app(store); c = app.test_client(); rng = np.random.default_rng(8)
T_END = 6 * 3600
for i in range(0, T_END, 60):
    for z in (1, 2, 3):
        if z == 3 and i > T_END - 600: continue                                          # zone 3 goes silent for the last 10 minutes
        soil = 38 - 0.004 * (i % 14400) / 60 * 4 + rng.normal(0, 0.3) + (6 if i % 14400 == 0 and i > 0 else 0)
        temp = 21 + 0.6 * math.sin(i / 700 + z) + rng.normal(0, 0.2)
        if z == 2 and i == 3 * 3600: temp = 44.0                                         # a glitch above the limit
        c.post("/api/ingest", json=dict(topic=f"greenhouse/zone{z}/soil", value=soil, t=float(i))); c.post("/api/ingest", json=dict(topic=f"greenhouse/zone{z}/temp", value=temp, t=float(i)))
now[0] = float(T_END)
latest = c.get("/api/latest").get_json(); alerts = c.get("/api/alerts").get_json()
print("topics", len(latest), "alerts", len(alerts), [(a["kind"], a["topic"], round(a["value"], 1)) for a in alerts][:6])
print("stale:", [k for k, v in latest.items() if v["stale"]])
fig = plt.figure(figsize=(7.8, 5.0)); gs = fig.add_gridspec(2, 3, height_ratios=[1, 2.2])
for j, z in enumerate((1, 2, 3)):
    ax = fig.add_subplot(gs[0, j]); ax.axis("off"); ax.grid(False)
    s, t = latest[f"greenhouse/zone{z}/soil"], latest[f"greenhouse/zone{z}/temp"]
    col = PAL["red"] if s["stale"] else PAL["green"]
    ax.add_patch(plt.Rectangle((0.02, 0.05), 0.96, 0.9, fc=col, alpha=0.15, ec=col)); ax.text(0.5, 0.78, f"zone {z}", ha="center", fontsize=10, fontweight="bold")
    ax.text(0.5, 0.5, f"soil {s['value']:.1f} %   temp {t['value']:.1f} C", ha="center", fontsize=9); ax.text(0.5, 0.2, "STALE (silent {:.0f} min)".format(s["age_s"] / 60) if s["stale"] else "fresh ({:.0f} s old)".format(s["age_s"]), ha="center", fontsize=8.5, color=col)
ax = fig.add_subplot(gs[1, :])
for z, col in zip((1, 2, 3), (PAL["blue"], PAL["orange"], PAL["green"])):
    s = c.get(f"/api/series?topic=greenhouse/zone{z}/temp").get_json(); ax.plot(np.array(s["t"]) / 3600, s["v"], color=col, lw=0.8, label=f"zone {z} temperature")
ta = [a_ for a_ in alerts if a_["topic"].endswith("/temp")]
for a_ in ta: ax.plot(a_["t"] / 3600, a_["value"], "v", color=PAL["red"], ms=7)
if ta: ax.annotate("+".join(sorted({a_["kind"] for a_ in ta})) + " alerts (zone 2)", (ta[0]["t"] / 3600, ta[0]["value"]), (ta[0]["t"] / 3600 + 0.15, 42.5), fontsize=7.5, color=PAL["red"])
ax.axhline(40, color=PAL["red"], ls=":", lw=0.8); ax.text(0.05, 40.5, "limit 40 C", fontsize=7.5, color=PAL["red"])
ax.set(xlabel="time (h)", ylabel="temperature (C)", title="Series from /api/series, alerts from /api/alerts"); ax.legend(fontsize=7.5, loc="lower right", ncol=3)
save(fig, out("fig06_dashboard.png"))
