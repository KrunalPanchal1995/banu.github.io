"""Unit 6 extra numbers: persistent-connection wire bytes per payload format, alert-fatigue arithmetic, EWMA step/ramp response, residual noise."""
from _common import *
use_code("net/mqtt_mini"); use_code("cloud/telemetry_np")
import netcalc as N, math, telemetry_np as T
TOPIC = "greenhouse/zone1/soil"
for name, n in (("JSON long", 70), ("JSON short", 50), ("CBOR short", 39), ("CBOR int", 20), ("binary", 11)):
    print(f"{name:11s} payload {n:3d} B  persistent QoS1 wire {N.wire_mqtt_persistent(TOPIC, bytes(n), 1):4d} B   fresh {N.wire_mqtt_fresh(TOPIC, bytes(n), 'node1', 1):4d} B")
print("persistent saving JSON long -> binary:", N.wire_mqtt_persistent(TOPIC, bytes(70), 1) - N.wire_mqtt_persistent(TOPIC, bytes(11), 1), "B of", N.wire_mqtt_persistent(TOPIC, bytes(70), 1), "=", round((N.wire_mqtt_persistent(TOPIC, bytes(70), 1) - N.wire_mqtt_persistent(TOPIC, bytes(11), 1)) / N.wire_mqtt_persistent(TOPIC, bytes(70), 1) * 100, 1), "percent")
print("quantisation: temperature step 0.01 C -> max error", 0.005, "; battery 1 mV -> 0.5 mV; temp range int16 in 0.01 C: +-327.67 C")
print("-- alert fatigue")
for k in (3.0, 3.5, 4.0, 4.5):
    p = math.erfc(k / math.sqrt(2)); print(f"k={k}: P(|Z|>k)={p:.2e}  false alarms per day for 6 sensors at 1/min: {p * 6 * 1440:.3f}; for 10 sensors: {p * 10 * 1440:.3f}")
k = 3.0
while math.erfc(k / math.sqrt(2)) * 8640 > 1: k += 0.001
print("k for under 1 false alarm per day with 6 sensors at 1/min:", round(k, 2), " P=", f"{math.erfc(k/math.sqrt(2)):.2e}")
print("-- EWMA lam=0.1 L=3: steady limit (units of sigma)", round(3 * math.sqrt(0.1 / 1.9), 4), " step 1.5: samples to cross:", round(math.log(1 - 3 * math.sqrt(0.1 / 1.9) / 1.5) / math.log(0.9), 2), " spike 7: peak lam*7 =", 0.7, " ramp 0.02/sample: steady lag", round(0.02 * 0.9 / 0.1, 3), "sigma; crossing time approx", round((3 * math.sqrt(0.1 / 1.9) + 0.18) / 0.02, 1))
print("-- twin residual: expected noise std", round(0.2 * math.sqrt(1 + math.exp(-2 / 60)), 4), " shift per on-minute at power p: p=0.7", round((0.7 - 1) * 0.5 * 60 * (1 - math.exp(-1 / 60)), 4), " p=0.5", round((0.5 - 1) * 0.5 * 60 * (1 - math.exp(-1 / 60)), 4))
print("-- z-score example: (22.2-21.0)/0.3 =", (22.2 - 21.0) / 0.3)
print("-- EWMA lam 0.2 sigma 0.5 L 3: steady limit", 3 * 0.5 * math.sqrt(0.2 / 1.8), " t=1 limit", 3 * 0.5 * math.sqrt(0.2 / 1.8 * (1 - 0.8 ** 2)))
print("-- P4: 200 nodes, persistent connection QoS1, 1/min: JSON long vs binary MB/day:", round(200 * 1440 * N.wire_mqtt_persistent(TOPIC, bytes(70), 1) / 1e6, 1), round(200 * 1440 * N.wire_mqtt_persistent(TOPIC, bytes(11), 1) / 1e6, 1))
print("-- aggregation: 10 samples -> mean change of a +3 spike:", 3 / 10)
