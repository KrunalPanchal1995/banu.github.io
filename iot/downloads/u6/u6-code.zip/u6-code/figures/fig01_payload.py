"""Fig 1: payload formats for one reading. Left: payload bytes. Right: bytes on the wire per reading (MQTT QoS 1, new connection each wake, simplified model of Unit 5)."""
from _common import *
use_code("cloud/telemetry_np"); use_code("net/mqtt_mini")
import telemetry_np as T, netcalc as N

TS = 1760000000
verbose = dict(zone=1, soil_raw=1832, temp_c=21.5, batt_v=3.71, ts=TS); short = dict(z=1, s=1832, t=21.5, b=3.71, ts=TS)
intkeys = {1: 1, 2: 1832, 3: 215, 4: 3710, 5: TS}                      # temperature in 0.1 degC, battery in mV (scaled integers)
items = [("JSON,\nlong keys", T.encode_json(verbose)), ("JSON,\nshort keys", T.encode_json(short)), ("CBOR,\nshort keys", T.cbor_encode(short)), ("CBOR,\ninteger keys", T.cbor_encode(intkeys)), ("packed\nbinary", T.pack_reading(1, 1832, 21.5, 3.71, ts=TS))]
for n, b in items: print(n.replace("\n", " "), len(b), "B", "wire", N.wire_mqtt_fresh("greenhouse/zone1/soil", b, "node1", 1))
print("JSON long:", items[0][1].decode()); print("CBOR int keys hex:", items[3][1].hex())
assert T.cbor_decode(items[3][1]) == intkeys and T.unpack_reading(items[4][1])["temp_c"] == 21.5
cols = [PAL["red"], PAL["orange"], PAL["blue"], PAL["sky"], PAL["green"]]
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.bar(range(5), [len(x) for _, x in items], color=cols)
for i, (_, x) in enumerate(items): a.text(i, len(x) + 1.5, str(len(x)), ha="center", fontsize=8.5)
a.set(xticks=range(5), xticklabels=[n for n, _ in items], ylabel="payload (bytes)", title="Same five numbers"); a.tick_params(axis="x", labelsize=7)
w = [N.wire_mqtt_fresh("greenhouse/zone1/soil", x, "node1", 1) for _, x in items]
b.bar(range(5), w, color=cols)
for i, v in enumerate(w): b.text(i, v + 6, str(v), ha="center", fontsize=8.5)
b.set(xticks=range(5), xticklabels=[n for n, _ in items], ylabel="bytes on the wire per reading", title="Whole exchange (new connection)", ylim=(0, max(w) * 1.12)); b.tick_params(axis="x", labelsize=7)
save(fig, out("fig01_payload.png"))
print("saving on wire verbose->binary:", w[0] - w[-1], "B =", round((w[0] - w[-1]) / w[0] * 100, 1), "percent; per day at 1/min kB:", [round(v * 1440 / 1e3, 1) for v in w])
