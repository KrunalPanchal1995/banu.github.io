"""Isolate the effect of the CUSUM baseline (selection bias): same k and h, baseline 0 versus the measured fault-free mean, on 100 fault-free 480-minute runs, and the same two on 100 fault runs."""
import sys
sys.argv = ["x"]
from _common import *
use_code("foundations/sense_think_act"); use_code("cloud/telemetry_np")
import sense_think_act as S, telemetry_np as T
TOUT, TAU, K, SIG = 5.0, 60.0, 0.5, 0.2
def run(seed, power_after, t_fault=180, n=480):
    rng = np.random.default_rng(seed); room = S.Room(21.0, TOUT, TAU, K); ctrl = S.BangBang(21.0, 0.5); y = np.zeros(n); u = np.zeros(n, int)
    for k in range(n):
        y[k] = room.T + rng.normal(0, SIG); u[k] = ctrl(y[k]); room.k = K * (power_after if k >= t_fault else 1.0); room.step(u[k], 1.0)
    return y, u
def resid(y, u):
    return np.array([y[k + 1] - S.Room(y[k], TOUT, TAU, K).step(u[k], 1.0) for k in range(len(y) - 1)])
def alarms(y, u, mu0, k, h):
    r = resid(y, u); cs = T.CusumDetector(mu0, k, h); a = np.zeros(len(r), bool)
    for i in range(len(r)):
        a[i] = cs.update(r[i]) if u[i] == 1 else (a[i - 1] if i else False)
    return a
for mu0 in (0.0, 0.0565):
    fa = sum(alarms(*run(5000 + s, 1.0), mu0, 0.075, 2.3).any() for s in range(100))
    det = []
    for s in range(100):
        a = alarms(*run(1000 + s, 0.7), mu0, 0.075, 2.3); hit = np.where(a[180:])[0]; det.append(hit[0] if len(hit) else None)
    ok = [d for d in det if d is not None]
    print(f"baseline {mu0}: fault-free runs with an alarm {fa}/100; fault detected {len(ok)}/100, mean delay {np.mean(ok):.1f} min")
