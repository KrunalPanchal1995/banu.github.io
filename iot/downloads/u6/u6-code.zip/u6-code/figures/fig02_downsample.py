"""Fig 2: aggregating at the edge. Thermostat temperature (Unit 1 model) sampled every minute for 6 h with one 1-sample glitch; 10-minute mean, min and max."""
from _common import *
use_code("foundations/sense_think_act"); use_code("cloud/telemetry_np")
import sense_think_act as S, telemetry_np as T

r = S.simulate(S.BangBang(21.0, 0.5), S.Room(21.0, 5.0), t_end=360, dt=0.1, sample_period=1.0, sigma=0.0)
t_min = np.arange(360.0); idx = (t_min * 10).astype(int)
rng = np.random.default_rng(3); raw = r["T"][idx] + rng.normal(0, 0.2, 360); raw[205] += 3.0                    # one glitch of +3 degC at minute 205
d = T.downsample(t_min * 60, raw, 600.0)
fig, ax = plt.subplots(figsize=FIG["single"])
ax.plot(t_min, raw, color=PAL["grey"], lw=0.6, label="raw, 1 per minute (360 points)")
tb = d["t"] / 60 + 5
ax.fill_between(tb, d["min"], d["max"], color=PAL["sky"], alpha=0.5, label="10-min min to max")
ax.plot(tb, d["mean"], "o-", color=PAL["blue"], ms=3, label="10-min mean (36 points)")
ax.annotate("glitch +3 C", (205, raw[205]), (225, 24.6), arrowprops=dict(arrowstyle="->", color=PAL["red"]), color=PAL["red"], fontsize=8)
ax.set(xlabel="time (min)", ylabel="temperature (C)", title="Mean alone hides a spike; min and max keep it"); ax.legend(fontsize=7.5, loc="lower right")
b = int(205 * 60 // 600); j = int(np.where(d["t"] == b * 600)[0][0])
print("points raw", len(raw), "-> aggregated", len(d["t"]), "; bucket containing the glitch: mean", round(float(d["mean"][j]), 3), "max", round(float(d["max"][j]), 3), "; neighbour bucket mean", round(float(d["mean"][j - 1]), 3), "max", round(float(d["max"][j - 1]), 3))
print("glitch amplitude seen in mean (C):", round(float(d["mean"][j] - np.mean([d["mean"][j - 1], d["mean"][j + 1]])), 3), "seen in max:", round(float(d["max"][j] - np.mean([d["max"][j - 1], d["max"][j + 1]])), 3))
save(fig, out("fig02_downsample.png"))
