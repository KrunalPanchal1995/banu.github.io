"""Fig 5: the soil node's power budget. Left: charge per 60 s cycle by state, before and after shortening the Wi-Fi connect.
Right: longest awake time per cycle that still gives 30 days (R4), against the reporting period.
ALL CURRENTS AND TIMES ARE ASSUMED illustrative values (typical order of magnitude for a Wi-Fi microcontroller), not measurements."""
from _common import *
from viz_style import CYCLE
use_code("electronics/circuits_np")
import circuits_np as C

CAP, ETA, SLP = 2000.0, 0.8, 0.01
def cyc(connect_s, period=60.0):
    st = [("wake + read sensor", 50.0, 0.2), ("Wi-Fi connect", 100.0, connect_s), ("MQTT publish", 140.0, 0.3), ("shutdown", 50.0, 0.2)]
    awake = sum(s for _, _, s in st); st.append(("deep sleep", SLP, period - awake)); return st
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1, 1.1]))
res = {}
for k, (name, cs) in enumerate([("before: connect 1.3 s", 1.3), ("after: connect 0.5 s", 0.5)]):
    st = cyc(cs); avg, period, share = C.power_budget(st); life = C.battery_life_days(CAP, avg, ETA); res[name] = (avg, life)
    left = 0
    for j, (sname, i, s) in enumerate(st):
        w = i * s; a.barh(k, w, left=left, color=CYCLE[j % len(CYCLE)], edgecolor="white", label=sname if k == 0 else None); left += w
    a.text(left + 4, k, f"{avg:.3f} mA avg\n{life:.1f} days", va="center", fontsize=8)
    print(name, "awake s", round(sum(s for n, _, s in st if n != "deep sleep"), 2), "charge per cycle mC", round(left, 2), "avg mA", round(avg, 4), "life days", round(life, 2), {n: round(v * 100, 2) for n, v in share.items()})
a.set(yticks=[0, 1], yticklabels=["before", "after"], xlabel="charge per 60 s cycle (mA x s)", xlim=(0, 260), title="Where the charge goes"); a.legend(fontsize=6.5, loc="upper center", bbox_to_anchor=(0.5, -0.22), ncol=3)
periods = np.array([10, 20, 30, 60, 120, 300, 600, 900])
for iact, col, lab in ((96.0, PAL["red"], "mean awake current 96 mA (before)"), (93.3, PAL["blue"], "mean awake current 93 mA (after)")):
    b.semilogx(periods, [C.max_awake_seconds(p, iact, SLP, CAP, 30) for p in periods], "o-", color=col, label=lab)
b.axhline(2.0, color=PAL["grey"], ls=":", lw=1)
b.plot(60, 2.0, "x", color=PAL["red"], ms=9, ls="none", label="before: 2.0 s awake (fails)"); b.plot(60, 1.2, "o", color=PAL["green"], ms=7, ls="none", label="after: 1.2 s awake (passes)")
b.set(xlabel="reporting period (s, log scale)", ylabel="max awake time per report (s)", title="Awake-time budget for 30 days"); b.legend(fontsize=7)
print("max awake at 60 s, 96 mA:", round(C.max_awake_seconds(60, 96.0, SLP, CAP, 30), 3), " budget avg mA:", round(CAP * ETA / (24 * 30), 4))
for p in periods: print("period", p, "max awake s", round(C.max_awake_seconds(p, 96.0, SLP, CAP, 30), 3))
save(fig, out("fig05_budget.png"))
