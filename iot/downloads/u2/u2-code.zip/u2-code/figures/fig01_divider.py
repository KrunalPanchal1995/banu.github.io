"""Fig 1: the voltage divider. Left: a soil sensor (a resistance) read through a divider. Right: loading error when the next stage draws current."""
from _common import *
use_code("electronics/circuits_np")
import circuits_np as C

VIN, R1 = 3.3, 10e3
rs = np.logspace(3, 5.3, 200)                         # sensor resistance 1k .. 200k
vout = np.array([C.divider(VIN, R1, r) for r in rs])
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.semilogx(rs / 1e3, vout, color=PAL["blue"]); a.set(xlabel="sensor resistance Rs (kohm, log scale)", ylabel="divider output (V)", title="Reading a resistive sensor")
a2 = a.twinx(); a2.set_ylim(0, VIN / C.lsb(3.3, 12) * 0 + 4095 * 1.0); a2.set_ylabel("12-bit ADC code"); a2.spines["right"].set_visible(True); a2.grid(False)
a2.set_ylim(a.get_ylim()[0] / 3.3 * 4096, a.get_ylim()[1] / 3.3 * 4096)
for r in (2e3, 10e3, 100e3): print("Rs", r, "vout", round(C.divider(VIN, R1, r), 4), "code12", int(C.adc_code(C.divider(VIN, R1, r), 3.3, 12)))
RL = np.logspace(3, 7, 200); R2 = 10e3
v = np.array([C.divider(VIN, 10e3, R2, rl) for rl in RL]); ideal = C.divider(VIN, 10e3, R2)
b.semilogx(RL / 1e3, (v - ideal) / ideal * 100, color=PAL["red"]); b.axhline(0, color=PAL["grey"], lw=0.8)
b.set(xlabel="load resistance RL (kohm, log scale)", ylabel="output error (percent)", title="Loading: R1 = R2 = 10 kohm")
for k in (1, 10, 100):
    rl = k * R2; e = (C.divider(VIN, 10e3, R2, rl) - ideal) / ideal * 100; b.plot(rl / 1e3, e, "o", color=PAL["orange"]); b.annotate(f"RL = {k}x R2: {e:.1f}%", (rl / 1e3, e), textcoords="offset points", xytext=(6, -12), fontsize=8)
    print("load", k, "xR2 -> error percent", round(e, 3))
print("ideal", ideal, "thevenin", C.parallel(10e3, 10e3))
save(fig, out("fig01_divider.png"))
