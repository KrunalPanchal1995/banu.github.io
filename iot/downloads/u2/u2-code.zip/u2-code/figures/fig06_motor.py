"""Fig 6: sizing the rover's motor drive. ASSUMED catalogue-style numbers: 6 V gear motor, stall 0.8 A, no-load 0.15 A at 200 rpm; rover 1.5 kg, wheel radius 33 mm,
rolling resistance 0.05; battery 7.4 V (2 cells); bipolar bridge drop 2.0 V vs MOSFET bridge drop 0.4 V (typical orders of magnitude; check a datasheet)."""
from _common import *
use_code("electronics/circuits_np")
import circuits_np as C

M = C.DCMotor(6.0, 0.8, 0.15, 200.0)
mass, mu, g, r = 1.5, 0.05, 9.81, 0.033
tau_cruise = mu * mass * g * r / 2              # per motor, N m
acc = 0.5; tau_acc = tau_cruise + mass * acc * r / 2
w_need = 0.5 / r
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
tq = np.linspace(0, M.stall_torque(6.0), 100)
for v, col in ((6.0, PAL["blue"]), (4.0, PAL["orange"])):
    tq_v = tq[tq <= M.stall_torque(v)]; a.plot(tq_v * 1e3, [M.speed(x, v) * 60 / (2 * np.pi) for x in tq_v], color=col, label=f"{v:g} V")
a.plot(tau_cruise * 1e3, M.speed(tau_cruise, 6.0) * 60 / (2 * np.pi), "o", color=PAL["green"]); a.annotate("cruise", (tau_cruise * 1e3, M.speed(tau_cruise, 6.0) * 60 / (2 * np.pi)), textcoords="offset points", xytext=(6, 4), fontsize=8)
a.plot(tau_acc * 1e3, M.speed(tau_acc, 6.0) * 60 / (2 * np.pi), "s", color=PAL["red"]); a.annotate("accelerating", (tau_acc * 1e3, M.speed(tau_acc, 6.0) * 60 / (2 * np.pi)), textcoords="offset points", xytext=(6, 4), fontsize=8)
a.axhline(w_need * 60 / (2 * np.pi), color=PAL["grey"], ls=":"); a.text(2, w_need * 60 / (2 * np.pi) + 3, "0.5 m/s needs 144 rpm", fontsize=8, color=PAL["grey"])
a.set(xlabel="shaft torque (mN m)", ylabel="speed (rpm)", title="Speed-torque line of one motor"); a.legend(fontsize=8)
need_c = M.volts_needed(w_need, tau_cruise); need_a = M.volts_needed(w_need, tau_acc)
vs = np.linspace(6.0, 8.4, 50)
for drop, col, lab in ((2.0, PAL["red"], "bipolar bridge (drop 2.0 V)"), (0.4, PAL["green"], "MOSFET bridge (drop 0.4 V)")):
    b.plot(vs, [C.h_bridge_voltage(v, 1.0, drop) for v in vs], color=col, label=lab)
b.axhline(need_c, color=PAL["grey"], ls=":"); b.axhline(need_a, color=PAL["grey"], ls="--")
b.text(6.05, need_c + 0.05, f"cruise needs {need_c:.2f} V", fontsize=8, color=PAL["grey"]); b.text(6.05, need_a + 0.05, f"accelerate needs {need_a:.2f} V", fontsize=8, color=PAL["grey"])
b.axvline(7.4, color=PAL["black"], lw=0.8); b.text(7.42, 7.7, "7.4 V pack", fontsize=8)
b.set(xlabel="battery voltage (V)", ylabel="max motor voltage at full duty (V)", title="The bridge drop eats the headroom"); b.legend(fontsize=8, loc="lower right")
print("k V s/rad", round(M.k, 4), "R", round(M.R, 3), "w0 rad/s", round(M.w0, 3), "stall torque N m at 6 V", round(M.stall_torque(6.0), 4))
print("tau cruise N m", round(tau_cruise, 5), "tau accel", round(tau_acc, 5), "w need rad/s", round(w_need, 3), "rpm", round(w_need * 60 / (2 * np.pi), 1))
print("volts needed cruise", round(need_c, 3), "accel", round(need_a, 3))
print("current cruise A", round(tau_cruise / M.k + M.i0, 4), "accel A", round(tau_acc / M.k + M.i0, 4))
for drop in (2.0, 0.4):
    for vb in (7.4, 6.8):
        vm = C.h_bridge_voltage(vb, 1.0, drop); print("drop", drop, "pack", vb, "max motor V", round(vm, 2), "duty for cruise", round(need_c / vm, 3), "duty for accel", round(need_a / vm, 3), "ok accel", need_a <= vm)
save(fig, out("fig06_motor.png"))
