"""Unit 2 extra numbers quoted in the text (level-shift divider, ADC SNR, rover endurance, flyback spike, pull-up). ASSUMED parts values are marked."""
from _common import *
use_code("electronics/circuits_np")
import circuits_np as C
import itertools, math

# 1) level shift 5 V -> at most 3.3 V with two E12 resistors (10 ohm .. 100k)
best = []
vals = [v * m for v in C.E12 for m in (1e3, 1e4)] + [1e5]
for r1, r2 in itertools.product(vals, vals):
    vo = C.divider(5.0, r1, r2)
    if vo <= 3.3: best.append((3.3 - vo, r1, r2, vo))
best.sort(); print("level shift best 3 (r1, r2, vout):", [(b[1], b[2], round(b[3], 3)) for b in best[:3]])
print("10k/20k ->", round(C.divider(5.0, 10e3, 20e3), 3), " 10k/22k ->", round(C.divider(5.0, 10e3, 22e3), 3), " 1.8k/3.3k ->", round(C.divider(5.0, 1.8e3, 3.3e3), 3))
# 2) SNR of a full-scale sine through an n-bit quantiser vs 6.02 n + 1.76
rng = np.random.default_rng(0); t = np.arange(200000); x = 1.65 + 1.65 * 0.999 * np.sin(2 * np.pi * t * 0.01234567)
for n in (8, 10, 12):
    q = C.adc_volts(C.adc_code(x, 3.3, n), 3.3, n); e = q - x; snr = 10 * math.log10(np.var(x) / np.var(e)); print("bits", n, "SNR dB", round(snr, 2), "formula", round(6.02 * n + 1.76, 2))
# 3) rover endurance (ASSUMED: 2S pack 7.4 V 2600 mAh, 80 percent usable, edge computer 0.5 A at 5 V, regulator 90 percent, MOSFET bridge)
M = C.DCMotor(6.0, 0.8, 0.15, 200.0); mass, mu, g, r = 1.5, 0.05, 9.81, 0.033
tau_c = mu * mass * g * r / 2; w = 0.5 / r; vneed = M.volts_needed(w, tau_c); duty = vneed / (7.4 - 0.4); i_m = tau_c / M.k + M.i0
i_batt_motors = 2 * duty * i_m; i_batt_pi = 5.0 * 0.5 / 7.4 / 0.9
print("cruise: volts", round(vneed, 3), "duty", round(duty, 3), "motor A each", round(i_m, 4), "battery A (motors)", round(i_batt_motors, 4), "(edge computer)", round(i_batt_pi, 4), "total", round(i_batt_motors + i_batt_pi, 4))
print("endurance h:", round(2600 * 0.8 / 1000 / (i_batt_motors + i_batt_pi), 2), " motors-only", round(2600 * 0.8 / 1000 / i_batt_motors, 2), "stall A both", 2 * 0.8)
print("energy Wh pack", round(2.6 * 7.4, 2), "usable", round(2.6 * 7.4 * 0.8, 2))
# 4) flyback spike and pull-up numbers
print("L di/dt spike V:", 2e-3 * 0.5 / 1e-6, " pull-up current 10k:", round(3.3 / 10e3 * 1e3, 3), "mA, 100k:", round(3.3 / 100e3 * 1e3, 4), "mA; tau 10k*10pF s:", 10e3 * 10e-12, " 100k*10pF:", 100e3 * 10e-12)
# 5) mosfet switch dissipation (ASSUMED Rds_on 0.1 ohm)
print("MOSFET P at 0.5 A, 0.1 ohm mW:", 0.5 ** 2 * 0.1 * 1e3, " BJT base current for Ic=0.2 A, forced beta 10 mA:", 0.2 / 10 * 1e3)
# 6) battery energy for node
print("node pack Wh:", round(2.0 * 3.7, 2), " avg power mW at 1.8765 mA, 3.7 V:", round(1.8765 * 3.7, 3))
# 7) divider sensor: sensitivity dV/dRs at Rs = R1 and 12-bit counts per kohm
rs = 10e3; dv = 3.3 * 10e3 / (20e3) ** 2; print("dVout/dRs at Rs=R1=10k V per ohm:", dv, " mV per kohm:", dv * 1e6, " counts/kohm:", dv * 1e3 / C.lsb(3.3, 12))
print("Thevenin of divider 10k/10k:", C.parallel(1e4, 1e4), " 12-bit lsb mV", C.lsb(3.3, 12) * 1e3)
