"""Fig 4: ADC quantisation. Left: a 3-bit ADC against a ramp and its error. Right: RMS error against bits, simulated vs lsb/sqrt(12)."""
from _common import *
use_code("electronics/circuits_np")
import circuits_np as C

VREF = 3.3
v = np.linspace(0, VREF * 0.9999, 2000)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
code = C.adc_code(v, VREF, 3); rec = C.adc_volts(code, VREF, 3)
a.plot(v, v, color=PAL["grey"], lw=1, label="true input"); a.step(v, rec, where="mid", color=PAL["blue"], label="3-bit ADC reading")
a.set(xlabel="input voltage (V)", ylabel="reading (V)", title="3-bit ADC: 8 levels, step 0.41 V"); a.legend(fontsize=8, loc="upper left")
ae = a.twinx(); ae.plot(v, rec - v, color=PAL["red"], lw=0.8); ae.set_ylabel("error (V)", color=PAL["red"]); ae.spines["right"].set_visible(True); ae.grid(False); ae.set_ylim(-0.6, 0.6)
print("3-bit lsb", C.lsb(VREF, 3), "max error", round(float(np.abs(rec - v).max()), 4))
bits = np.arange(4, 13); rng = np.random.default_rng(0); x = rng.uniform(0, VREF, 200000)
sim = np.array([np.std(C.adc_volts(C.adc_code(x, VREF, n), VREF, n) - x) for n in bits]); th = np.array([C.adc_rms_error(VREF, n) for n in bits])
b.semilogy(bits, sim * 1e3, "o", color=PAL["blue"], label="simulated (200k random inputs)"); b.semilogy(bits, th * 1e3, "-", color=PAL["red"], lw=1, label="lsb / sqrt(12)")
b.set(xlabel="ADC bits", ylabel="RMS quantisation error (mV)", title="Each bit halves the error"); b.legend(fontsize=8)
for n, s, t_ in zip(bits, sim, th): print("bits", n, "lsb mV", round(C.lsb(VREF, n) * 1e3, 4), "sim rms mV", round(s * 1e3, 4), "theory mV", round(t_ * 1e3, 4))
save(fig, out("fig04_adc.png"))
