"""Fig 2: LED current-limiting resistor. Left: LED I-V curve (assumed model: 2.0 V at 10 mA, n = 2) with load lines. Right: current vs supply for R = 150 ohm."""
from _common import *
use_code("electronics/circuits_np")
import circuits_np as C

N = 2.0; IS = C.led_is_for(2.0, 0.010, N)
VS = 3.3
i = np.linspace(1e-6, 0.03, 400); vf = np.array([C.led_vf(x, IS, N) for x in i])
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.plot(vf, i * 1e3, color=PAL["black"], label="LED I-V (assumed)")
for r, col in ((100, PAL["red"]), (130, PAL["green"]), (150, PAL["blue"]), (330, PAL["purple"])):
    v = np.linspace(0, VS, 50); a.plot(v, (VS - v) / r * 1e3, "--", color=col, lw=1.2, label=f"load line R = {r} ohm")
    io = C.led_current(VS, r, IS, N); a.plot(C.led_vf(io, IS, N), io * 1e3, "o", color=col)
    print("R", r, "current mA", round(io * 1e3, 3), "vf", round(C.led_vf(io, IS, N), 3), "power in R mW", round(io ** 2 * r * 1e3, 2))
a.set(xlim=(0, 3.4), ylim=(0, 32), xlabel="voltage across LED (V)", ylabel="current (mA)", title="Operating point = load line meets LED curve"); a.legend(fontsize=7.5, loc="upper left")
vs = np.linspace(3.0, 4.2, 60)
for r, col in ((150, PAL["blue"]), (330, PAL["purple"])):
    b.plot(vs, [C.led_current(x, r, IS, N) * 1e3 for x in vs], color=col, label=f"R = {r} ohm")
b.set(xlabel="supply voltage (V)", ylabel="LED current (mA)", title="Supply droop changes current"); b.legend()
for r in (150, 330): print("R", r, "I at 3.0 V", round(C.led_current(3.0, r, IS, N) * 1e3, 3), "at 4.2 V", round(C.led_current(4.2, r, IS, N) * 1e3, 3))
print("design R", C.led_resistor(3.3, 2.0, 0.010), "E12 up", C.nearest_e12(130, "up"), "down", C.nearest_e12(130, "down"), "nearest", C.nearest_e12(130))
save(fig, out("fig02_led.png"))
