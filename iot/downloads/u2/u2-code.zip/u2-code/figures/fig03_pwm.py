"""Fig 3: PWM and an RC filter. Left: PWM input and filtered output (D = 0.5, tau = 10 periods). Right: ripple against tau/T, measured and formula."""
from _common import *
use_code("electronics/circuits_np")
import circuits_np as C

T = 1e-3
t, vin, vout = C.rc_pwm(3.3, 0.5, T, 10 * T, n_periods=60, steps=100)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.plot(t * 1e3, vin, color=PAL["grey"], lw=0.8, label="PWM input (3.3 V, D = 0.5)"); a.plot(t * 1e3, vout, color=PAL["blue"], label="RC output, tau = 10 ms")
a.axhline(1.65, color=PAL["red"], ls=":", lw=1); a.text(1, 1.72, "mean = D x 3.3 V = 1.65 V", color=PAL["red"], fontsize=8)
a.set(xlabel="time (ms)", ylabel="voltage (V)", title="PWM smoothed by an RC filter"); a.legend(loc="lower right", fontsize=7.5, framealpha=0.95)
taus = np.array([3, 5, 10, 20, 50, 100, 200]) * T
for D, col, mk in ((0.5, PAL["blue"], "o"), (0.25, PAL["orange"], "s")):
    meas = []
    for tau in taus:
        _, _, vo = C.rc_pwm(3.3, D, T, tau, n_periods=int(max(40, 12 * tau / T)), steps=100)
        tail = vo[-100 * 10:]; meas.append(tail.max() - tail.min())
    th = [C.rc_ripple_pp(3.3, D, T, tau) for tau in taus]
    b.loglog(taus / T, meas, mk, color=col, label=f"measured, D = {D}"); b.loglog(taus / T, th, "-", color=col, lw=1, label=f"formula, D = {D}")
    print("D", D, [f"tau/T={x/T:.0f}: meas {m:.4f} V vs formula {y:.4f} V" for x, m, y in zip(taus, meas, th)])
b.set(xlabel="tau / T  (filter time constant / PWM period)", ylabel="peak-to-peak ripple (V)", title="Slower filter, smaller ripple"); b.legend(fontsize=7.5)
tail = vout[-100 * 10:]; print("mean tail", round(tail.mean(), 4), "ripple", round(tail.max() - tail.min(), 4))
# settling: time for the output mean to reach 63 percent and 95 percent of 1.65 V (envelope of the average): tau and 3 tau
print("63 percent of mean at ~tau = 10 ms;", "95 percent at ~3 tau = 30 ms")
save(fig, out("fig03_pwm.png"))
