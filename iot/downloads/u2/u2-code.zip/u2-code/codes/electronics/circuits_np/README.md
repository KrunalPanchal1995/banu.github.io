# circuits_np

> Circuit helpers for embedded systems: dividers, LED resistor and load line, PWM and RC filtering, ADC quantisation, power budget and battery life, DC motor and H-bridge sizing.

**Topic:** electronics  |  **Created in session:** 002 (Unit 2)  |  **Status:** tested (8 tests)

## What this code is for
Small, dependency-light formulas and simulators used to size the parts of an IoT node and a rover: read a resistive sensor, limit an LED, smooth PWM, understand ADC resolution, budget battery life and check that a motor driver can deliver the voltage a motor needs. A future AI can use it to check a hardware sizing calculation in numpy without a circuit simulator.

## Capabilities
- `series(*r)`, `parallel(*r)`: ohms.
- `nearest_e12(r, direction)`: nearest/up/down E12 value.
- `divider(vin, r1, r2, r_load=None)`: output across r2 (r_load in parallel with r2 if given).
- `led_resistor(vs, vf, i)`, `led_vf(i, i_s, n)`, `led_is_for(vf_at, i_at, n)`, `led_current(vs, r, i_s, n)`: LED design and the load-line operating point (bisection).
- `pwm_stats(vhigh, duty)` -> (mean, rms); `rc_pwm(vhigh, duty, period, tau, n_periods, steps)` -> (t, vin, vout) exact RC simulation; `rc_ripple_pp(...)`: V D (1-D) T / tau.
- `lsb(vref, bits)`, `adc_code`, `adc_volts`, `adc_rms_error(vref, bits)` = lsb / sqrt(12).
- `power_budget(states)` -> (avg_mA, period_s, charge shares); `battery_life_days`; `max_awake_seconds(period, i_act, i_slp, capacity, target_days)`.
- `DCMotor(v_rated, i_stall, i_noload, rpm_noload)`: `.current`, `.speed(torque, v)`, `.volts_needed(omega, torque)`, `.stall_torque(v)`; `h_bridge_voltage(v_supply, duty, drop)`.

## Theory in one paragraph
Ohm V=IR, KCL/KVL; divider Vout = Vin R2/(R1+R2); LED load line I=(Vs-V)/R; PWM mean D V_H, rms V_H sqrt(D); RC tau = RC (first-order, as Unit 1); ripple ~ V D(1-D)T/tau; ADC step q=Vref/2^n, rms error q/sqrt(12); motor V = iR + k omega, torque = k (i - i0). Derived in Unit 2, Section 3.

## Quick start
```bash
python circuits_np.py
python -m pytest -q tests
```
```python
import circuits_np as C
print(C.divider(3.3, 10e3, 10e3, r_load=10e3))   # 1.10
```

## Examples
| File | Shows | Output |
|------|-------|--------|
| `example_basic.py` | scaffold placeholder; real examples are `sessions/002-unit2-electronics/figures/fig01..fig06` and `analysis_numbers.py` | `example_basic.png` |

## Inputs / outputs and units
Volts, amperes, ohms, seconds; `*_mA`, `*_mAh` named explicitly; motor in SI (V s/rad, N m, rad/s). `rc_pwm` rounds the duty to a whole number of steps.

## Validation
Tests: series/parallel, divider limit, E12, LED operating point 10.00 mA at 130 ohm, PWM mean/rms, RC ripple vs formula (<10 percent in test, <0.5 percent in fig03), ADC rms error vs q/sqrt(12) (<2 percent), power-budget round trip (30 days exactly), motor stall/no-load consistency. These check the algebra and code, not any real part.

## Known limits and gotchas
- All component values in the Unit are assumed; no temperature, tolerance or battery-curve effects.
- ADC model is ideal (no noise/INL/DNL, perfect reference).
- LED model is a single Shockley diode with n=2; motor model ignores inductance and temperature.
- First version of `rc_pwm` compared float times for the duty and gave 17 percent ripple error; fixed by integer step counting.

## Dependencies
numpy

## Extending toward the open-source package
`iotrobotics/electronics.py`. To do: real battery discharge curves, ADC noise model, motor inductance.
