import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import circuits_np as C  # noqa: E402


def test_series_parallel():
    assert C.series(100, 220) == 320
    assert abs(C.parallel(100, 100) - 50) < 1e-12


def test_divider_and_loading():
    assert abs(C.divider(3.3, 1e4, 1e4) - 1.65) < 1e-12
    assert C.divider(3.3, 1e4, 1e4, r_load=1e4) < 1.65
    assert abs(C.divider(3.3, 1e4, 1e4, r_load=1e12) - 1.65) < 1e-6      # huge load changes nothing


def test_e12():
    assert C.nearest_e12(130) == 120 or C.nearest_e12(130) == 150
    assert C.nearest_e12(130, "up") == 150 and C.nearest_e12(130, "down") == 120
    assert C.nearest_e12(4700) == 4700 and C.nearest_e12(9.5e3, "up") == 10000.0


def test_led_load_line():
    n, i_s = 2.0, C.led_is_for(2.0, 0.010, 2.0)
    assert abs(C.led_vf(0.010, i_s, n) - 2.0) < 1e-9
    r = C.led_resistor(3.3, 2.0, 0.010)
    assert abs(r - 130) < 1e-9
    assert abs(C.led_current(3.3, 130.0, i_s, n) - 0.010) < 1e-6       # operating point on the designed current
    assert C.led_current(3.3, 150.0, i_s, n) < 0.010                   # bigger R, less current


def test_pwm_mean_rms_and_rc_ripple():
    m, r = C.pwm_stats(3.3, 0.25)
    assert abs(m - 0.825) < 1e-12 and abs(r - 3.3 * 0.5) < 1e-12
    t, vin, vout = C.rc_pwm(3.3, 0.5, 1e-3, 50e-3, n_periods=400, steps=100)
    tail = vout[-100 * 20:]                                           # last 20 periods, steady state
    assert abs(tail.mean() - 1.65) < 0.02
    assert abs((tail.max() - tail.min()) - C.rc_ripple_pp(3.3, 0.5, 1e-3, 50e-3)) < 0.1 * C.rc_ripple_pp(3.3, 0.5, 1e-3, 50e-3)


def test_adc():
    assert C.adc_code(0.0, 3.3, 10) == 0 and C.adc_code(3.3, 3.3, 10) == 1023
    v = np.random.default_rng(0).uniform(0, 3.3, 200000)
    err = C.adc_volts(C.adc_code(v, 3.3, 8), 3.3, 8) - v
    assert abs(err.std() - C.adc_rms_error(3.3, 8)) < 0.02 * C.adc_rms_error(3.3, 8)


def test_power_budget_and_max_awake():
    avg, period, share = C.power_budget([("awake", 120.0, 2.0), ("sleep", 0.01, 58.0)])
    assert abs(avg - 240.58 / 60) < 1e-12 and period == 60 and abs(sum(share.values()) - 1) < 1e-12
    t = C.max_awake_seconds(60, 120, 0.01, 2000, 30)
    avg2, _, _ = C.power_budget([("awake", 120.0, t), ("sleep", 0.01, 60 - t)])
    assert abs(C.battery_life_days(2000, avg2) - 30) < 1e-9


def test_motor_consistency():
    m = C.DCMotor()
    assert abs(m.current(0.0, 6.0) - 0.8) < 1e-12                     # stall current
    assert abs(m.current(m.w0, 6.0) - 0.15) < 1e-9                    # no-load current at no-load speed
    assert abs(m.speed(0.0, 6.0) - m.w0) < 1e-9                       # no load: no-load speed
    assert m.speed(m.stall_torque(6.0), 6.0) < 1e-9
    assert abs(m.volts_needed(m.w0, 0.0) - 6.0) < 1e-9
    assert abs(C.h_bridge_voltage(7.4, 1.0, 2.0) - 5.4) < 1e-12
