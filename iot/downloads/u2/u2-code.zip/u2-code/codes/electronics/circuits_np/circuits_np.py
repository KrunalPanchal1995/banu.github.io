"""Circuit helpers for embedded systems (numpy only). Units: volts, amperes, ohms, seconds unless a name says mA/mAh/ms.

Covers: series/parallel, voltage divider with load, LED resistor and the diode load line, PWM mean/RMS and RC smoothing,
ADC quantisation, duty-cycled power budget and battery life, and a DC motor behind an H-bridge. See README.md.
"""
import math

import numpy as np

E12 = (1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2)


# ---------------------------------------------------------------- resistors
def series(*r):
    return float(sum(r))


def parallel(*r):
    return float(1.0 / sum(1.0 / x for x in r))


def nearest_e12(r, direction="nearest"):
    """Closest E12 preferred value (10 percent series). direction: 'nearest' (in log scale), 'up' (>= r) or 'down' (<= r)."""
    dec = 10.0 ** math.floor(math.log10(r))
    cands = [v * dec * m for v in E12 for m in (0.1, 1.0, 10.0)] + [10.0 * dec]
    cands = sorted(set(round(c, 6) for c in cands))
    if direction == "up":
        return min(c for c in cands if c >= r - 1e-9)
    if direction == "down":
        return max(c for c in cands if c <= r + 1e-9)
    return min(cands, key=lambda c: abs(math.log(c / r)))


def divider(vin, r1, r2, r_load=None):
    """Output across r2 of a series pair (r1 on top). If r_load is given it is connected in parallel with r2."""
    r2e = r2 if r_load is None else parallel(r2, r_load)
    return vin * r2e / (r1 + r2e)


# ---------------------------------------------------------------- LED
def led_resistor(vs, vf, i_led):
    """Series resistor (ohm) that gives i_led (A) from supply vs through an LED of forward drop vf."""
    return (vs - vf) / i_led


def led_vf(i, i_s, n, vt=0.02585):
    """Diode (Shockley) forward voltage at current i: n*vt*ln(i/i_s + 1)."""
    return n * vt * math.log(i / i_s + 1.0)


def led_is_for(vf_at, i_at, n, vt=0.02585):
    """Saturation current i_s such that the LED drops vf_at volts at i_at amperes."""
    return i_at / (math.exp(vf_at / (n * vt)) - 1.0)


def led_current(vs, r, i_s, n, vt=0.02585):
    """Operating current (A): solve vs - i*r = led_vf(i) by bisection (the load-line intersection)."""
    lo, hi = 1e-15, vs / r
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if vs - mid * r - led_vf(mid, i_s, n, vt) > 0:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


# ---------------------------------------------------------------- PWM and RC
def pwm_stats(vhigh, duty):
    """(mean, rms) of a 0/vhigh square wave with the given duty cycle: mean = D*V, rms = V*sqrt(D)."""
    return vhigh * duty, vhigh * math.sqrt(duty)


def rc_pwm(vhigh, duty, period, tau, n_periods=40, steps=200):
    """Exact simulation of an RC low-pass driven by PWM (duty rounded to a whole number of steps). Returns (t, vin, vout); vout starts at 0."""
    dt = period / steps
    n = n_periods * steps
    t = np.arange(n) * dt
    on_steps = int(round(duty * steps))             # integer counting: no floating-point jitter in the duty cycle
    vin = np.where((np.arange(n) % steps) < on_steps, vhigh, 0.0)
    a = math.exp(-dt / tau)
    vout = np.zeros(n)
    v = 0.0
    for i in range(n):
        v = vin[i] + (v - vin[i]) * a      # exact for a constant input over one step
        vout[i] = v
    return t, vin, vout


def rc_ripple_pp(vhigh, duty, period, tau):
    """Peak-to-peak ripple of the smoothed PWM for tau >> period: V * D * (1 - D) * period / tau."""
    return vhigh * duty * (1.0 - duty) * period / tau


# ---------------------------------------------------------------- ADC
def lsb(vref, bits):
    return vref / 2 ** bits


def adc_code(v, vref, bits):
    """Ideal ADC: floor(v / lsb), clipped to 0 .. 2^bits - 1."""
    return np.clip(np.floor(np.asarray(v) / lsb(vref, bits)), 0, 2 ** bits - 1).astype(int)


def adc_volts(code, vref, bits):
    """Reconstruct the voltage at the middle of the code's bin."""
    return (np.asarray(code) + 0.5) * lsb(vref, bits)


def adc_rms_error(vref, bits):
    """Theoretical RMS quantisation error of an ideal ADC for a busy input: lsb / sqrt(12)."""
    return lsb(vref, bits) / math.sqrt(12.0)


# ---------------------------------------------------------------- power budget
def power_budget(states):
    """states: list of (name, current_mA, seconds) that make up one cycle. Returns (avg_mA, period_s, share dict of charge fractions)."""
    period = sum(s for _, _, s in states)
    charge = {name: i * s for name, i, s in states}      # mA*s
    total = sum(charge.values())
    return total / period, period, {k: v / total for k, v in charge.items()}


def battery_life_days(capacity_mAh, avg_mA, usable_fraction=0.8):
    return capacity_mAh * usable_fraction / avg_mA / 24.0


def max_awake_seconds(period_s, i_act_mA, i_slp_mA, capacity_mAh, target_days, usable_fraction=0.8):
    """Longest awake time per cycle that still reaches target_days (solves avg current <= budget)."""
    i_budget = capacity_mAh * usable_fraction / (24.0 * target_days)
    return period_s * (i_budget - i_slp_mA) / (i_act_mA - i_slp_mA)


# ---------------------------------------------------------------- DC motor + H-bridge
class DCMotor:
    """Permanent-magnet DC motor in SI units: v - i*R = ke*omega, torque = kt*i (ke = kt in SI).
    Built from catalogue-style numbers: rated volts, no-load speed (rpm) and current, stall current."""

    def __init__(self, v_rated=6.0, i_stall=0.8, i_noload=0.15, rpm_noload=200.0):
        self.v, self.R = v_rated, v_rated / i_stall
        w0 = rpm_noload * 2 * math.pi / 60.0
        self.k = (v_rated - i_noload * self.R) / w0
        self.i0 = i_noload
        self.w0 = w0

    def current(self, omega, v_applied):
        return max((v_applied - self.k * omega) / self.R, 0.0)

    def speed(self, torque, v_applied):
        """Steady shaft speed (rad/s) when the shaft delivers `torque` (N m). The no-load current i0 pays for internal
        friction, so the winding carries i = torque/k + i0."""
        i = torque / self.k + self.i0
        return max((v_applied - i * self.R) / self.k, 0.0)

    def volts_needed(self, omega, torque):
        """Applied voltage (V) needed to hold speed omega (rad/s) while the shaft delivers torque (N m)."""
        return self.k * omega + (torque / self.k + self.i0) * self.R

    def stall_torque(self, v_applied):
        """Shaft torque at stall (N m): winding current minus the friction current."""
        return self.k * (v_applied / self.R - self.i0)


def h_bridge_voltage(v_supply, duty, drop):
    """Average motor voltage from a supply, PWM duty and the bridge's conduction drop (both legs together)."""
    return max(duty * (v_supply - drop), 0.0)


def main():
    print("divider 3.3 V, 10k/10k:", divider(3.3, 1e4, 1e4))
    print("E12 for 130 ohm:", nearest_e12(130.0))
    print("ADC 10-bit rms error (V):", adc_rms_error(3.3, 10))


if __name__ == "__main__":
    main()
