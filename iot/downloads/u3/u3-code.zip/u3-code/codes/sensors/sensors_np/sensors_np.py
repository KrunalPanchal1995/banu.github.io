"""Sensors and actuators in numpy: a simple sensor model, bias/variance, least-squares calibration, moving-average and
exponential filters, sampling and aliasing, a quadrature encoder, and NTC / ultrasonic / servo / stepper helpers. See README.md."""
import math

import numpy as np


# ------------------------------------------------------------------ sensor model and accuracy
class Sensor:
    """reading = gain * true + offset + curvature * true^2 + drift_per_day * days + N(0, sigma^2)."""

    def __init__(self, gain=1.0, offset=0.0, curvature=0.0, sigma=0.0, drift_per_day=0.0, seed=0):
        self.gain, self.offset, self.curv, self.sigma, self.drift = gain, offset, curvature, sigma, drift_per_day
        self.rng = np.random.default_rng(seed)

    def read(self, true, days=0.0):
        true = np.asarray(true, dtype=float)
        clean = self.gain * true + self.offset + self.curv * true ** 2 + self.drift * days
        return clean + (self.rng.normal(0.0, self.sigma, true.shape) if self.sigma else 0.0)


def bias_variance(readings, true):
    """Return (bias, std, rmse). rmse^2 = bias^2 + std^2 exactly (population std)."""
    r = np.asarray(readings, dtype=float)
    bias = float(r.mean() - true)
    std = float(r.std())
    return bias, std, float(np.sqrt(np.mean((r - true) ** 2)))


# ------------------------------------------------------------------ least-squares calibration
def fit_line(x, y):
    """Ordinary least squares y = a + b x. Returns dict(a, b, s, se_b, se_a, r2) with s the residual std (n-2 dof)."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    n = len(x)
    xm, ym = x.mean(), y.mean()
    sxx = np.sum((x - xm) ** 2)
    sxy = np.sum((x - xm) * (y - ym))
    b = sxy / sxx
    a = ym - b * xm
    res = y - (a + b * x)
    s = math.sqrt(np.sum(res ** 2) / (n - 2)) if n > 2 else float("nan")
    se_b = s / math.sqrt(sxx)
    se_a = s * math.sqrt(1.0 / n + xm ** 2 / sxx)
    r2 = 1.0 - np.sum(res ** 2) / np.sum((y - ym) ** 2)
    return dict(a=float(a), b=float(b), s=float(s), se_b=float(se_b), se_a=float(se_a), r2=float(r2))


def fit_poly(x, y, deg):
    """Least-squares polynomial; returns coefficients, highest power first (numpy.polyfit order)."""
    return np.polyfit(np.asarray(x, float), np.asarray(y, float), deg)


def two_point(x0, y0, x1, y1):
    """Line through two calibration points: returns (a, b) with y = a + b x."""
    b = (y1 - y0) / (x1 - x0)
    return y0 - b * x0, b


# ------------------------------------------------------------------ filters
def moving_average(x, n):
    """Causal moving average of the last n samples (shorter window at the start)."""
    x = np.asarray(x, float)
    c = np.cumsum(np.insert(x, 0, 0.0))
    out = np.empty_like(x)
    for i in range(len(x)):
        lo = max(0, i + 1 - n)
        out[i] = (c[i + 1] - c[lo]) / (i + 1 - lo)
    return out


def ema(x, alpha, y0=None):
    """First-order (exponential) filter y[k] = y[k-1] + alpha (x[k] - y[k-1]); starts at y0 (default x[0])."""
    x = np.asarray(x, float)
    y = np.empty_like(x)
    prev = x[0] if y0 is None else y0
    for i, v in enumerate(x):
        prev = prev + alpha * (v - prev)
        y[i] = prev
    return y


def alpha_from_tau(tau, ts):
    """EMA alpha giving continuous time constant tau at sampling period ts (exact discretisation of an RC filter)."""
    return 1.0 - math.exp(-ts / tau)


def alpha_matching_ma(n):
    """EMA alpha with the same white-noise gain and mean delay as an n-point moving average: 2/(n+1)."""
    return 2.0 / (n + 1)


def noise_gain_ma(n):
    """Std of the filtered white noise divided by the input std for an n-point moving average: 1/sqrt(n)."""
    return 1.0 / math.sqrt(n)


def noise_gain_ema(alpha):
    """Same ratio for the EMA: sqrt(alpha / (2 - alpha))."""
    return math.sqrt(alpha / (2.0 - alpha))


def mean_delay_ma(n):
    """Mean delay in samples of an n-point moving average: (n-1)/2."""
    return (n - 1) / 2.0


def mean_delay_ema(alpha):
    """Mean delay in samples of the EMA: (1 - alpha) / alpha."""
    return (1.0 - alpha) / alpha


# ------------------------------------------------------------------ sampling and aliasing
def alias_frequency(f, fs):
    """Apparent frequency (0 .. fs/2) of a sinusoid of frequency f sampled at fs."""
    return abs(f - fs * round(f / fs))


def sample(fn, fs, duration, t0=0.0):
    """Sample fn(t) at rate fs for `duration` seconds; returns (t, values)."""
    t = t0 + np.arange(int(round(duration * fs))) / fs
    return t, fn(t)


# ------------------------------------------------------------------ quadrature encoder
_QTAB = {(0, 0): {(0, 1): +1, (1, 0): -1}, (0, 1): {(1, 1): +1, (0, 0): -1},
         (1, 1): {(1, 0): +1, (0, 1): -1}, (1, 0): {(0, 0): +1, (1, 1): -1}}


def quadrature_signals(position_counts):
    """A/B logic levels for an integer position given in counts (4 counts per cycle): sequence 00, 01, 11, 10."""
    seq = [(0, 0), (0, 1), (1, 1), (1, 0)]
    ab = [seq[int(p) % 4] for p in position_counts]
    return np.array([a for a, _ in ab]), np.array([b for _, b in ab])


def quadrature_decode(a, b):
    """Total signed count from A/B sample sequences (x4 decoding). Illegal two-bit jumps are ignored (counted as errors in .errors)."""
    count, errors = 0, 0
    prev = (int(a[0]), int(b[0]))
    for i in range(1, len(a)):
        cur = (int(a[i]), int(b[i]))
        if cur != prev:
            step = _QTAB[prev].get(cur)
            if step is None:
                errors += 1
            else:
                count += step
            prev = cur
    quadrature_decode.errors = errors
    return count


def distance_per_count(counts_per_rev, wheel_radius):
    """Metres of travel per encoder count: 2 pi r / counts_per_rev."""
    return 2.0 * math.pi * wheel_radius / counts_per_rev


# ------------------------------------------------------------------ NTC thermistor, ultrasonic, servo, stepper
def ntc_resistance(temp_c, r0=10e3, t0_c=25.0, beta=3950.0):
    """Beta model: R = R0 exp(beta (1/T - 1/T0)), T in kelvin."""
    return r0 * math.exp(beta * (1.0 / (temp_c + 273.15) - 1.0 / (t0_c + 273.15)))


def ntc_temperature(r, r0=10e3, t0_c=25.0, beta=3950.0):
    """Inverse of ntc_resistance, in degrees C."""
    return 1.0 / (1.0 / (t0_c + 273.15) + math.log(r / r0) / beta) - 273.15


def sound_speed(temp_c):
    """Speed of sound in air (m/s), standard linear approximation 331.3 + 0.606 T."""
    return 331.3 + 0.606 * temp_c


def ultrasonic_distance(t_echo_s, temp_c=20.0):
    """Distance (m) from the round-trip echo time: v t / 2."""
    return sound_speed(temp_c) * t_echo_s / 2.0


def servo_pulse_us(angle_deg, lo_us=1000.0, hi_us=2000.0, span_deg=180.0):
    """Typical hobby-servo mapping (assumed): pulse width in microseconds for an angle, repeated every 20 ms."""
    return lo_us + (hi_us - lo_us) * angle_deg / span_deg


def stepper_angle(steps, steps_per_rev=200, microstep=1):
    """Shaft angle in degrees after `steps` (full or micro) steps."""
    return 360.0 * steps / (steps_per_rev * microstep)


def main():
    print("alias of 9 Hz at 10 Hz sampling:", alias_frequency(9, 10))
    print("EMA alpha matching 19-point MA:", alpha_matching_ma(19))


if __name__ == "__main__":
    main()
