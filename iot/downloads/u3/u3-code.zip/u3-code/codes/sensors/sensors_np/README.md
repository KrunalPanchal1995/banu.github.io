# sensors_np

> Sensor model, bias/variance, least-squares calibration, moving-average and EMA filters, sampling and aliasing, quadrature encoder, NTC, ultrasonic and servo helpers.

**Topic:** sensors  |  **Created in session:** 003 (Unit 3)  |  **Status:** tested (8 tests)

## What this code is for
Reference implementations of the measurement chain of an IoT node or rover: how a sensor's error splits into bias and noise, how to calibrate with least squares, how to filter and how to avoid aliasing, how to decode a wheel encoder, and how to convert thermistor and ultrasonic readings. A future AI can use it to sanity-check a sensing design in numpy.

## Capabilities
- `Sensor(gain, offset, curvature, sigma, drift_per_day, seed).read(true, days)`: simulated sensor.
- `bias_variance(readings, true) -> (bias, std, rmse)`; rmse^2 = bias^2 + std^2.
- `fit_line(x, y)` (a, b, s, se_b, se_a, r2), `fit_poly(x, y, deg)`, `two_point(x0, y0, x1, y1)`.
- `moving_average(x, n)`, `ema(x, alpha, y0)`, `alpha_from_tau(tau, ts)`, `alpha_matching_ma(n)` = 2/(n+1); `noise_gain_ma/ema`, `mean_delay_ma/ema`.
- `alias_frequency(f, fs)`, `sample(fn, fs, duration)`.
- `quadrature_signals(position_counts)`, `quadrature_decode(a, b)` (+ `.errors`), `distance_per_count(cpr, radius)`.
- `ntc_resistance`, `ntc_temperature` (beta model), `sound_speed(T)`, `ultrasonic_distance(t, T)`, `servo_pulse_us(angle)`, `stepper_angle(steps, steps_per_rev, microstep)`.

## Theory in one paragraph
MSE = bias^2 + variance; least squares b = Sxy/Sxx, a = ybar - b xbar, Var(b) = s^2/Sxx; aliasing fa = |f - fs round(f/fs)|; MA gain 1/sqrt(n), delay (n-1)/2; EMA gain sqrt(alpha/(2-alpha)), delay (1-alpha)/alpha; equal at alpha = 2/(n+1). Derived in Unit 3, Section 3.

## Quick start
```bash
python sensors_np.py
python -m pytest -q tests
```
```python
import sensors_np as S
print(S.alias_frequency(130, 100))   # 30.0
```

## Examples
| File | Shows | Output |
|------|-------|--------|
| `example_basic.py` | scaffold placeholder; real examples are `sessions/003-unit3-sensors/figures/fig01..fig06` and `analysis_numbers.py` | `example_basic.png` |

## Inputs / outputs and units
Volts, hertz, seconds, metres, degrees C, kelvin inside the beta model; counts are integers; filter windows are in samples.

## Validation
Tests: bias-variance identity; fit_line equals polyfit; slope SE vs 4000-run Monte Carlo (5%); MA/EMA noise gains vs theory on 400k samples; exact MA/EMA equivalence of gain and delay; 9 Hz = negated 1 Hz at 10 Hz sampling; quadrature round trip; NTC round trip; ultrasonic round trip.

## Known limits and gotchas
- White, Gaussian noise only; no 1/f noise, outliers or temperature dependence.
- `quadrature_decode` stores `.errors` as a function attribute (not thread-safe).
- `moving_average` uses a shorter window at the start (a start-up transient).
- Soil, thermistor, servo and encoder numbers in the Unit are assumed.

## Dependencies
numpy

## Extending toward the open-source package
`iotrobotics/sensing.py`. To do: median filter, Allan variance, weighted/robust fits.
