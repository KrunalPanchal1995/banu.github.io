import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import sensors_np as S  # noqa: E402


def test_bias_variance_identity():
    r = S.Sensor(offset=1.5, sigma=0.8, seed=1).read(np.full(5000, 25.0))
    b, s, rmse = S.bias_variance(r, 26.5 - 1.5)
    assert abs(rmse ** 2 - (b ** 2 + s ** 2)) < 1e-9


def test_fit_line_exact_and_matches_polyfit():
    x = np.arange(10.0); y = 3.0 + 2.0 * x
    f = S.fit_line(x, y)
    assert abs(f["a"] - 3) < 1e-12 and abs(f["b"] - 2) < 1e-12 and abs(f["r2"] - 1) < 1e-12
    rng = np.random.default_rng(0); y2 = y + rng.normal(0, 0.5, 10)
    p = np.polyfit(x, y2, 1); f2 = S.fit_line(x, y2)
    assert abs(f2["b"] - p[0]) < 1e-9 and abs(f2["a"] - p[1]) < 1e-9


def test_slope_standard_error_formula_matches_monte_carlo():
    x = np.linspace(0, 10, 8); rng = np.random.default_rng(3)
    slopes = [S.fit_line(x, 1 + 2 * x + rng.normal(0, 0.5, 8))["b"] for _ in range(4000)]
    se_formula = 0.5 / math.sqrt(np.sum((x - x.mean()) ** 2))
    assert abs(np.std(slopes) - se_formula) < 0.05 * se_formula


def test_moving_average_and_ema_noise_gain():
    rng = np.random.default_rng(0); x = rng.normal(0, 1, 400000)
    y = S.moving_average(x, 16)[100:]
    assert abs(y.std() - S.noise_gain_ma(16)) < 0.02
    e = S.ema(x, 0.1)[1000:]
    assert abs(e.std() - S.noise_gain_ema(0.1)) < 0.01


def test_ma_and_ema_with_matching_alpha_have_same_gain_and_delay():
    n = 19; a = S.alpha_matching_ma(n)
    assert abs(S.noise_gain_ma(n) - S.noise_gain_ema(a)) < 1e-12         # alpha/(2-alpha) = 1/n exactly when alpha = 2/(n+1)
    assert abs(S.mean_delay_ma(n) - S.mean_delay_ema(a)) < 1e-12         # (n-1)/2 = (1-alpha)/alpha exactly
    imp = np.zeros(2000); imp[0] = 1.0
    h = S.ema(imp, a, y0=0.0)                                            # impulse response alpha (1-alpha)^k
    assert abs(np.sum(np.arange(2000) * h) / np.sum(h) - S.mean_delay_ema(a)) < 1e-9
    imp2 = np.zeros(2000); imp2[100] = 1.0                               # impulse after the start-up window
    hm = S.moving_average(imp2, n)                                       # impulse response 1/n for k < n
    assert abs(np.sum((np.arange(2000) - 100) * hm) / np.sum(hm) - S.mean_delay_ma(n)) < 1e-9


def test_alias():
    assert S.alias_frequency(9, 10) == 1 and S.alias_frequency(5, 6) == 1 and S.alias_frequency(3, 10) == 3
    t, v = S.sample(lambda t: np.sin(2 * np.pi * 9 * t), 10, 2)
    t2, v2 = S.sample(lambda t: -np.sin(2 * np.pi * 1 * t), 10, 2)
    assert np.allclose(v, v2, atol=1e-9)                                  # 9 Hz and (negated) 1 Hz are the same samples


def test_quadrature_round_trip_and_direction():
    pos = np.concatenate([np.arange(0, 41), np.arange(40, 14, -1)])
    a, b = S.quadrature_signals(pos)
    assert S.quadrature_decode(a, b) == 15
    assert S.quadrature_decode.errors == 0
    assert abs(S.distance_per_count(1320, 0.033) - 2 * math.pi * 0.033 / 1320) < 1e-15


def test_ntc_ultrasonic_servo_stepper():
    assert abs(S.ntc_resistance(25.0) - 10e3) < 1e-6 and abs(S.ntc_temperature(S.ntc_resistance(37.0)) - 37.0) < 1e-9
    assert S.ntc_resistance(0.0) > 10e3 > S.ntc_resistance(50.0)
    assert abs(S.ultrasonic_distance(2 * 1.0 / S.sound_speed(25.0), 25.0) - 1.0) < 1e-12
    assert S.servo_pulse_us(0) == 1000 and S.servo_pulse_us(90) == 1500 and S.servo_pulse_us(180) == 2000
    assert abs(S.stepper_angle(200) - 360) < 1e-12 and abs(S.stepper_angle(1, microstep=16) - 0.1125) < 1e-12
