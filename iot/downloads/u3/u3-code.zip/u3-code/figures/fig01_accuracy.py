"""Fig 1: accuracy vs precision. Four simulated temperature sensors read a true 25.0 C a thousand times. Left: histograms of the readings. Right: RMSE split into bias^2 and variance."""
from _common import *
use_code("sensors/sensors_np")
import sensors_np as S

TRUE = 25.0
specs = [("A: accurate, precise", 0.0, 0.1), ("B: accurate, noisy", 0.0, 0.8), ("C: biased, precise", 1.5, 0.1), ("D: biased, noisy", 1.5, 0.8)]
cols = [PAL["green"], PAL["blue"], PAL["orange"], PAL["red"]]
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
rows = []
for k, (name, bias, sg) in enumerate(specs):
    r = S.Sensor(offset=bias, sigma=sg, seed=10 + k).read(np.full(1000, TRUE))
    bi, sd, rm = S.bias_variance(r, TRUE); rows.append((name, bi, sd, rm))
    a.hist(r, bins=np.linspace(22, 29, 71), histtype="stepfilled", alpha=0.45, color=cols[k], label=name)
    print(name, "bias", round(bi, 3), "std", round(sd, 3), "rmse", round(rm, 3), "check", round(np.sqrt(bi ** 2 + sd ** 2), 3))
a.axvline(TRUE, color=PAL["black"], ls=":"); a.text(TRUE + 0.05, a.get_ylim()[1] * 0.9, "true 25.0 C", fontsize=8)
a.set(xlabel="reading (C)", ylabel="count (of 1000)", title="1000 readings of 25.0 C"); a.legend(fontsize=7)
x = np.arange(4); b.bar(x, [r[1] ** 2 for r in rows], color=PAL["orange"], label="bias squared"); b.bar(x, [r[2] ** 2 for r in rows], bottom=[r[1] ** 2 for r in rows], color=PAL["sky"], label="variance (std squared)")
for i, r in enumerate(rows): b.text(i, r[1] ** 2 + r[2] ** 2 + 0.05, f"RMSE {r[3]:.2f}", ha="center", fontsize=8)
b.set(xticks=x, xticklabels=["A", "B", "C", "D"], ylabel="mean squared error (C squared)", title="MSE = bias^2 + variance"); b.legend(fontsize=8)
save(fig, out("fig01_accuracy.png"))
