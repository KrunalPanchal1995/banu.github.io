"""Unit 3 extra numbers quoted in the text: NTC divider, ultrasonic temperature error, mains aliasing and burst averaging, soil-node error budget,
servo/stepper arithmetic. ASSUMED parameters are marked in the text."""
from _common import *
use_code("sensors/sensors_np"); use_code("electronics/circuits_np")
import sensors_np as S, circuits_np as C
import math

# NTC 10k beta 3950 as the bottom resistor of a divider with 10k on top, 3.3 V supply, 12-bit ADC
for T in (0.0, 25.0, 50.0):
    R = S.ntc_resistance(T); V = C.divider(3.3, 10e3, R)
    dRdT = -3950.0 * R / (T + 273.15) ** 2; dVdT = 3.3 * 10e3 / (10e3 + R) ** 2 * dRdT
    print(f"T {T:5.1f} C  R {R:9.1f} ohm  V {V:.4f}  dR/dT {dRdT:8.1f} ohm/K  dV/dT {dVdT*1e3:7.2f} mV/K  counts/K {abs(dVdT)/C.lsb(3.3,12):6.1f}  K per count {C.lsb(3.3,12)/abs(dVdT):.4f}")
print("round trip ntc_temperature(R(37)) =", round(S.ntc_temperature(S.ntc_resistance(37.0)), 6))
P = (1.65 ** 2) / 10e3; print("self-heating power at 25 C mW:", round(P * 1e3, 4), "; temperature rise at ASSUMED 1 mW/K:", round(P * 1e3 / 1.0, 3), "K")
# ultrasonic
for T in (5, 20, 25, 35):
    print(f"sound speed at {T} C = {S.sound_speed(T):.2f} m/s")
t_echo = 2 * 1.0 / S.sound_speed(25.0); print("echo time for 1.000 m at 25 C (ms):", round(t_echo * 1e3, 4))
for assumed in (20.0,):
    d = S.ultrasonic_distance(t_echo, assumed); print(f"reading assuming {assumed} C when air is 25 C: {d:.4f} m, error {(d-1)*100:.2f} percent ({(d-1)*1000:.1f} mm)")
t5 = 2 * 1.0 / S.sound_speed(5.0); d5 = S.ultrasonic_distance(t5, 25.0); print(f"1.000 m at 5 C read with 25 C formula: {d5:.4f} m ({(d5-1)*100:.2f} percent)")
print("ultrasonic echo for 0.05 m at 25 C us:", round(2 * 0.05 / S.sound_speed(25.0) * 1e6, 1), " for 4 m ms:", round(2 * 4 / S.sound_speed(25.0) * 1e3, 2))
# mains aliasing: 50 Hz interference of amplitude 0.05 V on the soil sensor, read once a minute vs a burst
rng = np.random.default_rng(0); amp = 0.05
single = amp * np.sin(2 * np.pi * 50 * rng.uniform(0, 60, 20000))      # one reading at an arbitrary time
print("alias of 50 Hz sampled at 1/60 Hz:", S.alias_frequency(50, 1 / 60), " ; single-reading std (V):", round(float(single.std()), 4), " theory amp/sqrt2:", round(amp / math.sqrt(2), 4))
t0 = rng.uniform(0, 60, 5000); burst = np.array([np.mean(amp * np.sin(2 * np.pi * 50 * (t + np.arange(20) / 1000.0))) for t in t0])
print("burst of 20 samples at 1 kHz (exactly one 50 Hz period) mean residual std (V):", float(f"{burst.std():.3g}"))
burst17 = np.array([np.mean(amp * np.sin(2 * np.pi * 50 * (t + np.arange(17) / 1000.0))) for t in t0]); print("burst of 17 samples at 1 kHz (not a whole period) residual std (V):", round(float(burst17.std()), 5))
# soil-node error budget at w = 25 percent VWC (ASSUMED sensor of Fig 2)
w = 25.0; dVdw = -0.04 - 2 * 0.0004 * w; print("sensitivity dV/dw at 25 percent (V per percent):", round(dVdw, 4))
lsb = C.lsb(3.3, 12); print("ADC step in percent VWC:", round(lsb / abs(dVdw), 4), " rms quantisation in percent:", round(lsb / math.sqrt(12) / abs(dVdw), 4))
for n in (1, 16): print("sensor noise 0.015 V averaged over", n, "-> percent VWC:", round(0.015 / math.sqrt(n) / abs(dVdw), 4))
print("budget (rss) with 16-sample average, quadratic calibration 0.33, drift 7 days x 0.15 half-interval:", round(math.sqrt(0.33 ** 2 + (0.015 / 4 / abs(dVdw)) ** 2 + (lsb / math.sqrt(12) / abs(dVdw)) ** 2), 3), "percent VWC")
# servo, stepper
print("servo 45 deg pulse us:", S.servo_pulse_us(45), " timer ticks per degree at 1 us tick:", 1000 / 180, " degrees per tick:", 180 / 1000)
print("stepper 200 steps/rev: deg/step", S.stepper_angle(1), " microstep 1/16 deg:", S.stepper_angle(1, microstep=16), " steps for 90 deg at 1/16:", int(90 / S.stepper_angle(1, microstep=16)))
# encoder numbers
cpr = 11 * 4 * 30; dpc = S.distance_per_count(cpr, 0.033); print("encoder counts per wheel rev", cpr, " mm/count", round(dpc * 1e3, 4), " counts/s at 0.5 m/s", round(0.5 / dpc, 1), " A-channel frequency Hz at 0.5 m/s:", round(0.5 / dpc / 4, 1))
print("odometry error from 1 count over 20 m patrol (percent):", round(dpc / 20 * 100, 5))
