"""Fig 3: sampling and aliasing. Left: a 5 Hz sine sampled at 50, 12 and 6 Hz. Right: apparent frequency against true frequency at fs = 10 Hz."""
from _common import *
use_code("sensors/sensors_np")
import sensors_np as S

F0 = 5.0
fn = lambda t: np.sin(2 * np.pi * F0 * t)
tt = np.linspace(0, 1.0, 2000)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1.3, 1]))
a.plot(tt, fn(tt), color=PAL["grey"], lw=0.8, label="true: 5 Hz")
for fs, col, mk in ((50, PAL["green"], "o"), (12, PAL["blue"], "s"), (6, PAL["red"], "^")):
    t, v = S.sample(fn, fs, 1.0); a.plot(t, v, mk + "-", color=col, ms=4, lw=0.9, label=f"fs = {fs} Hz  (apparent {S.alias_frequency(F0, fs):g} Hz)")
    print("fs", fs, "apparent frequency", S.alias_frequency(F0, fs))
a.set(xlabel="time (s)", ylabel="amplitude", title="Too slow a sample rate invents a slow wave"); a.legend(fontsize=7, loc="lower left")
f = np.linspace(0, 30, 600); fs = 10.0
b.plot(f, [S.alias_frequency(x, fs) for x in f], color=PAL["blue"]); b.axvline(fs / 2, color=PAL["grey"], ls=":"); b.text(fs / 2 + 0.3, 0.3, "Nyquist\nfs/2 = 5 Hz", fontsize=8, color=PAL["grey"])
b.set(xlabel="true frequency (Hz)", ylabel="apparent frequency (Hz)", title="Folding at fs = 10 Hz")
for fq in (4, 5.5, 9, 11, 19): print("fs 10: true", fq, "apparent", S.alias_frequency(fq, 10.0))
t, v = S.sample(lambda t: np.sin(2 * np.pi * 9 * t), 10, 2); t2, v2 = S.sample(lambda t: -np.sin(2 * np.pi * 1 * t), 10, 2); print("9 Hz vs -1 Hz samples identical:", bool(np.allclose(v, v2, atol=1e-9)))
save(fig, out("fig03_aliasing.png"))
