"""Fig 2: calibrating a capacitive soil sensor. ASSUMED sensor: V = 3.0 - 0.04 w - 0.0004 w^2 (w = volumetric water content in percent), noise 0.015 V.
Left: raw curve with calibration points. Right: error of three calibrations on a dense test grid: two-point line, six-point line, six-point quadratic."""
from _common import *
use_code("sensors/sensors_np")
import sensors_np as S

sens = lambda seed: S.Sensor(gain=-0.04, offset=3.0, curvature=-0.0004, sigma=0.015, seed=seed)
wc = np.array([5.0, 12.0, 20.0, 28.0, 36.0, 45.0])
res = {}
rng_seed = 100
test_w = np.linspace(5, 45, 81)
def rmse_of(coefs, v, w):
    return float(np.sqrt(np.mean((np.polyval(coefs, v) - w) ** 2)))
tr = {"two-point line": [], "six-point line": [], "six-point quadratic": []}
curves = {}
for rep in range(300):
    s = sens(rng_seed + rep); v = s.read(wc); vt = s.read(test_w)
    a2, b2 = S.two_point(v[0], wc[0], v[-1], wc[-1]); c2 = np.array([b2, a2])
    c1 = S.fit_poly(v, wc, 1); cq = S.fit_poly(v, wc, 2)
    for k, c in (("two-point line", c2), ("six-point line", c1), ("six-point quadratic", cq)):
        tr[k].append(rmse_of(c, vt, test_w))
    if rep == 0: curves = {"two-point line": c2, "six-point line": c1, "six-point quadratic": cq}; v0, vt0 = v, vt
for k, vals in tr.items(): print(k, "mean RMSE over 300 repeats (percent VWC):", round(float(np.mean(vals)), 3), "min", round(float(np.min(vals)), 3), "max", round(float(np.max(vals)), 3))
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
wd = np.linspace(0, 47, 200); a.plot(wd, 3.0 - 0.04 * wd - 0.0004 * wd ** 2, color=PAL["grey"], label="true curve (noise-free)"); a.plot(wc, v0, "o", color=PAL["blue"], label="6 calibration readings"); a.set(xlabel="true water content w (percent)", ylabel="sensor voltage (V)", title="Raw soil sensor: curved, noisy"); a.legend(fontsize=8)
vv = np.linspace(vt0.min(), vt0.max(), 200); cols = [PAL["red"], PAL["orange"], PAL["green"]]
for (k, c), col in zip(curves.items(), cols):
    err = np.polyval(c, S.Sensor(gain=-0.04, offset=3.0, curvature=-0.0004).read(test_w)) - test_w
    b.plot(test_w, err, color=col, label=f"{k}: RMSE {np.mean(tr[k]):.2f}")
b.axhline(0, color=PAL["black"], lw=0.6); b.set(xlabel="true water content w (percent)", ylabel="calibration error (percent VWC)", title="Error left after calibration"); b.legend(fontsize=7.5)
save(fig, out("fig02_calibration.png"))
# slope standard error: formula vs Monte Carlo (line fit of w on x=0..10 with noise 0.5)
x = np.linspace(0, 10, 8); rng = np.random.default_rng(1)
sl = [S.fit_line(x, 1 + 2 * x + rng.normal(0, 0.5, 8))["b"] for _ in range(5000)]
print("slope se: formula", round(0.5 / np.sqrt(np.sum((x - x.mean()) ** 2)), 4), "monte carlo", round(float(np.std(sl)), 4))
f = S.fit_line(wc, S.Sensor(gain=-0.04, offset=3.0, curvature=-0.0004, sigma=0.015, seed=5).read(wc)); print("fit of V on w (6 points): slope", round(f["b"], 4), "se", round(f["se_b"], 4), "r2", round(f["r2"], 5), "resid std", round(f["s"], 4))
