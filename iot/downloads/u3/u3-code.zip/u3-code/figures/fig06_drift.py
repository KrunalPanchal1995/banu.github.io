"""Fig 6: sensor drift and recalibration. ASSUMED soil sensor drift 0.15 percent VWC per day after calibration, calibration error 0.7 percent VWC (RMS from Fig 2), tolerance 3 percent VWC."""
from _common import *
use_code("sensors/sensors_np")
import sensors_np as S

DRIFT, E0, TOL = 0.15, 0.7, 3.0
days = np.arange(0, 61)
fig, ax = plt.subplots(figsize=FIG["single"])
for T, col in ((None, PAL["red"]), (14, PAL["orange"]), (7, PAL["green"])):
    since = days if T is None else days % T
    err = E0 + DRIFT * since
    ax.plot(days, err, color=col, lw=1.5, label="never recalibrated" if T is None else f"recalibrated every {T} days")
    print("interval", T, "worst error", round(float(err.max()), 2), "days over tolerance", int(np.sum(err > TOL)))
ax.axhline(TOL, color=PAL["black"], ls=":"); ax.text(1, TOL + 0.1, "tolerance 3 percent VWC", fontsize=8)
tmax = (TOL - E0) / DRIFT; ax.axvline(tmax, color=PAL["grey"], ls="--", lw=0.8); ax.text(tmax + 0.5, 0.2, f"limit {tmax:.1f} days", fontsize=8, color=PAL["grey"])
ax.set(xlabel="days since first calibration", ylabel="worst-case error (percent VWC)", title="Drift sets the recalibration interval"); ax.legend(fontsize=8, loc="upper left")
print("max days between calibrations:", round(tmax, 2))
save(fig, out("fig06_drift.png"))
