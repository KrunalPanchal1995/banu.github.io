"""Fig 5: wheel encoder. Left: A/B quadrature waveforms and the running count (forward then back). Right: speed estimated from counts over a sample window.
ASSUMED encoder: 11 pulses/rev on the motor shaft, x4 decoding, 1:30 gearbox, wheel radius 33 mm."""
from _common import *
use_code("sensors/sensors_np")
import sensors_np as S

cpr = 11 * 4 * 30; dpc = S.distance_per_count(cpr, 0.033)
print("counts per wheel rev", cpr, "distance per count mm", round(dpc * 1e3, 4))
pos = np.concatenate([np.arange(0, 13), np.arange(12, 4, -1)]); a_, b_ = S.quadrature_signals(pos)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1.1, 1]))
k = np.arange(len(pos)); a.step(k, a_ + 2.4, where="post", color=PAL["blue"], label="A"); a.step(k, b_ + 1.2, where="post", color=PAL["orange"], label="B"); a.step(k, pos / 12 * 1.0 - 0.0, where="post", color=PAL["black"], lw=1, label="count / 12")
a.set(xlabel="sample", yticks=[0.5, 1.7, 2.9], yticklabels=["count", "B", "A"], title="Quadrature: B lags A going forward"); a.legend(fontsize=7, loc="lower right")
print("decoded count of the sequence:", S.quadrature_decode(a_, b_), "errors", S.quadrature_decode.errors, "expected", int(pos[-1]))
v_true = 0.5; ts_list = [0.01, 0.05, 0.1, 0.5]; t_end = 5.0
colors = [PAL["red"], PAL["orange"], PAL["blue"], PAL["green"]]
for Ts, col in zip(ts_list, colors):
    tk = np.arange(0, t_end + 1e-9, Ts); counts = np.floor(v_true * tk / dpc + 0.37).astype(int)      # arbitrary phase of the encoder
    vest = np.diff(counts) * dpc / Ts
    b.step(tk[1:], vest, where="post", color=col, lw=0.9, label=f"Ts = {int(Ts*1000)} ms")
    print("Ts", Ts, "speed resolution mm/s", round(dpc / Ts * 1e3, 3), "peak error mm/s", round(float(np.max(np.abs(vest - v_true))) * 1e3, 3), "counts per window", round(v_true * Ts / dpc, 1))
b.axhline(v_true, color=PAL["black"], ls=":", lw=0.8); b.set(xlabel="time (s)", ylabel="estimated speed (m/s)", title="Speed from counts: window vs resolution", xlim=(0, 1), ylim=(0.47, 0.53)); b.legend(fontsize=7)
save(fig, out("fig05_encoder.png"))
