"""Fig 4: filtering a noisy step. Left: noisy step, 19-point moving average and the EMA with alpha = 2/(n+1) = 0.1. Right: noise gain against mean delay for both filter families (they coincide)."""
from _common import *
use_code("sensors/sensors_np")
import sensors_np as S

fs = 100; n = 600; t = np.arange(n) / fs
step = np.where(t >= 2.0, 1.0, 0.0); rng = np.random.default_rng(2); noisy = step + rng.normal(0, 0.2, n)
N = 19; al = S.alpha_matching_ma(N)
ma = S.moving_average(noisy, N); ex = S.ema(noisy, al, y0=0.0)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1.3, 1]))
a.plot(t, noisy, color=PAL["grey"], lw=0.6, label="noisy sensor (sigma 0.2)"); a.plot(t, ma, color=PAL["blue"], label="moving average, n = 19"); a.plot(t, ex, "--", color=PAL["red"], label="EMA, alpha = 0.1")
a.set(xlabel="time (s)", ylabel="reading", title="Same smoothing, same lag", xlim=(1.5, 3.5)); a.legend(fontsize=7.5, loc="lower right")
def t90(y):
    idx = np.where((y >= 0.9) & (t >= 2.0))[0]; return t[idx[0]] - 2.0
print("t90 moving average (s):", round(t90(ma), 3), " EMA:", round(t90(ex), 3))
sd_raw = np.std(noisy[:190]); print("noise std raw (first 1.9 s)", round(float(sd_raw), 4), "MA", round(float(np.std(ma[100:190])), 4), "EMA", round(float(np.std(ex[100:190])), 4))
# measured gains on long white noise
big = np.random.default_rng(3).normal(0, 1, 400000)
ns = np.array([1, 2, 4, 8, 16, 32, 64]); g_ma = [S.moving_average(big, k)[200:].std() for k in ns]; al_s = [S.alpha_matching_ma(k) for k in ns]; g_ema = [S.ema(big, a_)[2000:].std() for a_ in al_s]
b.loglog(ns, [S.noise_gain_ma(k) for k in ns], "-", color=PAL["grey"], lw=1, label="theory 1/sqrt(n)")
b.loglog(ns, g_ma, "o", color=PAL["blue"], label="moving average (measured)")
b.loglog(ns, g_ema, "x", color=PAL["red"], ms=8, label="EMA alpha=2/(n+1) (measured)")
b.set(xlabel="window n  (EMA: alpha = 2/(n+1);  mean delay = (n-1)/2 samples)", ylabel="noise std after / before", title="Smoothing buys noise with delay"); b.legend(fontsize=7.5)
for k, gm, ge, a_ in zip(ns, g_ma, g_ema, al_s): print("n", k, "alpha", round(a_, 4), "MA gain", round(float(gm), 4), "theory", round(S.noise_gain_ma(k), 4), "EMA gain", round(float(ge), 4), "theory", round(S.noise_gain_ema(a_), 4), "delay MA", S.mean_delay_ma(k), "EMA", round(S.mean_delay_ema(a_), 3))
print("tau EMA at alpha 0.1, fs 100:", round(-1 / np.log(1 - 0.1) / fs, 4), "s; alpha_from_tau(0.1 s, 0.01):", round(S.alpha_from_tau(0.1, 0.01), 4))
save(fig, out("fig04_filters.png"))
