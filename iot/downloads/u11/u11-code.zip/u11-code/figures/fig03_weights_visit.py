"""Fig 3: left, weighted A* (cost of the path and nodes expanded against the weight w, with the guaranteed bound w x optimal) and an inadmissible heuristic;
right, the order in which to visit the four dry plants (nearest neighbour against the best of all 24 orders)."""
from _common import *
use_code("robotics/planning_np")
import planning_np as P, itertools, math
from _world import *

occ = make_world(); infl = P.inflate(occ, INFL, RES); start, goal = cell(START), cell(PLANTS["P4"])
base = P.astar(infl, start, goal); print("optimal cost", round(base["cost"] * RES, 3), "m, expanded", base["expanded"])
ws = [1.0, 1.2, 1.5, 2.0, 3.0, 5.0, 10.0]; cost, exp = [], []
for w in ws:
    r = P.astar(infl, start, goal, weight=w); cost.append(r["cost"] / base["cost"]); exp.append(r["expanded"])
    print(f"w = {w:4.1f}: cost ratio {r['cost'] / base['cost']:.4f} (bound {w}), expanded {r['expanded']}")
for k in (1.5, 3.0):
    r = P.astar(infl, start, goal, h=lambda a, b, k=k: k * P.octile(a, b)); print(f"inadmissible heuristic {k} x octile: cost ratio {r['cost'] / base['cost']:.4f}, expanded {r['expanded']}")
r0 = P.astar(infl, start, goal, h=None); print("h = 0 (Dijkstra): expanded", r0["expanded"])
# visiting order
names = ["dock"] + list(PLANTS); pts = [START] + list(PLANTS.values()); n = len(pts); D = np.zeros((n, n)); 
for i in range(n):
    for j in range(n):
        if i != j: D[i, j] = P.astar(infl, cell(pts[i]), cell(pts[j]))["cost"] * RES
print("path-length matrix (m), order", names); print(np.round(D, 2))
nn, nl, best, bl = P.visit_orders(D); allL = sorted(D[0, p[0]] + sum(D[a, b] for a, b in zip(p[:-1], p[1:])) for p in itertools.permutations(range(1, n)))
print("nearest neighbour order", [names[i] for i in nn], round(nl, 3), "m ; best order", [names[i] for i in best], round(bl, 3), "m ; worst of the 24 orders", round(allL[-1], 3), "m ; number of orders", len(allL))
print("nearest neighbour is", round((nl / bl - 1) * 100, 2), "percent longer than the best; the worst order is", round((allL[-1] / bl - 1) * 100, 1), "percent longer")
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.plot(ws, cost, "o-", color=PAL["blue"], label="cost / optimal"); a.plot(ws, ws, ":", color=PAL["red"], label="guaranteed bound w"); a.set(xscale="log", yscale="log", xlabel="weight w on the heuristic", ylabel="path cost / optimal", title="Weighted A*")
a2 = a.twinx(); a2.plot(ws, exp, "s--", color=PAL["orange"], label="nodes expanded"); a2.set_ylabel("nodes expanded", color=PAL["orange"]); a.legend(fontsize=7.5, loc="upper left")
img = np.where(occ, 0.0, 1.0); b.imshow(img, origin="lower", extent=(0, 10, 0, 6), cmap="gray", vmin=0, vmax=1)
for order, col, lab in ((nn, PAL["orange"], f"nearest neighbour {nl:.1f} m"), (best, PAL["blue"], f"best of 24 {bl:.1f} m")):
    for i, j in zip(order[:-1], order[1:]):
        pth = np.array([P.cell_center(c, RES) for c in P.astar(infl, cell(pts[i]), cell(pts[j]))["path"]]); b.plot(pth[:, 0], pth[:, 1], color=col, lw=1.3, label=lab if i == order[0] else None)
for k, p in zip(names, pts): b.plot(*p, "o", color=PAL["red"], ms=4); b.text(p[0] + 0.1, p[1] + 0.12, k, fontsize=7, color=PAL["red"])
b.set(title="Visiting four dry plants", xticks=[0, 5, 10], yticks=[0, 3, 6]); b.legend(fontsize=7, loc="lower right")
save(fig, out("fig03_weights_visit.png"))
