"""The greenhouse of Units 11 and 12: 10 m x 6 m, 5 cm cells, two long plant beds, a crate that leaves a 0.20 m gap (too narrow for the rover), four dry plants. ASSUMED layout."""
import numpy as np
RES = 0.05
ROVER_R = 0.13          # ASSUMED radius of the circle that contains the rover's body (m)
INFL = ROVER_R + RES / 2 + 0.02   # inflation radius: body circle + half a cell (cells are squares) + 2 cm margin = 0.175 m
START = (0.6, 0.6)
PLANTS = {"P1": (5.0, 0.9), "P2": (9.2, 2.8), "P3": (3.0, 2.8), "P4": (6.0, 5.0)}


def make_world():
    nx, ny = int(10 / RES), int(6 / RES)
    w = np.zeros((ny, nx), bool)
    w[0, :] = w[-1, :] = w[:, 0] = w[:, -1] = True
    def box(x0, x1, y0, y1): w[int(round(y0 / RES)):int(round(y1 / RES)), int(round(x0 / RES)):int(round(x1 / RES))] = True
    box(2.0, 8.0, 1.4, 2.0)           # bed 1
    box(2.0, 6.0, 3.6, 4.2)           # bed 2
    box(6.2, 9.95, 3.6, 4.2)          # crate: a 0.20 m gap between bed 2 and the crate (x 6.0 to 6.2)
    return w


def cell(p): return (int(p[1] / RES), int(p[0] / RES))
