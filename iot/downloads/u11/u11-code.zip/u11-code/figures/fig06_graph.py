"""Fig 6: the rover as a ROS-style graph (nodes, topics, a service, an action, the tf tree), run on the miniature Bus of planning_np (concepts only; ROS 2 is not installed or run)."""
from _common import *
use_code("robotics/planning_np")
import planning_np as P, math
from matplotlib.patches import FancyBboxPatch

bus = P.Bus()
for t, ty in (("/range", float), ("/odom", tuple), ("/pose", tuple), ("/path", list), ("/cmd_vel", tuple)): bus.advertise(t, ty)
state = {"pose": None, "path": None, "cmd": None}
bus.subscribe("/range", lambda m: bus.publish("/pose", (1.0, 0.5, 0.0)))               # estimator node: range + odom -> pose (stub)
bus.subscribe("/pose", lambda m: state.__setitem__("pose", m))
bus.add_service("/plan", lambda req: [(0.6, 0.6), (1.9, 4.3), (6.0, 5.0)])                   # planner service: goal -> path
def on_path(p): state["path"] = p; bus.publish("/cmd_vel", (0.5, 0.0))
bus.subscribe("/path", on_path); bus.subscribe("/cmd_vel", lambda m: state.__setitem__("cmd", m))
bus.publish("/range", 1.5); path = bus.call("/plan", (6.0, 5.0)); bus.publish("/path", path)
print("message flow:", [t for _, t in bus.log]); print("state:", state)
tf = P.TFTree(); tf.set("map", "odom", (0.12, -0.05, 0.02)); tf.set("odom", "base_link", (3.0, 1.5, math.pi / 2)); tf.set("base_link", "range_sensor", (0.10, 0.0, math.pi / 2))
T = tf.lookup("map", "range_sensor"); print("range_sensor in the map frame: x %.3f y %.3f heading %.1f deg" % (T[0, 2], T[1, 2], math.degrees(math.atan2(T[1, 0], T[0, 0]))))
Ti = tf.lookup("range_sensor", "map") @ T; print("inverse lookup composes to the identity:", bool(np.allclose(Ti, np.eye(3))))
try: bus.publish("/range", "far")
except TypeError as e: print("typed topic rejects a wrong message:", e)
fig, (a, b) = plt.subplots(1, 2, figsize=(FIG["panel2"][0], 3.3), gridspec_kw=dict(width_ratios=[1.6, 1]))
nodes = {"range_driver": (0.1, 0.8), "wheel_driver": (0.1, 0.3), "estimator": (0.45, 0.55), "planner": (0.45, 0.1), "controller": (0.78, 0.4), "motor_driver": (0.78, 0.9)}
for n, (x, y) in nodes.items():
    a.add_patch(FancyBboxPatch((x - 0.12, y - 0.07), 0.24, 0.14, boxstyle="round,pad=0.01", fc="#dbe9f6", ec=PAL["blue"])); a.text(x, y, n, ha="center", va="center", fontsize=7.5)
def arrow(n1, n2, lab, dy=0.0, col=PAL["black"]):
    (x1, y1), (x2, y2) = nodes[n1], nodes[n2]; a.annotate("", (x2 - 0.0, y2 + dy), (x1, y1 + dy), arrowprops=dict(arrowstyle="->", color=col, lw=1, shrinkA=32, shrinkB=32)); a.text((x1 + x2) / 2, (y1 + y2) / 2 + dy + 0.03, lab, fontsize=6.5, ha="center", color=col)
arrow("range_driver", "estimator", "/range"); arrow("wheel_driver", "estimator", "/odom"); arrow("estimator", "controller", "/pose"); arrow("planner", "controller", "/path (topic)")
arrow("controller", "motor_driver", "/cmd_vel"); a.annotate("", (0.45, 0.17), (0.45, 0.48), arrowprops=dict(arrowstyle="<->", color=PAL["red"], lw=1, shrinkA=2, shrinkB=2)); a.text(0.47, 0.32, "/plan (service)", fontsize=6.5, color=PAL["red"])
a.set(xlim=(-0.1, 1.0), ylim=(0, 1.05)); a.axis("off"); a.set_title("Nodes and topics of the rover", fontsize=9)
for (x, y, t) in ((0.5, 0.9, "map"), (0.5, 0.65, "odom"), (0.5, 0.4, "base_link"), (0.5, 0.15, "range_sensor")): b.add_patch(FancyBboxPatch((x - 0.3, y - 0.07), 0.6, 0.14, boxstyle="round,pad=0.01", fc="#fdf0d5", ec=PAL["orange"])); b.text(x, y, t, ha="center", va="center", fontsize=8)
for y in (0.83, 0.58, 0.33): b.annotate("", (0.5, y - 0.04), (0.5, y + 0.04 + 0.0), arrowprops=dict(arrowstyle="<-", color=PAL["black"]))
b.set(xlim=(0, 1), ylim=(0, 1.05)); b.axis("off"); b.set_title("tf tree: frames", fontsize=9)
save(fig, out("fig06_graph.png"))
