"""Fig 1: BFS, Dijkstra and A* on the inflated greenhouse grid (inflation 0.175 m) from the dock to plant P4. Expanded cells are shaded."""
from _common import *
use_code("robotics/planning_np")
import planning_np as P, time, math, networkx as nx
from _world import *

occ = make_world(); infl = P.inflate(occ, INFL, RES); s, g = P.cell_center, None
start, goal = cell(START), cell(PLANTS["P4"])
print("grid", occ.shape, "cells", occ.size, "free after inflation", int((~infl).sum()), "start", start, "goal", goal)
def timed(f, *a, **k):
    t = time.perf_counter(); r = f(*a, **k); return r, (time.perf_counter() - t) * 1e3
rb, tb = timed(P.bfs, infl, start, goal); rd, td = timed(P.dijkstra, infl, start, goal); ra, ta = timed(P.astar, infl, start, goal)
rw, tw = timed(P.astar, infl, start, goal, weight=3.0); re_, te = timed(P.astar, infl, start, goal, h=P.euclid)
r4, _ = timed(P.dijkstra, infl, start, goal, conn=4)
Lb = P.path_length(rb["path"], RES)
print(f"BFS (8-connected): {rb['steps']} steps, metric length {Lb:.3f} m, expanded {rb['expanded']}, {tb:.1f} ms")
print(f"Dijkstra: length {rd['cost']*RES:.3f} m, expanded {rd['expanded']}, {td:.1f} ms")
print(f"A* octile: length {ra['cost']*RES:.3f} m, expanded {ra['expanded']}, {ta:.1f} ms ; ratio of expansions Dijkstra/A* = {rd['expanded']/ra['expanded']:.2f}")
print(f"A* euclid: length {re_['cost']*RES:.3f} m, expanded {re_['expanded']}")
print(f"weighted A* w=3: length {rw['cost']*RES:.3f} m (ratio {rw['cost']/ra['cost']:.4f}), expanded {rw['expanded']}")
print(f"4-connected Dijkstra: length {P.path_length(r4['path'], RES) if False else r4['cost']*RES:.3f} m (Manhattan metric, steps cost 1)")
rng = np.random.default_rng(0); free = np.argwhere(~infl); worse = []; 
for _ in range(150):
    a_, b_ = tuple(free[rng.integers(len(free))]), tuple(free[rng.integers(len(free))])
    if a_ == b_: continue
    q = P.bfs(infl, a_, b_); d_ = P.dijkstra(infl, a_, b_)
    if q["path"] is None: continue
    worse.append(P.path_length(q["path"], RES) / (d_["cost"] * RES))
worse = np.array(worse); print(f"150 random start-goal pairs: BFS metric length / optimal: mean {worse.mean():.4f}, max {worse.max():.4f}, pairs where BFS is longer: {(worse > 1 + 1e-9).sum()}")
# networkx cross-check on the real map
G = nx.Graph(); R, C = infl.shape
for r in range(R):
    for c in range(C):
        if infl[r, c]: continue
        for dr, dc, w in P.N8:
            rr, cc = r + dr, c + dc
            if 0 <= rr < R and 0 <= cc < C and not infl[rr, cc] and not (dr and dc and (infl[r + dr, c] or infl[r, c + dc])): G.add_edge((r, c), (rr, cc), weight=w)
ref = nx.shortest_path_length(G, start, goal, weight="weight"); print(f"networkx shortest path: {ref*RES:.3f} m ; A* and Dijkstra agree: {abs(ref - ra['cost']) < 1e-9 and abs(ref - rd['cost']) < 1e-9}")
def expanded_map(name, fn):
    # re-run recording expansions through a copy of the search (closed set) by replaying with instrumented search
    import heapq
    h = {"bfs": None}.get(name)
    return None
fig, axs = plt.subplots(2, 2, figsize=(FIG["panel2"][0], 5.6))
def show(ax, res, title, kind):
    img = np.where(occ, 0.0, np.where(infl, 0.35, 1.0))
    for (r, c) in res["closed"]: img[r, c] = min(img[r, c], 0.0) if occ[r, c] else 0.8 * (img[r, c] if img[r, c] < 1 else 1) if False else (0.78 if not infl[r, c] else img[r, c])
    ax.imshow(img, origin="lower", extent=(0, 10, 0, 6), cmap="gray", vmin=0, vmax=1)
    pts = np.array([P.cell_center(c, RES) for c in res["path"]]); ax.plot(pts[:, 0], pts[:, 1], color=PAL["red"], lw=1.6)
    ax.plot(*START, "o", color=PAL["green"], ms=5); ax.plot(*PLANTS["P4"], "*", color=PAL["blue"], ms=9); ax.set_title(title, fontsize=8.5); ax.set_xticks([0, 5, 10]); ax.set_yticks([0, 3, 6])
show(axs[0, 0], rb, f"BFS: {rb['steps']} steps, {Lb:.2f} m, {rb['expanded']} expanded", "bfs")
show(axs[0, 1], rd, f"Dijkstra: {rd['cost']*RES:.2f} m, {rd['expanded']} expanded", "dij")
show(axs[1, 0], ra, f"A* (octile): {ra['cost']*RES:.2f} m, {ra['expanded']} expanded", "astar")
show(axs[1, 1], rw, f"weighted A* (w = 3): {rw['cost']*RES:.2f} m, {rw['expanded']} expanded", "wastar")
save(fig, out("fig01_search.png"))
