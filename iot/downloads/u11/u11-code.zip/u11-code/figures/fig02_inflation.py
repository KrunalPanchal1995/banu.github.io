"""Fig 2: obstacle inflation. The rover (ASSUMED body circle of radius 0.13 m) is planned as a point (inflation 0), with 0.10 m, and with 0.15 m of inflation, from plant P3 to plant P4
(the straight way is through a 0.20 m gap between bed 2 and the crate). The path is then checked with the rover's real disc."""
from _common import *
use_code("robotics/planning_np")
import planning_np as P, math
from _world import *

occ = make_world(); start, goal = cell(PLANTS["P3"]), cell(PLANTS["P4"]); fig, axs = plt.subplots(1, 3, figsize=(FIG["panel2"][0] * 1.45, 2.9))
print("rover circle radius", ROVER_R, "m; the gap between bed 2 and the crate is 0.20 m wide (needs 2 x radius =", 2 * ROVER_R, "m)")
cl = P.clearance_map(occ, RES); print("largest clearance (distance to the nearest obstacle cell centre) in the middle of the gap:", round(float(cl[int(3.9 / RES), int(6.1 / RES)]), 3), "m")
for ax, r in zip(axs, (0.0, 0.10, INFL)):
    infl = P.inflate(occ, r, RES) if r > 0 else occ
    res = P.astar(infl, start, goal)
    pts = [P.cell_center(c, RES) for c in res["path"]]; n_col = P.path_collisions(occ, pts, ROVER_R, RES); L = res["cost"] * RES
    sm = P.shortcut(infl, res["path"]); smp = [P.cell_center(c, RES) for c in sm]; n_col_s = P.path_collisions(occ, smp, ROVER_R, RES); Ls = P.path_length(sm, RES)
    print(f"inflation {r:.3g} m: A* length {L:.3f} m, sample points where the rover's disc hits an obstacle: {n_col} of {int(L / (RES / 2))}; after line-of-sight smoothing: length {Ls:.3f} m, collisions {n_col_s}, waypoints {len(res['path'])} -> {len(sm)}")
    img = np.where(occ, 0.0, np.where(infl, 0.35, 1.0)); ax.imshow(img, origin="lower", extent=(0, 10, 0, 6), cmap="gray", vmin=0, vmax=1)
    p = np.array(pts); ax.plot(p[:, 0], p[:, 1], color=PAL["red"], lw=1.4); ax.plot(*PLANTS["P3"], "o", color=PAL["green"], ms=4); ax.plot(*PLANTS["P4"], "*", color=PAL["blue"], ms=8)
    hit = [q for q in pts if P.disc_collides(occ, q, ROVER_R, RES)]
    if hit: h = np.array(hit); ax.plot(h[:, 0], h[:, 1], "x", color=PAL["orange"], ms=5)
    ax.set_title(f"inflation {r:.3g} m: {L:.2f} m, {n_col} collisions", fontsize=8.5); ax.set_xticks([0, 5, 10]); ax.set_yticks([0, 3, 6])
# a thin wall: the cost of inflation on the number of reachable plants
for r in (0.0, 0.10, INFL, 0.20, 0.30):
    infl = P.inflate(occ, r, RES) if r > 0 else occ
    reach = {k: P.astar(infl, start, cell(v))["path"] is not None for k, v in PLANTS.items()}; print(f"inflation {r:.3g} m: reachable plants {reach}; free cells {int((~infl).sum())}")
save(fig, out("fig02_inflation.png"))
