"""Fig 5: closing R3 and S1. Left: worst-case stopping distance at 0.5 m/s against the ultrasonic ping period (latency = ping period + 15 ms edge loop; braking at mu g, ASSUMED mu = 0.6),
with a simulated worst case. Right: distance travelled after the last good command when the rover stops on a command timeout (watchdog)."""
from _common import *
use_code("robotics/planning_np")
import planning_np as P, math

v, mu, edge = 0.5, 0.6, 0.015
print("braking distance at 0.5 m/s:", round(P.braking_distance(v, mu) * 100, 3), "cm")
T = np.linspace(0, 0.3, 121); sd = [P.stopping_distance(v, t + edge, mu) * 100 for t in T]
for per in (0.01, 0.03, 0.04, 0.0425, 0.06, 0.1, 0.15, 0.25):
    gap = P.simulate_stop(v, 1.0, per, edge, mu, phase=1.0)   # worst case: obstacle appears just after a ping
    print(f"ping period {per*1e3:6.1f} ms: worst-case latency {(per+edge)*1e3:6.1f} ms ; formula stop {P.stopping_distance(v, per+edge, mu)*100:6.2f} cm ; simulated worst case {(1.0-gap)*100:6.2f} cm")
print("largest ping period for a 5 cm stop:", round(P.max_ping_period(v, 0.05, edge, mu) * 1e3, 2), "ms (= ", round(1 / P.max_ping_period(v, 0.05, edge, mu), 1), "Hz) ; for a 10 cm stop:", round(P.max_ping_period(v, 0.10, edge, mu) * 1e3, 2), "ms")
print("echo time for a 1.5 m target at 20 degC:", round(2 * 1.5 / 343.21 * 1e3, 2), " ms ; for 4 m:", round(2 * 4 / 343.21 * 1e3, 2), "ms (so a ping period below 23 ms is impossible at 4 m range)")
for lat in (0.015, 0.075, 0.150):
    print(f"latency {lat*1e3:.0f} ms: max speed that stops within 1.5 m - 5 cm margin = {P.max_safe_speed(1.45, lat, mu):.3f} m/s ; within 0.30 m - 5 cm = {P.max_safe_speed(0.25, lat, mu):.3f} m/s ; vs rover top speed 0.691")
for to in (0.05, 0.1, 0.2, 0.5, 1.0, 2.0):
    print(f"watchdog timeout {to:.2f} s: distance after the last good command at 0.5 m/s = {P.watchdog_stop_distance(v, to, edge, mu)*100:.1f} cm ; at 0.25 m/s = {P.watchdog_stop_distance(0.25, to, edge, mu)*100:.1f} cm")
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.plot(T * 1e3, sd, color=PAL["blue"], label="stopping distance (worst case)"); a.axhline(5, color=PAL["red"], ls=":"); a.text(150, 5.5, "R3 target 5 cm", color=PAL["red"], fontsize=8)
Tm = P.max_ping_period(v, 0.05, edge, mu); a.plot(Tm * 1e3, 5, "o", color=PAL["red"]); a.annotate(f"{Tm*1e3:.1f} ms ({1/Tm:.0f} Hz)", (Tm * 1e3, 5), (Tm * 1e3 + 10, 2.6), fontsize=8, arrowprops=dict(arrowstyle="-", lw=0.6))
for per, lab in ((0.06, "60 ms ping"), (0.025, "25 ms ping")): a.plot(per * 1e3, P.stopping_distance(v, per + edge, mu) * 100, "s", color=PAL["orange"], ms=5); a.text(per * 1e3 + 4, P.stopping_distance(v, per + edge, mu) * 100 - 0.9, lab, fontsize=7.5)
a.set(xlabel="ultrasonic ping period (ms)", ylabel="stopping distance from 0.5 m/s (cm)", title="R3: sensing rate sets the stop"); a.legend(fontsize=7.5, loc="upper left")
to = np.linspace(0, 2, 100); b.plot(to, [P.watchdog_stop_distance(0.5, t, edge, mu) * 100 for t in to], color=PAL["blue"], label="0.5 m/s"); b.plot(to, [P.watchdog_stop_distance(0.25, t, edge, mu) * 100 for t in to], color=PAL["green"], label="0.25 m/s")
for d in (10, 25): b.axhline(d, color=PAL["grey"], ls=":")
b.set(xlabel="command timeout (s)", ylabel="distance after the last command (cm)", title="S1: link loss, stop on timeout"); b.legend(fontsize=7.5)
save(fig, out("fig05_stop_budget.png"))
