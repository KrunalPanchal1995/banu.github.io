"""Fig 4: pure-pursuit path following. The A* path from the dock to plant P4 (inflation 0.175 m), smoothed by line of sight, is followed at 0.5 m/s with the shared rover
(commanded turn rate through a 30 ms lag = the wheel loops of Unit 9). Left: paths at lookahead 0.1, 0.4 and 1.2 m near the first corner; right: cross-track error against lookahead."""
from _common import *
use_code("robotics/planning_np")
import planning_np as P, math
from _world import *

occ = make_world(); infl = P.inflate(occ, INFL, RES); start, goal = cell(START), cell(PLANTS["P4"])
res = P.astar(infl, start, goal); sm = P.shortcut(infl, res["path"]); path = [P.cell_center(c, RES) for c in sm]
print("smoothed path:", len(res["path"]), "->", len(sm), "waypoints, length", round(P.path_length(sm, RES), 3), "m ; waypoints", [tuple(round(v, 2) for v in p) for p in path])
Ld = [0.1, 0.2, 0.3, 0.4, 0.6, 0.8, 1.2]; rows = []
for L in Ld:
    r = P.follow_path(path, L, 0.5); pc = P.path_collisions(occ, [(p[0], p[1]) for p in r["pose"][::5]], ROVER_R, RES)
    rows.append((L, r)); print(f"lookahead {L:.1f} m: finished {r['finished']}, time {r['time']:.2f} s, max cross-track error {r['max_xte']*100:.1f} cm, rms {r['rms_xte']*100:.1f} cm, sample points where the rover disc hits an obstacle {pc}")
for L in (0.1, 0.4):
    r0 = P.follow_path(path, L, 0.5, lag=0.0); r1 = P.follow_path(path, L, 0.5, lag=0.03); r2 = P.follow_path(path, L, 0.5, lag=0.2)
    print(f"lookahead {L} m: max error with no lag {r0['max_xte']*100:.1f} cm, 30 ms lag {r1['max_xte']*100:.1f} cm, 200 ms lag {r2['max_xte']*100:.1f} cm")
r = P.follow_path(path, 0.4, 0.5); poses = r["pose"]
curv = np.max(np.abs(np.diff(np.unwrap(poses[:, 2]))) / 0.02); print("max turn rate along the run (rad/s) at lookahead 0.4:", round(float(curv), 2), "; rover's feasible limit at 0.5 m/s:", round((RoverP := 0) or (0.691 - 0.5) / 0.08, 2))
for sp in (0.2, 0.5, 0.65):
    rr = P.follow_path(path, 0.4, sp); print(f"speed {sp} m/s, lookahead 0.4 m: time {rr['time']:.1f} s, max error {rr['max_xte']*100:.1f} cm, finished {rr['finished']}")
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.imshow(np.where(occ, 0.0, np.where(infl, 0.35, 1.0)), origin="lower", extent=(0, 10, 0, 6), cmap="gray", vmin=0, vmax=1)
pp = np.array(path); a.plot(pp[:, 0], pp[:, 1], "o--", color=PAL["black"], ms=3, lw=0.8, label="smoothed A* path")
for L, col in ((0.1, PAL["orange"]), (0.4, PAL["blue"]), (1.2, PAL["red"])):
    rr = dict(rows)[L]; a.plot(rr["pose"][:, 0], rr["pose"][:, 1], color=col, lw=1.2, label=f"lookahead {L} m")
a.set(xlim=(0, 7), ylim=(0, 5.5), title="Corners: short lookahead hugs, long cuts"); a.legend(fontsize=7, loc="lower right")
b.plot(Ld, [r["max_xte"] * 100 for _, r in rows], "o-", color=PAL["red"], label="maximum"); b.plot(Ld, [r["rms_xte"] * 100 for _, r in rows], "s-", color=PAL["blue"], label="rms")
b.set(xlabel="lookahead distance (m)", ylabel="distance from the path (cm)", title="Cross-track error against lookahead"); b.legend(fontsize=7.5)
save(fig, out("fig04_pursuit.png"))
