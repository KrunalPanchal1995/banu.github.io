# IoT Security and Privacy: code bundle

Run everything from this folder with Python 3.9+ and `pip install -r requirements.txt`.

- `codes/`   the importable modules, each with its own README, example and tests (net/mqtt_mini, security/iot_sec)
- `figures/` the scripts that produced every figure in the PDF (run: `python figures/fig01_*.py`) and `numbers_log.txt`, the printed output of all of them
- `logs/`    external check logs, where the unit has any (MQTT conformance, CBOR cross-check)

Quick test: `python -m pytest codes/security/iot_sec/tests`   (prints a pass count).
Packages in parentheses in requirements.txt are optional (cross-checks); lines without them are needed by the code.
Honesty labels: firmware that touches hardware was NOT run on hardware; cloud/battery/radio numbers marked 'assumed' in the PDF are assumptions.
MIT licence.
