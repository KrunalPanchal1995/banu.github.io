"""Fig 5: left, signed OTA update flow with the outcome of six real checks; right, the MQTT topic ACL as a matrix (computed from the Acl object)."""
from _common import *
use_code("security/iot_sec")
import iot_sec as S, os
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, (a, b) = plt.subplots(1, 2, figsize=(7.9, 4.0), gridspec_kw=dict(width_ratios=[1.15, 1]))
a.axis("off"); a.grid(False); a.set_xlim(0, 10); a.set_ylim(0, 10)
def box(x, y, w, h, t, col, fs=7.6): a.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.03,rounding_size=0.12", fc=col, ec="none", alpha=0.3)); a.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs)
box(0.2, 8.2, 4.0, 1.5, "ROM boot code\n(immutable; holds\nthe public key)", PAL["purple"]); box(5.8, 8.2, 4.0, 1.5, "bootloader:\nverifies the app\nsignature, then runs it", PAL["orange"])
a.add_patch(FancyArrowPatch((4.2, 8.95), (5.8, 8.95), arrowstyle="-|>", mutation_scale=9, color="k"))
sk, pk = S.make_keypair(); sk2, pk2 = S.make_keypair(); img = os.urandom(50000); man = S.make_manifest(7, img, sk)
cases = [("genuine, newer version", man, img, pk), ("one image byte changed", man, img[:-1] + bytes([img[-1] ^ 1]), pk), ("signed by another key", man, img, pk2), ("old version (rollback)", S.make_manifest(5, img, sk), img, pk), ("manifest version edited", man[:3] + bytes([man[3] ^ 1]) + man[4:], img, pk), ("image truncated", man, img[:-100], pk)]
a.text(0.2, 7.6, "OTA checks, in order: size, signature, version newer, length, hash", fontsize=8, fontweight="bold")
for i, (n, m, im, k) in enumerate(cases):
    ok, why = S.verify_ota(m, im, k, 6); y = 6.6 - i * 1.05; col = PAL["green"] if ok else PAL["red"]
    a.add_patch(plt.Rectangle((0.2, y - 0.4), 9.6, 0.8, fc=col, alpha=0.14, ec="none")); a.text(0.35, y, n, va="center", fontsize=7.8); a.text(9.7, y, "install" if ok else "refuse: " + why, va="center", ha="right", fontsize=7.8, color=col, fontweight="bold")
    print(n, "->", ok, why)
acl = S.Acl([(r"node\d+", "pub", "greenhouse/+/soil"), (r"node\d+", "pub", "greenhouse/+/temp"), ("dashboard", "sub", "greenhouse/#"), ("dashboard", "pub", "greenhouse/rover/cmd"), ("rover", "sub", "greenhouse/rover/cmd"), ("rover", "pub", "greenhouse/rover/pose")])
ops = [("pub", "greenhouse/zone1/soil"), ("pub", "greenhouse/rover/cmd"), ("pub", "greenhouse/rover/pose"), ("sub", "greenhouse/#"), ("sub", "greenhouse/+/soil"), ("sub", "greenhouse/rover/cmd")]
clients = ["node1", "rover", "dashboard", "stranger"]
M = np.array([[int(acl(c, act, t)) for act, t in ops] for c in clients])
b.imshow(M, cmap=matplotlib.colors.ListedColormap([PAL["red"], PAL["green"]]) if False else plt.cm.RdYlGn, vmin=-0.3, vmax=1.3, aspect="auto"); b.grid(False)
for i in range(len(clients)):
    for j in range(len(ops)): b.text(j, i, "allow" if M[i, j] else "deny", ha="center", va="center", fontsize=7.5, color="white" if not M[i, j] else "black")
b.set(xticks=range(len(ops)), yticks=range(len(clients)), yticklabels=clients); b.set_xticklabels(["pub\nsoil", "pub\ncmd", "pub\npose", "sub\n#", "sub\n+/soil", "sub\ncmd"], fontsize=7.5, rotation=0); b.set_xlabel("topic under greenhouse/ (soil = zone1/soil, cmd = rover/cmd, pose = rover/pose)", fontsize=6.8); b.set_title("Topic ACL: least privilege", fontsize=10)
save(fig, out("fig05_ota_acl.png"))
