"""Unit 7 numbers: password and dictionary arithmetic, forgery experiments, tag-length trade, TLS meter, ACL matrix, OTA outcomes. Output is saved to analysis_log.txt by the author."""
from _common import *
use_code("security/iot_sec")
import iot_sec as S, tls_cost as T, math, os

print("-- passwords (bits, expected guesses, time at 1e3 / 1e6 / 1e9 guesses per second)")
for name, bits in (("4-digit PIN", S.password_entropy_bits(4, 10)), ("8 lowercase letters", S.password_entropy_bits(8, 26)), ("8 mixed alnum", S.password_entropy_bits(8, 62)), ("12 random alnum", S.password_entropy_bits(12, 62)), ("one of Mirai's 62 pairs", math.log2(62))):
    t = [S.time_to_crack_s(bits, r) for r in (1e3, 1e6, 1e9)]
    print(f"{name:24s} {bits:6.2f} bits  guesses {S.expected_guesses(bits):.3g}  times s: {t[0]:.3g} {t[1]:.3g} {t[2]:.3g}  years at 1e9/s: {t[2]/3.156e7:.3g}")
print("-- dictionary coverage of Zipf(1) over 200 default credentials:", {D: round(S.dictionary_coverage(D), 3) for D in (1, 5, 10, 20, 62, 100, 200)})
print("-- HMAC experiments")
key = S.derive_key(b"master-secret", "rover1"); env = S.sign_command(key, 10, b"goto plant7")
rng = np.random.default_rng(0); acc = sum(S.verify_command(key, os.urandom(len(env)), 0)[0] for _ in range(100000)); print("100000 random envelopes accepted:", acc, "; expected", 100000 * S.forgery_probability(8))
flips = sum(S.verify_command(key, bytes(bytearray(env[:i // 8]) + bytes([env[i // 8] ^ (1 << (i % 8))]) + env[i // 8 + 1:]), 0)[0] for i in range(len(env) * 8)); print("single-bit flips accepted:", flips, "of", len(env) * 8)
print("replay:", S.verify_command(key, env, 10)[:2], " first use:", S.verify_command(key, env, 9)[:2], " wrong device key:", S.verify_command(S.derive_key(b"master-secret", "node1"), env, 9)[:2])
print("envelope overhead: 4-byte counter + 8-byte tag = 12 bytes on top of the command; message", len(env), "bytes for an 11-byte command")
for tb in (2, 4, 8, 16): p = S.forgery_probability(tb); print(f"tag {tb:2d} B: forgery per guess {p:.3g}  expected guesses {1/p:.3g}  at 100 guesses/s: {1/p/100/86400:.3g} days = {1/p/100/3.156e7:.3g} years")
print("-- TLS meter (self-signed single certificate, OpenSSL in memory, 31-byte application record)")
for kind in ("ec", "rsa"):
    for v in ("1.3", "1.2"):
        r = T.measure(kind, v); f, q = r["full"], r["resumed"]; print(f"{kind} TLS{v}: cert {r['cert_der']} B | full {f['c2s']}+{f['s2c']}={f['c2s']+f['s2c']} B, {f['rtt_to_app']} RTT | resumed {q['c2s']}+{q['s2c']}={q['c2s']+q['s2c']} B, {q['rtt_to_app']} RTT | record overhead {f['app_overhead']} B")
print("MQTT fresh QoS 1 plain: 540 B; plus TLS 1.3 ECDSA full handshake: ", 540 + 1533, "B, ratio", round((540 + 1533) / 540, 2))
print("-- Ed25519 sizes (bytes): manifest 104 = 4 version + 4 length + 32 hash + 64 signature; public key 32")
sk, pk = S.make_keypair(); from cryptography.hazmat.primitives import serialization as ser
print("public key bytes:", len(pk.public_bytes(ser.Encoding.Raw, ser.PublicFormat.Raw)), " signature bytes:", len(sk.sign(b"x")))
img = os.urandom(200_000); man = S.make_manifest(7, img, sk); sk2, pk2 = S.make_keypair()
cases = [("genuine update, newer version", man, img, pk, 6), ("one image byte changed", man, img[:-1] + bytes([img[-1] ^ 1]), pk, 6), ("signed by another key", man, img, pk2, 6), ("old version replayed (rollback)", S.make_manifest(5, img, sk), img, pk, 6), ("manifest version edited", man[:3] + bytes([man[3] ^ 1]) + man[4:], img, pk, 6), ("image truncated", man, img[:-100], pk, 6)]
for n, m, i, k, cur in cases: print(f"{n:34s} -> {S.verify_ota(m, i, k, cur)}")
print("SHA-256 of 200 kB image: manifest signs only 40 bytes, so signing cost does not grow with image size")
print("-- ACL matrix")
acl = S.Acl([(r"node\d+", "pub", "greenhouse/+/soil"), (r"node\d+", "pub", "greenhouse/+/temp"), ("dashboard", "sub", "greenhouse/#"), ("dashboard", "pub", "greenhouse/rover/cmd"), ("rover", "sub", "greenhouse/rover/cmd"), ("rover", "pub", "greenhouse/rover/pose")])
ops = [("pub", "greenhouse/zone1/soil"), ("pub", "greenhouse/rover/cmd"), ("pub", "greenhouse/rover/pose"), ("sub", "greenhouse/#"), ("sub", "greenhouse/+/soil"), ("sub", "greenhouse/rover/cmd")]
for c in ("node1", "rover", "dashboard", "stranger"): print(c, [int(acl(c, a, t)) for a, t in ops])
