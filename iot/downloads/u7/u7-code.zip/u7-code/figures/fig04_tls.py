"""Fig 4: what TLS costs a node that reconnects at every wake-up, measured with OpenSSL 3.4 in memory (single self-signed certificate; real chains are larger)."""
from _common import *
use_code("security/iot_sec")
import tls_cost as T

cfgs = [("ec", "1.3", "ECDSA\nTLS 1.3"), ("ec", "1.2", "ECDSA\nTLS 1.2"), ("rsa", "1.3", "RSA-2048\nTLS 1.3"), ("rsa", "1.2", "RSA-2048\nTLS 1.2")]
res = {(k, v): T.measure(k, v) for k, v, _ in cfgs}
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
x = np.arange(4); w = 0.38
full_c = [res[(k, v)]["full"]["c2s"] for k, v, _ in cfgs]; full_s = [res[(k, v)]["full"]["s2c"] for k, v, _ in cfgs]
a.bar(x - w / 2, full_c, w, color=PAL["blue"], label="client to server (full)"); a.bar(x - w / 2, full_s, w, bottom=full_c, color=PAL["sky"], label="server to client (full)")
rc = [res[(k, v)]["resumed"]["c2s"] for k, v, _ in cfgs]; rs = [res[(k, v)]["resumed"]["s2c"] for k, v, _ in cfgs]
a.bar(x + w / 2, rc, w, color=PAL["orange"], label="client to server (resumed)"); a.bar(x + w / 2, rs, w, bottom=rc, color="#f5cf80", label="server to client (resumed)")
for i, (k, v, _) in enumerate(cfgs):
    a.text(i - w / 2, full_c[i] + full_s[i] + 30, str(full_c[i] + full_s[i]), ha="center", fontsize=7.5); a.text(i + w / 2, rc[i] + rs[i] + 30, str(rc[i] + rs[i]), ha="center", fontsize=7.5)
a.axhline(540, color=PAL["red"], ls=":", lw=1); a.text(3.45, 560, "plain MQTT exchange: 540 bytes", fontsize=7.5, color=PAL["red"], ha="right")
a.set(xticks=x, xticklabels=[n for _, _, n in cfgs], ylabel="handshake bytes", title="Bytes of one handshake", ylim=(0, 3300)); a.legend(fontsize=6.5, loc="upper right", ncol=1); a.tick_params(axis="x", labelsize=7.5)
rt_full = [res[(k, v)]["full"]["rtt_to_app"] for k, v, _ in cfgs]; rt_res = [res[(k, v)]["resumed"]["rtt_to_app"] for k, v, _ in cfgs]
b.bar(x - w / 2, rt_full, w, color=PAL["blue"], label="full"); b.bar(x + w / 2, rt_res, w, color=PAL["orange"], label="resumed")
b.set(xticks=x, xticklabels=[n for _, _, n in cfgs], ylabel="round trips before the first data byte", title="Extra waiting (x 40 ms assumed)", ylim=(0, 3)); b.legend(fontsize=8); b.tick_params(axis="x", labelsize=7.5)
save(fig, out("fig04_tls.png"))
for k, v, n in cfgs: print(n.replace("\n", " "), "full", full_c[cfgs.index((k, v, n))], full_s[cfgs.index((k, v, n))])
