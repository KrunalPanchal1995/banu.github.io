"""Fig 1: data-flow diagram of the greenhouse with trust boundaries and the STRIDE threats of each flow (diagram)."""
from _common import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

fig, ax = plt.subplots(figsize=(7.9, 4.7)); ax.set_xlim(0, 13); ax.set_ylim(0, 7.8); ax.axis("off"); ax.grid(False)
def box(x, y, w, h, t, col, fs=8.5): ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.03,rounding_size=0.12", fc=col, ec="none", alpha=0.28)); ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs)
ax.add_patch(Rectangle((0.1, 0.5), 4.1, 6.4, fill=False, ls="--", ec=PAL["grey"])); ax.text(0.2, 6.65, "greenhouse (physical access possible)", fontsize=7.5, color=PAL["grey"])
ax.add_patch(Rectangle((4.8, 0.5), 3.4, 6.4, fill=False, ls="--", ec=PAL["grey"])); ax.text(4.9, 6.65, "local network + broker", fontsize=7.5, color=PAL["grey"])
ax.add_patch(Rectangle((8.8, 0.5), 4.1, 6.4, fill=False, ls="--", ec=PAL["grey"])); ax.text(8.9, 6.65, "office / internet", fontsize=7.5, color=PAL["grey"])
box(0.4, 4.6, 3.5, 1.3, "soil node\n(battery, Wi-Fi)", PAL["blue"]); box(0.4, 2.6, 3.5, 1.3, "rover\n(motors, edge computer)", PAL["green"]); box(0.4, 0.8, 3.5, 1.1, "OTA update server", PAL["orange"])
box(5.2, 2.7, 2.6, 2.4, "MQTT broker\n+ topic ACL", PAL["purple"]); box(9.2, 4.6, 3.5, 1.3, "dashboard\n+ alerts", PAL["sky"]); box(9.2, 2.6, 3.5, 1.3, "operator phone\n(sends commands)", PAL["sky"])
def arr(p, q, lab, ox=0, oy=0, col=PAL["black"]):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=10, color=col, lw=1.1)); ax.text((p[0] + q[0]) / 2 + ox, (p[1] + q[1]) / 2 + oy, lab, fontsize=7.3, ha="center", va="center", bbox=dict(fc="white", ec="none", pad=0.4, alpha=0.92))
arr((3.9, 5.2), (5.2, 4.6), "readings\nS T I D", oy=0.5); arr((7.8, 4.6), (9.2, 5.1), "readings\nS T I", oy=0.5); arr((9.2, 3.2), (7.8, 3.5), "commands\nS T E", oy=-0.55); arr((5.2, 3.1), (3.9, 3.2), "commands\nT E D", oy=-0.55)
arr((3.9, 1.4), (3.9, 2.6), "firmware\nT E", ox=0.9, oy=0.0)
ax.text(6.5, 0.15, "S spoofing   T tampering   R repudiation   I information disclosure   D denial of service   E elevation of privilege", fontsize=7.2, ha="center")
save(fig, out("fig01_stride.png"))
