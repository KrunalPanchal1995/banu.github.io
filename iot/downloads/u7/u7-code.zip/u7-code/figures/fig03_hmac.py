"""Fig 3: authenticated commands. Left: outcome of eight attacks on the HMAC command envelope (run for real). Right: tag length against forgery probability and envelope overhead."""
from _common import *
use_code("security/iot_sec")
import iot_sec as S, os

key = S.derive_key(b"master-secret", "rover1"); other = S.derive_key(b"master-secret", "node1"); last = 9
env = S.sign_command(key, 10, b"goto plant7")
flip = bytearray(env); flip[8] ^= 1
trunc = env[:-1]
rng = np.random.default_rng(0)
attacks = [("genuine command (counter 10)", env, key), ("random bytes (100,000 tries)", None, key), ("one bit of the command flipped", bytes(flip), key), ("command text edited, tag kept", env[:4] + b"goto plant9" + env[-8:], key), ("same envelope replayed", env, key), ("signed with another device's key", S.sign_command(other, 11, b"goto plant7"), key), ("tag shortened by one byte", trunc, key), ("old counter, valid tag", S.sign_command(key, 5, b"goto plant7"), key)]
rows = []
for name, e, k in attacks:
    if e is None:
        n_ok = sum(S.verify_command(k, os.urandom(len(env)), last)[0] for _ in range(100000)); rows.append((name, f"{n_ok} of 100000 accepted", n_ok == 0)); continue
    if name == "same envelope replayed":
        ok, why, _, _ = S.verify_command(k, e, 10)
    else:
        ok, why, _, _ = S.verify_command(k, e, last)
    rows.append((name, "ACCEPTED" if ok else "rejected: " + why, ok == (name.startswith("genuine"))))
    print(name, "->", ok, why)
fig, (a, b) = plt.subplots(1, 2, figsize=(7.9, 3.7), gridspec_kw=dict(width_ratios=[1.35, 1]))
a.axis("off"); a.grid(False); a.set_xlim(0, 10); a.set_ylim(0, len(rows) + 1)
for i, (n, r, good) in enumerate(rows):
    y = len(rows) - i - 0.2; col = PAL["green"] if good else PAL["red"]
    a.add_patch(plt.Rectangle((0.1, y - 0.35), 9.8, 0.7, fc=col, alpha=0.14, ec="none")); a.text(0.25, y, n, va="center", fontsize=7.8); a.text(9.8, y, r, va="center", ha="right", fontsize=7.8, color=col, fontweight="bold")
a.text(0.1, len(rows) + 0.5, "attack on the command envelope (all outcomes as designed)", fontsize=8.5, fontweight="bold")
tb = np.array([1, 2, 3, 4, 6, 8, 12, 16]); b.semilogy(tb, [S.forgery_probability(t) for t in tb], "o-", color=PAL["blue"]); b.set(xlabel="tag length (bytes)", ylabel="forgery probability per guess", title="Longer tag, safer envelope")
b2 = b.twinx(); b2.plot(tb, 4 + tb, "s--", color=PAL["orange"]); b2.set_ylabel("overhead: counter + tag (bytes)", color=PAL["orange"]); b2.spines["right"].set_visible(True); b2.grid(False)
b.axvline(8, color=PAL["grey"], ls=":"); b.text(8.2, 1e-5, "8 bytes\nchosen", fontsize=7.5)
save(fig, out("fig03_hmac.png"))
