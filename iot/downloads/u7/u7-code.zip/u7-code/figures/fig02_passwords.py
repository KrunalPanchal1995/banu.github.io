"""Fig 2: why default passwords fall. Left: bits of entropy by scheme with the time to search at 10^9 guesses per second. Right: share of devices with a default credential covered by an attacker's dictionary
of the D most popular defaults (ASSUMED Zipf(1) popularity over 200 default credentials)."""
from _common import *
use_code("security/iot_sec")
import iot_sec as S, math

items = [("Mirai's 62\npairs", math.log2(62)), ("4-digit\nPIN", S.password_entropy_bits(4, 10)), ("8 lowercase", S.password_entropy_bits(8, 26)), ("8 mixed\nalnum", S.password_entropy_bits(8, 62)), ("12 random\nalnum", S.password_entropy_bits(12, 62))]
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
cols = [PAL["red"], PAL["red"], PAL["orange"], PAL["blue"], PAL["green"]]
a.bar(range(5), [v for _, v in items], color=cols)
for i, (_, v) in enumerate(items):
    t = S.time_to_crack_s(v, 1e9); lab = f"{t:.1e} s" if t < 1 else (f"{t:.0f} s" if t < 3600 * 24 else f"{t / 3.156e7:.2g} y")
    a.text(i, v + 1.5, f"{v:.1f} bits\n{lab}", ha="center", fontsize=7.2)
a.set(xticks=range(5), xticklabels=[n for n, _ in items], ylabel="entropy (bits)", title="Search time at 10^9 guesses/s", ylim=(0, 88)); a.tick_params(axis="x", labelsize=7)
D = np.arange(1, 201); a_cov = [S.dictionary_coverage(int(d)) * 100 for d in D]
b.plot(D, a_cov, color=PAL["blue"]); b.plot([62], [S.dictionary_coverage(62) * 100], "o", color=PAL["red"]); b.annotate("62 pairs (Mirai):\n80% of defaults", (62, S.dictionary_coverage(62) * 100), (90, 55), arrowprops=dict(arrowstyle="->", color=PAL["red"]), fontsize=8, color=PAL["red"])
b.axhline(0, color=PAL["green"], lw=2); b.text(120, 4, "unique random password per device: 0%", fontsize=7.5, color=PAL["green"])
b.set(xlabel="attacker dictionary size D (most popular default credentials)", ylabel="default-credential devices covered (percent)", title="A small list breaks most defaults (assumed model)")
save(fig, out("fig02_passwords.png"))
