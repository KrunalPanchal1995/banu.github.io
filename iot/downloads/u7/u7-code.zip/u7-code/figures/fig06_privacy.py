"""Fig 6: privacy and aggregation. Two appliances with the same energy: a kettle (2000 W for 3 min) and a heater (400 W for 15 min). Left: a household power trace at 1 minute and as 15-minute means.
Right: how well an observer can tell the two apart, and tell that something happened, as the window grows. ASSUMED appliance powers and noise."""
from _common import *
rng = np.random.default_rng(7)
BASE, SD = 300.0, 30.0
def trace(kind, n=120, start=40):
    p = BASE + rng.normal(0, SD, n)
    if kind == "kettle": p[start:start + 3] += 2000
    elif kind == "heater": p[start:start + 15] += 400
    return p
def window_means(p, w): return np.array([p[i:i + w].mean() for i in range(0, len(p) - w + 1, w)])
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
pk, ph = trace("kettle", start=36), trace("heater", start=45)
a.plot(pk, color=PAL["red"], lw=0.8, label="kettle (2000 W, 3 min), 1-min samples"); a.plot(ph - 0, color=PAL["blue"], lw=0.8, label="heater (400 W, 15 min), 1-min samples")
a.step(np.arange(0, 120, 15), window_means(pk, 15), where="post", color=PAL["red"], lw=2.2, ls="--"); a.step(np.arange(0, 120, 15), window_means(ph, 15), where="post", color=PAL["blue"], lw=2.2, ls="--")
a.text(62, 1050, "dashed: 15-minute means\n(both +400 W: the same)", fontsize=8); a.set(xlabel="time (min)", ylabel="household power (W)", title="Same energy, different shape"); a.legend(fontsize=7, loc="upper right")
ws = [1, 2, 3, 5, 10, 15, 30]
ident, detect = [], []
for w in ws:
    feats, labs = [], []
    for _ in range(400):
        k = rng.random() < 0.5; p = trace("kettle" if k else "heater", 120, int(rng.integers(0, 100))); m = window_means(p, w); feats.append(m.max()); labs.append(k)
    feats = np.array(feats); labs = np.array(labs); mk, mh = feats[labs].mean(), feats[~labs].mean(); thr = (mk + mh) / 2
    ident.append(np.mean((feats > thr) == labs) * 100)
    quiet = [window_means(trace("none"), w).max() for _ in range(400)]; ev = feats; tt = (np.mean(quiet) + np.min(ev)) / 2; detect.append(np.mean(np.r_[ev > BASE + 150, np.array(quiet) <= BASE + 150]) * 100)
    print("window", w, "min: identify kettle vs heater", round(ident[-1], 1), "percent; detect that something happened", round(detect[-1], 1), "percent")
b.plot(ws, detect, "o-", color=PAL["orange"], label="'something big was on?'"); b.plot(ws, ident, "s-", color=PAL["blue"], label="'kettle or heater?'"); b.axhline(50, color=PAL["grey"], ls=":"); b.text(1.2, 51.5, "guessing", fontsize=7.5, color=PAL["grey"])
b.set(xscale="log", xlabel="aggregation window (min)", ylabel="observer accuracy (percent)", title="Aggregation hides what, not whether", ylim=(40, 104)); b.legend(fontsize=7.5, loc="lower left")
save(fig, out("fig06_privacy.png"))
