"""Fig 2: wheel-speed step responses (3 rad/s step at 0.1 s, 0.1 m/s) of P, PI, an aggressive PI and the Ziegler-Nichols PID, with the +-7 V limit and one sample of delay.
Left: clean speed measurement (metrics); right: with the real encoder quantisation (16 percent of the step per count), the steady-state voltage the controllers send."""
from _common import *
use_code("robotics/control_np")
import control_np as C

m0 = C.WheelMotor(); kp_l, ti_l = C.lambda_pi(m0.K, m0.tau, 0.03); ku, tu = C.ultimate_gain(m0, 0.01, 1); zkp, zti, ztd = C.zn_pid(ku, tu)
specs = [("P, kp = 1.0", dict(kp=1.0), PAL["orange"]), ("PI lambda (kp %.2f, Ti %.0f ms)" % (kp_l, ti_l * 1e3), dict(kp=kp_l, ki=kp_l / ti_l), PAL["blue"]), ("PI aggressive (kp 3, Ti 112 ms)", dict(kp=3.0, ki=3.0 / ti_l), PAL["green"]),
         ("PID Ziegler-Nichols (kp %.2f, Ti %.1f ms, Td %.1f ms)" % (zkp, zti * 1e3, ztd * 1e3), dict(kp=zkp, ki=zkp / zti, kd=zkp * ztd), PAL["red"])]
print(f"Ku = {ku:.4f}, Tu = {tu*1e3:.2f} ms -> ZN PID kp {zkp:.4f}, Ti {zti*1e3:.2f} ms, Td {ztd*1e3:.3f} ms ; ki {zkp/zti:.2f}, kd {zkp*ztd:.5f}; kp 3 is {3/ku*100:.0f} percent of Ku")
print("CLEAN MEASUREMENT: controller                       rise ms  overshoot %  settle(2%) ms  sse rad/s   u peak V")
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1.3, 1]))
for name, g, col in specs:
    m = C.WheelMotor(); pid = C.PID(**g, ts=0.01, windup="clamp")
    sim = C.simulate_speed_loop(pid, m, lambda t: 3.0 if t >= 0.1 else 0.0, 3.0, quantise=False)
    met = C.step_metrics(sim["t"][10:], sim["w"][10:], 3.0)
    print(f"{name[:46]:46s} {met['rise']*1e3:8.0f} {met['overshoot']:10.1f} {met['settle']*1e3:12.0f} {met['sse']:10.3f} {sim['u'].max():10.2f}")
    a.plot(sim["t"], sim["w"], color=col, label=name)
a.axhline(3.0, color=PAL["grey"], ls=":"); a.set(xlim=(0, 1.0), xlabel="time (s)", ylabel="wheel speed (rad/s)", title="Step responses (clean measurement)"); a.legend(fontsize=6.3, loc="lower right")
print("QUANTISED MEASUREMENT (one count = 0.476 rad/s at 10 ms): steady-state voltage noise, setpoint 3 rad/s held from 0.1 s")
for name, g, col in specs:
    m = C.WheelMotor(); pid = C.PID(**g, ts=0.01, windup="clamp")
    sim = C.simulate_speed_loop(pid, m, lambda t: 3.0 if t >= 0.1 else 0.0, 4.0, quantise=True)
    ss = sim["u"][int(2.0 / 0.01):]; sw = sim["w"][int(2.0 / 0.01):]
    print(f"{name[:46]:46s} u std {ss.std():.3f} V  u peak-to-peak {ss.max()-ss.min():.2f} V  speed std {sw.std():.3f} rad/s")
    if name.startswith(("PI lambda", "PID")): b.plot(sim["t"][int(2.0 / 0.01):int(3.0 / 0.01)], ss[:100], color=col, lw=0.9, label=name.split(" (")[0])
b.set(xlabel="time (s)", ylabel="voltage command (V)", title="Quantisation noise reaches the motor"); b.legend(fontsize=7.5)
save(fig, out("fig02_step.png"))
