"""Fig 3: the Ziegler-Nichols experiment. Left: a P-only loop (linear model, voltage limit lifted) at 0.5, 0.9, 1.0 and 1.1 times the ultimate gain. Right: Ku and Tu against the loop delay in samples."""
from _common import *
use_code("robotics/control_np")
import control_np as C

m0 = C.WheelMotor(); ku, tu = C.ultimate_gain(m0, 0.01, 1)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
for f, col in ((0.5, PAL["green"]), (0.9, PAL["blue"]), (1.0, PAL["orange"]), (1.1, PAL["red"])):
    m = C.WheelMotor(); m.u_max = 1e9
    sim = C.simulate_speed_loop(C.PID(f * ku, 0, 0, u_min=-1e9, u_max=1e9, windup="none"), m, lambda t: 1.0 if t >= 0.05 else 0.0, 0.8, 0.01, 1, False)
    a.plot(sim["t"], sim["w"], color=col, label=f"{f:g} Ku = {f*ku:.2f}")
    print(f"P loop at {f} Ku: growth ratio late/earlier envelope {C.oscillation_growth(C.WheelMotor, f*ku, 0.01, 1):.3f}")
a.set(ylim=(-0.5, 1.8), xlabel="time (s)", ylabel="wheel speed (rad/s) for a 1 rad/s step", title=f"P only, 1 sample delay: Ku = {ku:.2f}, Tu = {tu*1e3:.0f} ms"); a.legend(fontsize=7.5, loc="upper right")
ds = np.arange(0, 6); res = [C.ultimate_gain(m0, 0.01, int(d)) for d in ds]
for d, (k, t_) in zip(ds, res): print(f"delay {d} samples: Ku {k:.4f}  Tu {t_*1e3:.2f} ms  ZN PID kp {0.6*k:.3f}")
b.plot(ds, [r[0] for r in res], "o-", color=PAL["blue"]); b.set(xlabel="extra delay (samples of 10 ms)", ylabel="ultimate gain Ku (V per rad/s)", title="More delay, less gain tolerated"); b.set_yscale("log")
b2 = b.twinx(); b2.plot(ds, [r[1] * 1e3 for r in res], "s--", color=PAL["orange"]); b2.set_ylabel("oscillation period Tu (ms)", color=PAL["orange"]); b2.spines["right"].set_visible(True); b2.grid(False)
save(fig, out("fig03_zn.png"))
