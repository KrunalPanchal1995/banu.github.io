"""Does the pole-zero (lambda) design hold when sampling and delay are added? PI with Ti = tau, kp = tau/(K tau_c), tau_c = 30 ms, clean measurement, 3 rad/s step."""
from _common import *
use_code("robotics/control_np")
import control_np as C, math
m0 = C.WheelMotor(); tau_c = 0.03; kp, ti = C.lambda_pi(m0.K, m0.tau, tau_c)
print(f"design: kp {kp:.4f}, Ti {ti*1e3:.2f} ms ; ideal first-order closed loop: rise(10-90) = 2.197 tau_c = {2.197*tau_c*1e3:.1f} ms, settle(2%) = 3.912 tau_c = {3.912*tau_c*1e3:.1f} ms, overshoot 0")
for ts, d in ((0.001, 0), (0.005, 0), (0.01, 0), (0.01, 1), (0.01, 2), (0.02, 1), (0.05, 1)):
    m = C.WheelMotor(); pid = C.PID(kp, kp / ti, ts=ts, u_min=-1e9, u_max=1e9, windup="none")
    sim = C.simulate_speed_loop(pid, m, lambda t: 3.0 if t >= 0.1 else 0.0, 3.0, ts, d, False)
    k0 = int(round(0.1 / ts)) - 1; met = C.step_metrics(sim["t"][k0:], sim["w"][k0:], 3.0)
    print(f"Ts {ts*1e3:5.0f} ms, delay {d} samples: rise {met['rise']*1e3:6.1f} ms, overshoot {met['overshoot']:5.1f} %, settle {met['settle']*1e3:6.0f} ms")
