"""Recovery of the PI wheel-speed loop from a 5 degree slope (load torque 0.0212 N m at t = 2 s), clean measurement; also the voltage needed to hold 0.5 m/s on the slope."""
from _common import *
use_code("robotics/control_np")
import control_np as C, math
m = C.WheelMotor(); kp, ti = C.lambda_pi(m.K, m.tau, 0.03); TL = 1.5 * 9.81 * math.sin(math.radians(5)) * 0.033 / 2
R = 15.15; m.w = R; pid = C.PID(kp, kp / ti); pid.i = R / m.K
sim = C.simulate_speed_loop(pid, m, R, 4.0, quantise=False, load=lambda t: TL if t >= 2.0 else 0.0)
w = sim["w"]; k2 = int(2.0 / 0.01); dip = R - w[k2:].min(); band = np.where(np.abs(w[k2:] - R) > 0.02 * R)[0]
print(f"load torque {TL:.4f} N m; PI: dip {dip:.3f} rad/s = {dip/R*100:.2f} percent of setpoint; time outside +-2 percent after the slope: {(band[-1]+1)*0.01 if len(band) else 0:.2f} s ; final error {R-w[-1]:.5f} rad/s")
print(f"voltage to hold {R} rad/s: flat {R/m.K:.3f} V ; on the 5 degree slope {R/m.K + TL/(m.den*m.K):.3f} V ; open-loop droop {TL/m.den:.3f} rad/s")
print("motor plug-braking from 15.15 rad/s at -7 V: deceleration", round(-(m.k * (-7 - m.k * R) / m.R - m.b * R) / m.J, 1), "rad/s^2 =", round(-(m.k * (-7 - m.k * R) / m.R - m.b * R) / m.J * 0.033, 2), "m/s^2 (traction limit 178.4 rad/s^2 = 5.89 m/s^2 for mu 0.6)")
