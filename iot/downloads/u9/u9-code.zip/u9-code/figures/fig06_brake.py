"""Fig 6: stopping the rover. Speed against distance after an obstacle is detected, for an edge (15 ms) and a cloud (150 ms) reaction, with braking limited by traction (ASSUMED friction coefficient 0.6).
Requirement R3 of Unit 1 is refined: stopping distance = v t_reaction + v^2 / (2 mu g)."""
from _common import *
use_code("robotics/control_np")
import control_np as C, math

MU, G, V0, RW = 0.6, 9.81, 0.5, 0.033
a_max = MU * G; print("traction-limited deceleration", round(a_max, 3), "m/s^2 = ", round(a_max / RW, 1), "rad/s^2 per wheel ; braking time from 0.5 m/s", round(V0 / a_max, 4), "s ; braking distance", round(V0 ** 2 / (2 * a_max), 4), "m")
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
sim_stop = {}
for lat, col, lab in ((0.015, PAL["green"], "edge loop, 15 ms"), (0.150, PAL["red"], "cloud loop, 150 ms")):
    m = C.WheelMotor(); m.w = V0 / RW; dt = 0.001; x = 0.0; xs, vs = [0.0], [V0]; t = 0.0
    while m.w > 1e-3 and t < 2:
        braking = t >= lat
        m.step(-7.0 if braking else m.w / m.K, dt, decel_limit=a_max / RW if braking else None)
        x += m.w * RW * dt; t += dt; xs.append(x); vs.append(m.w * RW)
    sim_stop[lat] = x
    a.plot(np.array(xs) * 100, vs, color=col, label=f"{lab}: stops after {x*100:.1f} cm"); print(f"latency {lat*1e3:.0f} ms: simulated stopping distance {x*100:.2f} cm ; formula {C.stopping_distance(V0, lat, MU, G)*100:.2f} cm")
a.set(xlabel="distance travelled after detection (cm)", ylabel="speed (m/s)", title="Braking at the traction limit"); a.legend(fontsize=7.5)
lats = np.linspace(0, 0.25, 100); b.plot(lats * 1e3, [C.stopping_distance(V0, l, MU, G) * 100 for l in lats], color=PAL["blue"]); b.axhline(5, color=PAL["red"], ls=":"); b.text(130, 5.4, "5 cm", color=PAL["red"], fontsize=8); b.axhline(10, color=PAL["orange"], ls=":"); b.text(130, 10.4, "10 cm", color=PAL["orange"], fontsize=8)
b.set(xlabel="reaction latency (ms)", ylabel="stopping distance from 0.5 m/s (cm)", title="Latency budget"); 
for L in (0.015, 0.100, 0.150): b.plot(L * 1e3, C.stopping_distance(V0, L, MU, G) * 100, "o", color=PAL["black"], ms=4)
print("latency allowed for a 5 cm stop:", round((0.05 - V0 ** 2 / (2 * a_max)) / V0 * 1e3, 1), "ms ; for 10 cm:", round((0.10 - V0 ** 2 / (2 * a_max)) / V0 * 1e3, 1), "ms ; at 100 ms:", round(C.stopping_distance(V0, 0.1, MU, G) * 100, 2), "cm ; at 15 ms:", round(C.stopping_distance(V0, 0.015, MU, G) * 100, 2), "cm")
for mu in (0.3, 0.6, 0.9): print("mu", mu, "braking distance", round(V0 ** 2 / (2 * mu * G) * 100, 2), "cm")
save(fig, out("fig06_brake.png"))
