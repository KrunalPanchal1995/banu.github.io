"""Fig 1: the wheel motor as a first-order system. Left: open-loop response to 6 V and its time constant. Right: a 5 degree slope (load torque 0.0212 N m) at t = 2 s: open loop, P and PI.
ASSUMED reflected inertia J = 1.0e-3 kg m^2; the rest from the Unit 2 motor."""
from _common import *
use_code("robotics/control_np")
import control_np as C, math

m = C.WheelMotor(); print(f"k {m.k:.4f}  R {m.R}  b {m.b:.6f}  den {m.den:.6f}  tau {m.tau*1e3:.2f} ms  K {m.K:.3f} rad/s per V ; w(6 V) = {m.K*6:.3f} rad/s ; w(7 V) = {m.K*7:.2f} rad/s = {m.K*7*0.033:.3f} m/s")
t = np.arange(0, 0.8, 0.001); w = [0.0]
mm = C.WheelMotor(); ws = []
for _ in t: mm.step(6.0, 0.001); ws.append(mm.w)
ws = np.array(ws); t63 = t[np.where(ws >= 0.632 * m.K * 6)[0][0]]; t95 = t[np.where(ws >= 0.95 * m.K * 6)[0][0]]
print(f"simulated time to 63.2 percent {t63*1e3:.0f} ms (tau {m.tau*1e3:.1f}); to 95 percent {t95*1e3:.0f} ms (3 tau {3*m.tau*1e3:.0f})")
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.plot(t, ws, color=PAL["blue"]); a.axhline(m.K * 6, color=PAL["grey"], ls=":"); a.axvline(m.tau, color=PAL["red"], ls="--", lw=0.9); a.plot(m.tau, 0.632 * m.K * 6, "o", color=PAL["red"])
a.text(m.tau + 0.02, 6, f"tau = {m.tau*1e3:.0f} ms:\n63% of {m.K*6:.1f} rad/s", color=PAL["red"], fontsize=8); a.set(xlabel="time (s)", ylabel="wheel speed (rad/s)", title="Open-loop step to 6 V")
TL = 1.5 * 9.81 * math.sin(math.radians(5)) * 0.033 / 2; print("5 degree slope: load torque per wheel", round(TL, 4), "N m ; open-loop droop", round(TL / m.den, 3), "rad/s =", round(TL / m.den * 0.033, 4), "m/s")
kp, ti = C.lambda_pi(m.K, m.tau, 0.03)
cases = [("open loop (voltage for 15.15 rad/s)", None, PAL["red"]), ("P, kp = 1", C.PID(1.0, 0, 0, windup="none"), PAL["orange"]), ("PI (lambda 30 ms)", C.PID(kp, kp / ti), PAL["blue"])]
for name, pid, col in cases:
    mo = C.WheelMotor(); R = 15.15
    if pid is None:
        mo.w = R; us = R / mo.K; ts_ = 0.01; out_t = np.arange(0, 4, ts_); y = []
        for tt in out_t: mo.step(us, ts_, tau_load=TL if tt >= 2.0 else 0.0); y.append(mo.w)
        b.plot(out_t, y, color=col, label=name); print(name, "speed 1 s after the slope:", round(y[int(3.0 / ts_)], 3), "rad/s, drop", round(R - y[int(3.0 / ts_)], 3))
    else:
        mo.w = R; pid.i = (R / mo.K) if pid.ki else 0.0
        sim = C.simulate_speed_loop(pid, mo, R, 4.0, quantise=False, load=lambda tt: TL if tt >= 2.0 else 0.0)
        b.plot(sim["t"], sim["w"], color=col, label=name); y = sim["w"]
        print(name, "min after the slope", round(y[int(2.0 / 0.01):].min(), 3), " speed at 3 s", round(y[int(3.0 / 0.01)], 3), " at 4 s", round(y[-1], 3))
b.set(xlabel="time (s)", ylabel="wheel speed (rad/s)", title="A 5 degree slope at t = 2 s", ylim=(10.5, 16.5)); b.legend(fontsize=7.2, loc="lower left")
save(fig, out("fig01_motor.png"))
