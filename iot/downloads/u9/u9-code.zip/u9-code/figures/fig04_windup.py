"""Fig 4: integral windup. The wheel is blocked from 1 s to 2 s while the setpoint is 15 rad/s; three anti-windup strategies."""
from _common import *
use_code("robotics/control_np")
import control_np as C

m0 = C.WheelMotor(); kp, ti = C.lambda_pi(m0.K, m0.tau, 0.03)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
print("mode      max speed after release (rad/s)  integrator at release (V)  time back within 2% after release (s)")
for mode, col in (("none", PAL["red"]), ("backcalc", PAL["orange"]), ("clamp", PAL["blue"])):
    m = C.WheelMotor(); pid = C.PID(kp, kp / ti, windup=mode)
    sim = C.simulate_speed_loop(pid, m, 15.0, 6.0, quantise=False, blocked=lambda t: 1.0 <= t < 2.0)
    i_rel = sim["i"][int(1.99 / 0.01)]; after = sim["w"][int(2.0 / 0.01):]; tt = sim["t"][int(2.0 / 0.01):]
    out_band = np.where(np.abs(after - 15.0) > 0.3)[0]; t_back = (tt[out_band[-1]] - 2.0) if len(out_band) else 0.0
    print(f"{mode:9s} {after.max():24.2f} {i_rel:26.2f} {t_back:30.2f}")
    a.plot(sim["t"], sim["w"], color=col, label=mode); b.plot(sim["t"], sim["i"], color=col, label=mode)
a.axvspan(1, 2, color=PAL["grey"], alpha=0.2); a.axhline(15, color=PAL["black"], ls=":", lw=0.8); a.text(1.05, 3, "wheel blocked", fontsize=8); a.set(xlabel="time (s)", ylabel="wheel speed (rad/s)", title="Speed after the wheel is freed"); a.legend(fontsize=8)
b.axvspan(1, 2, color=PAL["grey"], alpha=0.2); b.axhline(7, color=PAL["black"], ls=":", lw=0.8); b.text(3.5, 9, "voltage limit 7 V", fontsize=8); b.set(xlabel="time (s)", ylabel="integrator term (V)", title="What the integrator stored", ylim=(-5, 160)); b.legend(fontsize=8)
save(fig, out("fig04_windup.png"))
