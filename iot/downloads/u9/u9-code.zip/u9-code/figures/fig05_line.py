"""Fig 5: line following with w = -k1 y - k2 theta (k1 = 8, k2 = 2.8, v = 0.5 m/s), start 0.3 m off the line, with wheel-speed loops and a delay in the lateral sensor."""
from _common import *
use_code("robotics/control_np")
import control_np as C

k1, k2, v = 8.0, 2.8, 0.5
print("closed-form delay margin of the ideal model:", round(C.line_delay_margin(k1, k2, v), 4), "s ; natural frequency sqrt(v k1) =", round((v * k1) ** 0.5, 3), "rad/s, damping k2/(2 sqrt(v k1)) =", round(k2 / (2 * (v * k1) ** 0.5), 3))
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1.3, 1]))
cols = {0.0: PAL["blue"], 0.2: PAL["green"], 0.6: PAL["orange"], 0.8: PAL["purple"], 1.0: PAL["red"]}
for d, col in cols.items():
    o = C.simulate_line_following(k1, k2, v, 0.3, 0.0, 14.0, sensor_delay_s=d); y = o["y"]
    inband = np.where(np.abs(y) > 0.01)[0]; settle = o["t"][inband[-1]] if len(inband) and inband[-1] < len(y) - 1 else float("nan")
    print(f"delay {d:.1f} s: min y {y.min():.3f} m (undershoot), settles into 1 cm at {settle:.2f} s, max |y| in last 3 s {np.abs(y[-300:]).max():.4f} m")
    a.plot(o["t"], y, color=col, label=f"sensor delay {d:g} s")
ideal = C.simulate_line_following(k1, k2, v, 0.3, 0.0, 14.0, motor_loops=False); print("ideal (no motor dynamics, no delay): min y", round(ideal["y"].min(), 4), " settle", round(ideal["t"][np.where(np.abs(ideal["y"]) > 0.01)[0][-1]], 2), "s")
a.plot(ideal["t"], ideal["y"], "--", color=PAL["black"], lw=0.8, label="ideal model"); a.axhline(0, color=PAL["grey"], lw=0.5); a.set(xlabel="time (s)", ylabel="lateral error y (m)", title="Convergence and the cost of delay"); a.legend(fontsize=6.8, loc="upper right")
for d, col in ((0.0, PAL["blue"]), (0.8, PAL["purple"]), (1.0, PAL["red"])):
    o = C.simulate_line_following(k1, k2, v, 0.3, 0.0, 14.0, sensor_delay_s=d); b.plot(o["t"] * v, o["y"], color=col, label=f"delay {d:g} s")
b.set(xlabel="distance along the line (m)", ylabel="y (m)", title="Paths"); b.legend(fontsize=7.5)
save(fig, out("fig05_line.png"))
