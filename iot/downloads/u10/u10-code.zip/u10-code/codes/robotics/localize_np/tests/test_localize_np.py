import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import localize_np as L  # noqa: E402


def test_gaussian_coverage_and_fusion():
    assert abs(L.gauss_prob_within(1) - 0.6827) < 1e-4 and abs(L.gauss_prob_within(2) - 0.9545) < 1e-4
    assert abs(L.gauss_prob_within(3) - 0.9973) < 1e-4
    m, v = L.fuse_gaussians(10.0, 4.0, 12.0, 1.0)
    assert abs(m - 11.6) < 1e-12 and abs(v - 0.8) < 1e-12
    assert abs(L.gauss_pdf(0.0, 0.0, 2.0) - 1 / (2 * math.sqrt(2 * math.pi))) < 1e-12


def test_bayes_posterior():
    assert abs(L.bayes_posterior(0.05, 0.9, 0.08) - 0.045 / (0.045 + 0.076)) < 1e-12


def test_histogram_filter():
    world = [1, 0, 0, 1, 0, 0, 0, 1, 0, 0]
    f = L.HistogramFilter(world, 0.9, 0.1)
    h0 = f.entropy_bits()
    assert abs(h0 - math.log2(10)) < 1e-9
    f.sense(1); f.move(3, 1.0, 0.0, 0.0); f.sense(1)
    assert abs(f.belief.sum() - 1) < 1e-12 and f.entropy_bits() < h0
    g = L.HistogramFilter(world)
    g.belief = np.eye(10)[2]
    g.move(3, 1.0, 0.0, 0.0)
    assert g.belief[5] == 1.0


def test_kalman1d_matches_closed_form_and_steady_state():
    k = L.Kalman1D(0.0, 4.0, 0.0, 1.0)
    k.update(10.0)
    assert abs(k.x - 8.0) < 1e-12 and abs(k.p - 0.8) < 1e-12
    q, r = 0.01, 0.25
    k = L.Kalman1D(0.0, 1.0, q, r)
    for _ in range(500):
        k.predict(); k.update(0.0)
    kg, pm = L.steady_state_gain(q, r)
    assert abs(k.k - kg) < 1e-9 and abs(k.p + q - pm) < 1e-9


def test_constant_velocity_filter_matches_riccati():
    from scipy.linalg import solve_discrete_are
    dt, qa, r = 0.1, 0.5, 0.04
    F = np.array([[1, dt], [0, 1.0]]); H = np.array([[1.0, 0.0]])
    Q = qa * np.array([[dt ** 4 / 4, dt ** 3 / 2], [dt ** 3 / 2, dt ** 2]])
    Pm = solve_discrete_are(F.T, H.T, Q, np.array([[r]]))
    Pp = Pm - Pm @ H.T @ np.linalg.inv(H @ Pm @ H.T + r) @ H @ Pm
    xs, ps = L.kalman_cv(np.zeros(600), dt, qa, r)
    assert abs(ps[-1] - Pp[0, 0]) < 1e-9


def test_speed_of_sound():
    assert abs(L.speed_of_sound(0) - 331.3) < 1e-9 and abs(L.speed_of_sound(20) - 343.2) < 0.1
    assert L.range_with_assumed_temperature(2.0, 20.0, 20.0) - 2.0 < 1e-12
    assert L.range_with_assumed_temperature(2.0, 35.0, 20.0) < 2.0


def test_ekf_jacobian_matches_finite_difference():
    e = L.PoseEKF((1.0, 0.5, 0.2))
    x = e.x.copy()
    h = lambda s: L.wall_range(s[:3])
    H = np.array([0.0, -1 / math.cos(x[2]), (L.WALL_Y - x[1]) * math.sin(x[2]) / math.cos(x[2]) ** 2, 0.0])
    for i in range(4):
        d = np.zeros(4); d[i] = 1e-6
        fd = (h(x + d) - h(x - d)) / 2e-6
        assert abs(fd - H[i]) < 1e-5


def test_patrol_ekf_beats_dead_reckoning():
    e = L.patrol("ekf"); g = L.patrol("gyro"); o = L.patrol("odom")
    assert not e.get("crashed") and e["err"] < 0.15 and e["err"] < g["err"] and o["crashed"]


def test_occupancy_grid_box_world():
    res = 0.05
    world = np.zeros((60, 60), bool)
    world[0, :] = world[-1, :] = world[:, 0] = world[:, -1] = True
    g = L.OccupancyGrid(3.0, 3.0, res)
    for th in np.linspace(0, 2 * math.pi, 180, endpoint=False):
        rng, hit = L.ray_cast(world, 1.5, 1.5, th, 4.0, res)
        g.update_ray(1.5, 1.5, th, rng, hit)
    acc, known = L.grid_accuracy(g, world)
    assert acc > 0.95 and known > 0.2
