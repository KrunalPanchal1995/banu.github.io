# localize_np

> Gaussian/Bayes helpers, histogram filter, scalar and constant-velocity Kalman filters, an EKF fusing encoders + gyro + wall ranges, ultrasonic range model, and a log-odds occupancy grid for the rover.

**Topic:** robotics  |  **Created in session:** 010 (Unit 10)  |  **Status:** tested (9 tests); simulation only

## What this code is for
Shows how a rover with drifting odometry estimates where it is and maps what is around it. Use it to fuse noisy sensors, test filter consistency, or build occupancy grids from range beams. Assumed (not measured): gyro bias 0.0035 rad/s and noise, ultrasonic noise, a straight wall at y = 1.5 m.

## Capabilities
- `gauss_pdf`, `gauss_prob_within(k)`, `fuse_gaussians(m1, v1, m2, v2)`, `bayes_posterior(prior, p_pos_h, p_pos_not_h)`.
- `HistogramFilter(world, p_hit, p_miss)`: `.sense(z)`, `.move(k, p_exact, p_under, p_over)`, `.entropy_bits()`.
- `Kalman1D(x0, p0, q, r)`: `.predict()`, `.update(z)`; `steady_state_gain(q, r)` -> (K, P-); `kalman_cv(zs, dt, q_acc, r)`.
- `speed_of_sound(T)`, `echo_range(t, T)`, `range_with_assumed_temperature(R, T_true, T_assumed)`.
- `PoseEKF(pose0, ...)`: state (x, y, theta, gyro bias); `.predict(ds, gyro, dt)`, `.update_range(z)`; `wall_range(pose)`.
- `patrol(mode="odom"|"gyro"|"ekf", ...)`: steer along a wall on the chosen estimate; returns paths, error, crashed.
- `OccupancyGrid(w, h, res)`: `.update_ray(x, y, th, range, hit)`, `.classify()`; `ray_cast`, `grid_accuracy`.

## Theory in one paragraph
Fusion: v = 1/(1/v1+1/v2). Scalar KF: P- = P+q, K = P-/(P-+r); steady state P- = (q+sqrt(q^2+4qr))/2. EKF wall range h = (W-y)/cos(theta). Log-odds l = ln(p/(1-p)), l += l_meas. Derived in Unit 10 Sections 3.1 to 3.4.

## Quick start
```bash
python -m pytest tests -q
```
```python
import localize_np as L
print(L.steady_state_gain(1e-4, 1e-2))   # (0.0951, 0.001051)
print(L.patrol("ekf")["err"])            # ~0.053 m after 20 m
```

## Tests
9 tests in `tests/test_localize_np.py` (coverage, Bayes, histogram, Kalman closed form, SciPy Riccati check, speed of sound, Jacobian by finite differences, patrol, grid).
