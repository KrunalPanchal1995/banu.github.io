"""Perception and localisation for the Smart Greenhouse Rover (Unit 10): Gaussians and Bayes, a histogram filter, the scalar Kalman filter,
an EKF that fuses encoder odometry, a gyroscope and ultrasonic wall ranges, an ultrasonic range model and an occupancy grid.

Units: metres, seconds, radians. See README.md. Depends on kinematics_np (Unit 8) for arc_pose and the shared RoverParams.
"""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "kinematics_np"))
from kinematics_np import RoverParams, arc_pose, wrap_angle  # noqa: E402


# ------------------------------------------------------------------ Gaussians and Bayes
def gauss_pdf(x, mu, sigma):
    return np.exp(-0.5 * ((np.asarray(x, float) - mu) / sigma) ** 2) / (sigma * math.sqrt(2 * math.pi))


def gauss_prob_within(k):
    """P(|x - mu| < k sigma) for a Gaussian: erf(k / sqrt 2)."""
    return math.erf(k / math.sqrt(2.0))


def fuse_gaussians(m1, v1, m2, v2):
    """Product of two Gaussian estimates of the same quantity: precision-weighted mean and variance 1/(1/v1 + 1/v2)."""
    v = 1.0 / (1.0 / v1 + 1.0 / v2)
    return v * (m1 / v1 + m2 / v2), v


def bayes_posterior(prior, p_pos_given_h, p_pos_given_not_h):
    """P(H | positive) from the prior P(H) and the two likelihoods."""
    num = p_pos_given_h * prior
    return num / (num + p_pos_given_not_h * (1.0 - prior))


# ------------------------------------------------------------------ histogram (grid) localisation on a circular corridor
class HistogramFilter:
    """1-D Bayes filter on a ring of n cells. world[i] is the colour (0/1) the sensor would see in cell i.
    sense(z): multiply by p_hit if the cell matches z else p_miss, normalise. move(k, p_exact, p_under, p_over): shift by k cells with errors."""

    def __init__(self, world, p_hit=0.8, p_miss=0.2):
        self.world = np.asarray(world, int)
        self.n = len(world)
        self.p_hit, self.p_miss = p_hit, p_miss
        self.belief = np.full(self.n, 1.0 / self.n)

    def sense(self, z):
        self.belief = self.belief * np.where(self.world == z, self.p_hit, self.p_miss)
        self.belief /= self.belief.sum()
        return self.belief

    def move(self, k, p_exact=0.8, p_under=0.1, p_over=0.1):
        b = self.belief
        self.belief = p_exact * np.roll(b, k) + p_under * np.roll(b, k - 1) + p_over * np.roll(b, k + 1)
        return self.belief

    def entropy_bits(self):
        b = self.belief[self.belief > 0]
        return float(-(b * np.log2(b)).sum())


# ------------------------------------------------------------------ scalar Kalman filter
class Kalman1D:
    """State x with random-walk model x' = x + w (variance q per step); measurement z = x + v (variance r)."""

    def __init__(self, x0=0.0, p0=1.0, q=0.0, r=1.0):
        self.x, self.p, self.q, self.r = float(x0), float(p0), float(q), float(r)
        self.k = 0.0

    def predict(self, u=0.0, q=None):
        self.x += u
        self.p += self.q if q is None else q
        return self.x, self.p

    def update(self, z):
        self.k = self.p / (self.p + self.r)
        self.x += self.k * (z - self.x)
        self.p *= (1.0 - self.k)
        return self.x, self.p


def steady_state_gain(q, r):
    """Steady-state Kalman gain of the random-walk filter: P- = (q + sqrt(q^2 + 4 q r))/2, K = P-/(P- + r). Equal to the fixed EMA coefficient of Unit 3."""
    pm = 0.5 * (q + math.sqrt(q * q + 4.0 * q * r))
    return pm / (pm + r), pm


def kalman_cv(zs, dt, q_acc, r, x0=(0.0, 0.0), p0=(1.0, 1.0)):
    """Constant-velocity Kalman filter (state position, velocity) for position measurements zs. Returns states (n, 2) and variances of position (n,)."""
    F = np.array([[1.0, dt], [0.0, 1.0]])
    Q = q_acc * np.array([[dt ** 4 / 4, dt ** 3 / 2], [dt ** 3 / 2, dt ** 2]])
    H = np.array([[1.0, 0.0]])
    x, P = np.array(x0, float), np.diag(p0).astype(float)
    xs, ps = [], []
    for z in zs:
        x, P = F @ x, F @ P @ F.T + Q
        S = H @ P @ H.T + r
        K = (P @ H.T) / S
        x = x + (K * (z - H @ x)).ravel()
        P = (np.eye(2) - K @ H) @ P
        xs.append(x.copy()); ps.append(P[0, 0])
    return np.array(xs), np.array(ps)


# ------------------------------------------------------------------ ultrasonic ranging
def speed_of_sound(T_c):
    """Speed of sound in dry air (m/s) at temperature T_c (degC): 331.3 sqrt(1 + T/273.15)."""
    return 331.3 * math.sqrt(1.0 + T_c / 273.15)


def echo_range(t_echo, T_c):
    """Distance from a round-trip echo time: c t / 2."""
    return speed_of_sound(T_c) * t_echo / 2.0


def range_with_assumed_temperature(true_range, T_true, T_assumed=20.0):
    """The range the node reports if it assumes T_assumed but the air is at T_true."""
    t = 2.0 * true_range / speed_of_sound(T_true)
    return echo_range(t, T_assumed)


# ------------------------------------------------------------------ EKF: encoders + gyro + wall range
WALL_Y = 1.5


def wall_range(pose, wall_y=WALL_Y):
    """Range measured by a left-facing ultrasonic sensor to a straight wall y = wall_y: (W - y)/cos(theta). None when the beam leaves the wall (|theta| > 60 degrees)."""
    x, y, th = pose[:3]
    c = math.cos(th)
    if c < 0.5:
        return None
    return (wall_y - y) / c


class PoseEKF:
    """State (x, y, theta, b): pose plus gyro bias b (rad/s). Predict from the encoder travel (ds) and the gyro; update with wall ranges.
    q_slip: variance of travel per metre (m^2/m); sigma_g: gyro noise per sample (rad/s); sigma_b: bias random walk (rad/s per sqrt s)."""

    def __init__(self, pose0, p0=(1e-4, 1e-4, 1e-4, 1e-4), q_slip=4e-6, sigma_g=0.01, sigma_b=1e-4, r_range=0.01, wall_y=WALL_Y):
        self.x = np.array([*pose0, 0.0], float)
        self.P = np.diag(p0).astype(float)
        self.q_slip, self.sigma_g, self.sigma_b, self.r, self.wall_y = q_slip, sigma_g, sigma_b, r_range, wall_y

    def predict(self, ds, gyro, dt):
        x, y, th, b = self.x
        dth = (gyro - b) * dt
        thm = th + 0.5 * dth
        self.x = np.array([x + ds * math.cos(thm), y + ds * math.sin(thm), wrap_angle(th + dth), b])
        F = np.eye(4)
        F[0, 2] = -ds * math.sin(thm); F[1, 2] = ds * math.cos(thm)
        F[2, 3] = -dt
        G = np.zeros((4, 3))                      # noise inputs: travel, gyro, bias walk
        G[0, 0], G[1, 0] = math.cos(thm), math.sin(thm)
        G[2, 1] = dt
        G[3, 2] = math.sqrt(dt)
        Qn = np.diag([self.q_slip * abs(ds), self.sigma_g ** 2, self.sigma_b ** 2])
        self.P = F @ self.P @ F.T + G @ Qn @ G.T

    def update_range(self, z):
        x, y, th, b = self.x
        c = math.cos(th)
        if c < 0.5:
            return None
        h = (self.wall_y - y) / c
        H = np.array([[0.0, -1.0 / c, (self.wall_y - y) * math.sin(th) / c ** 2, 0.0]])
        S = float((H @ self.P @ H.T)[0, 0]) + self.r
        K = (self.P @ H.T) / S
        innov = z - h
        self.x = self.x + (K * innov).ravel()
        self.x[2] = wrap_angle(self.x[2])
        I = np.eye(4)
        self.P = (I - K @ H) @ self.P @ (I - K @ H).T + (K * self.r) @ K.T
        return innov, S

    @property
    def pose(self):
        return self.x[:3].copy()


def patrol(mode="ekf", length=20.0, v=0.5, dt=0.01, eps_l=0.0, eps_r=0.005, slip_q=4e-6, gyro_bias=0.0035, gyro_sigma=0.01, range_sigma=0.01,
           range_period=0.2, y_ref=0.5, k1=1.0, k2=2.0, half_width=0.1, seed=0, params=None):
    """Drive along x for `length` metres, steering with the Unit 9 law w = -k1 (y_hat - y_ref) - k2 theta_hat on the chosen ESTIMATE of the pose, next to a wall at y = WALL_Y.
    mode: "odom" (encoders only), "gyro" (encoder distance + gyro heading), "ekf" (encoders + gyro + wall ranges). Wheel radius error eps_r (right wheel, relative),
    random slip, a gyro bias and noise are applied to the TRUE rover. The run stops early if the rover's side touches the wall (y + half_width >= WALL_Y).
    Returns dict: t, true, est (n,3), err (final distance between estimate and truth), crashed, x_end, clearance (minimum wall gap)."""
    p = params or RoverParams()
    rng = np.random.default_rng(seed)
    n = int(round(length / v / dt)) + 200
    true = np.array([0.0, y_ref, 0.0])
    est = true.copy()
    ekf = PoseEKF(true, q_slip=slip_q, sigma_g=gyro_sigma, r_range=range_sigma ** 2)
    ekf.r = range_sigma ** 2
    rev = [0.0, 0.0]; cnt = [0, 0]
    T, TR, ES, SG = [], [], [], []
    next_r = 0.0
    crashed = False
    clearance = WALL_Y - y_ref - half_width
    for i in range(n):
        t = i * dt
        if true[0] >= length:
            break
        w_cmd = -k1 * (est[1] - y_ref) - k2 * est[2]
        w_cmd = max(-1.0, min(1.0, w_cmd))
        vl, vr = v - 0.5 * w_cmd * p.track, v + 0.5 * w_cmd * p.track
        ds_true = []
        rot = []
        for j, (vw, e) in enumerate(((vl, eps_l), (vr, eps_r))):
            a = vw / p.wheel_r * dt
            rot.append(a)
            s = p.wheel_r * (1 + e) * a
            if slip_q > 0 and s != 0:
                s += rng.normal(0.0, math.sqrt(slip_q * abs(s)))
            ds_true.append(s)
        true = arc_pose(true, ds_true[0], ds_true[1], p.track)
        dc = []
        for j in range(2):
            rev[j] += rot[j] / (2 * math.pi)
            new_c = int(math.floor(rev[j] * p.cpr)) if rev[j] >= 0 else -int(math.floor(-rev[j] * p.cpr))
            dc.append(new_c - cnt[j]); cnt[j] = new_c
        dsl, dsr = dc[0] * p.dist_per_count, dc[1] * p.dist_per_count
        ds = 0.5 * (dsl + dsr)
        w_true = (ds_true[1] - ds_true[0]) / p.track / dt
        gyro = w_true + gyro_bias + rng.normal(0.0, gyro_sigma)
        if mode == "odom":
            est = arc_pose(est, dsl, dsr, p.track)
        elif mode == "gyro":
            est = np.array([est[0] + ds * math.cos(est[2]), est[1] + ds * math.sin(est[2]), wrap_angle(est[2] + gyro * dt)])
        else:
            ekf.predict(ds, gyro, dt)
            if t >= next_r - 1e-9:
                z = wall_range(true)
                if z is not None:
                    ekf.update_range(z + rng.normal(0.0, range_sigma))
                next_r += range_period
            est = ekf.pose
        clearance = min(clearance, WALL_Y - true[1] - half_width)
        if true[1] + half_width >= WALL_Y:
            crashed = True
        if i % 10 == 0:
            T.append(t); TR.append(true.copy()); ES.append(est.copy()); SG.append(np.sqrt(np.diag(ekf.P)[:3]))
        if crashed:
            break
    TR.append(true.copy()); ES.append(est.copy()); T.append(t); SG.append(np.sqrt(np.diag(ekf.P)[:3]))
    TR, ES = np.array(TR), np.array(ES)
    return dict(t=np.array(T), true=TR, est=ES, sig=np.array(SG), err=float(np.hypot(*(ES[-1][:2] - TR[-1][:2]))), crashed=crashed,
                x_end=float(true[0]), clearance=float(clearance), y_end=float(true[1]), bias_hat=float(ekf.x[3]))


# ------------------------------------------------------------------ occupancy grid
class OccupancyGrid:
    """Log-odds occupancy grid, cell size `res` metres, origin at (0, 0). update_ray marks the cells along a beam free and the end cell occupied (if hit)."""

    def __init__(self, width, height, res=0.05, l_occ=0.85, l_free=-0.4, l_min=-5.0, l_max=5.0):
        self.res, self.l_occ, self.l_free, self.l_min, self.l_max = res, l_occ, l_free, l_min, l_max
        self.nx, self.ny = int(round(width / res)), int(round(height / res))
        self.L = np.zeros((self.ny, self.nx))

    def cell(self, x, y):
        return int(math.floor(y / self.res)), int(math.floor(x / self.res))

    def update_ray(self, x, y, th, rng, hit=True):
        n = int(rng / (self.res * 0.5))
        seen = set()
        for k in range(n):
            s = k * self.res * 0.5
            r, c = self.cell(x + s * math.cos(th), y + s * math.sin(th))
            if 0 <= r < self.ny and 0 <= c < self.nx and (r, c) not in seen:
                seen.add((r, c))
                self.L[r, c] = np.clip(self.L[r, c] + self.l_free, self.l_min, self.l_max)
        if hit:
            r, c = self.cell(x + rng * math.cos(th), y + rng * math.sin(th))
            if 0 <= r < self.ny and 0 <= c < self.nx:
                if (r, c) in seen:                     # undo the free update for the end cell
                    self.L[r, c] -= self.l_free
                self.L[r, c] = np.clip(self.L[r, c] + self.l_occ, self.l_min, self.l_max)

    def prob(self):
        return 1.0 / (1.0 + np.exp(-self.L))

    def classify(self, p_occ=0.65, p_free=0.35):
        p = self.prob()
        return np.where(p > p_occ, 1, np.where(p < p_free, 0, -1))        # 1 occupied, 0 free, -1 unknown


def ray_cast(world, x, y, th, max_range, res):
    """True range to the first occupied cell of `world` (bool array [row, col]) along a ray; max_range if none."""
    step = res * 0.25
    s = 0.0
    while s < max_range:
        r, c = int(math.floor((y + s * math.sin(th)) / res)), int(math.floor((x + s * math.cos(th)) / res))
        if not (0 <= r < world.shape[0] and 0 <= c < world.shape[1]) or world[r, c]:
            return s, True
        s += step
    return max_range, False


def grid_accuracy(grid, world):
    """Among known cells: fraction classified correctly, plus the fraction of cells that are known."""
    cls = grid.classify()
    known = cls >= 0
    if known.sum() == 0:
        return 0.0, 0.0
    return float((cls[known] == world[known].astype(int)).mean()), float(known.mean())


def main():
    for m in ("odom", "gyro", "ekf"):
        r = patrol(m)
        print(m, round(r["err"], 3), r["crashed"], round(r["x_end"], 2), round(r["clearance"], 3))


if __name__ == "__main__":
    main()
