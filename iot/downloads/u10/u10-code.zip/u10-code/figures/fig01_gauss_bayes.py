"""Fig 1: noise as a Gaussian (10000 simulated ultrasonic readings of a wall 2.00 m away, ASSUMED sigma 1 cm) and Bayes' rule for a soil-dryness alert."""
from _common import *
use_code("robotics/localize_np")
import localize_np as L

rng = np.random.default_rng(1); sig = 0.01; z = 2.0 + rng.normal(0, sig, 10000)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.hist((z - 2.0) * 100, bins=50, density=True, color=PAL["blue"], alpha=0.55, label="10000 readings")
xs = np.linspace(-4, 4, 400); a.plot(xs, L.gauss_pdf(xs, 0, 1.0), color=PAL["red"], label="Gaussian, sigma = 1 cm")
for k, c in ((1, PAL["green"]), (2, PAL["orange"]), (3, PAL["purple"])):
    a.axvline(k, color=c, ls=":"); a.axvline(-k, color=c, ls=":")
    frac = np.mean(np.abs(z - 2.0) < k * sig); print(f"within {k} sigma: measured {frac:.4f} ; erf formula {L.gauss_prob_within(k):.4f}")
a.set(xlabel="reading error (cm)", ylabel="density", title="Noise follows a bell curve"); a.legend(fontsize=7.5)
print("sample mean error (mm):", round((z.mean() - 2.0) * 1000, 3), " sample std (mm):", round(z.std() * 1000, 3), " std of the mean (mm):", round(sig / 100 ** 0.5 * 1000, 3))
prior, ph, pf = 0.05, 0.90, 0.08
post = [prior]
for k in range(4):
    p = post[-1]; post.append(L.bayes_posterior(p, ph, pf))
for k, p in enumerate(post): print(f"after {k} positive readings: P(dry) = {p:.4f}")
print("one positive:", round(L.bayes_posterior(prior, ph, pf), 4), "; false alarms among positives:", round(1 - L.bayes_posterior(prior, ph, pf), 4))
for pr in (0.01, 0.05, 0.2, 0.5): print(f"prior {pr}: posterior after one positive = {L.bayes_posterior(pr, ph, pf):.4f}")
b.bar(range(5), post, color=PAL["blue"]); b.set_xticks(range(5)); 
for k, p in enumerate(post): b.text(k, p + 0.02, f"{p:.3f}", ha="center", fontsize=8)
b.set(xlabel="number of independent 'dry' readings in a row", ylabel="P(soil is dry)", ylim=(0, 1.05), title="Bayes' rule: prior 5%, hit 90%, false alarm 8%")
save(fig, out("fig01_gauss_bayes.png"))
