"""Fig 4: ultrasonic ranging (speed of sound and temperature) and a constant-velocity Kalman filter that estimates speed from position readings alone."""
from _common import *
use_code("robotics/localize_np")
import localize_np as L, math
from scipy.linalg import solve_discrete_are

fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
T = np.linspace(0, 40, 81)
for R, c in ((0.5, PAL["green"]), (2.0, PAL["blue"]), (4.0, PAL["red"])):
    err = [L.range_with_assumed_temperature(R, t, 20.0) - R for t in T]; a.plot(T, np.array(err) * 100, color=c, label=f"true range {R} m")
    print(f"true range {R} m: reported-minus-true at 0 degC {(L.range_with_assumed_temperature(R, 0, 20) - R) * 100:.1f} cm, at 35 degC {(L.range_with_assumed_temperature(R, 35, 20) - R) * 100:.1f} cm")
a.axhline(0, color=PAL["black"], lw=0.6); a.set(xlabel="actual air temperature (degC); the node assumes 20 degC", ylabel="range error (cm)", title="Sound is faster in warm air"); a.legend(fontsize=7.5)
for t in (0, 10, 20, 30, 40): print(f"speed of sound at {t} degC: {L.speed_of_sound(t):.2f} m/s")
print("relative range error per degC near 20 degC:", round((L.speed_of_sound(21) / L.speed_of_sound(20) - 1) * 100, 4), "percent")
# constant-velocity filter: rover drives 0.5 m/s, position measured every 0.1 s with sigma 1 cm
dt, sig, v = 0.1, 0.01, 0.5; rng = np.random.default_rng(2); n = 120; t = np.arange(n) * dt
xt = 3.0 - v * t; z = xt + rng.normal(0, sig, n)
qa = 0.05
xs, ps = L.kalman_cv(z, dt, qa, sig ** 2, x0=(z[0], 0.0), p0=(sig ** 2, 4.0))
diff = np.diff(z) / dt
print(f"naive speed from differencing: std {np.std(diff + v):.3f} m/s (theory sqrt2 sigma/dt = {math.sqrt(2) * sig / dt:.3f}); Kalman speed error after 5 s: rms {np.sqrt(np.mean((xs[50:, 1] + v) ** 2)):.4f} m/s")
F = np.array([[1, dt], [0, 1.0]]); H = np.array([[1.0, 0.0]]); Q = qa * np.array([[dt ** 4 / 4, dt ** 3 / 2], [dt ** 3 / 2, dt ** 2]])
Pm = solve_discrete_are(F.T, H.T, Q, np.array([[sig ** 2]])); K = Pm @ H.T / (H @ Pm @ H.T + sig ** 2); Pp = Pm - K @ H @ Pm
print("steady state (Riccati): position std", round(math.sqrt(Pp[0, 0]) * 100, 3), "cm ; velocity std", round(math.sqrt(Pp[1, 1]), 4), "m/s ; gains", np.round(K.ravel(), 4))
print("raw position error std (cm)", sig * 100, " Kalman position rms error after 5 s (cm)", round(np.sqrt(np.mean((xs[50:, 0] - xt[50:]) ** 2)) * 100, 3))
b.plot(t[1:], diff, ".", ms=3, color=PAL["grey"], label="difference of readings"); b.plot(t, xs[:, 1], color=PAL["blue"], label="Kalman velocity"); b.axhline(-v, color=PAL["black"], ls=":", label="true -0.5 m/s")
b.set(xlabel="time (s)", ylabel="velocity (m/s)", ylim=(-1.5, 0.5), title="Speed from position readings alone"); b.legend(fontsize=7.5)
save(fig, out("fig04_range_cv.png"))

vr, pr = [], []
for sd in range(300):
    zz = xt + np.random.default_rng(sd).normal(0, sig, n); xx, _ = L.kalman_cv(zz, dt, qa, sig ** 2, x0=(zz[0], 0.0), p0=(sig ** 2, 4.0))
    vr.append(np.mean((xx[50:, 1] + v) ** 2)); pr.append(np.mean((xx[50:, 0] - xt[50:]) ** 2))
print(f"300 runs after 5 s: speed rms error {math.sqrt(np.mean(vr)):.4f} m/s ; position rms error {math.sqrt(np.mean(pr)) * 100:.3f} cm (the filter assumes acceleration noise {qa}, the true motion has none, so its reported 0.0356 m/s is conservative)")
