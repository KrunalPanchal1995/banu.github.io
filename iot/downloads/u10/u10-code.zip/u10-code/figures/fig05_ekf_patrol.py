"""Fig 5: a 20 m patrol along a wall (ASSUMED: right wheel 0.5% large, slip variance 4e-6 m^2/m (Unit 8), gyro bias 0.0035 rad/s = 0.2 deg/s, gyro noise 0.01 rad/s per 10 ms sample,
wall-range noise 1 cm every 0.2 s). The rover steers (Unit 9 law, k1 = 1, k2 = 2) on its own pose ESTIMATE, three ways."""
from _common import *
use_code("robotics/localize_np")
import localize_np as L

res = {m: L.patrol(m) for m in ("odom", "gyro", "ekf")}
for m, r in res.items(): print(f"{m:5s}: reached x = {r['x_end']:.2f} m, true y = {r['y_end']:.3f} m, estimate-vs-truth error {r['err']:.3f} m, crashed into the wall: {r['crashed']}, minimum wall gap {r['clearance']*100:.1f} cm")
for m, r in res.items(): d = r["est"][-1] - r["true"][-1]; print(f"{m:5s}: final estimate-minus-truth: dx {d[0]*100:.1f} cm, dy {d[1]*100:.1f} cm, dtheta {np.degrees(d[2]):.2f} deg")
print("EKF final sigma (x, y, theta):", np.round(res["ekf"]["sig"][-1][:2] * 100, 2), "cm", round(float(np.degrees(res["ekf"]["sig"][-1][2])), 3), "deg")
bh = [L.patrol('ekf', seed=s)['bias_hat'] for s in range(20)]
print(f"EKF gyro-bias estimate at 20 m over 20 runs: mean {np.mean(bh):.5f} rad/s, std {np.std(bh):.5f} (true 0.0035)")
# open loop (no steering) from Unit 8, same wheel error, to quote the dead reckoning error at 20 m
from kinematics_np import Rover
rv = Rover(eps_r=0.005, seed=0); rv.drive(0.5, 0.0, 40.0); print("Unit 8 open-loop 20 m, 0.5% radius error, no slip: odometry error", round(rv.position_error(), 3), "m")
# Monte Carlo
N = 60; E = {m: [] for m in ("odom", "gyro", "ekf")}; C = {m: 0 for m in E}; ey = []; yb = []; bias_est = []
for s in range(N):
    for m in E:
        r = L.patrol(m, seed=s); E[m].append(r["err"]); C[m] += r["crashed"]
        if m == "ekf": ey.append(r["true"][-1][1] - r["est"][-1][1]); yb.append(r["sig"][-1][1])
for m in E: print(f"{m:5s}: {N} runs, final error median {np.median(E[m]):.3f} m, mean {np.mean(E[m]):.3f}, 90th percentile {np.percentile(E[m], 90):.3f} m ; crashes {C[m]}/{N}")
print("EKF lateral error std over runs:", round(float(np.std(ey)), 4), "m ; mean reported sigma_y:", round(float(np.mean(yb)), 4), "m")
# R5 budget: 10% of 20 m
print("R5 limit (10 percent of 20 m):", 2.0, "m")
# range update period sweep
for per in (0.2, 1.0, 5.0, 20.0):
    e = [L.patrol("ekf", seed=s, range_period=per)["err"] for s in range(20)]; cr = sum(L.patrol("ekf", seed=s, range_period=per)["crashed"] for s in range(20))
    print(f"wall range every {per:4.1f} s: median final error {np.median(e):.3f} m, crashes {cr}/20")
# gyro bias estimate
r = L.patrol("ekf", seed=0)
ek = L.PoseEKF((0, 0.5, 0))
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.axhline(L.WALL_Y, color=PAL["black"], lw=3, label="wall"); cols = {"odom": PAL["red"], "gyro": PAL["orange"], "ekf": PAL["blue"]}
for m, r in res.items():
    a.plot(r["true"][:, 0], r["true"][:, 1], color=cols[m], label=f"true path, steering on {'encoders' if m == 'odom' else 'encoders + gyro' if m == 'gyro' else 'EKF'}")
    a.plot(r["est"][:, 0], r["est"][:, 1], color=cols[m], ls=":", lw=1)
a.set(xlabel="x (m)", ylabel="y (m)", ylim=(-1.3, 1.7), title="Dotted: what the rover believes"); a.legend(fontsize=7, loc="center right")
for m, r in res.items():
    d = np.hypot(*(r["est"][:, :2] - r["true"][:, :2]).T); b.plot(r["true"][:, 0], d, color=cols[m], label=m)
r = res["ekf"]; b.plot(r["true"][:, 0], 2 * np.hypot(r["sig"][:, 0], r["sig"][:, 1]), color=PAL["blue"], ls="--", lw=0.8, label="EKF 2 sigma (position)")
b.axhline(2.0, color=PAL["grey"], ls=":"); b.text(0.3, 2.05, "R5: 10% of 20 m", fontsize=7.5)
b.set(xlabel="distance along the wall (m)", ylabel="position error, estimate vs truth (m)", yscale="log", title="Estimate error"); b.legend(fontsize=7.5)
save(fig, out("fig05_ekf_patrol.png"))
