"""Fig 3: the scalar Kalman filter on a slowly drifting soil-moisture level (ASSUMED: drift variance q = 1e-4 per sample, sensor noise sigma 0.1 so r = 0.01), against the raw reading and the fixed-gain EMA of Unit 3."""
from _common import *
use_code("robotics/localize_np")
import localize_np as L

q, r, n = 1e-4, 1e-2, 400
def sim(seed):
    rng = np.random.default_rng(seed); x = 0.5 + np.cumsum(rng.normal(0, q ** 0.5, n)); z = x + rng.normal(0, r ** 0.5, n); return x, z
def kf(z, p0=1.0):
    k = L.Kalman1D(z[0], p0, q, r); xs, ks, ps = [], [], []
    for zi in z:
        k.predict(); k.update(zi); xs.append(k.x); ks.append(k.k); ps.append(k.p)
    return np.array(xs), np.array(ks), np.array(ps)
def ema(z, a):
    y = [z[0]]
    for zi in z[1:]: y.append(y[-1] + a * (zi - y[-1]))
    return np.array(y)
kinf, pm = L.steady_state_gain(q, r)
print(f"steady-state gain {kinf:.5f}  prior variance P- {pm:.6f}  posterior P {pm * (1 - kinf):.6f}  (std {np.sqrt(pm * (1 - kinf)):.4f}); raw std {np.sqrt(r):.3f}")
res = {}
for name in ("raw", "kf", "ema_kinf", "ema_0.5", "ema_0.02"): res[name] = []
for seed in range(200):
    x, z = sim(seed); k, ks, ps = kf(z)
    m = slice(100, None)
    res["raw"].append(np.sqrt(np.mean((z[m] - x[m]) ** 2))); res["kf"].append(np.sqrt(np.mean((k[m] - x[m]) ** 2)))
    for nm, a in (("ema_kinf", kinf), ("ema_0.5", 0.5), ("ema_0.02", 0.02)): res[nm].append(np.sqrt(np.mean((ema(z, a)[m] - x[m]) ** 2)))
for nm, v in res.items(): print(f"RMSE after sample 100 (mean of 200 runs): {nm:9s} {np.mean(v):.4f}")
x, z = sim(5); k, ks, ps = kf(z)
print("gain at samples 1, 2, 5, 10, 50, 399:", [round(float(ks[i]), 4) for i in (0, 1, 4, 9, 49, 399)])
print("coverage: fraction of samples after 100 with |error| < 2 sigma_P (200 runs):", round(np.mean([np.mean(np.abs(kf(sim(s)[1])[0] - sim(s)[0])[100:] < 2 * np.sqrt(kf(sim(s)[1])[2][100:])) for s in range(200)]), 3))
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.plot(z, ".", ms=2, color=PAL["grey"], label="raw readings"); a.plot(x, color=PAL["black"], lw=1.2, label="true level"); a.plot(k, color=PAL["blue"], lw=1.4, label="Kalman")
a.plot(ema(z, 0.5), color=PAL["orange"], lw=0.9, label="EMA, alpha = 0.5"); a.plot(ema(z, 0.02), color=PAL["green"], lw=0.9, label="EMA, alpha = 0.02")
a.set(xlabel="sample", ylabel="soil moisture (fraction)", title="Tracking a drifting level"); a.legend(fontsize=7, ncol=2)
b.plot(ks, color=PAL["blue"], label="gain K"); b.axhline(kinf, color=PAL["red"], ls=":", label=f"steady state {kinf:.3f}"); b.set(xlabel="sample", ylabel="Kalman gain K", ylim=(0, 1.02), xscale="log")
b2 = b.twinx(); b2.plot(np.sqrt(ps), color=PAL["purple"], label="std of estimate"); b2.set_ylabel("posterior std", color=PAL["purple"]); b.legend(fontsize=7.5, loc="upper right"); b.set_title("The gain starts near 1 and settles")
save(fig, out("fig03_kalman1d.png"))
