"""Fig 2: histogram (grid) localisation along a ring corridor of 20 cells with doors. Sensor: right 90% of the time. Move: +1 cell, exact 95%, short 2.5%, long 2.5%.
Top: belief snapshots for one run. Bottom: Monte Carlo over 400 runs of how often the most likely cell is the true cell, and the probability on the true cell."""
from _common import *
use_code("robotics/localize_np")
import localize_np as L

world = np.array([1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0]); N = 20
def run(seed, nsteps=14, snaps=()):
    rng = np.random.default_rng(seed); pos = int(rng.integers(N)); f = L.HistogramFilter(world, 0.9, 0.1)
    hit, ptrue, ent, shots = [], [], [], []
    for i in range(nsteps):
        z = world[pos] if rng.random() < 0.9 else 1 - world[pos]
        f.sense(z)
        hit.append(int(np.argmax(f.belief)) == pos); ptrue.append(f.belief[pos]); ent.append(f.entropy_bits())
        if i in snaps: shots.append((f"after sensing #{i+1} (read {'door' if z else 'wall'})", f.belief.copy(), pos))
        u = rng.random(); pos = (pos + (1 if u < 0.95 else (0 if u < 0.975 else 2))) % N; f.move(1, 0.95, 0.025, 0.025)
    return np.array(hit), np.array(ptrue), np.array(ent), shots
nruns = 400
H, P, E = zip(*[run(s)[:3] for s in range(nruns)])
H, P, E = np.mean(H, 0), np.mean(P, 0), np.mean(E, 0)
for i in range(14): print(f"sensing #{i+1:2d}: P(peak is the true cell) = {H[i]:.3f}   mean probability on true cell = {P[i]:.3f}   mean entropy = {E[i]:.3f} bits")
print("uniform start: P(peak) = 1/20 = 0.05, entropy", round(np.log2(20), 3), "bits ; runs:", nruns)
p10 = np.array([run(sd)[1][9] for sd in range(nruns)]); med = np.median(p10); seed = int(np.argmin(np.abs(p10 - med)))
print("snapshot run: seed", seed, "chosen because its probability on the true cell after 10 readings", round(p10[seed], 3), "is closest to the median", round(med, 3), "of", nruns, "runs")
_, pt, _, shots = run(seed, snaps=(0, 2, 5, 9))
for lab, bel, p in shots: print(lab, ": true cell", p, "peak", int(np.argmax(bel)), "p(true)", round(bel[p], 3))
fig = plt.figure(figsize=(FIG["panel2"][0], 7.2)); gs = fig.add_gridspec(len(shots) + 2, 1, height_ratios=[1] * len(shots) + [2.2, 0.01])
for i, (lab, bel, p) in enumerate(shots):
    ax = fig.add_subplot(gs[i]); ax.bar(range(N), bel, color=PAL["blue"]); ax.axvline(p, color=PAL["red"], lw=1.5)
    for c in np.where(world == 1)[0]: ax.axvspan(c - 0.5, c + 0.5, color=PAL["grey"], alpha=0.25, lw=0)
    ax.set(ylim=(0, max(0.3, bel.max() * 1.15)), yticks=[], xticks=range(N) if i == len(shots) - 1 else []); ax.text(0.01, 0.74, lab, transform=ax.transAxes, fontsize=7.5)
ax = fig.add_subplot(gs[len(shots)]); xs = np.arange(1, 15)
ax.plot(xs, H, "o-", color=PAL["blue"], ms=3, label="P(most likely cell = true cell)"); ax.plot(xs, P, "s-", color=PAL["orange"], ms=3, label="mean probability on the true cell")
ax.set(xlabel="number of door/wall readings (moving one cell between readings)", ylabel="probability", ylim=(0, 1), title=f"Average of {nruns} runs (grey bars above: doors, red line: true cell)"); ax.legend(fontsize=7.5)
save(fig, out("fig02_histogram.png"))
