"""Fig 6: occupancy-grid mapping of a 6 m x 4 m greenhouse bay with two plant beds. The rover circuits the bay (about 15 m); a ring of 24 ultrasonic beams (sigma 2 cm, range 3 m) is integrated
three times: with the TRUE pose (the ideal), with a pose estimate of EKF quality (ASSUMED error 2 cm / 0.5 deg), and with the encoder odometry of a rover whose right wheel is 0.5% large."""
from _common import *
use_code("robotics/localize_np")
import localize_np as L, math
from kinematics_np import Rover

res = 0.05; W, Hh = 6.0, 4.0; nx, ny = int(W / res), int(Hh / res)
world = np.zeros((ny, nx), bool); world[0, :] = world[-1, :] = world[:, 0] = world[:, -1] = True
world[int(1.7 / res):int(2.3 / res), int(2.0 / res):int(4.0 / res)] = True       # a bed in the middle
world[int(1.0 / res):int(1.4 / res), int(4.6 / res):int(5.0 / res)] = True       # a pot stand
rv = Rover(pose=(0.8, 0.8, 0.0), eps_r=0.005, slip_q=4e-6, seed=1)
poses_true, poses_odom = [], []
def record(): poses_true.append(rv.pose.copy()); poses_odom.append(rv.odom.copy())
def wrap(a): return (a + math.pi) % (2 * math.pi) - math.pi
def leg(p0, p1):
    """Drive from corner p0 to p1 steering on the TRUE pose (a perfect external guide), so the true path is the planned rectangle; the odometry still drifts."""
    d = np.array(p1) - np.array(p0); L_ = np.hypot(*d); h = math.atan2(d[1], d[0]); n = np.array([-d[1], d[0]]) / L_
    while (rv.pose[:2] - np.array(p0)) @ (d / L_) < L_ - 0.05:
        e = (rv.pose[:2] - np.array(p0)) @ n; w = -2.0 * e - 2.8 * wrap(rv.pose[2] - h)
        rv.drive(0.5, max(-1.5, min(1.5, w)), 0.1, 0.01); record()
def turn_to(h):
    while abs(wrap(rv.pose[2] - h)) > 0.02:
        w = -2.0 * wrap(rv.pose[2] - h); w = math.copysign(max(0.4, min(1.2, abs(w))), w)
        rv.drive(0.0, w, 0.1, 0.01); record()
C = [(0.8, 0.8), (5.2, 0.8), (5.2, 3.2), (0.8, 3.2)]
for i in range(4):
    leg(C[i], C[(i + 1) % 4]); h_next = math.atan2(C[(i + 2) % 4][1] - C[(i + 1) % 4][1], C[(i + 2) % 4][0] - C[(i + 1) % 4][0]); turn_to(h_next)
tp, op = np.array(poses_true), np.array(poses_odom)
print(f"{len(tp)} scans, path length {rv.distance:.2f} m; final pose error of the odometry: {np.hypot(*(tp[-1][:2] - op[-1][:2])):.3f} m, heading {np.degrees(abs(tp[-1][2] - op[-1][2])):.2f} deg")
rng = np.random.default_rng(5)
err_pose = tp + np.column_stack([rng.normal(0, 0.02, len(tp)), rng.normal(0, 0.02, len(tp)), rng.normal(0, np.radians(0.5), len(tp))])
beams = np.linspace(0, 2 * math.pi, 24, endpoint=False)
scans = []
for p in tp:
    s = []
    for b in beams:
        r, hit = L.ray_cast(world, p[0], p[1], p[2] + b, 3.0, res); s.append((b, r + (rng.normal(0, 0.02) if hit else 0.0), hit))
    scans.append(s)
def build(poses):
    g = L.OccupancyGrid(W, Hh, res)
    for p, s in zip(poses, scans):
        for b, r, hit in s: g.update_ray(p[0], p[1], p[2] + b, max(r, 0.0), hit)
    return g
def score(g):
    cls = g.classify(); occ_true = world; occ_map = cls == 1
    # tolerance of one cell: a true wall cell is recovered if an occupied cell lies within the 3x3 neighbourhood
    from scipy.ndimage import binary_dilation
    d_map = binary_dilation(occ_map, iterations=1); d_true = binary_dilation(occ_true, iterations=1)
    recall = (occ_true & d_map).sum() / occ_true.sum(); spurious = (occ_map & ~d_true).sum()
    acc, known = L.grid_accuracy(g, world)
    return recall, int(spurious), int(occ_map.sum()), acc, known
grids = {"true pose": build(tp), "EKF-quality pose": build(err_pose), "encoder odometry": build(op)}
print("true occupied cells:", int(world.sum()))
for k, g in grids.items():
    rc, sp, nocc, acc, known = score(g); print(f"{k:17s}: true cells recovered within 1 cell {rc:.3f}; spurious occupied cells (more than 1 cell from truth) {sp}; occupied cells {nocc}; accuracy on known cells {acc:.3f}; known fraction {known:.3f}")
fig, axs = plt.subplots(1, 3, figsize=(FIG["panel2"][0] * 1.45, 3.1))
for ax, (k, g) in zip(axs, grids.items()):
    img = np.where(g.classify() == 1, 0.0, np.where(g.classify() == 0, 1.0, 0.6))
    ax.imshow(img, origin="lower", extent=(0, W, 0, Hh), cmap="gray", vmin=0, vmax=1); ax.set_title(k, fontsize=9); ax.set_xticks([0, 2, 4, 6]); ax.set_yticks([0, 2, 4])
    path = {"true pose": tp, "EKF-quality pose": err_pose, "encoder odometry": op}[k]; ax.plot(path[:, 0], path[:, 1], color=PAL["red"], lw=0.8)
axs[0].set_ylabel("y (m)")
for ax in axs: ax.set_xlabel("x (m)")
save(fig, out("fig06_grid.png"))
