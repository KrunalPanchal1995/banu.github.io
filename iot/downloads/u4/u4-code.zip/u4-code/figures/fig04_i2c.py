"""Fig 4: I2C timing. Left: 30-70 percent rise time against pull-up resistance for two bus capacitances. Right: time to read registers at 100 and 400 kHz."""
from _common import *
use_code("embedded/fsm_sim")
import fsm_sim as F

R = np.linspace(500, 15000, 200)
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
for C, col in ((100e-12, PAL["blue"]), (400e-12, PAL["orange"])):
    a.plot(R / 1e3, [F.i2c_rise_time_ns(r, C) for r in R], color=col, label=f"bus capacitance {C*1e12:.0f} pF")
    print("C", C * 1e12, "pF: max pull-up for 1000 ns", round(F.i2c_max_pullup(1000, C)), "ohm; for 300 ns", round(F.i2c_max_pullup(300, C)), "ohm; 4.7k gives", round(F.i2c_rise_time_ns(4.7e3, C), 1), "ns")
a.axhline(1000, color=PAL["grey"], ls=":"); a.text(0.7, 1040, "1000 ns (standard mode, assumed spec)", fontsize=7.5, color=PAL["grey"])
a.axhline(300, color=PAL["grey"], ls="--"); a.text(0.7, 340, "300 ns (fast mode, assumed spec)", fontsize=7.5, color=PAL["grey"])
a.set(xlabel="pull-up resistance (kohm)", ylabel="rise time 30 to 70 percent (ns)", title="Pull-up and bus capacitance set the speed"); a.legend(fontsize=8, loc="upper left")
nb = [1, 2, 6]; w = 0.38; x = np.arange(len(nb))
b.bar(x - w / 2, [F.i2c_transfer_time_us(n, 100e3) for n in nb], w, color=PAL["blue"], label="100 kHz"); b.bar(x + w / 2, [F.i2c_transfer_time_us(n, 400e3) for n in nb], w, color=PAL["green"], label="400 kHz")
b.set(xticks=x, xticklabels=[f"{n} byte{'s' if n > 1 else ''}" for n in nb], ylabel="transfer time (us)", title="Register read time"); b.legend(fontsize=8)
for n in nb: print("read", n, "bytes: clocks", F.i2c_read_clocks(n), "100 kHz us", F.i2c_transfer_time_us(n, 100e3), "400 kHz us", F.i2c_transfer_time_us(n, 400e3))
print("bus busy fraction reading 2 bytes at 10 Hz, 100 kHz (percent):", round(F.i2c_transfer_time_us(2, 100e3) * 1e-6 * 10 * 100, 3), "; pull-up current when low at 4.7k (mA):", round(3.3 / 4.7e3 * 1e3, 3))
save(fig, out("fig04_i2c.png"))
