"""Fig 6: two design trade-offs. Left: control-loop gap in a super-loop with a blocking publish vs preemptive scheduling.
Right: delivery ratio against battery life for three retry policies (ASSUMED currents of Unit 2; wait currents assumed)."""
from _common import *
use_code("embedded/fsm_sim"); use_code("electronics/circuits_np")
import fsm_sim as F, circuits_np as C

fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
others_nb = [(1000.0, 5.0), (60000.0, 2.0)]; others_bl = [(1000.0, 5.0), (60000.0, 300.0)]
g_nb = F.superloop_control_gaps(10.0, 0.2, others_nb, 120000.0); g_bl = F.superloop_control_gaps(10.0, 0.2, others_bl, 120000.0)
print("super-loop, short tasks: gap max", round(float(g_nb.max()), 2), "ms median", round(float(np.median(g_nb)), 2)); print("super-loop, 300 ms blocking publish: gap max", round(float(g_bl.max()), 2), "ms; gaps over 20 ms:", int(np.sum(g_bl > 20)), "of", len(g_bl))
print("blind distance at 0.5 m/s for the worst gap (cm):", round(0.5 * float(g_bl.max()) / 1000 * 100, 1), " for preemptive 10 ms:", 0.5 * 0.010 * 100)
labels = ["preemptive\n(RTOS)", "super-loop,\nshort tasks", "super-loop,\n300 ms publish"]; vals = [10.0, float(g_nb.max()), float(g_bl.max())]
a.bar(range(3), vals, color=[PAL["green"], PAL["orange"], PAL["red"]]); a.axhline(100, color=PAL["grey"], ls=":"); a.text(-0.45, 108, "R3: 100 ms", fontsize=8, color=PAL["grey"], ha="left")
for i, v in enumerate(vals): a.text(i, v + 6, f"{v:.0f} ms", ha="center", fontsize=8)
a.set(xticks=range(3), xticklabels=labels, ylabel="longest gap between control steps (ms)", title="Blocking code starves the control loop")
ps = [0.0, 0.05, 0.1, 0.2, 0.3, 0.5]
pols = [("no retry (1 attempt)", 1, 5.0, 20.0, PAL["red"], "o"), ("3 attempts, back-off idle 20 mA", 3, 5.0, 20.0, PAL["orange"], "s"), ("3 attempts, back-off light sleep 1 mA", 3, 5.0, 1.0, PAL["green"], "^")]
for name, M, bo, iw, col, mk in pols:
    life = [C.battery_life_days(2000, F.expected_node(p, M, bo, iw)["avg_ma"]) for p in ps]; dr = [100 * F.expected_node(p, M, bo, iw)["delivery"] for p in ps]
    b.plot(life, dr, mk + "-", color=col, label=name)
    print(name, [(p, round(l, 1), round(d, 2)) for p, l, d in zip(ps, life, dr)])
b.set(xlabel="battery life (days, 2000 mAh)", ylabel="readings delivered per cycle (percent)", title="Retries trade battery for delivery"); b.legend(fontsize=6.5, loc="center left", bbox_to_anchor=(0.0, 0.3)); b.invert_xaxis()
for p, l, d in zip(ps, [C.battery_life_days(2000, F.expected_node(p, 1, 5.0, 20.0)["avg_ma"]) for p in ps], [100 * F.expected_node(p, 1, 5, 20)["delivery"] for p in ps]): b.annotate(f"p={p:g}", (l, d), textcoords="offset points", xytext=(3, -9), fontsize=6.5, color=PAL["red"])
sim = F.simulate_node(20000, 0.2, 3, 5.0, 20.0, seed=7); ex = F.expected_node(0.2, 3, 5.0, 20.0); print("check p=0.2 M=3 idle: simulated", {k: round(v, 4) for k, v in sim.items()}, "expected", {k: round(v, 4) for k, v in ex.items()})
save(fig, out("fig06_policy.png"))
