"""Fig 2: polling versus interrupts for the rover's encoder. Left: count error against polling rate at 0.5 m/s (3183 transitions/s). Right: CPU load of the interrupt method against speed (ASSUMED 5 us handler)."""
from _common import *
use_code("embedded/fsm_sim")
import fsm_sim as F

RATE = 3183.0
polls = np.array([500, 1000, 2000, 3000, 3500, 4000, 8000, 16000])
err = []
for p in polls:
    c, tr, ill = F.polled_encoder_count(RATE, float(p), t_end=1.0); err.append(100 * (c - tr) / tr)
    print("poll", p, "Hz counted", c, "true", tr, "illegal jumps", ill, "error percent", round(err[-1], 2))
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.semilogx(polls, err, "o-", color=PAL["red"]); a.axvline(RATE, color=PAL["grey"], ls=":"); a.text(RATE * 1.05, -60, "transition\nrate 3183 Hz", fontsize=8, color=PAL["grey"])
a.set(xlabel="polling rate (Hz, log scale)", ylabel="count error (percent of true count)", title="Polling below the edge rate loses counts")
v = np.linspace(0, 3.0, 100); dpc = 2 * np.pi * 0.033 / 1320
for isr, col in ((5.0, PAL["blue"]), (20.0, PAL["orange"])):
    b.plot(v, [100 * F.isr_cpu_load(x / dpc, isr) for x in v], color=col, label=f"handler {isr:g} us")
    print("isr", isr, "us: load at 0.5 m/s", round(100 * F.isr_cpu_load(0.5 / dpc, isr), 2), "percent; load at 3 m/s", round(100 * F.isr_cpu_load(3.0 / dpc, isr), 1), "percent")
b.set(xlabel="rover speed (m/s)", ylabel="CPU time in the handler (percent)", title="Interrupt cost grows with speed"); b.legend(fontsize=8)
save(fig, out("fig02_polling.png"))
