"""Fig 1: contact bounce and debouncing. Left: one simulated press (raw vs debounced, 20 ms rule). Right: events counted per press, and presses lost, against the debounce time."""
from _common import *
use_code("embedded/fsm_sim")
import fsm_sim as F
from node_fsm import Debouncer

rng = np.random.default_rng(4)
t, lv = F.bouncy_press(rng, 10.0, 120.0, dt_ms=0.05)
d = Debouncer(20, 1); deb = np.array([d.update(int(v), tm)[0] for tm, v in zip(t, lv)])
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1.15, 1]))
a.step(t, lv + 1.3, where="post", color=PAL["red"], lw=0.8, label="raw pin"); a.step(t, deb, where="post", color=PAL["blue"], lw=1.6, label="debounced (20 ms)")
a.set(xlim=(5, 50), xlabel="time (ms)", yticks=[0, 1, 1.3, 2.3], yticklabels=["deb: pressed", "deb: released", "raw: pressed", "raw: released"], title="One press: chatter, then one clean edge"); a.legend(fontsize=7.5, loc="center right", bbox_to_anchor=(1.0, 0.55))
edges = int(np.sum(np.abs(np.diff(lv)) > 0)); print("raw edges in this record", edges, "(press edge + release edge each chatter)")
rng = np.random.default_rng(5); presses = []
for _ in range(150):
    dur = rng.uniform(15.0, 200.0); tt, ll = F.bouncy_press(rng, 10.0, 10.0 + dur, dt_ms=0.1); presses.append((dur, tt, ll))
Ws = [0, 1, 2, 5, 10, 20, 30, 60]
ev_per = []; lost = []
for W in Ws:
    ev = 0; miss = 0
    for dur, tt, ll in presses:
        e = F.count_events(tt, ll) if W == 0 else F.count_events(tt, ll, float(W)); ev += e
        if e == 0: miss += 1
    ev_per.append(ev / len(presses)); lost.append(miss / len(presses) * 100)
    print("W", W, "events per press", round(ev_per[-1], 3), "presses lost percent", round(lost[-1], 1))
b.plot(Ws, ev_per, "o-", color=PAL["blue"]); b.axhline(1.0, color=PAL["grey"], ls=":"); b.set(xlabel="debounce time W (ms)", ylabel="events counted per press", title="Counting and losing presses")
b2 = b.twinx(); b2.plot(Ws, lost, "s--", color=PAL["red"]); b2.set_ylabel("presses lost (percent)", color=PAL["red"]); b2.spines["right"].set_visible(True); b2.grid(False)
save(fig, out("fig01_bounce.png"))
