"""Fig 3: UART baud-rate tolerance. Left: byte error rate against clock mismatch. Right: where the receiver samples a 0xA5 frame at three mismatches."""
from _common import *
use_code("embedded/fsm_sim")
import fsm_sim as F

mis = np.linspace(-0.09, 0.09, 91)
rate = np.array([F.uart_error_rate(float(m), n=600, seed=2) for m in mis]) * 100
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1, 1.15]))
a.plot(mis * 100, rate, color=PAL["red"]); a.axvline(-100 / 19, color=PAL["grey"], ls=":"); a.axvline(100 / 17, color=PAL["grey"], ls=":")
a.set(xlabel="receiver clock mismatch (percent)", ylabel="bytes received wrongly (percent)", title="Random bytes, 8N1"); a.text(-8.8, 60, "-5.26", fontsize=8, color=PAL["grey"]); a.text(5.95, 60, "+5.88", fontsize=8, color=PAL["grey"])
# exact first-failure mismatch over all 256 bytes
grid = np.linspace(0, 0.12, 2401)
def first_fail(sign):
    best = 1.0
    for byte in range(256):
        for g in grid:
            if F.uart_receive(byte, sign * g) != byte:
                best = min(best, g); break
    return best
pos, neg = first_fail(+1), first_fail(-1)
print("first byte error at mismatch +", round(pos * 100, 3), "percent; at -", round(neg * 100, 3), "percent; theory +5.882 / -5.263")
for m in (0.0, 0.04, 0.06, -0.04, -0.06): print("mismatch", m, "error rate percent", round(F.uart_error_rate(m, n=2000) * 100, 2))
byte = 0x5A; bits = F.uart_frame_bits(byte)
for k, (m, col) in enumerate(((0.0, PAL["green"]), (0.04, PAL["blue"]), (0.06, PAL["red"]))):
    y0 = 2.2 - k * 1.1
    xs = np.arange(len(bits) + 1); b.step(xs, bits + [1], where="post", color=PAL["black"], lw=0.9, ls="-") if False else None
    b.step(np.arange(len(bits) + 1), [x * 0.6 + y0 for x in bits + [1]], where="post", color=PAL["grey"], lw=1)
    rx = 1 + m; ts = [(0.5 + i) * rx for i in range(10)]
    b.plot(ts, [y0 + 0.3] * 10, "v", color=col, ms=5, label=f"mismatch {m*100:+.0f} percent -> read {F.uart_receive(byte, m)!s}")
    print("0x5A mismatch", m, "-> received", F.uart_receive(byte, m))
b.set(xlabel="time (transmitter bit times)", yticks=[], title="Sample points (triangles) on a 0x5A frame"); b.legend(fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.18), ncol=1)
save(fig, out("fig03_uart.png"))
