"""Fig 5: the sensor-node state machine (diagram of node_fsm.NodeFSM)."""
from _common import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(7.8, 4.0)); ax.set_xlim(0, 12); ax.set_ylim(0, 6); ax.axis("off"); ax.grid(False)
pos = {"SENSE": (1.2, 4.2), "CONNECT": (4.2, 4.2), "PUBLISH": (7.2, 4.2), "SLEEP": (10.4, 4.2), "WAIT": (4.2, 1.4)}
cols = {"SENSE": PAL["blue"], "CONNECT": PAL["orange"], "PUBLISH": PAL["green"], "SLEEP": PAL["purple"], "WAIT": PAL["grey"]}
sub = {"SENSE": "read sensor\n(burst of 20)", "CONNECT": "Wi-Fi connect", "PUBLISH": "send reading", "SLEEP": "deep sleep\n(chip resets on wake)", "WAIT": "back-off\n5 s, 10 s, ..."}
for k, (x, y) in pos.items():
    ax.add_patch(FancyBboxPatch((x - 1.0, y - 0.6), 2.0, 1.2, boxstyle="round,pad=0.04,rounding_size=0.15", fc=cols[k], ec="none", alpha=0.25))
    ax.text(x, y + 0.2, k, ha="center", va="center", fontsize=10.5, fontweight="bold", color=cols[k]); ax.text(x, y - 0.25, sub[k], ha="center", va="center", fontsize=7.5)
def arrow(p, q, label, rad=0.0, lp=None, ox=0, oy=0):
    ar = FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=12, color=PAL["black"], lw=1.1, connectionstyle=f"arc3,rad={rad}"); ax.add_patch(ar)
    mx, my = (p[0] + q[0]) / 2 + ox, (p[1] + q[1]) / 2 + oy; ax.text(mx, my, label, fontsize=7.5, ha="center", va="center", bbox=dict(fc="white", ec="none", pad=0.6, alpha=0.9))
arrow((2.2, 4.2), (3.2, 4.2), "sensor_done", ox=0, oy=0.45)
arrow((5.2, 4.2), (6.2, 4.2), "wifi_ok", oy=0.45)
arrow((8.2, 4.2), (9.4, 4.2), "publish_ok", oy=0.45)
arrow((4.2, 3.6), (4.2, 2.0), "wifi_fail\n(attempt < 3)", ox=-1.05)
arrow((4.9, 2.0), (4.9, 3.6), "waited", ox=0.5)
arrow((7.2, 3.6), (5.2, 1.7), "", rad=-0.1)
ax.text(6.9, 1.55, "publish_fail\n(attempt < 3)", fontsize=7.5, ha="center", va="center", bbox=dict(fc="white", ec="none", pad=0.6, alpha=0.9))
arrow((5.1, 3.65), (10.1, 3.6), "", rad=0.75)
ax.text(9.4, 1.9, "3rd failure of either:\ngive up, sleep until next period", fontsize=7.5, ha="center", va="center", bbox=dict(fc="white", ec="none", pad=0.6, alpha=0.9))
arrow((10.4, 4.8), (1.2, 4.8), "wake: the chip resets and starts again", rad=0.18, oy=0.95)
save(fig, out("fig05_fsm.png"))
