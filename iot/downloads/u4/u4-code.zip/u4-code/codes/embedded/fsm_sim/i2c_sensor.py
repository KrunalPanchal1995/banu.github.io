"""Lab 5: reading an I2C temperature sensor. Plain Python (MicroPython-compatible): the register decode and the read function take any object with the MicroPython
machine.I2C method readfrom_mem(addr, register, nbytes), so they run on the host with a fake bus.

MODEL, NOT A DATASHEET: the register format below is modelled on a TMP102-style sensor (address 0x48, register 0x00 holds a 12-bit two's-complement value
left-justified in 16 bits, 0.0625 degC per count). It is from memory and was not checked against a datasheet; check the part you use. Not run on hardware.
"""

I2C_ADDR = 0x48
REG_TEMP = 0x00
LSB_C = 0.0625


def decode_temp(two_bytes):
    """16-bit big-endian register, 12-bit two's-complement value in the top 12 bits -> degrees C."""
    raw = (two_bytes[0] << 8) | two_bytes[1]
    counts = raw >> 4
    if counts & 0x800:
        counts -= 0x1000
    return counts * LSB_C


def encode_temp(temp_c):
    """Inverse of decode_temp (used by the fake bus in tests)."""
    counts = int(round(temp_c / LSB_C))
    counts = max(-2048, min(2047, counts))
    raw = (counts & 0xFFF) << 4
    return bytes([raw >> 8, raw & 0xFF])


def read_temp(i2c, addr=I2C_ADDR):
    """Read the temperature register over I2C (register read: address+W, register, restart, address+R, two data bytes)."""
    return decode_temp(i2c.readfrom_mem(addr, REG_TEMP, 2))
