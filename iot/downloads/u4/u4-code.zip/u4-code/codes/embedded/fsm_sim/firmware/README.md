# Firmware for Unit 4 (ESP32)

**Honesty label: logic tested on the host; hardware I/O not executed.**
- `micropython/main.py` + `../node_fsm.py`: the sensor node. `node_fsm.py` (debouncer, state machine, `run_cycle`) is plain Python and is unit-tested under CPython with a fake hardware object (`tests/test_fsm_sim.py`). `main.py` is the thin glue to `machine`, `network` and `umqtt.simple`; it has **not** been run on a board.
- `arduino/button_fsm.ino`: the same debounce rule and a three-mode LED state machine in Arduino C++; **not** compiled here.
- `wokwi/diagram.json`: a starting wiring for the Wokwi online simulator (ESP32, button, LED, 330 ohm resistor). It was **not opened in Wokwi** here; pin names may need adjusting in the editor.

- `micropython/i2c_read.py` + `../i2c_sensor.py` (Lab 5): reads a TMP102-style I2C temperature sensor. The register format is modelled from memory, not from a datasheet; `i2c_sensor.py` is tested on the host with a fake bus (`tests/test_i2c_sensor.py`); `i2c_read.py` was **not run** on a board or in Wokwi, and no Wokwi project for it is provided (add an I2C temperature part in the Wokwi editor).

## Running the MicroPython node in Wokwi or on a board
1. Create an ESP32 MicroPython project (Wokwi: "New project", ESP32, MicroPython), or flash MicroPython to a real ESP32.
2. Copy `node_fsm.py` and `micropython/main.py` into it; put your Wi-Fi name and password in `main.py` (Wokwi's guest Wi-Fi is `Wokwi-GUEST` with an empty password).
3. Run. The serial console is quiet by design; add `print(log)` after `run_cycle` to see the actions.

## Optional: on a real ESP32 kit
Connect the capacitive soil sensor (or a 10 k potentiometer as a stand-in) to pin 34 through the Unit 2 divider, measure the current of the board in deep sleep with a multimeter in series, and compare with the assumed 0.01 mA (a bare board with a USB-serial chip will read far higher: the assumed figure is for the module alone).
