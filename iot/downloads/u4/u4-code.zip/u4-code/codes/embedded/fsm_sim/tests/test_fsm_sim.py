import math
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import fsm_sim as F  # noqa: E402
from node_fsm import Debouncer, NodeFSM, run_cycle  # noqa: E402


def test_debouncer_accepts_only_stable_levels():
    d = Debouncer(20, 1)
    seq = [(1, 0), (0, 1), (1, 3), (0, 5), (0, 30)]           # chatter, then stable low for 25 ms
    out = [d.update(v, t) for v, t in seq]
    assert out[:-1] == [(1, False)] * 4 and out[-1] == (0, True)
    assert d.update(0, 40) == (0, False)                      # no repeated event while held


def test_debounce_removes_false_presses():
    rng = np.random.default_rng(1)
    raw = deb = 0
    for _ in range(40):
        t, lv = F.bouncy_press(rng, 10.0, 120.0)
        raw += F.count_events(t, lv); deb += F.count_events(t, lv, 20.0)
    assert raw > 40 and deb == 40                               # many raw edges, exactly one press each when debounced


def test_fsm_happy_path_and_retry_and_giveup():
    f = NodeFSM(60, 3, 5)
    assert f.start() == ("read_sensor",)
    assert f.handle("sensor_done") == ("wifi_connect",)
    assert f.handle("wifi_fail") == ("wait", 5)
    assert f.handle("waited") == ("wifi_connect",)
    assert f.handle("wifi_fail") == ("wait", 10)
    assert f.handle("waited") == ("wifi_connect",)
    assert f.handle("wifi_fail") == ("deep_sleep", 60) and not f.delivered
    g = NodeFSM(60, 3, 5); g.start(); g.handle("sensor_done"); g.handle("wifi_ok")
    assert g.handle("publish_ok") == ("deep_sleep", 60) and g.delivered
    with pytest.raises(ValueError):
        NodeFSM().handle("publish_ok")


def test_run_cycle_with_fake_hardware():
    class Fake:
        def __init__(self, script): self.script, self.slept, self.deep = list(script), [], None
        def read_sensor(self): return "sensor_done"
        def wifi_connect(self): return self.script.pop(0)
        def publish(self): return "publish_ok"
        def sleep_s(self, s): self.slept.append(s)
        def deep_sleep(self, s): self.deep = s
    hw = Fake(["wifi_fail", "wifi_ok"]); log = run_cycle(hw, NodeFSM(60, 3, 5))
    assert [a[0] for a in log] == ["read_sensor", "wifi_connect", "wait", "wifi_connect", "publish", "deep_sleep"]
    assert hw.slept == [5] and hw.deep == 60


def test_polling_must_exceed_transition_rate():
    rate = 3183.0
    assert F.polled_encoder_count(rate, 8000)[0] == F.polled_encoder_count(rate, 8000)[1]
    c, tr, ill = F.polled_encoder_count(rate, 2000)
    assert c != tr or ill > 0
    assert abs(F.isr_cpu_load(3183, 5.0) - 0.0159) < 1e-4


def test_uart_roundtrip_and_tolerance():
    for b in (0x00, 0x55, 0xA5, 0xFF, 0x80):
        assert F.uart_receive(b, 0.0) == b
    assert F.uart_error_rate(0.04) == 0.0 and F.uart_error_rate(-0.04) == 0.0
    assert F.uart_error_rate(0.07) > 0.2 and F.uart_error_rate(-0.07) > 0.2


def test_i2c_numbers():
    assert F.i2c_read_clocks(2) == 48
    assert abs(F.i2c_transfer_time_us(2, 100e3) - 480.0) < 1e-9 and abs(F.i2c_transfer_time_us(2, 400e3) - 120.0) < 1e-9
    assert abs(F.i2c_rise_time_ns(4.7e3, 100e-12) - 398.2) < 0.5
    assert abs(F.i2c_rise_time_ns(F.i2c_max_pullup(300, 100e-12), 100e-12) - 300) < 1e-9


def test_superloop_gap_grows_with_blocking_task():
    nb = F.superloop_control_gaps(10.0, 0.2, [(1000.0, 5.0)], 20000.0)
    bl = F.superloop_control_gaps(10.0, 0.2, [(1000.0, 5.0), (10000.0, 300.0)], 20000.0)
    assert nb.max() < 20.0 and bl.max() > 300.0


def test_node_expected_matches_simulation_and_no_failure_case():
    e0 = F.expected_node(0.0, 3, 5, 20.0); assert abs(e0["avg_ma"] - 1.8765) < 1e-3 and e0["delivery"] == 1.0
    for cfg in ((0.2, 1, 5, 20.0), (0.2, 3, 5, 20.0), (0.3, 3, 5, 1.0)):
        s = F.simulate_node(20000, *cfg, seed=3); e = F.expected_node(*cfg)
        assert abs(s["avg_ma"] - e["avg_ma"]) < 0.03 * e["avg_ma"] and abs(s["delivery"] - e["delivery"]) < 0.01
