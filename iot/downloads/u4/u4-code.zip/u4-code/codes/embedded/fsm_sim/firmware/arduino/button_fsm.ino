// Button + LED state machine for an ESP32 (Arduino framework): press cycles OFF -> ON -> BLINK -> OFF.
// Debounce: a new button level is accepted only after it has been stable for STABLE_MS (same rule as node_fsm.Debouncer).
// STATUS: NOT RUN ON HARDWARE in this course material; the debounce rule is tested on the host in Python.
const int BTN = 4;               // button between pin 4 and GND, internal pull-up
const int LED = 2;               // LED (with a series resistor) from pin 2 to GND
const unsigned long STABLE_MS = 20;
const unsigned long BLINK_MS = 250;

int accepted = HIGH, cand = HIGH;
unsigned long tChange = 0, tBlink = 0;
enum Mode { OFF, ON, BLINK };
Mode mode = OFF;
bool ledState = false;

void setup() {
  pinMode(BTN, INPUT_PULLUP);    // Unit 2: pull-up resistor, no floating input
  pinMode(LED, OUTPUT);
}

void loop() {
  unsigned long now = millis();
  int raw = digitalRead(BTN);
  if (raw != cand) { cand = raw; tChange = now; }
  else if (raw != accepted && now - tChange >= STABLE_MS) {
    accepted = raw;
    if (accepted == LOW) mode = (Mode)((mode + 1) % 3);      // one event per press
  }
  if (mode == OFF) ledState = false;
  else if (mode == ON) ledState = true;
  else if (now - tBlink >= BLINK_MS) { tBlink = now; ledState = !ledState; }
  digitalWrite(LED, ledState);
}
