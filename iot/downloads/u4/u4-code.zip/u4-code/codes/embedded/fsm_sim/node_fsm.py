"""Pure-logic embedded code: a button debouncer and the sensor-node state machine.

Written to run unchanged on MicroPython (ESP32) and CPython: no imports, no typing, no dataclasses, only ints, tuples and lists.
Time and hardware are injected, so the same logic is unit-tested on the host. See README.md.
"""


class Debouncer:
    """Accept a new button level only after it has been stable for `stable_ms` milliseconds."""

    def __init__(self, stable_ms=20, initial=1):
        self.stable_ms = stable_ms
        self.state = initial        # the accepted (debounced) level
        self.cand = initial         # the level currently being timed
        self.t_change = 0           # when the raw level last changed

    def update(self, raw, now_ms):
        """Feed one raw sample. Returns (accepted_level, changed_now)."""
        if raw != self.cand:
            self.cand = raw
            self.t_change = now_ms
        elif raw != self.state and now_ms - self.t_change >= self.stable_ms:
            self.state = raw
            return self.state, True
        return self.state, False


class NodeFSM:
    """Sensor-node cycle: SENSE -> CONNECT -> PUBLISH -> SLEEP, with bounded retries and exponential back-off.

    start() and handle(event) return the next action as a tuple:
      ("read_sensor",), ("wifi_connect",), ("publish",), ("wait", seconds), ("deep_sleep", seconds)
    Events: "sensor_done", "sensor_fail", "wifi_ok", "wifi_fail", "publish_ok", "publish_fail", "waited".
    """

    def __init__(self, period_s=60, max_attempts=3, backoff_s=5):
        self.period_s = period_s
        self.max_attempts = max_attempts
        self.backoff_s = backoff_s
        self.state = "BOOT"
        self.attempts = 0
        self.delivered = False
        self.sensor_ok = True

    def start(self):
        self.state = "SENSE"
        self.attempts = 0
        self.delivered = False
        self.sensor_ok = True
        return ("read_sensor",)

    def _fail(self):
        self.attempts += 1
        if self.attempts >= self.max_attempts:
            self.state = "SLEEP"
            return ("deep_sleep", self.period_s)
        self.state = "WAIT"
        return ("wait", self.backoff_s * (2 ** (self.attempts - 1)))

    def handle(self, event):
        s = self.state
        if s == "SENSE" and event in ("sensor_done", "sensor_fail"):
            self.sensor_ok = event == "sensor_done"
            self.state = "CONNECT"
            return ("wifi_connect",)
        if s == "CONNECT" and event == "wifi_ok":
            self.state = "PUBLISH"
            return ("publish",)
        if s == "CONNECT" and event == "wifi_fail":
            return self._fail()
        if s == "PUBLISH" and event == "publish_ok":
            self.delivered = True
            self.state = "SLEEP"
            return ("deep_sleep", self.period_s)
        if s == "PUBLISH" and event == "publish_fail":
            return self._fail()
        if s == "WAIT" and event == "waited":
            self.state = "CONNECT"
            return ("wifi_connect",)
        raise ValueError("event %s not allowed in state %s" % (event, s))


def run_cycle(hw, fsm):
    """Drive one wake-up cycle. `hw` provides read_sensor(), wifi_connect(), publish(), sleep_s(sec), deep_sleep(sec),
    each returning the event name (or nothing). Returns the list of actions taken (for tests and logs)."""
    log = []
    action = fsm.start()
    while True:
        log.append(action)
        name = action[0]
        if name == "read_sensor":
            ev = hw.read_sensor()
        elif name == "wifi_connect":
            ev = hw.wifi_connect()
        elif name == "publish":
            ev = hw.publish()
        elif name == "wait":
            hw.sleep_s(action[1])
            ev = "waited"
        else:                                   # deep_sleep: the MCU resets on wake, so the cycle ends here
            hw.deep_sleep(action[1])
            return log
        action = fsm.handle(ev)
