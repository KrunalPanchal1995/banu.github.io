import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import i2c_sensor as S  # noqa: E402
import fsm_sim as F  # noqa: E402


class FakeI2C:
    def __init__(self, temp_c):
        self.temp_c, self.calls = temp_c, []

    def readfrom_mem(self, addr, reg, n):
        self.calls.append((addr, reg, n))
        assert addr == 0x48 and reg == 0x00 and n == 2
        return S.encode_temp(self.temp_c)


def test_decode_known_values():
    assert S.decode_temp(bytes([0x19, 0x00])) == 25.0           # 0x190 = 400 counts x 0.0625
    assert S.decode_temp(bytes([0x00, 0x00])) == 0.0
    assert S.decode_temp(bytes([0xE7, 0x00])) == -25.0           # two's complement: 0xE70 -> -400 counts
    assert S.decode_temp(bytes([0x7F, 0xF0])) == 127.9375


def test_round_trip_and_read():
    for t in (-40.0, -0.0625, 0.0, 21.5, 36.6, 100.0):
        assert abs(S.decode_temp(S.encode_temp(t)) - t) <= S.LSB_C / 2 + 1e-12
    bus = FakeI2C(23.4375)
    assert S.read_temp(bus) == 23.4375 and bus.calls == [(0x48, 0, 2)]


def test_i2c_read_time_matches_clock_count():
    assert F.i2c_read_clocks(2) == 48 and abs(F.i2c_transfer_time_us(2, 100e3) - 480.0) < 1e-9
