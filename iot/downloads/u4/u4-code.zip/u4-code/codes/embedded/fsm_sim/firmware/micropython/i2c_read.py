# i2c_read.py: Lab 5 on an ESP32 running MicroPython. Thin glue around i2c_sensor.py (copy i2c_sensor.py to the board too).
# STATUS: NOT RUN ON HARDWARE or in Wokwi. The logic is tested on the host with a fake bus (tests/test_i2c_sensor.py).
# machine.I2C(...) and readfrom_mem are standard MicroPython calls, written from memory; ESP32 default pins SCL 22, SDA 21.
import time
import machine
from i2c_sensor import read_temp

i2c = machine.I2C(0, scl=machine.Pin(22), sda=machine.Pin(21), freq=100000)
print("devices found:", [hex(a) for a in i2c.scan()])
while True:
    print("temperature: %.2f C" % read_temp(i2c))
    time.sleep(1)
