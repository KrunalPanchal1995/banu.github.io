# main.py: sensor node for an ESP32 running MicroPython. Thin hardware glue around node_fsm.py (copy node_fsm.py to the board too).
# STATUS: NOT RUN ON HARDWARE in this course material. The logic in node_fsm.py is tested on the host (tests/test_fsm_sim.py);
# the calls below (machine.ADC, network.WLAN, umqtt.simple, machine.deepsleep) are standard MicroPython APIs but untested here.
import time
import machine
import network
from node_fsm import NodeFSM, run_cycle

SSID, PASSWORD = "your-ssid", "your-password"
BROKER, TOPIC = "192.168.1.10", b"greenhouse/zone1/soil"
PERIOD_S = 60


class Hardware:
    def __init__(self):
        self.adc = machine.ADC(machine.Pin(34))            # soil-sensor divider output (Unit 2, Unit 3)
        self.adc.atten(machine.ADC.ATTN_11DB)              # full 0 to ~3.3 V range
        self.wlan = network.WLAN(network.STA_IF)
        self.raw = 0

    def read_sensor(self):
        try:
            total = 0
            for _ in range(20):                            # burst of 20 readings, 1 ms apart: one whole 50 Hz period (Unit 3)
                total += self.adc.read()
                time.sleep_ms(1)
            self.raw = total // 20
            return "sensor_done"
        except Exception:
            return "sensor_fail"

    def wifi_connect(self, timeout_ms=3000):
        self.wlan.active(True)
        if not self.wlan.isconnected():
            self.wlan.connect(SSID, PASSWORD)
        t0 = time.ticks_ms()
        while not self.wlan.isconnected():
            if time.ticks_diff(time.ticks_ms(), t0) > timeout_ms:
                return "wifi_fail"
            time.sleep_ms(20)
        return "wifi_ok"

    def publish(self):
        try:
            from umqtt.simple import MQTTClient            # MQTT itself is Unit 5
            c = MQTTClient("node1", BROKER)
            c.connect()
            c.publish(TOPIC, str(self.raw))
            c.disconnect()
            return "publish_ok"
        except OSError:
            return "publish_fail"

    def sleep_s(self, s):
        time.sleep(s)

    def deep_sleep(self, s):
        self.wlan.active(False)
        machine.deepsleep(int(s * 1000))                   # the chip resets on wake and main.py runs again


run_cycle(Hardware(), NodeFSM(PERIOD_S, 3, 5))
