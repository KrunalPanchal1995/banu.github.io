"""Host-side simulators for Unit 4 (numpy): contact bounce and debouncing, polling vs interrupt counting, UART timing,
I2C timing, super-loop scheduling, and node energy with retries. Uses node_fsm.NodeFSM for the node logic. See README.md."""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from node_fsm import Debouncer, NodeFSM  # noqa: E402


# ------------------------------------------------------------------ contact bounce and debouncing
def bouncy_press(rng, t_press, t_release, n_bounce=(2, 8), bounce_ms=(0.05, 2.0), settle_ms=6.0, dt_ms=0.05, t_end=None):
    """Raw button level (1 = released, 0 = pressed) sampled every dt_ms. The contact chatters for up to `settle_ms` after
    each press and release edge: a random number of short toggles, then it settles."""
    t_end = t_end or (t_release + 20.0)
    n = int(round(t_end / dt_ms))
    t = np.arange(n) * dt_ms
    level = np.ones(n, dtype=int)
    level[(t >= t_press) & (t < t_release)] = 0
    for edge, final in ((t_press, 0), (t_release, 1)):
        k = int(rng.integers(n_bounce[0], n_bounce[1] + 1))
        ts = edge + np.sort(rng.uniform(0.0, settle_ms, k))
        lv = 1 - final
        for x in ts:
            level[(t >= x) & (t < x + rng.uniform(*bounce_ms))] = lv
    return t, level


def count_events(t_ms, level, stable_ms=None):
    """Count falling edges (presses). With stable_ms=None the raw edges are counted; otherwise the Debouncer is used."""
    if stable_ms is None:
        return int(np.sum((level[1:] == 0) & (level[:-1] == 1)))
    d = Debouncer(stable_ms, 1)
    presses = 0
    for tm, v in zip(t_ms, level):
        s, ch = d.update(int(v), tm)
        if ch and s == 0:
            presses += 1
    return presses


# ------------------------------------------------------------------ polling vs interrupts for a quadrature encoder
_QTAB = {(0, 0): {(0, 1): 1, (1, 0): -1}, (0, 1): {(1, 1): 1, (0, 0): -1}, (1, 1): {(1, 0): 1, (0, 1): -1}, (1, 0): {(0, 0): 1, (1, 1): -1}}
_SEQ = [(0, 0), (0, 1), (1, 1), (1, 0)]


def polled_encoder_count(rate_counts_per_s, poll_hz, t_end=1.0, phase=0.37):
    """Constant-speed encoder (rate_counts_per_s transitions per second) read by polling at poll_hz.
    Returns (counted, true, illegal_jumps)."""
    tp = np.arange(0.0, t_end, 1.0 / poll_hz)
    pos = np.floor(rate_counts_per_s * tp + phase).astype(int)
    true = int(pos[-1] - pos[0])
    prev = _SEQ[pos[0] % 4]
    count = illegal = 0
    for p in pos[1:]:
        cur = _SEQ[p % 4]
        if cur != prev:
            step = _QTAB[prev].get(cur)
            if step is None:
                illegal += 1
            else:
                count += step
            prev = cur
    return count, true, illegal


def isr_cpu_load(rate_counts_per_s, isr_us):
    """Fraction of CPU time spent in the interrupt handler: transitions per second times handler time."""
    return rate_counts_per_s * isr_us * 1e-6


# ------------------------------------------------------------------ UART timing
def uart_frame_bits(byte):
    """8N1 frame, LSB first: start (0), 8 data bits, stop (1)."""
    return [0] + [(byte >> i) & 1 for i in range(8)] + [1]


def uart_receive(byte, mismatch):
    """Receive one frame when the receiver's bit time is (1 + mismatch) times the transmitter's. The receiver finds the
    falling edge of the start bit exactly, then samples the middle of each of its own bit times. Returns the byte, or None
    on a framing error (stop bit read as 0 or start bit not 0)."""
    bits = uart_frame_bits(byte)

    def level(t):                       # transmitter's line level at time t (in tx bit times); idle high outside the frame
        k = int(math.floor(t))
        return bits[k] if 0 <= k < len(bits) else 1

    rx = 1.0 + mismatch
    if level(0.5 * rx) != 0:
        return None
    val = 0
    for i in range(8):
        val |= level((1.5 + i) * rx) << i
    if level(9.5 * rx) != 1:
        return None
    return val


def uart_error_rate(mismatch, n=2000, seed=0):
    rng = np.random.default_rng(seed)
    bad = 0
    for b in rng.integers(0, 256, n):
        if uart_receive(int(b), mismatch) != int(b):
            bad += 1
    return bad / n


# ------------------------------------------------------------------ I2C timing
def i2c_read_clocks(n_bytes):
    """SCL clocks to read n_bytes from a register: start, addr+W (9), reg (9), repeated start, addr+R (9), n_bytes x 9, stop;
    start/repeated start/stop counted as one clock each."""
    return 3 + 27 + 9 * n_bytes


def i2c_transfer_time_us(n_bytes, f_scl_hz):
    return i2c_read_clocks(n_bytes) / f_scl_hz * 1e6


def i2c_rise_time_ns(r_pullup, c_bus):
    """30% to 70% rise time of an RC-charged line: tau * ln(0.7/0.3) = 0.8473 R C (the I2C-specification definition)."""
    return 0.8473 * r_pullup * c_bus * 1e9


def i2c_max_pullup(t_rise_ns, c_bus):
    return t_rise_ns * 1e-9 / (0.8473 * c_bus)


# ------------------------------------------------------------------ scheduling: super-loop vs preemptive
def superloop_control_gaps(control_period_ms, control_cost_ms, others, t_end_ms=120000.0):
    """Super-loop: tasks run to completion in a fixed order whenever due. `others` = list of (period_ms, cost_ms) tasks
    (including a blocking network task). Returns the gaps (ms) between successive starts of the control task."""
    tasks = [(control_period_ms, control_cost_ms)] + list(others)
    due = [0.0] * len(tasks)
    t, starts = 0.0, []
    while t < t_end_ms:
        ran = False
        for i, (p, c) in enumerate(tasks):
            if t >= due[i]:
                if i == 0:
                    starts.append(t)
                t += c
                due[i] += p
                ran = True
        if not ran:
            t = min(due)
    return np.diff(starts)


# ------------------------------------------------------------------ node energy with retries
STATES_MA_S = dict(wake=(50.0, 0.2), connect_ok=(100.0, 0.5), connect_fail=(100.0, 3.0), publish=(140.0, 0.3), shutdown=(50.0, 0.2))
I_SLEEP_MA = 0.01


def simulate_node(n_cycles, p_fail, max_attempts, backoff_s, i_wait_ma, period_s=60.0, seed=0):
    """Drive NodeFSM with random Wi-Fi failures (each connect attempt fails with probability p_fail). Returns
    dict(avg_ma, delivery, awake_s). Currents/times are the ASSUMED values of STATES_MA_S."""
    rng = np.random.default_rng(seed)
    q_total = delivered = awake_total = 0.0
    for _ in range(n_cycles):
        fsm = NodeFSM(period_s, max_attempts, backoff_s)
        q = awake = 0.0
        a = fsm.start()
        while True:
            name = a[0]
            if name == "read_sensor":
                i, t = STATES_MA_S["wake"]; q += i * t; awake += t; ev = "sensor_done"
            elif name == "wifi_connect":
                if rng.random() < p_fail:
                    i, t = STATES_MA_S["connect_fail"]; ev = "wifi_fail"
                else:
                    i, t = STATES_MA_S["connect_ok"]; ev = "wifi_ok"
                q += i * t; awake += t
            elif name == "publish":
                i, t = STATES_MA_S["publish"]; q += i * t; awake += t; ev = "publish_ok"
            elif name == "wait":
                q += i_wait_ma * a[1]; awake += a[1]; ev = "waited"
            else:
                i, t = STATES_MA_S["shutdown"]; q += i * t; awake += t
                q += I_SLEEP_MA * max(period_s - awake, 0.0)
                break
            a = fsm.handle(ev)
        q_total += q
        delivered += fsm.delivered
        awake_total += awake
    return dict(avg_ma=q_total / (n_cycles * period_s), delivery=delivered / n_cycles, awake_s=awake_total / n_cycles)


def expected_node(p_fail, max_attempts, backoff_s, i_wait_ma, period_s=60.0):
    """Closed-form expectation of simulate_node. An attempt reaches the connect step with probability p^(k-1); it costs
    connect_ok + publish with probability (1-p) or connect_fail with probability p, then a back-off wait if it failed and
    another attempt remains. Returns dict(avg_ma, delivery, awake_s)."""
    p = p_fail
    fixed_q = sum(STATES_MA_S[k][0] * STATES_MA_S[k][1] for k in ("wake", "shutdown"))
    fixed_t = sum(STATES_MA_S[k][1] for k in ("wake", "shutdown"))
    ok_q = STATES_MA_S["connect_ok"][0] * STATES_MA_S["connect_ok"][1] + STATES_MA_S["publish"][0] * STATES_MA_S["publish"][1]
    ok_t = STATES_MA_S["connect_ok"][1] + STATES_MA_S["publish"][1]
    fail_q = STATES_MA_S["connect_fail"][0] * STATES_MA_S["connect_fail"][1]
    fail_t = STATES_MA_S["connect_fail"][1]
    q, t = fixed_q, fixed_t
    for k in range(1, max_attempts + 1):
        reach = p ** (k - 1)
        q += reach * ((1 - p) * ok_q + p * fail_q)
        t += reach * ((1 - p) * ok_t + p * fail_t)
        if k < max_attempts:
            b = backoff_s * 2 ** (k - 1)
            q += reach * p * i_wait_ma * b
            t += reach * p * b
    q += I_SLEEP_MA * max(period_s - t, 0.0)
    return dict(avg_ma=q / period_s, delivery=1.0 - p ** max_attempts, awake_s=t)


def main():
    print(expected_node(0.2, 3, 5, 20.0))


if __name__ == "__main__":
    main()
