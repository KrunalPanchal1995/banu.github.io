# fsm_sim

> Embedded logic on the host: a debouncer and the sensor-node state machine (MicroPython-compatible), plus simulators for contact bounce, polling vs interrupts, UART timing, I2C timing, super-loop scheduling and node energy with retries.

**Topic:** embedded  |  **Created in session:** 004 (Unit 4)  |  **Status:** tested (9 tests); firmware hardware glue NOT run on hardware

## What this code is for
`node_fsm.py` holds the logic that runs on the ESP32 (button debouncer, node state machine, `run_cycle`) in plain Python with no imports, so it is the same file on MicroPython and under pytest. `fsm_sim.py` holds host-only numpy simulators used to size and check the design (bounce, polling, UART, I2C, scheduling, retry energy). A future AI can use it to test firmware logic and timing arguments without hardware.

## Capabilities
- `node_fsm.Debouncer(stable_ms, initial).update(raw, now_ms) -> (level, changed)`.
- `node_fsm.NodeFSM(period_s, max_attempts, backoff_s)`: `.start()`, `.handle(event) -> action`; actions `("read_sensor",)`, `("wifi_connect",)`, `("publish",)`, `("wait", s)`, `("deep_sleep", s)`; illegal events raise `ValueError`.
- `node_fsm.run_cycle(hw, fsm)`: drives one wake cycle against a hardware object (`read_sensor`, `wifi_connect`, `publish`, `sleep_s`, `deep_sleep`); returns the action log.
- `fsm_sim.bouncy_press`, `count_events`; `polled_encoder_count`, `isr_cpu_load`; `uart_frame_bits`, `uart_receive`, `uart_error_rate`; `i2c_read_clocks`, `i2c_transfer_time_us`, `i2c_rise_time_ns`, `i2c_max_pullup`; `superloop_control_gaps`; `simulate_node`, `expected_node` (state currents in `STATES_MA_S`, ASSUMED).
- `firmware/`: MicroPython `main.py`, Arduino `button_fsm.ino`, Wokwi `diagram.json` (see `firmware/README.md`).

## Theory in one paragraph
Debounce: accept a level after W ms stable. Polling must exceed the transition rate or counts are lost or reversed (aliasing). UART tolerance: stop-bit sample at 9.5(1+d) must fall in [9,10) so |d| < 5.26 percent (fast side 5.88). I2C rise 30-70 percent = 0.8473 R C. Expected node charge: fixed + sum_k p^(k-1) [(1-p) S + p C_fail] + back-off waits. Derived in Unit 4, Section 3.

## Quick start
```bash
python -m pytest -q tests
python fsm_sim.py
```
```python
from node_fsm import NodeFSM
f = NodeFSM(60, 3, 5); print(f.start(), f.handle("sensor_done"), f.handle("wifi_fail"))
```

## Examples
| File | Shows | Output |
|------|-------|--------|
| `example_basic.py` | scaffold placeholder; real examples are `sessions/004-unit4-microcontrollers/figures/fig01..fig06` | `example_basic.png` |

## Inputs / outputs and units
Times in ms (debouncer) or s (node); currents in mA; frequencies in Hz; I2C rise times in ns. The node currents and timings in `STATES_MA_S` are assumed.

## Validation
Tests: debouncer behaviour; one press per bounce record; FSM paths incl. illegal event; `run_cycle` with a fake board; polling threshold and ISR load (1.59 percent at 3183/s, 5 us); UART round trip and +-4 percent clean; I2C clock count 48 and 480/120 us; super-loop gap > 300 ms with a blocking task; `expected_node` vs 20,000-cycle simulation within 3 percent.

## Known limits and gotchas
- `main.py`, the Arduino sketch and `diagram.json` were never run on hardware or in Wokwi.
- Bounce model is synthetic (uniform toggles within 6 ms); real switches vary.
- `simulate_node` assumes only connect fails; publish always succeeds after connect.
- The super-loop simulation ignores interrupts and RTOS tick overhead.
- `node_fsm.py` must stay MicroPython-safe: no imports, typing, dataclasses.

## Dependencies
numpy (host simulators only); `node_fsm.py` has none.

## Extending toward the open-source package
`iotrobotics/embedded.py`. To do: watchdog in the FSM, publish failures in the simulator, measured timings.
