"""Unit 1 theory check: closed-form duty/period/overshoot bound for the bang-bang room loop vs the simulator (numbers quoted in Sections 3.3 and 5)."""
from _common import *
use_code("foundations/sense_think_act")
import sense_think_act as S

SP, H, TOUT, TAU, K = 21.0, 0.5, 5.0, 60.0, 0.5
duty_theory = (SP - TOUT) / (K * TAU)
s_on = -(SP - TOUT) / TAU + K          # degC/min heating at the setpoint
s_off = (SP - TOUT) / TAU              # degC/min cooling at the setpoint (magnitude)
t_on, t_off = 2 * H / s_on, 2 * H / s_off
print("duty theory", round(duty_theory, 4), "slope on", round(s_on, 4), "slope off", round(s_off, 4))
print("period theory (min)", round(t_on + t_off, 3), "on", round(t_on, 3), "off", round(t_off, 3))
# ideal continuous loop: fine sampling, no noise, no delay
r = S.simulate(S.BangBang(SP, H), S.Room(15, TOUT, TAU, K), t_end=600, dt=0.01, sample_period=0.01)
m = S.metrics(r, SP, settle_after=60)
n_sw = m["switches"]; span = 600 - 60
print("ideal sim duty", round(m["duty"], 4), "switches", n_sw, "period (min)", round(2 * span / n_sw, 3), "max err", round(m["max_abs_err"], 3))
# sampled (1 min) loop, as in Figure 1A
r1 = S.simulate(S.BangBang(SP, H), S.Room(15, TOUT, TAU, K), t_end=600, dt=0.1, sample_period=1.0)
m1 = S.metrics(r1, SP, 60); print("sampled 1 min: duty", round(m1["duty"], 4), "period", round(2 * span / m1["switches"], 3), "max err", round(m1["max_abs_err"], 3))
# worst-error bound: h + s_max * (sample_period + delay)
for d in (0, 1, 2, 5, 10, 20, 30):
    meas = S.metrics(S.simulate(S.BangBang(SP, H), S.Room(15, TOUT, TAU, K), t_end=480, delay=d), SP)["max_abs_err"]
    bound = H + max(s_on, s_off) * (1.0 + d)
    print("delay", d, "measured", round(meas, 3), "bound", round(bound, 3), "holds", meas <= bound + 1e-9)
# noise-only effect: sigma sweep at no delay, switches and worst error
for sg in (0.0, 0.1, 0.3, 0.6):
    mm = S.metrics(S.simulate(S.BangBang(SP, H), S.Room(15, TOUT, TAU, K), t_end=480, sigma=sg, seed=1), SP)
    print("sigma", sg, "switches", mm["switches"], "worst", round(mm["max_abs_err"], 3), "duty", round(mm["duty"], 3))
# Cloud heater-on equilibrium
print("T_inf on", TOUT + K * TAU, "T_inf off", TOUT)
# exact band-crossing times from the closed-form solution (Section 3.3.3)
import math
ton = TAU * math.log((35 - (SP - H)) / (35 - (SP + H))); toff = TAU * math.log(((SP + H) - TOUT) / ((SP - H) - TOUT))
print("exact t_on", round(ton, 3), "t_off", round(toff, 3), "period", round(ton + toff, 3), "duty", round(ton / (ton + toff), 4))
