"""Fig 5: why control loops that move things run at the edge. Distance a rover travels while waiting for a decision.
Stage latencies are ASSUMED round numbers for illustration (not measurements)."""
from _common import *
from viz_style import CYCLE

stages_edge = {"sensor read": 5, "rover": 5, "motor command": 5}
stages_cloud = {"sensor read": 5, "uplink": 60, "cloud": 20, "downlink": 60, "motor command": 5}
tot_e, tot_c = sum(stages_edge.values()), sum(stages_cloud.values())
speeds = [0.2, 0.5, 1.0, 2.0]
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw=dict(width_ratios=[1, 1.15]))
for k, (name, st) in enumerate([("edge loop", stages_edge), ("cloud loop", stages_cloud)]):
    left = 0
    for j, (s, v) in enumerate(st.items()):
        a.barh(k, v, left=left, color=CYCLE[j % len(CYCLE)], edgecolor="white")
        if v >= 20: a.text(left + v / 2, k, s, ha="center", va="center", fontsize=7, color="white")
        left += v
    a.text(left + 3, k, f"{left} ms", va="center", fontsize=9)
a.set(yticks=[0, 1], yticklabels=["edge", "cloud"], xlabel="latency (ms)", xlim=(0, 190), title="Latency budget (assumed)")
w = 0.38; x = np.arange(len(speeds))
b.bar(x - w / 2, [v * tot_e / 1000 * 100 for v in speeds], w, color=PAL["green"], label=f"edge ({tot_e} ms)")
b.bar(x + w / 2, [v * tot_c / 1000 * 100 for v in speeds], w, color=PAL["red"], label=f"cloud ({tot_c} ms)")
b.set(xticks=x, xticklabels=[f"{v} m/s" for v in speeds], ylabel="distance travelled before reacting (cm)", title="Blind distance"); b.legend()
save(fig, out("fig05_latency.png"))
print("edge total", tot_e, "cloud total", tot_c)
for v in speeds: print("speed", v, "edge cm", round(v * tot_e / 10, 2), "cloud cm", round(v * tot_c / 10, 2))
