"""Fig 4: the four-layer IoT architecture applied to the Smart Greenhouse Rover (diagram; no data)."""
from _common import *
from matplotlib.patches import FancyBboxPatch

layers = [("Cloud / application", "dashboard, history, alerts, watering plan", PAL["purple"]),
          ("Network", "Wi-Fi to the greenhouse router; MQTT broker", PAL["orange"]),
          ("Edge", "rover computer: localisation, path planning, collision stop", PAL["green"]),
          ("Device", "soil + temperature sensors, wheel encoders, motors, water valve", PAL["blue"])]
fig, ax = plt.subplots(figsize=(7.4, 4.2)); ax.set_xlim(0, 10); ax.set_ylim(0, 8.6); ax.axis("off"); ax.grid(False)
for i, (name, what, col) in enumerate(layers):
    y = 6.5 - 2.1 * i
    ax.add_patch(FancyBboxPatch((0.3, y), 9.4, 1.6, boxstyle="round,pad=0.05,rounding_size=0.15", fc=col, ec="none", alpha=0.22))
    ax.text(0.6, y + 1.0, name, fontsize=12, fontweight="bold", color=col, va="center")
    ax.text(0.6, y + 0.4, what, fontsize=9.5, va="center")
for i in range(3):
    y = 6.5 - 2.1 * i
    ax.annotate("", xy=(4.4, y - 0.5), xytext=(4.4, y), arrowprops=dict(arrowstyle="-|>", color=PAL["grey"], lw=1.6, mutation_scale=14))
    ax.annotate("", xy=(5.6, y), xytext=(5.6, y - 0.5), arrowprops=dict(arrowstyle="-|>", color=PAL["grey"], lw=1.6, mutation_scale=14))
ax.text(4.25, 6.25, "commands", fontsize=8, ha="right", va="center", color=PAL["grey"])
ax.text(5.75, 6.25, "telemetry", fontsize=8, ha="left", va="center", color=PAL["grey"])
save(fig, out("fig04_architecture.png"))
