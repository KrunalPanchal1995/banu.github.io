"""Fig 1: the sense-think-act loop on a heated room. Panel A: ideal loop. Panel B: the same loop with sensor noise and a link delay."""
from _common import *
use_code("foundations/sense_think_act")
import sense_think_act as S

SP, H = 21.0, 0.5
cases = [("A: ideal sensor (no noise, no delay)", dict(sigma=0.0, delay=0.0)),
         ("B: noise sigma = 0.3 C, delay = 5 min", dict(sigma=0.3, delay=5.0))]
fig, axs = plt.subplots(2, 2, figsize=(7.8, 5.4), sharex=True, gridspec_kw=dict(height_ratios=[3, 1]))
for j, (name, kw) in enumerate(cases):
    r = S.simulate(S.BangBang(SP, H), S.Room(15.0, 5.0), t_end=240, **kw)
    m = S.metrics(r, SP)
    ax, au = axs[0, j], axs[1, j]
    ax.axhspan(SP - H, SP + H, color=PAL["sky"], alpha=0.25, label="dead band (setpoint +/- 0.5 C)")
    ax.plot(r["t"], r["T"], color=PAL["blue"], label="true temperature")
    ax.plot(r["t"], r["T_meas"], color=PAL["red"], lw=0.8, alpha=0.7, label="what the controller sees")
    ax.axhline(SP, color=PAL["grey"], ls=":", lw=1)
    ax.set(title=name, ylabel="temperature (C)"); ax.set_ylim(14, 25)
    au.step(r["t"], r["u"], where="post", color=PAL["orange"]); au.set(xlabel="time (min)", ylabel="heater", yticks=[0, 1], yticklabels=["off", "on"])
    print(name, {k: round(v, 3) for k, v in m.items()})
axs[0, 0].legend(loc="lower right", fontsize=7.5)
save(fig, out("fig01_loop.png"))
