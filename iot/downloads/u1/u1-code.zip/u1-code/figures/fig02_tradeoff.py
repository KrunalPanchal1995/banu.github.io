"""Fig 2: what the loop's design choices cost. Left: link delay vs worst temperature error. Right: dead-band half-width h vs heater switching and error."""
from _common import *
use_code("foundations/sense_think_act")
import sense_think_act as S

SP = 21.0
delays = np.array([0, 1, 2, 5, 10, 20, 30])
worst = [S.metrics(S.simulate(S.BangBang(SP, 0.5), t_end=480, delay=d), SP)["max_abs_err"] for d in delays]
hs = np.array([0.1, 0.25, 0.5, 1.0, 2.0])
sw = []; we = []
for h in hs:
    m = S.metrics(S.simulate(S.BangBang(SP, h), t_end=480), SP)
    sw.append(m["switches"]); we.append(m["max_abs_err"])
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.plot(delays, worst, "o-", color=PAL["red"]); a.set(xlabel="link delay (min)", ylabel="worst |T - setpoint| after warm-up (C)", title="Delay widens the swing")
b.plot(hs, sw, "s-", color=PAL["blue"], label="heater switches in 420 min")
b.set(xlabel="dead-band half-width h (C)", ylabel="switches (count)", title="A wider band switches less")
b2 = b.twinx(); b2.plot(hs, we, "^--", color=PAL["orange"], label="worst error"); b2.set_ylabel("worst error (C)"); b2.spines["right"].set_visible(True); b2.grid(False)
lines = b.get_lines() + b2.get_lines(); b.legend(lines, [l.get_label() for l in lines], fontsize=8, loc="upper center")
save(fig, out("fig02_tradeoff.png"))
for d, w in zip(delays, worst): print("delay", d, round(w, 3))
for h, s, w in zip(hs, sw, we): print("h", h, "switches", s, "worst", round(w, 3))
