"""Fig 3: an IoT node's battery life and data volume against its reporting period.
Node model (ASSUMED illustrative numbers, not measurements): awake 120 mA for 2 s per report, sleep 0.01 mA, 2000 mAh battery, 80% usable."""
from _common import *
use_code("foundations/sense_think_act")
import sense_think_act as S

I_ACT, T_ACT, I_SLP, CAP = 120.0, 2.0, 0.01, 2000.0
def avg_mA(period_s): return (I_ACT * T_ACT + I_SLP * (period_s - T_ACT)) / period_s
periods = np.array([5, 10, 30, 60, 300, 900, 3600])
life = np.array([S.battery_life_days(CAP, avg_mA(p)) for p in periods])
data = np.array([S.data_per_day(24, p, 60) for p in periods]) / 1e6   # 24 B payload + 60 B headers, megabytes/day
fig, (a, b) = plt.subplots(1, 2, figsize=FIG["panel2"])
a.loglog(periods, life, "o-", color=PAL["green"]); a.axhline(365, color=PAL["grey"], ls=":"); a.text(5.5, 400, "1 year", color=PAL["grey"], fontsize=8)
a.set(xlabel="reporting period (s)", ylabel="battery life (days)", title="Sleeping longer buys battery")
b.loglog(periods, data, "s-", color=PAL["purple"]); b.set(xlabel="reporting period (s)", ylabel="data sent (MB/day)", title="...and saves data")
save(fig, out("fig03_budget.png"))
for p, l, d in zip(periods, life, data): print("period", p, "s  avg", round(avg_mA(p), 4), "mA  life", round(l, 1), "days  data", round(d, 3), "MB/day")
