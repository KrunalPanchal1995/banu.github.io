# sense_think_act

> Sense-think-act loop simulator: a heated room, an on/off controller with hysteresis, a sampled noisy delayed sensor, and two IoT budget calculators.

**Topic:** foundations  |  **Created in session:** 001 (Unit 1)  |  **Status:** tested (7 tests)

## What this code is for
Shows, in about 100 lines of numpy, how a closed control loop behaves when its measurement is noisy, sampled and late. Reused by later Units as the reference loop (sensor filtering in Unit 3, dashboards in Unit 6, PID in Unit 9). Also holds the two small calculators used in the Unit 1 budget examples (data per day, battery life).

## Capabilities
- `Room(T0, T_out, tau, k).step(u, dt)`: first-order thermal room, exact solution for constant heater state u in {0,1}. Units: minutes, degrees C.
- `BangBang(setpoint, h)(measurement) -> u`: on/off controller with hysteresis (on below setpoint-h, off above setpoint+h, else keeps state).
- `simulate(controller, room, t_end, dt, sample_period, delay, sigma, seed) -> dict(t, T, u, T_meas)`: runs the loop; readings every `sample_period` min, noise N(0, sigma^2), arriving `delay` min late.
- `metrics(res, setpoint, settle_after=60) -> dict(mean_abs_err, max_abs_err, duty, switches)`.
- `data_per_day(payload_bytes, period_s, overhead_bytes=0) -> bytes/day`.
- `battery_life_days(capacity_mAh, avg_current_mA, usable_fraction=0.8) -> days`.

## Theory in one paragraph
dT/dt = -(T - T_out)/tau + k u. For constant u: T(t) = T_inf + (T0 - T_inf) exp(-t/tau), T_inf = T_out + k tau u. Steady duty D = (r - T_out)/(k tau); switching period 2h/s_on + 2h/s_off; worst error <= h + s_max (T_s + d). Derived in Unit 1, Section 3.3.

## Quick start
```bash
python sense_think_act.py        # prints metrics for a noisy, delayed loop
python -m pytest -q tests
```
```python
import sense_think_act as S
res = S.simulate(S.BangBang(21.0, 0.5), S.Room(15, 5), t_end=240, sigma=0.2, delay=1.0)
print(S.metrics(res, 21.0))
```

## Examples
| File | Shows | Output |
|------|-------|--------|
| `example_basic.py` | placeholder from the scaffold (the Unit 1 figure scripts in sessions/001-unit1-foundations/figures are the real examples) | `example_basic.png` |

## Inputs / outputs and units
| name | type | units | meaning |
|---|---|---|---|
| t, T, T_meas | float arrays | min, degC | time, true temperature, last reading seen by the controller |
| u | 0/1 array | - | heater state |
| sample_period, delay | float | min | reading interval, link latency |
| sigma | float | degC | sensor noise standard deviation |

## Validation
Analytic: exact exponential solution and equilibrium T_inf = 35 degC (tests); duty 0.5333 predicted vs 0.5335 simulated; period 8.04 predicted vs 8.06 simulated (`sessions/001-unit1-foundations/figures/analysis_theory.py`).

## Known limits and gotchas
- Single-room, single-heater, constant outside temperature; parameters are round numbers, not a measured building.
- The sensor model is white Gaussian noise plus fixed delay and fixed sampling; no drift, no packet loss (Exercise 5 of Unit 1).
- `simulate` uses a Python loop: fine for 10^4-10^5 steps, slow beyond.

## Dependencies
numpy (matplotlib only for the example)

## Extending toward the open-source package
Would live in `iotrobotics/loops.py`. Remaining cleanup: pluggable sensor/link models (loss, drift), replace the example scaffold.
