"""Sense-think-act loop simulator: a room with a heater, a noisy sampled sensor, a link delay and a bang-bang controller,
plus two small calculators for an IoT node (data per day, battery life).

Units: time in minutes, temperature in degrees Celsius. See README.md in this folder for purpose, API and examples.
"""
import numpy as np


class Room:
    """First-order thermal room: dT/dt = -(T - T_out)/tau + k*u, with u in {0, 1} (heater off/on).

    tau (min) is how fast the room relaxes to the outside temperature; k (degC/min) is the heating rate when u = 1.
    For constant u the solution is exact: T(t+dt) = T_inf + (T - T_inf) * exp(-dt/tau), T_inf = T_out + k*tau*u.
    """

    def __init__(self, T0=15.0, T_out=5.0, tau=60.0, k=0.5):
        self.T, self.T_out, self.tau, self.k = float(T0), float(T_out), float(tau), float(k)

    def step(self, u, dt):
        t_inf = self.T_out + self.k * self.tau * u
        self.T = t_inf + (self.T - t_inf) * np.exp(-dt / self.tau)
        return self.T


class BangBang:
    """On/off controller with hysteresis: heater on below setpoint - h, off above setpoint + h, otherwise keep state."""

    def __init__(self, setpoint=21.0, h=0.5):
        self.setpoint, self.h, self.u = float(setpoint), float(h), 0

    def __call__(self, measurement):
        if measurement < self.setpoint - self.h:
            self.u = 1
        elif measurement > self.setpoint + self.h:
            self.u = 0
        return self.u


def simulate(controller, room=None, t_end=240.0, dt=0.1, sample_period=1.0, delay=0.0, sigma=0.0, seed=0):
    """Run the loop. Every sample_period minutes the sensor measures the true temperature plus N(0, sigma^2) noise;
    the value reaches the controller `delay` minutes later; the controller acts on the newest value it has received.

    Returns a dict of arrays: t, T (true), u (heater), T_meas (what the controller last saw).
    """
    room = room or Room()
    rng = np.random.default_rng(seed)
    n = int(round(t_end / dt))
    t = np.arange(n) * dt
    T, u, seen = np.zeros(n), np.zeros(n), np.zeros(n)
    pending = []            # (arrival_time, value)
    last = room.T + (rng.normal(0, sigma) if sigma else 0.0)
    next_sample = 0.0
    for i in range(n):
        if t[i] >= next_sample - 1e-9:
            pending.append((t[i] + delay, room.T + (rng.normal(0, sigma) if sigma else 0.0)))
            next_sample += sample_period
        while pending and pending[0][0] <= t[i] + 1e-9:
            last = pending.pop(0)[1]
        cmd = controller(last)
        T[i], u[i], seen[i] = room.T, cmd, last
        room.step(cmd, dt)
    return dict(t=t, T=T, u=u, T_meas=seen)


def metrics(res, setpoint, settle_after=60.0):
    """Summary numbers after the warm-up time `settle_after` (min): mean/max |error|, heater duty cycle, switch count."""
    m = res["t"] >= settle_after
    err = res["T"][m] - setpoint
    u = res["u"][m]
    return dict(mean_abs_err=float(np.mean(np.abs(err))), max_abs_err=float(np.max(np.abs(err))),
                duty=float(np.mean(u)), switches=int(np.sum(np.abs(np.diff(u)) > 0)))


def data_per_day(payload_bytes, period_s, overhead_bytes=0):
    """Bytes sent per day by a node that sends one message of payload_bytes + overhead_bytes every period_s seconds."""
    return (payload_bytes + overhead_bytes) * 86400.0 / period_s


def battery_life_days(capacity_mAh, avg_current_mA, usable_fraction=0.8):
    """Days a battery lasts at a constant average current; usable_fraction accounts for the unusable end of the discharge."""
    return capacity_mAh * usable_fraction / avg_current_mA / 24.0


def main():
    res = simulate(BangBang(21.0, 0.5), Room(15.0, 5.0), t_end=240, sigma=0.2, delay=1.0)
    print(metrics(res, 21.0))


if __name__ == "__main__":
    main()
