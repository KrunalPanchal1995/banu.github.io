import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import sense_think_act as sta  # noqa: E402


def test_room_cools_exactly_like_newton():
    r = sta.Room(T0=25.0, T_out=5.0, tau=60.0, k=0.5)
    for _ in range(600):
        r.step(0, 0.1)           # 60 minutes = one time constant
    assert abs(r.T - (5.0 + 20.0 * np.exp(-1.0))) < 1e-9


def test_room_heated_forever_reaches_T_out_plus_k_tau():
    r = sta.Room(T0=5.0, T_out=5.0, tau=60.0, k=0.5)
    for _ in range(20000):
        r.step(1, 0.1)
    assert abs(r.T - 35.0) < 1e-6


def test_bang_bang_hysteresis_memory():
    c = sta.BangBang(21.0, 0.5)
    assert c(20.0) == 1 and c(21.2) == 1 and c(21.6) == 0 and c(20.8) == 0 and c(20.4) == 1


def test_ideal_loop_stays_in_band():
    res = sta.simulate(sta.BangBang(21.0, 0.5), sta.Room(15.0, 5.0), t_end=300, dt=0.05, sample_period=0.05)
    m = res["t"] > 60
    assert res["T"][m].min() > 21.0 - 0.5 - 0.1 and res["T"][m].max() < 21.0 + 0.5 + 0.1


def test_delay_widens_swing():
    a = sta.metrics(sta.simulate(sta.BangBang(21.0, 0.5), t_end=300, delay=0.0), 21.0)
    b = sta.metrics(sta.simulate(sta.BangBang(21.0, 0.5), t_end=300, delay=5.0), 21.0)
    assert b["max_abs_err"] > a["max_abs_err"]


def test_simulate_is_deterministic():
    a = sta.simulate(sta.BangBang(), sigma=0.3, seed=7)
    b = sta.simulate(sta.BangBang(), sigma=0.3, seed=7)
    assert np.array_equal(a["T"], b["T"])


def test_budget_calculators():
    assert sta.data_per_day(20, 60, 10) == 30 * 1440
    assert abs(sta.battery_life_days(2000, 100, 1.0) - 2000 / 100 / 24) < 1e-12
