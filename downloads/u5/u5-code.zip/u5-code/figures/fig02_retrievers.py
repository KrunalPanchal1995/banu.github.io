"""Fig 2: recall@k for BM25, TF-IDF cosine, LSA (dense) and hybrid rank fusion."""
from _common import *
use_code("rag/rag_np")
import rag_np as R
corpus = R.load_corpus(); Q = R.load_queries()["answerable"]; ch = R.chunk_corpus(corpus, 600, 120); T = [c["text"] for c in ch]
bm, tf, lsa = R.BM25(T), R.Tfidf(T), R.LSA(T, 64)
hyb = lambda q: R.as_ranking(R.rrf([R.rank(bm.scores(q)), R.rank(lsa.scores(q))]))
hyb3 = lambda q: R.as_ranking(R.rrf([R.rank(bm.scores(q)), R.rank(tf.scores(q)), R.rank(lsa.scores(q))]))
ks = list(range(1, 11)); methods = {"BM25": bm.scores, "TF-IDF cosine": tf.scores, "LSA 64-d (dense)": lsa.scores, "hybrid: BM25 + LSA (RRF)": hyb, "hybrid: BM25 + TF-IDF + LSA": hyb3}
cols = [PAL["blue"], PAL["orange"], PAL["green"], PAL["red"], PAL["purple"]]; fig, ax = plt.subplots(figsize=FIG["single"]); out_res = {}
for (n, f), c in zip(methods.items(), cols):
    r = R.evaluate(f, ch, Q, ks=tuple(ks)); out_res[n] = r; ax.plot(ks, [r[f"recall@{k}"] for k in ks], "o-", color=c, label=n, ms=3.5)
ax.set(xlabel="k (chunks retrieved)", ylabel="share of questions with the answer in the top k", ylim=(0, 1.02)); ax.legend(fontsize=7, loc="lower right")
save(fig, out("fig02_retrievers.png")); print("chunks", len(ch))
for n, r in out_res.items(): print(f"{n:30s} r@1 {r['recall@1']:.3f} r@3 {r['recall@3']:.3f} r@5 {r['recall@5']:.3f} r@10 {r['recall@10']:.3f} mrr {r['mrr']:.3f}")
# which questions does each method miss at k=5?
miss = {n: {i for i, x in enumerate(r["ranks"]) if x is None or x > 5} for n, r in out_res.items()}
print("missed@5: BM25", sorted(miss["BM25"]), "| LSA", sorted(miss["LSA 64-d (dense)"]), "| hybrid", sorted(miss["hybrid: BM25 + LSA (RRF)"]))
print("BM25-only misses fixed by LSA:", sorted(miss["BM25"] - miss["LSA 64-d (dense)"]), " LSA-only misses fixed by BM25:", sorted(miss["LSA 64-d (dense)"] - miss["BM25"]))

# paired comparison on the 30 questions (hit@5): bootstrap CI for LSA - BM25 and hybrid - BM25
use_code("llm/prompting_tools"); import prompting_tools as P
hit = {n: np.array([x is not None and x <= 5 for x in r["ranks"]], float) for n, r in out_res.items()}
for other in ("LSA 64-d (dense)", "hybrid: BM25 + LSA (RRF)", "TF-IDF cosine"):
    d, lo, hi = P.paired_bootstrap_ci(hit["BM25"], hit[other], B=4000, rng=np.random.default_rng(0)); b_ = int(((hit[other] == 1) & (hit["BM25"] == 0)).sum()); c_ = int(((hit[other] == 0) & (hit["BM25"] == 1)).sum())
    print(f"{other} minus BM25 at recall@5: {d:+.3f}  95% CI [{lo:+.3f}, {hi:+.3f}]  (only-it {b_}, only-BM25 {c_}, n=30)")
