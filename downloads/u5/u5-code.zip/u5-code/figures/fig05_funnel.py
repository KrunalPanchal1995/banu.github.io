"""Fig 5: end-to-end funnel: retrieve -> build context -> extractive answer -> contains the gold phrase."""
from _common import *
use_code("rag/rag_np")
import rag_np as R
corpus = R.load_corpus(); Q = R.load_queries()["answerable"]; ch = R.chunk_corpus(corpus, 600, 120); T = [c["text"] for c in ch]; bm = R.BM25(T)
stages = {"answer chunk retrieved in top 5": 0, "answer chunk fits in the 2000-character context": 0, "best sentence contains the answer": 0, "best 3 sentences contain the answer": 0}; why = []
for k in (3, 5):
    pass
for e in Q:
    order = R.rank(bm.scores(e["q"])); r = R.first_gold_rank(order[:5], ch, e["gold"])
    if r is None: why.append("not retrieved"); continue
    stages["answer chunk retrieved in top 5"] += 1
    ctx = R.build_context(ch, order, 2000)
    if not any(e["gold"] in ch[i]["text"] for i in ctx): why.append("retrieved but cut from context"); continue
    stages["answer chunk fits in the 2000-character context"] += 1
    a = R.extractive_answer(e["q"], [ch[i]["text"] for i in ctx])
    a3 = R.extractive_answer(e["q"], [ch[i]["text"] for i in ctx], n=3)
    if a and e["gold"] in a: stages["best sentence contains the answer"] += 1
    if a3 and e["gold"] in a3: stages["best 3 sentences contain the answer"] += 1
    if not (a3 and e["gold"] in a3): why.append("context ok, answer sentence not picked")
n = len(Q); vals = [n] + list(stages.values()); names = ["all questions"] + list(stages)
fig, ax = plt.subplots(figsize=(7.6, 3.1)); y = np.arange(len(vals))
ax.barh(y, vals, color=[PAL["grey"], PAL["blue"], PAL["sky"], PAL["green"], PAL["green"]]); ax.set_yticks(y, names, fontsize=7); ax.invert_yaxis(); ax.set(xlabel="number of questions (of 30)")
for i, v in enumerate(vals): ax.text(v + .3, i, str(v), va="center")
save(fig, out("fig05_funnel.png")); print(dict(zip(names, vals))); from collections import Counter; print(Counter(why))
