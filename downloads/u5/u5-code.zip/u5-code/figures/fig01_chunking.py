"""Fig 1: chunk size and overlap vs retrieval quality (BM25, 30 questions over the course text), on an equal-cost axis."""
from _common import *
use_code("rag/rag_np")
import rag_np as R
corpus = R.load_corpus(); Q = R.load_queries()["answerable"]
sizes = [150, 300, 600, 1200, 2400]; ks = list(range(1, 11)); curves = {}; r5 = {0.0: [], 0.2: []}; cut = {0.0: [], 0.2: []}; dup = {}
for ov in (0.0, 0.2):
    for s in sizes:
        ch = R.chunk_corpus(corpus, s, int(ov * s)); b = R.BM25([c["text"] for c in ch]); r = R.evaluate(b.scores, ch, Q, ks=tuple(ks))
        curves[(ov, s)] = [r[f"recall@{k}"] for k in ks]; r5[ov].append(r["recall@5"]); cut[ov].append(sum(not any(e["gold"] in c["text"] for c in ch) for e in Q))
        # near-duplicate rate: share of top-5 lists that contain two chunks of the same document whose indices differ by 1 (they overlap)
        n = 0
        for e in Q:
            top = R.rank(b.scores(e["q"]))[:5]; ids = [(ch[i]["doc"], ch[i]["i"]) for i in top]; n += any(a[0] == c[0] and abs(a[1] - c[1]) == 1 for x, a in enumerate(ids) for c in ids[x + 1:])
        dup[(ov, s)] = n / len(Q)
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
axs[0].semilogx(sizes, r5[0.0], "o--", color=PAL["red"], label="no overlap"); axs[0].semilogx(sizes, r5[0.2], "o-", color=PAL["blue"], label="20% overlap")
axs[0].set(xlabel="chunk size (characters)", ylabel="recall@5 (answer in top 5 chunks)", ylim=(0, 1.02)); axs[0].legend(fontsize=7); axs[0].set_xticks(sizes, [str(v) for v in sizes]); axs[0].minorticks_off()
cols = [PAL["purple"], PAL["red"], PAL["orange"], PAL["green"], PAL["blue"]]
for s, c in zip(sizes, cols): axs[1].plot(np.array(ks) * s, curves[(0.2, s)], "o-", ms=3, color=c, label=f"size {s}")
axs[1].set(xscale="log", xlabel="characters retrieved (k x chunk size)", ylabel="share answered", ylim=(0, 1.02)); axs[1].legend(fontsize=6, loc="lower right")
save(fig, out("fig01_chunking.png"))
print("sizes", sizes); print("recall@5 no overlap", np.round(r5[0.0], 3), " 20% overlap", np.round(r5[0.2], 3)); print("answers cut by a boundary: no overlap", cut[0.0], " 20% overlap", cut[0.2])
print("near-duplicate in top-5 (20% overlap):", {s: round(dup[(0.2, s)], 2) for s in sizes}, " (no overlap):", {s: round(dup[(0.0, s)], 2) for s in sizes})
for s in sizes: print("size", s, "equal-cost: recall at ~1200 chars:", [ (k*s, round(curves[(0.2,s)][k-1],2)) for k in ks if 900 <= k*s <= 1500 ], " at ~3000 chars:", [(k*s, round(curves[(0.2,s)][k-1],2)) for k in ks if 2400 <= k*s <= 3600])
