"""Fig 3: approximate nearest-neighbour search with an IVF index on real LSA chunk vectors: recall vs work."""
from _common import *
use_code("rag/rag_np")
import rag_np as R
corpus = R.load_corpus(); Q = R.load_queries()["answerable"]; ch = R.chunk_corpus(corpus, 150, 0); T = [c["text"] for c in ch]
lsa = R.LSA(T, 64); X = lsa.D; qv = []
for e in Q:
    v = lsa.Vt @ lsa.t.query_vec(e["q"]); n = np.linalg.norm(v); qv.append(v / n if n else v)
qv = np.array(qv); K = 10
truth = [set(np.argsort(((X - q) ** 2).sum(1))[:K]) for q in qv]; N = len(X)
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained"); table = {}
for nlist, c in [(16, PAL["blue"]), (32, PAL["orange"]), (64, PAL["green"])]:
    ivf = R.IVF(X, nlist, seed=0); rec, cost = [], []
    ps = [1, 2, 4, 8, 16, 32, 64]; ps = [p for p in ps if p <= nlist]
    for npb in ps:
        rr, cc = [], []
        for q, t in zip(qv, truth):
            ids, w = ivf.search(q, K, npb); rr.append(len(set(ids) & t) / K); cc.append(w)
        rec.append(np.mean(rr)); cost.append(np.mean(cc) / N)
    axs[0].plot(ps, rec, "o-", color=c, label=f"nlist = {nlist}"); axs[1].plot(cost, rec, "o-", color=c, label=f"nlist = {nlist}"); table[nlist] = list(zip(ps, np.round(rec, 3), np.round(cost, 3)))
axs[0].set(xlabel="cells probed (nprobe)", ylabel=f"recall@{K} against exact search", xscale="log"); axs[0].legend(fontsize=7)
axs[1].set(xlabel="distance computations / exact search (N)", ylabel=f"recall@{K}"); axs[1].axvline(1, color=PAL["grey"], ls=":")
save(fig, out("fig03_ivf.png")); print("N vectors", N, "dim", X.shape[1])
for k, v in table.items(): print("nlist", k, "(nprobe, recall, cost/N):", v)
