"""Retrieval-augmented generation building blocks in plain numpy: chunking, BM25, TF-IDF, LSA (a classical dense embedding),
rank fusion, an IVF vector index, context building, an extractive "generator", and retrieval metrics.

See README.md. The bundled corpus (data/u*.txt) is the text of the first four course units; data/eval_queries.json holds 30 answerable
questions (each with a gold phrase that occurs exactly once in the corpus), 10 off-topic unanswerable ones and 10 on-topic 'near-miss'
questions whose key term does not occur in the corpus.
"""
import glob
import json
import math
import os
import re
from collections import Counter

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
STOP = set("a an and are as at be by for from has have in is it its of on or that the this to was were which with not no do does did how what why when who can".split())


# ------------------------------------------------------------------ corpus and chunking
def load_corpus(data_dir=None):
    """Returns {doc_name: text}; whitespace already normalised to single spaces."""
    d = data_dir or os.path.join(HERE, "data")
    return {os.path.basename(p)[:-4]: open(p, encoding="utf-8").read() for p in sorted(glob.glob(os.path.join(d, "u*.txt")))}


def load_queries(data_dir=None):
    return json.load(open(os.path.join(data_dir or os.path.join(HERE, "data"), "eval_queries.json"), encoding="utf-8"))


def chunk_text(text, size, overlap=0):
    """Sliding window of about `size` characters, extended to the next space so words are not cut; consecutive chunks share about
    `overlap` characters (start moved to a word boundary). Returns a list of strings that together cover the text."""
    assert size > overlap >= 0
    out, i, n = [], 0, len(text)
    while i < n:
        j = min(i + size, n)
        while j < n and text[j] != " ":
            j += 1
        out.append(text[i:j].strip())
        if j >= n:
            break
        nxt = max(i + 1, j - overlap)
        while nxt < n and text[nxt] != " ":
            nxt += 1
        i = nxt + 1 if nxt > i else j
    return [c for c in out if c]


def chunk_corpus(corpus, size, overlap=0):
    """Chunk every document separately; returns list of dicts {doc, i, text}."""
    return [{"doc": d, "i": k, "text": c} for d, t in corpus.items() for k, c in enumerate(chunk_text(t, size, overlap))]


# ------------------------------------------------------------------ sparse retrieval
def tokenize(text, stop=True):
    toks = re.findall(r"[a-z0-9]+", text.lower())
    return [t for t in toks if t not in STOP] if stop else toks


class BM25:
    """Okapi BM25 with the Lucene idf: ln(1 + (N - df + 0.5)/(df + 0.5)); k1 = 1.5, b = 0.75."""

    def __init__(self, docs, k1=1.5, b=0.75):
        self.k1, self.b = k1, b
        self.tf = [Counter(tokenize(d)) for d in docs]
        self.dl = np.array([sum(c.values()) for c in self.tf], float)
        self.avgdl = self.dl.mean()
        df = Counter(t for c in self.tf for t in c)
        N = len(docs)
        self.idf = {t: math.log(1 + (N - n + 0.5) / (n + 0.5)) for t, n in df.items()}

    def scores(self, query):
        s = np.zeros(len(self.tf))
        for t in set(tokenize(query)):
            if t not in self.idf:
                continue
            for i, c in enumerate(self.tf):
                f = c.get(t, 0)
                if f:
                    s[i] += self.idf[t] * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * self.dl[i] / self.avgdl))
        return s


class Tfidf:
    """Sublinear tf (1 + ln tf), idf = ln((1+N)/(1+df)) + 1, l2-normalised rows; retrieval by cosine."""

    def __init__(self, docs):
        toks = [Counter(tokenize(d)) for d in docs]
        self.vocab = {t: i for i, t in enumerate(sorted({t for c in toks for t in c}))}
        N = len(docs)
        df = np.zeros(len(self.vocab))
        for c in toks:
            for t in c:
                df[self.vocab[t]] += 1
        self.idf = np.log((1 + N) / (1 + df)) + 1
        self.X = np.stack([self._vec(c) for c in toks])

    def _vec(self, counter):
        v = np.zeros(len(self.vocab))
        for t, f in counter.items():
            if t in self.vocab:
                v[self.vocab[t]] = (1 + math.log(f)) * self.idf[self.vocab[t]]
        n = np.linalg.norm(v)
        return v / n if n else v

    def query_vec(self, q):
        return self._vec(Counter(tokenize(q)))

    def scores(self, q):
        return self.X @ self.query_vec(q)


class LSA:
    """Latent semantic analysis: truncated SVD of the TF-IDF matrix. A classical DENSE embedding (no neural network): words that
    co-occur in the same chunks end up close together, so a query can match a chunk that shares no word with it."""

    def __init__(self, docs, dim=64):
        self.t = Tfidf(docs)
        U, S, Vt = np.linalg.svd(self.t.X, full_matrices=False)
        self.dim = min(dim, len(S))
        self.Vt = Vt[: self.dim]
        D = self.t.X @ self.Vt.T
        self.D = D / np.maximum(np.linalg.norm(D, axis=1, keepdims=True), 1e-12)

    def scores(self, q):
        v = self.Vt @ self.t.query_vec(q)
        n = np.linalg.norm(v)
        return self.D @ (v / n) if n else np.zeros(len(self.D))


def rank(scores):
    """Indices from best to worst; ties broken by index (stable)."""
    return np.argsort(-scores, kind="stable")


def rrf(rankings, k=60):
    """Reciprocal rank fusion: score(d) = sum over rankings 1/(k + rank_r(d)), rank starting at 1. Returns fused ranking (best first)."""
    n = len(rankings[0])
    s = np.zeros(n)
    for r in rankings:
        for pos, d in enumerate(r):
            s[d] += 1.0 / (k + pos + 1)
    return rank(s)


# ------------------------------------------------------------------ vector index (IVF)
class IVF:
    """Inverted-file index: k-means partitions the vectors into `nlist` cells; a query scans only the `nprobe` closest cells.
    Approximate: the true neighbour can sit in a cell that is not probed. Returns ids and the number of distance computations."""

    def __init__(self, X, nlist, iters=15, seed=0):
        rng = np.random.default_rng(seed)
        self.X = X
        self.C = X[rng.choice(len(X), nlist, replace=False)].copy()
        for _ in range(iters):
            a = ((X[:, None, :] - self.C[None]) ** 2).sum(2).argmin(1)
            for c in range(nlist):
                if (a == c).any():
                    self.C[c] = X[a == c].mean(0)
        self.assign = ((X[:, None, :] - self.C[None]) ** 2).sum(2).argmin(1)
        self.lists = [np.where(self.assign == c)[0] for c in range(nlist)]

    def search(self, q, topk, nprobe):
        cd = ((self.C - q) ** 2).sum(1)
        cells = np.argsort(cd)[:nprobe]
        cand = np.concatenate([self.lists[c] for c in cells])
        d = ((self.X[cand] - q) ** 2).sum(1)
        order = np.argsort(d, kind="stable")[:topk]
        return cand[order], len(self.C) + len(cand)


# ------------------------------------------------------------------ context building and a toy generator
def build_context(chunks, order, budget_chars):
    """Take chunks in rank order until the budget (characters) is used; returns list of chunk indices kept."""
    out, used = [], 0
    for i in order:
        L = len(chunks[i]["text"])
        if used + L > budget_chars:
            break
        out.append(int(i))
        used += L
    return out


def split_sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]


def extractive_answer(question, context_texts, n=1):
    """A deliberately simple 'generator': return the n context sentences that best match the question (BM25 over sentences), best first,
    joined by a space. It can only quote its context, so it is grounded by construction, and it cannot answer what the context lacks."""
    sents = [s for t in context_texts for s in split_sentences(t)]
    if not sents:
        return None
    order = rank(BM25(sents).scores(question))[:n]
    return " ".join(sents[int(i)] for i in order)


# ------------------------------------------------------------------ evaluation
def first_gold_rank(order, chunks, gold):
    """1-based rank of the first retrieved chunk that contains the gold phrase, or None."""
    for pos, i in enumerate(order):
        if gold in chunks[i]["text"]:
            return pos + 1
    return None


def evaluate(score_fn, chunks, queries, ks=(1, 3, 5, 10)):
    """score_fn(question) -> score array over chunks (or a ready ranking if returned as a list/ndarray of ints with attr 'is_rank').
    Returns dict with recall@k, mrr, and the list of per-query ranks. Queries whose gold phrase is in NO chunk (split by a boundary) count as misses."""
    ranks = []
    for q in queries:
        s = score_fn(q["q"])
        order = s if getattr(s, "is_rank", False) else rank(s)
        ranks.append(first_gold_rank(order, chunks, q["gold"]))
    res = {f"recall@{k}": float(np.mean([r is not None and r <= k for r in ranks])) for k in ks}
    res["mrr"] = float(np.mean([1 / r if r else 0 for r in ranks]))
    res["ranks"] = ranks
    return res


class Ranking(np.ndarray):
    is_rank = True


def as_ranking(order):
    return np.asarray(order).view(Ranking)


def query_coverage(question, text):
    """Share of the question's (non-stopword) terms that occur in `text`: a simple 'does this chunk even talk about the question' signal."""
    q = set(tokenize(question))
    return len(q & set(tokenize(text))) / len(q) if q else 0.0


def main():
    corpus = load_corpus()
    chunks = chunk_corpus(corpus, 600, 100)
    b = BM25([c["text"] for c in chunks])
    r = evaluate(b.scores, chunks, load_queries()["answerable"])
    print(len(chunks), "chunks; BM25", {k: round(v, 3) for k, v in r.items() if k != "ranks"})


if __name__ == "__main__":
    main()
