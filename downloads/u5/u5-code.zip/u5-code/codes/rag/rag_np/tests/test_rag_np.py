"""Tests: pytest, or python test_rag_np.py."""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import rag_np as R

corpus = R.load_corpus()
Q = R.load_queries()


def test_gold_phrases_occur_exactly_once_in_the_corpus():
    text = " ".join(corpus.values())
    assert len(Q["answerable"]) == 30 and len(Q["unanswerable"]) == 10
    assert all(text.count(e["gold"]) == 1 for e in Q["answerable"])
    assert len(Q["near_miss"]) == 10 and all(e["absent"].lower() not in text.lower() for e in Q["near_miss"])


def test_chunking_covers_text_and_respects_overlap():
    t = " ".join(f"w{i}" for i in range(400))
    for size, ov in ((100, 0), (100, 30), (57, 20)):
        ch = R.chunk_text(t, size, ov)
        assert set(" ".join(ch).split()) == set(t.split())                   # every word appears
        assert all(len(c) >= size * 0.5 for c in ch[:-1]) and all(len(c) <= size + 12 for c in ch)
        if ov == 0:
            assert " ".join(ch) == t                                          # exact partition
        else:
            assert sum(map(len, ch)) > len(t)                                 # overlapping chunks repeat some text


def test_bm25_matches_hand_computation():
    docs = ["apple banana", "apple apple cherry", "durian"]
    b = R.BM25(docs, k1=1.5, b=0.75)
    N, df = 3, 2                                                              # 'apple' is in 2 of 3 docs
    idf = math.log(1 + (N - df + .5) / (df + .5)); avg = (2 + 3 + 1) / 3
    want = idf * 2 * 2.5 / (2 + 1.5 * (1 - .75 + .75 * 3 / avg))               # doc 1: tf = 2, length 3
    assert abs(b.scores("apple")[1] - want) < 1e-12 and b.scores("apple")[2] == 0 and b.scores("apple")[1] > b.scores("apple")[0]


def test_tfidf_self_retrieval_and_unit_norm():
    docs = ["red apple pie", "green apple tart", "blue ocean waves", "red ocean fish"]
    t = R.Tfidf(docs)
    assert np.allclose(np.linalg.norm(t.X, axis=1), 1) and R.rank(t.scores("blue ocean waves"))[0] == 2


def test_lsa_matches_synonym_through_cooccurrence():
    docs = ["car engine repair", "automobile engine repair", "banana smoothie recipe", "car tyre repair", "automobile tyre service", "mango banana smoothie"]
    lsa = R.LSA(docs, dim=3)
    s = lsa.scores("automobile repair"); assert s[0] > s[2] and s[0] > s[5]    # doc 0 shares no 'automobile' yet outranks the smoothies


def test_rrf_by_hand():
    a, b = np.array([0, 1, 2]), np.array([2, 1, 0])
    f = R.rrf([a, b], k=60)                                                   # doc 1 is rank 2 in both: 2/62; docs 0 and 2: 1/61 + 1/63
    assert list(f) == [0, 2, 1] or list(f) == [2, 0, 1]
    assert list(R.rrf([np.array([3, 0, 1, 2]), np.array([3, 1, 0, 2])]))[0] == 3


def test_metrics_by_hand():
    chunks = [{"text": "a b"}, {"text": "gold here"}, {"text": "c"}]
    assert R.first_gold_rank([2, 1, 0], chunks, "gold") == 2 and R.first_gold_rank([0, 2], chunks, "gold") is None
    res = R.evaluate(lambda q: np.array([0.1, 0.9, 0.0]), chunks, [{"q": "x", "gold": "gold"}], ks=(1, 2))
    assert res["recall@1"] == 1 and res["mrr"] == 1


def test_ivf_exact_when_all_cells_probed_and_approximate_otherwise():
    rng = np.random.default_rng(0); X = np.vstack([rng.normal(c, 0.3, (60, 8)) for c in range(8)])
    ivf = R.IVF(X, nlist=8, seed=0); q = X[5] + 0.05
    exact = np.argsort(((X - q) ** 2).sum(1))[:5]
    ids, cost = ivf.search(q, 5, nprobe=8); assert list(ids) == list(exact) and cost == 8 + len(X)
    ids1, cost1 = ivf.search(q, 5, nprobe=1); assert cost1 < cost


def test_context_budget_and_extractive_answer_is_grounded():
    chunks = [{"text": "x" * 100}, {"text": "y" * 100}, {"text": "z" * 100}]
    assert R.build_context(chunks, [2, 0, 1], 250) == [2, 0]
    ctx = ["Paris is the capital of France. Berlin is in Germany.", "The Seine flows through Paris."]
    a = R.extractive_answer("What is the capital of France?", ctx)
    assert a == "Paris is the capital of France." and any(a in c for c in ctx) and R.extractive_answer("x", []) is None
    two = R.extractive_answer("What is the capital of France?", ctx, n=2); assert two.startswith(a) and len(two) > len(a)


def test_bm25_finds_most_gold_chunks_and_coverage_separates_unanswerable():
    chunks = R.chunk_corpus(corpus, 600, 100); b = R.BM25([c["text"] for c in chunks])
    r = R.evaluate(b.scores, chunks, Q["answerable"])
    assert r["recall@5"] >= 0.7 and r["recall@10"] >= r["recall@5"] >= r["recall@1"] and 0 < r["mrr"] < 1
    cov = lambda q: R.query_coverage(q, chunks[int(R.rank(b.scores(q))[0])]["text"])
    ans = np.mean([cov(e["q"]) for e in Q["answerable"]]); un = np.mean([cov(q) for q in Q["unanswerable"]])
    assert ans > un + 0.2


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
    print("ok")
