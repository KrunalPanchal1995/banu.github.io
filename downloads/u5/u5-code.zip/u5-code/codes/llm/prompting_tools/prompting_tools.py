"""Prompting toolkit that runs WITHOUT a model: templates, few-shot prompts, context budgeting, structured output, tool calling,
and the statistics for evaluating prompts. A MockLLM stands in for a real model; swap in any object with a `complete(messages)` method.

See README.md in this folder. Messages are dicts {"role": "system"|"user"|"assistant"|"tool", "content": str}.
"""
import json
import math
import re

import numpy as np


# ------------------------------------------------------------------ templates and few-shot
def render(template, **vars):
    """Fill {{name}} placeholders. Raises KeyError on a missing variable and ValueError on an unused one (silent typos are the #1 prompt bug)."""
    names = set(re.findall(r"\{\{\s*(\w+)\s*\}\}", template))
    missing, extra = names - set(vars), set(vars) - names
    if missing:
        raise KeyError(f"missing template variables: {sorted(missing)}")
    if extra:
        raise ValueError(f"unused variables: {sorted(extra)}")
    return re.sub(r"\{\{\s*(\w+)\s*\}\}", lambda m: str(vars[m.group(1)]), template)


def few_shot_messages(system, examples, query):
    """System prompt, then each (input, output) example as a user/assistant pair, then the real query."""
    msgs = [{"role": "system", "content": system}]
    for x, y in examples:
        msgs += [{"role": "user", "content": x}, {"role": "assistant", "content": y}]
    return msgs + [{"role": "user", "content": query}]


# ------------------------------------------------------------------ context budgeting
def approx_tokens(text):
    """Rough token count: about 4 characters per token for English (a heuristic; use the model's own tokenizer for real budgets)."""
    return max(1, math.ceil(len(text) / 4))


def fit_context(messages, window, reserve_output=0, count=approx_tokens):
    """Keep every system message and every message with {"pin": True}, then as many of the NEWEST other messages as fit in
    window - reserve_output tokens. Returns (kept, dropped), both in original order. Dropping the OLDEST messages first silently removes
    early instructions, few-shot examples and retrieved documents unless you pin them. Raises ValueError if the pinned messages plus the
    latest message do not fit."""
    budget = window - reserve_output
    fixed = [m for m in messages if m["role"] == "system" or m.get("pin")]
    rest = [m for m in messages if m not in fixed]
    used = sum(count(m["content"]) for m in fixed)
    keep = []
    for m in reversed(rest):
        c = count(m["content"])
        if used + c > budget:
            if not keep:
                raise ValueError("the pinned messages plus the latest message do not fit in the context window")
            break
        keep.append(m)
        used += c
    kept_ids = {id(m) for m in fixed} | {id(m) for m in keep}
    return [m for m in messages if id(m) in kept_ids], [m for m in messages if id(m) not in kept_ids]


# ------------------------------------------------------------------ structured output
def validate(obj, schema, path="$"):
    """Validate against a small JSON-Schema subset (type, properties, required, enum, minimum, maximum, items). Returns a list of error strings."""
    errs = []
    t = schema.get("type")
    py = {"string": str, "number": (int, float), "integer": int, "boolean": bool, "array": list, "object": dict}
    if t and (not isinstance(obj, py[t]) or (t in ("number", "integer") and isinstance(obj, bool))):
        return [f"{path}: expected {t}, got {type(obj).__name__}"]
    if "enum" in schema and obj not in schema["enum"]:
        errs.append(f"{path}: {obj!r} not in {schema['enum']}")
    if t in ("number", "integer"):
        if "minimum" in schema and obj < schema["minimum"]:
            errs.append(f"{path}: {obj} < minimum {schema['minimum']}")
        if "maximum" in schema and obj > schema["maximum"]:
            errs.append(f"{path}: {obj} > maximum {schema['maximum']}")
    if t == "object":
        for k in schema.get("required", []):
            if k not in obj:
                errs.append(f"{path}: missing required key {k!r}")
        for k, sub in schema.get("properties", {}).items():
            if k in obj:
                errs += validate(obj[k], sub, f"{path}.{k}")
    if t == "array" and "items" in schema:
        for i, v in enumerate(obj):
            errs += validate(v, schema["items"], f"{path}[{i}]")
    return errs


def parse_json_lenient(text):
    """Parse JSON out of typical model output: strips ``` fences and prose around the first {...} or [...], removes trailing commas,
    converts single quotes to double when no double quotes are present. Returns (obj, repairs) or raises ValueError."""
    repairs = []
    s = text.strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", s, re.S)
    if m:
        s = m.group(1).strip(); repairs.append("stripped code fence")
    a = min([i for i in (s.find("{"), s.find("[")) if i >= 0], default=-1)
    b = max(s.rfind("}"), s.rfind("]"))
    if a < 0 or b < a:
        raise ValueError("no JSON object found")
    if a > 0 or b < len(s) - 1:
        repairs.append("cut surrounding prose")
    s = s[a:b + 1]
    try:
        return json.loads(s), repairs
    except json.JSONDecodeError:
        pass
    s2 = re.sub(r",\s*([}\]])", r"\1", s)
    if s2 != s:
        repairs.append("removed trailing comma")
    if '"' not in s2 and "'" in s2:
        s2 = s2.replace("'", '"'); repairs.append("single to double quotes")
    try:
        return json.loads(s2), repairs
    except json.JSONDecodeError as e:
        raise ValueError(f"unrepairable JSON: {e}")


def structured_call(llm, messages, schema, max_retries=3):
    """Ask the model for JSON, validate, and on failure append the error as feedback and retry. Returns (obj, attempts)."""
    msgs = list(messages)
    for attempt in range(1, max_retries + 2):
        out = llm.complete(msgs)
        try:
            obj, _ = parse_json_lenient(out)
            errs = validate(obj, schema)
        except ValueError as e:
            obj, errs = None, [str(e)]
        if not errs:
            return obj, attempt
        msgs += [{"role": "assistant", "content": out}, {"role": "user", "content": "Invalid output: " + "; ".join(errs) + ". Reply with valid JSON only."}]
    raise ValueError(f"no valid output after {max_retries + 1} attempts: {errs}")


# ------------------------------------------------------------------ tools
class ToolRegistry:
    """Named functions with a JSON-schema for their arguments; calls are validated before they run and errors come back as text."""

    def __init__(self):
        self.tools = {}

    def register(self, name, fn, schema, description=""):
        self.tools[name] = (fn, schema, description)

    def specs(self):
        return [{"name": n, "description": d, "parameters": s} for n, (f, s, d) in self.tools.items()]

    def call(self, name, args):
        if name not in self.tools:
            return f"error: unknown tool {name!r}"
        fn, schema, _ = self.tools[name]
        errs = validate(args, schema)
        if errs:
            return "error: " + "; ".join(errs)
        try:
            return str(fn(**args))
        except Exception as e:  # tool failures must not crash the loop
            return f"error: {type(e).__name__}: {e}"


def safe_calc(expression):
    """Arithmetic only: digits, + - * / ( ) . and spaces; no names, attribute access or exponent operator. A whitelist plus eval is a teaching
    shortcut: production code should use a real expression parser."""
    if not re.fullmatch(r"[0-9+\-*/(). ]+", expression) or "**" in expression or len(expression) > 200:
        raise ValueError("only short arithmetic without ** is allowed")   # '9**9**9' would hang the process
    return eval(expression, {"__builtins__": {}}, {})  # noqa: S307  (input restricted by the regex above)


class MockLLM:
    """A deterministic stand-in for a model, for testing the plumbing. If the last message is a tool result it answers with it;
    if the user asks for arithmetic it emits a tool call as JSON; otherwise it echoes. It does NOT understand language."""

    def complete(self, messages):
        last = messages[-1]
        if last["role"] == "tool":
            return f"The answer is {last['content']}."
        m = re.search(r"([\d(][\d+\-*/(). ]*[\d)])", last["content"])
        if m and re.search(r"calculate|compute|what is|how much", last["content"].lower()):
            return json.dumps({"tool": "calculator", "arguments": {"expression": m.group(1).strip()}})
        return "I can only echo: " + last["content"]


def run_tool_loop(llm, registry, user_message, max_steps=4):
    """Send messages; if the model replies with {"tool": name, "arguments": {...}} run it and feed back the result; stop on plain text."""
    msgs = [{"role": "user", "content": user_message}]
    log = []
    for _ in range(max_steps):
        out = llm.complete(msgs)
        log.append(("assistant", out))
        try:
            call = json.loads(out)
            assert isinstance(call, dict) and "tool" in call
        except (json.JSONDecodeError, AssertionError):
            return out, log
        res = registry.call(call["tool"], call.get("arguments", {}))
        log.append(("tool", res))
        msgs += [{"role": "assistant", "content": out}, {"role": "tool", "content": res}]
    return None, log


# ------------------------------------------------------------------ evaluation statistics
def majority_vote_accuracy(p, k):
    """P(majority of k independent samples is correct) when each is correct with probability p and wrong answers do NOT agree with each other
    (they are spread over many different wrong answers). Needs strictly more than k/2 correct; k odd. Assumes independence: the weak point in practice."""
    return float(sum(math.comb(k, j) * p ** j * (1 - p) ** (k - j) for j in range(k // 2 + 1, k + 1)))


def mc_majority_accuracy(p, k, trials, rng):
    return float((rng.random((trials, k)) < p).sum(1).__gt__(k // 2).mean())


def paired_bootstrap_ci(a, b, B=2000, level=0.95, rng=None):
    """Bootstrap CI for mean(b) - mean(a) on PAIRED per-item scores (same test items for both prompts)."""
    rng = rng or np.random.default_rng(0)
    d = np.asarray(b, float) - np.asarray(a, float)
    idx = rng.integers(0, len(d), (B, len(d)))
    means = d[idx].mean(1)
    lo, hi = np.quantile(means, [(1 - level) / 2, 1 - (1 - level) / 2])
    return float(d.mean()), float(lo), float(hi)


def main():
    reg = ToolRegistry()
    reg.register("calculator", lambda expression: safe_calc(expression), {"type": "object", "required": ["expression"], "properties": {"expression": {"type": "string"}}}, "evaluate arithmetic")
    ans, log = run_tool_loop(MockLLM(), reg, "Please calculate 23 * (4 + 6)")
    print(ans); [print(" ", r, "|", c) for r, c in log]
    print("majority vote, p=0.6:", [round(majority_vote_accuracy(0.6, k), 3) for k in (1, 5, 11, 21)])


if __name__ == "__main__":
    main()
