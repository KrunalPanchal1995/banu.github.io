"""Tests: pytest, or python test_prompting_tools.py."""
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import prompting_tools as P


def test_render_strict():
    assert P.render("Hi {{name}}, {{ n }} items", name="Ann", n=3) == "Hi Ann, 3 items"
    for bad in (dict(name="Ann"), dict(name="Ann", n=1, extra=2)):
        try:
            P.render("Hi {{name}}, {{n}}", **bad); raise AssertionError("should raise")
        except (KeyError, ValueError):
            pass


def test_few_shot_structure():
    m = P.few_shot_messages("sys", [("a", "A"), ("b", "B")], "q")
    assert [x["role"] for x in m] == ["system", "user", "assistant", "user", "assistant", "user"] and m[-1]["content"] == "q"


def test_fit_context_keeps_system_and_newest():
    msgs = [{"role": "system", "content": "x" * 40}] + [{"role": "user" if i % 2 == 0 else "assistant", "content": "y" * 40} for i in range(10)]
    kept, dropped = P.fit_context(msgs, window=60, reserve_output=10)         # budget 50 tokens: system 10 + 4 messages of 10
    assert kept[0]["role"] == "system" and len(kept) == 5 and len(dropped) == 6 and kept[-1] is msgs[-1] and dropped[0] is msgs[1]
    pinned = [dict(m, pin=True) if i in (1, 2) else m for i, m in enumerate(msgs)]    # pin the two oldest non-system messages
    k2, d2 = P.fit_context(pinned, window=60, reserve_output=10)                      # 10 system + 2 pinned x 10 + 2 newest x 10
    assert pinned[1] in k2 and pinned[2] in k2 and len(k2) == 5 and k2[-1] is pinned[-1] and len(d2) == 6
    try:
        P.fit_context([{"role": "user", "content": "z" * 4000}], 100); raise AssertionError
    except ValueError:
        pass


def test_validate():
    sch = {"type": "object", "required": ["name", "age"], "properties": {"name": {"type": "string"}, "age": {"type": "integer", "minimum": 0, "maximum": 130}, "tags": {"type": "array", "items": {"type": "string"}}, "kind": {"enum": ["a", "b"]}}}
    assert P.validate({"name": "x", "age": 5, "tags": ["t"], "kind": "a"}, sch) == []
    e = P.validate({"name": 3, "age": 200, "tags": [1], "kind": "z"}, sch)
    assert len(e) == 4 and P.validate({"name": "x"}, sch) == ["$: missing required key 'age'"] and P.validate(True, {"type": "integer"})


def test_lenient_json_repairs():
    cases = ['```json\n{"a": 1}\n```', 'Sure! Here you go: {"a": 1} Hope that helps', '{"a": 1,}', "{'a': 1}", '[1, 2, 3,]']
    for c in cases:
        obj, rep = P.parse_json_lenient(c); assert obj in ({"a": 1}, [1, 2, 3]) and rep
    for bad in ("no json here", '{"a": }'):
        try:
            P.parse_json_lenient(bad); raise AssertionError
        except ValueError:
            pass


def test_structured_call_retries_with_feedback():
    class Flaky:
        def __init__(self): self.n = 0
        def complete(self, msgs):
            self.n += 1
            return "not json at all" if self.n == 1 else json.dumps({"label": "positive"}) if "Invalid output" in msgs[-1]["content"] else "?"
    sch = {"type": "object", "required": ["label"], "properties": {"label": {"enum": ["positive", "negative"]}}}
    obj, attempts = P.structured_call(Flaky(), [{"role": "user", "content": "classify"}], sch)
    assert obj == {"label": "positive"} and attempts == 2


def test_tool_loop_and_safety():
    reg = P.ToolRegistry()
    reg.register("calculator", lambda expression: P.safe_calc(expression), {"type": "object", "required": ["expression"], "properties": {"expression": {"type": "string"}}})
    ans, log = P.run_tool_loop(P.MockLLM(), reg, "Please calculate 23 * (4 + 6)")
    assert ans == "The answer is 230." and [r for r, _ in log] == ["assistant", "tool", "assistant"]
    assert reg.call("calculator", {"expression": "__import__('os').system('x')"}).startswith("error")
    assert reg.call("calculator", {"expression": "9**9**9"}).startswith("error")
    assert reg.call("calculator", {}).startswith("error: $: missing") and reg.call("nope", {}).startswith("error: unknown")
    assert P.run_tool_loop(P.MockLLM(), reg, "hello")[0] == "I can only echo: hello"


def test_majority_vote_exact_values_and_monte_carlo():
    assert abs(P.majority_vote_accuracy(0.6, 1) - 0.6) < 1e-12
    assert abs(P.majority_vote_accuracy(0.6, 3) - (0.6 ** 3 + 3 * 0.6 ** 2 * 0.4)) < 1e-12 and abs(P.majority_vote_accuracy(0.6, 3) - 0.648) < 1e-12
    assert abs(P.majority_vote_accuracy(0.5, 11) - 0.5) < 1e-12
    assert P.majority_vote_accuracy(0.4, 21) < 0.4 < 0.6 < P.majority_vote_accuracy(0.6, 21)
    assert abs(P.mc_majority_accuracy(0.6, 11, 200000, np.random.default_rng(0)) - P.majority_vote_accuracy(0.6, 11)) < 0.005


def test_paired_bootstrap_ci_covers_true_difference_and_detects_zero():
    rng = np.random.default_rng(0)
    n = 2000; a = (rng.random(n) < 0.6).astype(float); b = np.where(rng.random(n) < 0.5, a, (rng.random(n) < 0.7)).astype(float)
    d, lo, hi = P.paired_bootstrap_ci(a, b, rng=np.random.default_rng(1)); assert lo < d < hi and lo > 0
    d, lo, hi = P.paired_bootstrap_ci(a, a.copy(), rng=np.random.default_rng(1)); assert d == 0 and lo == hi == 0


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
    print("ok")
