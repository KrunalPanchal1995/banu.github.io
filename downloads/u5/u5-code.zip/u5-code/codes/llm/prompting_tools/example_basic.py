"""Minimal runnable example for prompting_tools. Run: python example_basic.py  (writes example_basic.png)."""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import prompting_tools  # noqa: F401


def main():
    fig, ax = plt.subplots()
    ax.set(title="prompting_tools example")
    fig.savefig(os.path.join(os.path.dirname(os.path.abspath(__file__)), "example_basic.png"), dpi=150)


if __name__ == "__main__":
    main()
