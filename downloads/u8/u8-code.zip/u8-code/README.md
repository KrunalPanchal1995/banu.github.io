# LLM Agents and Tool Use: code bundle

Run everything from this folder with Python 3.9+ and `pip install -r requirements.txt` (numpy, matplotlib).

- `codes/`   the importable modules with their own README, example and tests
- `figures/` the scripts that produced every figure in the PDF (run: `python figures/fig01_*.py`)
- `colab/`   notebooks that need a GPU or Hugging Face (run on Google Colab)

Quick test: `python codes/agents/agents_np/tests/test_agents_np.py`  ->  prints `ok`.
MIT licence. Course site: see the Downloads page.
