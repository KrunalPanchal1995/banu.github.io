"""Fig 6: multi-agent cost: messages per round, and token cost of one agent versus a manager with workers on the same task (executed)."""
from _common import *
use_code("agents/agents_np")
import agents_np as A
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained"); ns = np.arange(2, 13)
axs[0].plot(ns, [A.messages_per_round(n, "full") for n in ns], "o-", color=PAL["red"], label="everyone talks to everyone: n(n-1)"); axs[0].plot(ns, [A.messages_per_round(n, "hub") for n in ns], "s-", color=PAL["blue"], label="manager and workers: 2(n-1)"); axs[0].set(xlabel="number of agents n", ylabel="messages per round"); axs[0].legend(fontsize=7)
tools = A.Tools(); t8 = A.make_task("chain", k=8); r1 = A.run_agent(t8, A.ScriptedPolicy(t8), tools); single = r1["tokens"]
handoff = A.approx_tokens("Please compute the next two operations on the value I send you and reply with the number only.") + A.approx_tokens("The value is 123")
parts = 0; calls = 0
for _ in range(4): tt = A.make_task("chain", k=2); rr = A.run_agent(tt, A.ScriptedPolicy(tt), tools); parts += rr["tokens"]; calls += rr["calls"]
multi = parts + 2 * 4 * handoff
axs[1].bar(["one agent\n(8 steps)", "manager + 4 workers\n(2 steps each)"], [single, multi], color=[PAL["blue"], PAL["orange"]]); axs[1].set(ylabel="tokens processed (approx.)")
for i, v in enumerate([single, multi]): axs[1].text(i, v + 2, str(v), ha="center", fontsize=8)
save(fig, out("fig06_multiagent.png")); print("one agent tokens", single, "calls", r1["calls"], "| 4 workers tokens", parts, "calls", calls, "+ handoffs", 2 * 4 * handoff, "= total", multi, "ratio", round(multi / single, 2))
print("messages n=5 full/hub", A.messages_per_round(5, "full"), A.messages_per_round(5, "hub"), " n=10", A.messages_per_round(10, "full"), A.messages_per_round(10, "hub"))
