"""Fig 1: a real run of the ReAct loop (scripted policy, real tools): the 'lookup' task."""
from _common import *
use_code("agents/agents_np")
import agents_np as A, textwrap
t = A.make_task("lookup", d=64); r = A.run_agent(t, A.ScriptedPolicy(t), A.Tools())
fig, ax = plt.subplots(figsize=(8.4, 3.6)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, 4.6)
ax.text(0.05, 4.4, "Question: " + t["question"], fontsize=7.5, weight="bold", va="top")
y = 3.6; cols = [(0.05, PAL["blue"], "Thought + Action (model)"), (5.3, PAL["orange"], "Observation (tool)")]
for x, c, h in cols: ax.text(x, y + .25, h, fontsize=7, color=c, weight="bold")
for i, (a, o) in enumerate(r["trace"]):
    ta = textwrap.fill(a.replace("\n", " | "), 62); to = textwrap.fill(o, 58)[:230] + ("..." if len(o) > 230 else "")
    ax.text(0.05, y, f"{i+1}. " + ta, fontsize=6.3, va="top", bbox=dict(boxstyle="round,pad=0.3", fc="none", ec=PAL["blue"])); ax.text(5.3, y, to, fontsize=6.3, va="top", bbox=dict(boxstyle="round,pad=0.3", fc="none", ec=PAL["orange"])); y -= 1.0
save(fig, out("fig01_trace.png")); print("steps", len(r["trace"]), "success", r["success"], "answer", r["answer"], "tokens", r["tokens"], "calls", r["calls"]); print(r["trace"][0][1][:200])
