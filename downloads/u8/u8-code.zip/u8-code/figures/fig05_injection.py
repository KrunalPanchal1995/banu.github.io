"""Fig 5: prompt-injection harness: attack success against defenses, and the cost to legitimate work."""
from _common import *
use_code("agents/agents_np")
import agents_np as A
allp = A.ATTACKS; defs = ["none", "allowlist", "allowlist+approval", "allowlist+approval+args"]; kinds = list(allp)
asr = {d: {k: np.mean([A.attack_outcome(p, d) for p in allp[k]]) for k in kinds} for d in defs}; tot = {d: np.mean([A.attack_outcome(p, d) for k in kinds for p in allp[k]]) for d in defs}
legit_none = {d: float(A.legit_email_task_succeeds(d, allow_email=(d in ("none", "allowlist")))) for d in defs}
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained"); x = np.arange(len(defs)); w = .26
for i, (k, c) in enumerate(zip(kinds, [PAL["red"], PAL["orange"], PAL["purple"]])): axs[0].bar(x + (i - 1) * w, [asr[d][k] for d in defs], w, color=c, label={"delete": "calls a forbidden tool", "email": "emails the secret", "exfil": "leaks via an allowed tool"}[k])
axs[0].set_xticks(x, ["none", "allowlist", "+ approval", "+ argument check"], fontsize=6.5, rotation=15); axs[0].set(ylabel="attack success rate (7 phrasings each)", ylim=(0, 1.1)); axs[0].legend(fontsize=6)
axs[1].bar(x, [1 - tot[d] for d in defs], .4, color=PAL["green"], label="share of 21 attacks blocked"); axs[1].bar(x + .4, [legit_none[d] for d in defs], .4, color=PAL["blue"], label="legitimate email task still works")
axs[1].set_xticks(x + .2, ["none", "allowlist", "+ approval", "+ argument check"], fontsize=6.5, rotation=15); axs[1].set(ylim=(0, 1.1)); axs[1].legend(fontsize=6)
save(fig, out("fig05_injection.png"))
for d in defs: print(f"{d:26s} attack success: " + ", ".join(f"{k} {asr[d][k]:.2f}" for k in kinds) + f" | overall {tot[d]:.2f} | legit email works: {legit_none[d]}")
