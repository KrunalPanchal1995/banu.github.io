"""Fig 3: memory: retrieval over notes against the number of notes, versus a sliding window of recent messages."""
from _common import *
use_code("agents/agents_np")
import agents_np as A
rng = np.random.default_rng(0); topics = ["lunch menu", "parking rules", "printer settings", "holiday dates", "wifi password", "team meeting room"]
def build(n):
    notes = []
    for i in range(n):
        if i % 6 == 5: notes.append(f"note {i}: the team {i // 6} meeting room is room {100 + i // 6}")
        else: notes.append(f"note {i}: about the {topics[i % 6]} on floor {rng.integers(1, 9)}, ask person {rng.integers(100)}")
    return notes
ns = [12, 30, 100, 300, 1000, 3000]; res = {1: [], 3: []}
for n in ns:
    m = A.Memory(); notes = build(n); [m.add(x) for x in notes]; teams = [i for i in range(n) if i % 6 == 5]; pick = rng.choice(teams, min(40, len(teams)), replace=False); hit = {1: 0, 3: 0}
    for i in pick:
        top = m.recall(f"which room is the meeting of team {i // 6}", 3)
        for k in (1, 3): hit[k] += notes[i] in top[:k]
    for k in (1, 3): res[k].append(hit[k] / len(pick))
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
axs[0].semilogx(ns, res[1], "o-", color=PAL["blue"], label="top 1"); axs[0].semilogx(ns, res[3], "s--", color=PAL["green"], label="top 3"); axs[0].set(xlabel="notes in long-term memory", ylabel="share of questions where the right note is recalled", ylim=(0, 1.02)); axs[0].legend(fontsize=7)
ages = np.arange(0, 400); 
for w, c in [(10, PAL["red"]), (50, PAL["orange"]), (200, PAL["purple"])]: axs[1].plot(ages, (ages < w).astype(float), color=c, label=f"keep last {w} messages")
axs[1].set(xlabel="how many messages ago the fact was said", ylabel="fact still in the window? (1 = yes)", ylim=(-.05, 1.1)); axs[1].legend(fontsize=7)
save(fig, out("fig03_memory.png")); print("notes", ns); print("recall top1", res[1]); print("recall top3", res[3])
