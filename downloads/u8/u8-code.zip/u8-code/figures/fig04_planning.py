"""Fig 4: fixed plan versus adaptive (react) execution when tool calls fail: theory and simulation."""
from _common import *
use_code("agents/agents_np")
import agents_np as A
rng = np.random.default_rng(0); kk = np.arange(1, 21); fig, ax = plt.subplots(figsize=FIG["single"])
for f, c in [(0.05, PAL["blue"]), (0.1, PAL["orange"]), (0.2, PAL["red"])]:
    ax.plot(kk, [A.plan_success_exact("plan", k, f) for k in kk], "--", color=c); ax.plot(kk, [A.plan_success_exact("react", k, f) for k in kk], "-", color=c, label=f"tool failure rate {f}")
    for strat, mk in (("plan", "s"), ("react", "o")): ax.plot([2, 6, 10, 16], [A.plan_success(strat, k, f, rng, 6000) for k in (2, 6, 10, 16)], mk, color=c, ms=4)
ax.set(xlabel="steps in the task k", ylabel="probability the task succeeds", ylim=(0, 1.02)); ax.plot([], [], "k--", label="fixed plan, no recovery"); ax.plot([], [], "k-", label="adaptive: retry a failed step once"); ax.legend(fontsize=6)
save(fig, out("fig04_planning.png"))
for f in (0.05, 0.1, 0.2): print(f"f={f}: k=10 plan {A.plan_success_exact('plan', 10, f):.3f} react {A.plan_success_exact('react', 10, f):.3f}; k=20 plan {A.plan_success_exact('plan', 20, f):.3f} react {A.plan_success_exact('react', 20, f):.3f}")
