"""Fig 2: reliability of multi-step agents: (1-eps)^k against agent runs, and what retry + verification buys."""
from _common import *
use_code("agents/agents_np")
import agents_np as A
tools = A.Tools(); rng = np.random.default_rng(0); ks = [1, 2, 4, 6, 8]; N = 1500; fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
kk = np.arange(1, 13)
for eps, c in [(0.02, PAL["green"]), (0.05, PAL["blue"]), (0.1, PAL["orange"]), (0.2, PAL["red"])]:
    axs[0].plot(kk, [A.chain_success(eps, k) for k in kk], "-", color=c, label=f"per-step error {eps}")
    sim = []
    for k in ks:
        t = A.make_task("chain", k=k); sim.append(np.mean([A.run_agent(t, A.ScriptedPolicy(t, eps=eps, p_malformed=0.0, rng=rng), tools)["success"] for _ in range(N)]))
    axs[0].plot(ks, sim, "o", color=c, ms=4); print(f"eps {eps}: simulated at k={ks}: {np.round(sim, 3)}  theory {np.round([A.chain_success(eps, k) for k in ks], 3)}")
axs[0].set(xlabel="steps in the task k", ylabel="probability the whole task succeeds", ylim=(0, 1.02)); axs[0].legend(fontsize=6)
eps, q = 0.2, 0.5; t8 = {}
for label, c_v, retries, col in [("no checks", 0.0, 0, PAL["red"]), ("retry malformed output only", 0.0, 30, PAL["orange"]), ("retry + verifier (catches 100% of wrong results)", 1.0, 30, PAL["green"])]:
    th = [A.step_success_with_retry(eps, q if c_v < 1 or retries else 0.0, c_v, retries) ** k for k in kk] if retries else [A.chain_success(eps, k) for k in kk]
    axs[1].plot(kk, th, "-", color=col, label=label); sim = []
    for k in ks:
        t = A.make_task("chain", k=k)
        sim.append(np.mean([A.run_agent(t, A.ScriptedPolicy(t, eps=eps, p_malformed=q, rng=rng), tools, retry_malformed=retries > 0, verify=A.chain_verifier if c_v > 0 else None, rng=rng, max_steps=80)["success"] for _ in range(N)]))
    axs[1].plot(ks, sim, "o", color=col, ms=4); print(f"{label}: simulated {np.round(sim, 3)} theory {np.round([th[k-1] for k in ks], 3)}")
axs[1].set(xlabel="steps in the task k", ylabel="probability the whole task succeeds", ylim=(0, 1.02), title=f"per-step error {eps}, half silent"); axs[1].legend(fontsize=5.5)
save(fig, out("fig02_reliability.png"))
print("10 steps at 95% per step:", round(A.chain_success(0.05, 10), 3), "| at 99%:", round(A.chain_success(0.01, 10), 3), "| 20 steps at 95%:", round(A.chain_success(0.05, 20), 3), "| steps for 50% at 95%:", round(np.log(0.5) / np.log(0.95), 1))
print("Wilson 95% interval for 1500 runs at p=0.6:", np.round(A.wilson(900, 1500), 3))
