"""Attention, multi-head attention, positional encoding and a Transformer block in plain numpy.

See README.md in this folder. Shapes: x is (n, d) for one sequence of n tokens of width d (no batch axis, on purpose).
"""
import numpy as np


def softmax(x, axis=-1):
    x = x - np.max(x, axis=axis, keepdims=True)
    e = np.exp(x)
    return e / e.sum(axis=axis, keepdims=True)


def causal_mask(n):
    """(n, n) boolean, True where attention is ALLOWED: position i may look at positions j <= i."""
    return np.tril(np.ones((n, n), dtype=bool))


def attention(Q, K, V, mask=None):
    """Scaled dot-product attention. Q:(nq,dk) K:(nk,dk) V:(nk,dv). Returns (out:(nq,dv), weights:(nq,nk))."""
    dk = Q.shape[-1]
    scores = Q @ K.T / np.sqrt(dk)
    if mask is not None:
        scores = np.where(mask, scores, -1e30)
    w = softmax(scores, axis=-1)
    return w @ V, w


def sinusoidal_pe(n, d):
    """Vaswani et al. 2017, Sec. 3.5: PE[pos,2i]=sin(pos/10000^(2i/d)), PE[pos,2i+1]=cos(same). d must be even."""
    pos = np.arange(n)[:, None]
    i = np.arange(d // 2)[None, :]
    ang = pos / np.power(10000.0, 2 * i / d)
    pe = np.zeros((n, d))
    pe[:, 0::2] = np.sin(ang)
    pe[:, 1::2] = np.cos(ang)
    return pe


def layer_norm(x, g, b, eps=1e-5):
    mu = x.mean(-1, keepdims=True)
    var = x.var(-1, keepdims=True)
    return g * (x - mu) / np.sqrt(var + eps) + b


def gelu(x):
    return 0.5 * x * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)))


def init_block(d, h, d_ff=None, rng=None, cross=False):
    """Random weights for one pre-LN Transformer block (self-attention [+ cross-attention] + feed-forward)."""
    rng = rng or np.random.default_rng(0)
    d_ff = d_ff or 4 * d
    s = 1 / np.sqrt(d)
    P = {"h": h}
    for name in (["att"] + (["xatt"] if cross else [])):
        P[name] = {k: rng.normal(0, s, (d, d)) for k in ("Wq", "Wk", "Wv", "Wo")}
        P[name].update({b: np.zeros(d) for b in ("bq", "bk", "bv", "bo")})
    P["ff"] = {"W1": rng.normal(0, s, (d, d_ff)), "b1": np.zeros(d_ff), "W2": rng.normal(0, 1 / np.sqrt(d_ff), (d_ff, d)), "b2": np.zeros(d)}
    for i in range(1, 4 if cross else 3):
        P[f"ln{i}"] = {"g": np.ones(d), "b": np.zeros(d)}
    return P


def mha(xq, xkv, A, h, mask=None):
    """Multi-head attention. xq:(nq,d) provides queries; xkv:(nk,d) provides keys and values (xkv is xq for self-attention).
    Returns (out:(nq,d), weights:(h,nq,nk))."""
    d = xq.shape[-1]
    dk = d // h
    Q = xq @ A["Wq"] + A["bq"]
    K = xkv @ A["Wk"] + A["bk"]
    V = xkv @ A["Wv"] + A["bv"]
    outs, ws = [], []
    for i in range(h):
        sl = slice(i * dk, (i + 1) * dk)
        o, w = attention(Q[:, sl], K[:, sl], V[:, sl], mask)
        outs.append(o)
        ws.append(w)
    return np.concatenate(outs, axis=-1) @ A["Wo"] + A["bo"], np.stack(ws)


def block(x, P, mask=None, memory=None):
    """Pre-LN Transformer block: x + SelfAtt(LN(x)); [+ CrossAtt(LN(.), memory)]; + FFN(LN(.)). Returns (y, self_att_weights)."""
    h = P["h"]
    a, w = mha(layer_norm(x, **P["ln1"]), layer_norm(x, **P["ln1"]), P["att"], h, mask)
    x = x + a
    if memory is not None:
        c, _ = mha(layer_norm(x, **P["ln2"]), memory, P["xatt"], h)
        x = x + c
    last = "ln3" if memory is not None else "ln2"
    y = layer_norm(x, **P[last])
    return x + gelu(y @ P["ff"]["W1"] + P["ff"]["b1"]) @ P["ff"]["W2"] + P["ff"]["b2"], w


def count_params(P):
    n = 0
    for k, v in P.items():
        if isinstance(v, dict):
            n += count_params(v)
        elif isinstance(v, np.ndarray):
            n += v.size
    return n


# ---------------------------------------------------------- recurrence vs attention
def rnn_gradient_norms(W, steps, rng=None):
    """Norm of d h_t / d h_0 for h_{t+1} = tanh(W h_t), t = 0..steps, with h_0 random. Shows the vanishing/exploding product of Jacobians."""
    rng = rng or np.random.default_rng(0)
    d = W.shape[0]
    h = rng.normal(size=d)
    J = np.eye(d)
    out = [1.0]
    for _ in range(steps):
        pre = W @ h
        h = np.tanh(pre)
        J = (np.diag(1 - h ** 2) @ W) @ J
        out.append(np.linalg.norm(J, 2))
    return np.array(out)


# ---------------------------------------------------------- cost model
def flops_attention_scores(n, d):
    """QK^T and (weights)V for all heads together: 2*n*n*d + 2*n*n*d = 4 n^2 d."""
    return 4 * n * n * d


def flops_dense(n, d, d_ff=None):
    """Q,K,V,O projections (4 matmuls n x d x d) and the two FFN matmuls: 8 n d^2 + 4 n d d_ff (= 24 n d^2 when d_ff = 4d)."""
    d_ff = d_ff or 4 * d
    return 8 * n * d * d + 4 * n * d * d_ff


def main():
    rng = np.random.default_rng(0)
    d, h, n = 16, 4, 6
    P = init_block(d, h, rng=rng)
    x = rng.normal(size=(n, d)) + sinusoidal_pe(n, d)
    y, w = block(x, P, mask=causal_mask(n))
    print("block output", y.shape, "params", count_params(P), "= 12 d^2 + 13 d =", 12 * d * d + 13 * d)
    print("causal weights row 2:", np.round(w[0, 2], 3))


if __name__ == "__main__":
    main()
