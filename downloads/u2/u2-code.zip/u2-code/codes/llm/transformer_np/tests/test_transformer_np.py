"""Tests: pytest, or python test_transformer_np.py."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import transformer_np as T

rng = np.random.default_rng(1)


def test_attention_rows_sum_to_one_and_mask():
    Q, K, V = rng.normal(size=(5, 8)), rng.normal(size=(5, 8)), rng.normal(size=(5, 3))
    out, w = T.attention(Q, K, V, T.causal_mask(5))
    assert np.allclose(w.sum(1), 1) and np.allclose(np.triu(w, 1), 0) and out.shape == (5, 3)


def test_sqrt_dk_keeps_score_variance_one():
    dk = 256
    q, k = rng.normal(size=(2000, dk)), rng.normal(size=(2000, dk))
    raw = (q * k).sum(1)
    assert abs(raw.std() - np.sqrt(dk)) < 1.0 and abs((raw / np.sqrt(dk)).std() - 1) < 0.1


def test_causal_no_future_leak():
    d, h, n = 16, 4, 7
    P = T.init_block(d, h)
    x = rng.normal(size=(n, d)); x2 = x.copy(); x2[5:] += 3.0
    y1, _ = T.block(x, P, T.causal_mask(n)); y2, _ = T.block(x2, P, T.causal_mask(n))
    assert np.allclose(y1[:5], y2[:5]) and not np.allclose(y1[5:], y2[5:])


def test_permutation_equivariance_without_pe_and_order_with_pe():
    d, h, n = 16, 4, 6
    P = T.init_block(d, h); x = rng.normal(size=(n, d)); perm = rng.permutation(n)
    y, _ = T.block(x, P); yp, _ = T.block(x[perm], P)
    assert np.allclose(y[perm], yp, atol=1e-9)                         # bag of tokens: order is invisible
    pe = T.sinusoidal_pe(n, d)
    y, _ = T.block(x + pe, P); yp, _ = T.block(x[perm] + pe, P)
    assert not np.allclose(y[perm], yp, atol=1e-3)                     # with PE the order matters


def test_pe_dot_product_depends_only_on_offset():
    pe = T.sinusoidal_pe(40, 32)
    for k in (1, 5, 11):
        dots = [pe[p] @ pe[p + k] for p in range(0, 25)]
        assert np.allclose(dots, dots[0], atol=1e-9)
    assert pe[3] @ pe[3] == pe[10] @ pe[10] == 16.0 or np.isclose(pe[3] @ pe[3], 16.0)


def test_param_count_formula():
    for d, h in ((16, 4), (64, 8)):
        assert T.count_params(T.init_block(d, h)) == 12 * d * d + 13 * d


def test_cross_attention_shapes():
    d, h = 16, 4
    P = T.init_block(d, h, cross=True)
    y, w = T.block(rng.normal(size=(4, d)), P, T.causal_mask(4), memory=rng.normal(size=(9, d)))
    assert y.shape == (4, d)


def test_rnn_gradient_decay_vs_growth():
    d = 32
    W = rng.normal(size=(d, d)) / np.sqrt(d)
    small = T.rnn_gradient_norms(0.7 * W, 40, np.random.default_rng(0)); big = T.rnn_gradient_norms(2.5 * W, 40, np.random.default_rng(0))
    assert small[-1] < 1e-3 * small[1] and big[10] > small[10]


def test_flops_crossover_is_six_d():
    d = 128
    assert T.flops_attention_scores(6 * d, d) == T.flops_dense(6 * d, d)


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
    print("ok")
