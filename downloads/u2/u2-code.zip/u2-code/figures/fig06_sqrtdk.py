"""Fig 6: why divide by sqrt(d_k): without it the softmax saturates (one weight ~ 1) as d_k grows."""
from _common import *
use_code("llm/transformer_np")
import transformer_np as T
rng = np.random.default_rng(0); dks = [4, 16, 64, 256, 1024, 4096]; res = {True: [], False: []}
for dk in dks:
    q = rng.normal(size=(300, dk)); K = rng.normal(size=(300, 16, dk))
    s = np.einsum("bd,bnd->bn", q, K)
    for sc in (True, False):
        w = T.softmax(s / (np.sqrt(dk) if sc else 1.0)); res[sc].append(w.max(1).mean())
fig, ax = plt.subplots(figsize=FIG["single"])
ax.semilogx(dks, res[True], "o-", color=PAL["blue"], label="scaled by 1/sqrt(d_k)"); ax.semilogx(dks, res[False], "s--", color=PAL["red"], label="unscaled")
ax.axhline(1 / 16, color=PAL["grey"], ls=":"); ax.text(4.5, 1 / 16 + .02, "uniform = 1/16", color=PAL["grey"], fontsize=8)
ax.set(xlabel="key dimension d_k", ylabel="mean of the largest attention weight", ylim=(0, 1.05)); ax.legend(loc="center right")
save(fig, out("fig06_sqrtdk.png")); print([round(v, 3) for v in res[True]], [round(v, 3) for v in res[False]])
