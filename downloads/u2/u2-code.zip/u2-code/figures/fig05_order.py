"""Fig 5: how much does shuffling the tokens change the block output, with and without positional encoding?"""
from _common import *
use_code("llm/transformer_np")
import transformer_np as T
rng = np.random.default_rng(0); d, h, n = 32, 4, 8
P = T.init_block(d, h); x = rng.normal(size=(n, d)); pe = T.sinusoidal_pe(n, d)
errs = {"no PE": [], "with PE": []}
for _ in range(20):
    perm = rng.permutation(n)
    y, _ = T.block(x, P); yp, _ = T.block(x[perm], P); errs["no PE"].append(np.abs(y[perm] - yp).max() + 1e-17)
    y, _ = T.block(x + pe, P); yp, _ = T.block(x[perm] + pe, P); errs["with PE"].append(np.abs(y[perm] - yp).max())
fig, ax = plt.subplots(figsize=FIG["single"])
for i, (k, v) in enumerate(errs.items()): ax.semilogy([i] * len(v), v, "o", color=[PAL["red"], PAL["green"]][i], alpha=.7); ax.hlines(np.median(v), i - .25, i + .25, color="k")
ax.set_xticks([0, 1], ["no positional encoding", "sinusoidal PE added"]); ax.set(ylabel="max |y[perm] - block(x[perm])|", xlim=(-.6, 1.6), title="20 random shuffles of 8 tokens")
save(fig, out("fig05_order.png")); print({k: (min(v), float(np.median(v)), max(v)) for k, v in errs.items()})
