"""Fig 3: product of Jacobians in a tanh RNN: gradient norm from step t back to step 0, versus attention's one-step path."""
from _common import *
use_code("llm/transformer_np")
import transformer_np as T
d = 64; W = np.random.default_rng(3).normal(size=(d, d)) / np.sqrt(d)
fig, ax = plt.subplots(figsize=FIG["single"])
for s, c in [(0.6, PAL["red"]), (1.0, PAL["blue"]), (1.6, PAL["green"])]:
    g = T.rnn_gradient_norms(s * W, 50, np.random.default_rng(0)); ax.semilogy(g, color=c, lw=2, label=f"RNN, weight scale {s}"); print(s, "norm at t=10:", g[10], "t=50:", g[50])
ax.axhline(1, color=PAL["grey"], ls=":"); ax.text(30, 1.4, "self-attention: any two tokens are 1 step apart", color=PAL["grey"], fontsize=8)
ax.set(xlabel="distance t between the two positions", ylabel="||d h_t / d h_0||  (spectral norm)", ylim=(1e-12, 1e3)); ax.legend(loc="lower left")
save(fig, out("fig03_rnn.png"))
