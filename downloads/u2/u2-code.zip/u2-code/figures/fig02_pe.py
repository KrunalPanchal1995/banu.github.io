"""Fig 2: sinusoidal positional encoding: the matrix, and the dot product PE[p].PE[p+k] as a function of the offset k only."""
from _common import *
use_code("llm/transformer_np")
import transformer_np as T
pe = T.sinusoidal_pe(64, 64)
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
im = axs[0].imshow(pe, cmap="RdBu_r", aspect="auto", vmin=-1, vmax=1); axs[0].grid(False)
axs[0].set(xlabel="dimension index", ylabel="position", title="PE matrix (n=64, d=64)"); fig.colorbar(im, ax=axs[0], label="value")
pe2 = T.sinusoidal_pe(300, 64); ks = np.arange(0, 120)
for p, c, ls in [(0, PAL["blue"], "-"), (50, PAL["orange"], "--"), (130, PAL["green"], ":")]:
    axs[1].plot(ks, [pe2[p] @ pe2[p + k] for k in ks], color=c, ls=ls, lw=1.8, label=f"start p = {p}")
axs[1].set(xlabel="offset k", ylabel="PE[p] . PE[p+k]", title="depends only on k"); axs[1].legend()
save(fig, out("fig02_pe.png"))
print("dot at k=0:", pe2[0] @ pe2[0], " k=10:", round(pe2[0] @ pe2[10], 3), pe2[50] @ pe2[60], "spread across starts at k=10:", np.ptp([pe2[p] @ pe2[p + 10] for p in range(0, 100)]))
