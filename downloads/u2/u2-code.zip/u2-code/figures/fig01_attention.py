"""Fig 1: reading an attention heatmap. A constructed 7-token example (features set by hand), without and with the causal mask."""
from _common import *
use_code("llm/transformer_np")
import transformer_np as T
toks = ["The", "animal", "didn't", "cross", "street", "it", "tired"]
# hand-set 3-d features: (noun-ness, verb-ness, pronoun-looks-for-noun)
K = np.array([[0, 0, 0], [3, 0, 0], [0, 2, 0], [0, 2, 0], [2, 0, 0], [0.5, 0, 0], [0, 1, 0]], float)
Q = np.array([[0, 0, 0], [0.5, 0, 0], [0, 1, 0], [0, 1, 0], [0.5, 0, 0], [3, 0, 0], [0, 1, 0]], float)
V = np.eye(7)
_, W = T.attention(Q * 1.5, K * 1.5, V)
_, Wm = T.attention(Q * 1.5, K * 1.5, V, T.causal_mask(7))
fig, axs = plt.subplots(1, 2, figsize=(7.8, 3.7))
for ax, M, title in [(axs[0], W, "no mask (encoder-style)"), (axs[1], Wm, "causal mask (decoder-style)")]:
    im = ax.imshow(M, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(7), toks, rotation=45, ha="right"); ax.set_yticks(range(7), toks)
    ax.set(title=title, xlabel="key (attended to)"); ax.grid(False)
axs[0].set_ylabel("query (attending)")
fig.colorbar(im, ax=axs, shrink=0.8, label="attention weight")
save(fig, out("fig01_attention.png"))
print("row 'it' (no mask):", dict(zip(toks, np.round(W[5], 3)))); print("row 'it' (causal):", dict(zip(toks, np.round(Wm[5], 3))))
print("row 'animal' (causal):", dict(zip(toks, np.round(Wm[1], 3))))
