"""Fig 4: per-layer FLOPs: attention score matrix (4 n^2 d) versus projections+FFN (24 n d^2), d = 768."""
from _common import *
use_code("llm/transformer_np")
import transformer_np as T
d = 768; n = np.logspace(2, 5, 100)
a = T.flops_attention_scores(n, d); f = T.flops_dense(n, d)
fig, ax = plt.subplots(figsize=FIG["single"])
ax.loglog(n, f, color=PAL["blue"], lw=2, label="projections + FFN  (24 n d^2)"); ax.loglog(n, a, color=PAL["orange"], lw=2, label="attention scores  (4 n^2 d)")
ax.axvline(6 * d, color=PAL["grey"], ls=":"); ax.text(6 * d * 1.05, 3e9, f"n = 6d = {6*d}", color=PAL["grey"])
ax.set(xlabel="sequence length n (tokens)", ylabel="FLOPs per layer"); ax.legend(loc="upper left")
save(fig, out("fig04_flops.png"))
for nn in (1024, 4608, 32768): print(nn, "attn share:", round(float(T.flops_attention_scores(nn, d) / (T.flops_attention_scores(nn, d) + T.flops_dense(nn, d))), 3), "attn GFLOP", T.flops_attention_scores(nn, d) / 1e9, "dense GFLOP", T.flops_dense(nn, d) / 1e9)
