"""Tests: pytest, or python test_adapt_np.py."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import adapt_np as A


def _numgrad(f, arr, idx, h=1e-6):
    old = arr[idx]; arr[idx] = old + h; fp = f(); arr[idx] = old - h; fm = f(); arr[idx] = old
    return (fp - fm) / (2 * h)


def test_backprop_matches_finite_differences_full_and_lora():
    rng = np.random.default_rng(0)
    X, y = rng.normal(size=(5, 3)), rng.normal(size=(5, 2))
    for mode in ("full", "lora"):
        net = A.Net([3, 6, 2], rng)
        if mode == "lora":
            net.add_lora(2, 4, rng)
            for a in net.adapters: a["B"][:] = rng.normal(0, 0.3, a["B"].shape)      # B = 0 would make dA = 0; test with nonzero B
        loss = lambda: float(((net.forward(X)[0] - y) ** 2).mean())
        out, acts = net.forward(X)
        for key, g in net.grads(acts, 2 * (out - y) / out.size * out.shape[1], mode):   # d mean(.)/d out = 2 (out - y)/size
            p = net.get(key)
            for _ in range(3):
                idx = tuple(rng.integers(s) for s in p.shape)
                num = _numgrad(loss, p, idx)
                assert abs(num - g[idx] / out.shape[1]) < 1e-6 * (1 + abs(num)), (mode, key, idx, num, g[idx] / out.shape[1])


def test_lora_starts_identical_and_adapter_off_restores_base():
    rng = np.random.default_rng(1)
    base = A.Net([1, 16, 1], rng); X = rng.uniform(-2, 2, (50, 1)); y0 = base.forward(X)[0].copy()
    base.add_lora(2, 4, rng)
    assert np.allclose(base.forward(X)[0], y0)                                    # B = 0 -> same function
    A.train(base, X, np.sin(X), 300, 1e-2, "lora", rng=rng)
    assert not np.allclose(base.forward(X)[0], y0) and np.allclose(base.forward(X, adapter=False)[0], y0)   # base untouched
    assert base.n_trainable("lora") == 2 * (16 + 1) + 2 * (1 + 16)


def test_lora_params_and_fraction():
    assert A.lora_params(4096, 4096, 8) == 65536 and abs(A.lora_fraction(4096, 4096, 8) - 2 * 8 / 4096) < 1e-12
    assert A.lora_params(768, 3072, 16) == 16 * (768 + 3072)


def test_truncated_svd_error_and_gradient_descent_agree():
    rng = np.random.default_rng(0)
    M = rng.normal(size=(20, 20)) @ np.diag(0.6 ** np.arange(20)) @ rng.normal(size=(20, 20)) / 5
    s = np.linalg.svd(M, compute_uv=False)
    assert abs(A.truncated_svd_error(M, 3) - np.sqrt((s[3:] ** 2).sum())) < 1e-12
    assert abs(A.fit_low_rank_gd(M, 3, steps=6000, lr=0.05) - A.truncated_svd_error(M, 3)) < 0.02 * A.truncated_svd_error(M, 3)
    low = rng.normal(size=(20, 2)) @ rng.normal(size=(2, 20)) / 4                 # exactly rank 2
    assert A.fit_low_rank_gd(low, 2, steps=6000, lr=0.05) < 1e-3 and A.truncated_svd_error(low, 2) < 1e-10


def test_uniform_quantization_grid_and_six_db_per_bit():
    rng = np.random.default_rng(0); w = rng.normal(size=8192)
    q = A.quantize_uniform(w, 4, block=None); scale = np.abs(w).max() / 7
    assert np.abs(w - q).max() <= scale / 2 + 1e-12 and len(np.unique(np.round(q / scale))) <= 15
    s = [A.sqnr_db(w, A.quantize_uniform(w, b, 64)) for b in (4, 6, 8)]
    assert 10 < s[1] - s[0] < 14 and 10 < s[2] - s[1] < 14                         # about 6 dB per bit


def test_blockwise_beats_per_tensor_with_an_outlier():
    rng = np.random.default_rng(0); w = rng.normal(size=4096); w[7] = 40.0
    assert A.sqnr_db(w, A.quantize_uniform(w, 4, 64)) > A.sqnr_db(w, A.quantize_uniform(w, 4, None)) + 3


def test_normalfloat_levels_and_codebook_quantization():
    L = A.normalfloat_levels(4)
    assert len(L) == 16 and np.all(np.diff(L) > 0) and abs(L[0] + L[-1]) < 1e-9 and abs(L).max() == 1.0
    w = np.random.default_rng(0).normal(size=8192)
    assert A.sqnr_db(w, A.quantize_codebook(w, L, 64)) > A.sqnr_db(w, A.quantize_uniform(w, 4, 64))     # quantile code wins on Gaussian weights


def test_sft_loss_mask_and_data_hygiene():
    nll = [5.0, 5.0, 5.0, 1.0, 2.0]; mask = [False, False, False, True, True]
    assert A.sft_loss(nll, mask) == 1.5 and np.mean(nll) == 3.6
    assert A.validate_sft_record({"instruction": "x", "response": "ok fine"}) == [] and len(A.validate_sft_record({"instruction": " ", "response": "a"})) == 2
    t = ["the cat sat on the mat", "the cat sat on a mat", "completely different words here"]
    assert A.near_duplicates(t, 0.6) == [(0, 1)] and A.near_duplicates(t, 0.95) == []
    recs = [{"p": f"prompt {i}"} for i in range(2000)]; tr, va = A.split_by_hash(recs, "p", 0.1); tr2, va2 = A.split_by_hash(recs, "p", 0.1)
    assert va == va2 and 0.07 < len(va) / len(recs) < 0.13 and len(tr) + len(va) == len(recs)


def test_forgetting_testbed_shows_forgetting_and_replay_fixes_it():
    fA = lambda x: np.sin(2.2 * x) + 0.3 * x; fB = lambda x: 0.8 * np.cos(1.7 * x) - 0.5
    rng = np.random.default_rng(0); XA = rng.uniform(-3, -1, (200, 1)); XB = rng.uniform(1, 3, (30, 1)); gA = np.linspace(-3, -1, 100)[:, None]
    base = A.Net([1, 32, 32, 1], np.random.default_rng(0)); A.train(base, XA, fA(XA), 1500, 1e-2, "full", rng=rng)
    a0 = A.mse(base, gA, fA(gA)); assert a0 < 1e-2
    import copy
    n1 = copy.deepcopy(base); A.train(n1, XB, fB(XB), 800, 3e-3, "full", rng=rng); assert A.mse(n1, gA, fA(gA)) > 20 * a0
    n2 = copy.deepcopy(base); A.train(n2, XB, fB(XB), 800, 3e-3, "full", rng=rng, X_extra=XA[:30], y_extra=fA(XA[:30])); assert A.mse(n2, gA, fA(gA)) < A.mse(n1, gA, fA(gA)) / 5


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
    print("ok")
