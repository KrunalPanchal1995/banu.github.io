"""Adaptation toolkit in plain numpy: an MLP with optional LoRA adapters and manual backprop, low-rank (Eckart-Young) tools,
weight quantization (uniform absmax and a quantile 'NormalFloat-like' 4-bit code), SFT loss masking and dataset hygiene helpers.

See README.md. Column-vector convention as in the LoRA paper: y = W x with W of shape (d_out, d_in); data rows are samples,
so a batch is computed as X @ W.T. LoRA: W = W0 + (alpha/r) B A with B (d_out, r) initialised to 0 and A (r, d_in) Gaussian.
"""
import hashlib
import math
import re

import numpy as np


# ------------------------------------------------------------------ MLP with optional LoRA
class Net:
    """tanh MLP. params: layers[i] = {"W": (d_out, d_in), "b": (d_out,)}; optional adapters[i] = {"A": (r, d_in), "B": (d_out, r)}."""

    def __init__(self, sizes, rng):
        self.layers = [{"W": rng.normal(0, 1 / np.sqrt(a), (b, a)), "b": np.zeros(b)} for a, b in zip(sizes[:-1], sizes[1:])]
        self.adapters = None
        self.scale = 1.0

    def add_lora(self, r, alpha, rng):
        """Attach rank-r adapters to every layer. B = 0 so the adapted net starts identical to the base net."""
        self.adapters = [{"A": rng.normal(0, 1 / np.sqrt(l["W"].shape[1]), (r, l["W"].shape[1])), "B": np.zeros((l["W"].shape[0], r))} for l in self.layers]
        self.scale = alpha / r

    def weight(self, i, adapter=True):
        W = self.layers[i]["W"]
        if adapter and self.adapters is not None:
            W = W + self.scale * self.adapters[i]["B"] @ self.adapters[i]["A"]
        return W

    def forward(self, X, adapter=True):
        acts = [X]
        for i, l in enumerate(self.layers):
            z = acts[-1] @ self.weight(i, adapter).T + l["b"]
            acts.append(np.tanh(z) if i < len(self.layers) - 1 else z)
        return acts[-1], acts

    def grads(self, acts, dy, mode):
        """mode 'full': gradients of W and b for every layer. mode 'lora': gradients of A and B only (W0 and b frozen)."""
        d, out = dy, []
        for i in reversed(range(len(self.layers))):
            if i < len(self.layers) - 1:
                d = d * (1 - acts[i + 1] ** 2)
            G = d.T @ acts[i]                                    # dL/dW_eff, shape (d_out, d_in)
            if mode == "full":
                out.append((("W", i), G)); out.append((("b", i), d.sum(0)))
            else:
                A, B = self.adapters[i]["A"], self.adapters[i]["B"]
                out.append((("A", i), self.scale * B.T @ G)); out.append((("B", i), self.scale * G @ A.T))
            d = d @ self.weight(i)
        return out

    def get(self, key):
        k, i = key
        return self.layers[i][k] if k in ("W", "b") else self.adapters[i][k]

    def n_trainable(self, mode):
        if mode == "full":
            return sum(l["W"].size + l["b"].size for l in self.layers)
        return sum(a["A"].size + a["B"].size for a in self.adapters)


def train(net, X, y, steps, lr, mode="full", batch=None, rng=None, X_extra=None, y_extra=None, record=None):
    """Adam on mean squared error. mode 'full' or 'lora'. record(step, net) is called every 50 steps if given. Extra (replay) data is mixed in."""
    rng = rng or np.random.default_rng(0)
    if X_extra is not None:
        X, y = np.vstack([X, X_extra]), np.vstack([y, y_extra])
    m, v, t = {}, {}, 0
    for s in range(steps):
        idx = rng.choice(len(X), batch, replace=False) if batch and batch < len(X) else slice(None)
        out, acts = net.forward(X[idx])
        dy = 2 * (out - y[idx]) / len(out)
        t += 1
        for key, g in net.grads(acts, dy, mode):
            p = net.get(key)
            m[key] = 0.9 * m.get(key, 0) + 0.1 * g; v[key] = 0.999 * v.get(key, 0) + 0.001 * g * g
            p -= lr * (m[key] / (1 - 0.9 ** t)) / (np.sqrt(v[key] / (1 - 0.999 ** t)) + 1e-8)
        if record and s % 50 == 0:
            record(s, net)
    return net


def mse(net, X, y, adapter=True):
    return float(((net.forward(X, adapter)[0] - y) ** 2).mean())


# ------------------------------------------------------------------ LoRA arithmetic and low-rank approximation
def lora_params(d_out, d_in, r):
    """Trainable parameters of one LoRA adapter: r (d_out + d_in); full matrix: d_out d_in."""
    return r * (d_out + d_in)


def lora_fraction(d_out, d_in, r):
    return lora_params(d_out, d_in, r) / (d_out * d_in)


def truncated_svd_error(M, r):
    """Frobenius error of the best rank-r approximation of M (Eckart-Young): sqrt(sum of squared singular values beyond r)."""
    s = np.linalg.svd(M, compute_uv=False)
    return float(np.sqrt((s[r:] ** 2).sum()))


def fit_low_rank_gd(M, r, steps=4000, lr=0.05, rng=None):
    """Minimise ||M - B A||_F^2 over B (d_out, r), A (r, d_in) by gradient descent from a small random start (plain GD, no tricks).
    Returns the final Frobenius error."""
    rng = rng or np.random.default_rng(0)
    B = rng.normal(0, 0.1, (M.shape[0], r)); A = rng.normal(0, 0.1, (r, M.shape[1]))
    for _ in range(steps):
        R = B @ A - M
        gB, gA = R @ A.T, B.T @ R
        B -= lr * gB; A -= lr * gA
    return float(np.linalg.norm(B @ A - M))


# ------------------------------------------------------------------ quantization
def quantize_uniform(w, bits, block=None):
    """Symmetric absmax quantization: scale = max|w| / (2^(bits-1) - 1) per block; round to integers; return the dequantized weights.
    block=None uses one scale for the whole vector."""
    w = np.asarray(w, float).ravel()
    out = np.empty_like(w)
    qmax = 2 ** (bits - 1) - 1
    blocks = [slice(0, len(w))] if block is None else [slice(i, i + block) for i in range(0, len(w), block)]
    for sl in blocks:
        a = np.abs(w[sl]).max()
        scale = a / qmax if a > 0 else 1.0
        out[sl] = np.clip(np.round(w[sl] / scale), -qmax, qmax) * scale
    return out


def normalfloat_levels(bits=4):
    """A quantile-based code for N(0,1) data in the spirit of QLoRA's NormalFloat: 2^bits levels at equally spaced quantiles of the standard
    normal, rescaled to [-1, 1]. (QLoRA's exact NF4 table differs in detail, e.g. it contains an exact zero; this is a simplified version.)"""
    n = 2 ** bits
    ps = (np.arange(n) + 0.5) / n
    z = np.array([_norm_ppf(p) for p in ps])
    return z / np.abs(z).max()


def _norm_ppf(p):
    """Inverse normal CDF by bisection (no scipy needed)."""
    lo, hi = -10.0, 10.0
    for _ in range(80):
        mid = (lo + hi) / 2
        if 0.5 * (1 + math.erf(mid / math.sqrt(2))) < p:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def quantize_codebook(w, levels, block=64):
    """Block-wise absmax scaling to [-1, 1], then snap each value to the nearest codebook level; returns dequantized weights."""
    w = np.asarray(w, float).ravel(); out = np.empty_like(w)
    for i in range(0, len(w), block):
        x = w[i:i + block]; a = np.abs(x).max() or 1.0
        out[i:i + block] = levels[np.abs((x / a)[:, None] - levels[None]).argmin(1)] * a
    return out


def sqnr_db(w, wq):
    """Signal-to-quantization-noise ratio in dB: 10 log10(sum w^2 / sum (w - wq)^2)."""
    w = np.asarray(w, float).ravel()
    return float(10 * np.log10((w ** 2).sum() / ((w - wq) ** 2).sum()))


# ------------------------------------------------------------------ SFT: loss masking and data hygiene
def sft_loss(token_nll, is_response):
    """Mean negative log-likelihood over RESPONSE tokens only. token_nll: per-token NLL; is_response: boolean mask. (Prompt tokens are context,
    not targets, so they are masked out of the loss.)"""
    nll = np.asarray(token_nll, float); m = np.asarray(is_response, bool)
    return float(nll[m].mean())


def validate_sft_record(rec):
    """Return a list of problems for a record {"instruction": str, "response": str, optional "input": str}."""
    probs = []
    for k in ("instruction", "response"):
        if not isinstance(rec.get(k), str) or not rec[k].strip():
            probs.append(f"missing or empty {k}")
    if isinstance(rec.get("response"), str) and rec["response"].strip() and len(rec["response"].split()) < 2:
        probs.append("response shorter than 2 words")
    return probs


def jaccard(a, b):
    sa, sb = set(re.findall(r"\w+", a.lower())), set(re.findall(r"\w+", b.lower()))
    return len(sa & sb) / len(sa | sb) if sa | sb else 1.0


def near_duplicates(texts, threshold=0.8):
    """Pairs (i, j) of texts whose word-set Jaccard similarity is >= threshold."""
    return [(i, j) for i in range(len(texts)) for j in range(i + 1, len(texts)) if jaccard(texts[i], texts[j]) >= threshold]


def split_by_hash(records, key, val_frac=0.1):
    """Deterministic train/validation split by a hash of the key text: the same prompt always lands on the same side, so near-copies cannot leak."""
    tr, va = [], []
    for r in records:
        h = int(hashlib.sha256(r[key].encode()).hexdigest(), 16) % 10000 / 10000
        (va if h < val_frac else tr).append(r)
    return tr, va


def main():
    rng = np.random.default_rng(0)
    M = rng.normal(size=(64, 64)) @ np.diag(0.7 ** np.arange(64)) @ rng.normal(size=(64, 64)) / 8
    for r in (1, 4, 16):
        print("rank", r, "optimal error", round(truncated_svd_error(M, r), 4), " gradient descent", round(fit_low_rank_gd(M, r), 4))
    w = rng.normal(size=4096)
    print("SQNR dB, 8-bit:", round(sqnr_db(w, quantize_uniform(w, 8, 64)), 1), " 4-bit:", round(sqnr_db(w, quantize_uniform(w, 4, 64)), 1))


if __name__ == "__main__":
    main()
