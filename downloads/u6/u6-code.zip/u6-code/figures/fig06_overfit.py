"""Fig 6: fine-tuning on very little data: training and held-out error against steps (full fine-tuning, 1-D regression, noisy targets)."""
from _common import *
use_code("adapt/adapt_np")
import adapt_np as AD, copy
fA = lambda x: np.sin(2.2 * x) + 0.3 * x; fB = lambda x: 0.8 * np.cos(1.7 * x) - 0.5
rng = np.random.default_rng(0); XA = rng.uniform(-3, -1, (300, 1)); base = AD.Net([1, 64, 64, 1], np.random.default_rng(0)); AD.train(base, XA, fA(XA), 3000, 1e-2, "full", rng=rng)
gB = np.linspace(1, 3, 200)[:, None]; fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained"); stats = {}
for ax, n in zip(axs, (8, 100)):
    r = np.random.default_rng(10 + n); XB = r.uniform(1, 3, (n, 1)); yB = fB(XB) + 0.3 * r.normal(size=(n, 1)); net = copy.deepcopy(base); rec = []
    AD.train(net, XB, yB, 2500, 3e-3, "full", rng=r, record=lambda s, nt: rec.append((s, AD.mse(nt, XB, yB), AD.mse(nt, gB, fB(gB)))))
    R = np.array(rec); ax.plot(R[:, 0], R[:, 1], color=PAL["blue"], label="training error (noisy)"); ax.plot(R[:, 0], R[:, 2], color=PAL["red"], label="error against the true function"); ax.axhline(0.09, color=PAL["grey"], ls=":"); ax.text(R[-1, 0] * .55, 0.097, "noise floor 0.09", fontsize=6, color=PAL["grey"])
    ax.set(xlabel="fine-tuning steps", ylabel="mean squared error", yscale="log", title=f"{n} fine-tuning examples"); ax.legend(fontsize=6)
    stats[n] = (R[:, 2].min(), R[R[:, 2].argmin(), 0], R[-1, 2], R[-1, 1])
save(fig, out("fig06_overfit.png"))
for n, (mn, at, last, tr) in stats.items(): print(f"n={n}: best true-function error {mn:.4f} at step {int(at)}; at the end {last:.4f}; final training error {tr:.4f}")
