"""Fig 4: weight quantization: SQNR against bits, block size, an outlier, and a quantile (NormalFloat-like) 4-bit code."""
from _common import *
use_code("adapt/adapt_np")
import adapt_np as AD
rng = np.random.default_rng(0); w = rng.normal(size=16384); bits = [2, 3, 4, 5, 6, 8]
fig, axs = plt.subplots(1, 3, figsize=(8.4, 3.2), layout="constrained")
for blk, c, ls in [(None, PAL["red"], "--"), (256, PAL["orange"], "-."), (64, PAL["blue"], "-")]: axs[0].plot(bits, [AD.sqnr_db(w, AD.quantize_uniform(w, b, blk)) for b in bits], "o" + ls, color=c, label="one scale for all" if blk is None else f"block {blk}")
axs[0].plot(bits, [6.02 * b - 1.0 for b in bits], ":", color=PAL["grey"], label="6 dB per bit"); axs[0].set(xlabel="bits per weight", ylabel="SQNR (dB, higher = better)"); axs[0].legend(fontsize=6)
wo = w.copy(); wo[100] = 40.0; blks = [None, 1024, 256, 64, 32, 16]
axs[1].plot(range(len(blks)), [AD.sqnr_db(wo, AD.quantize_uniform(wo, 4, b)) for b in blks], "o-", color=PAL["red"], label="with one outlier (40 sigma)"); axs[1].plot(range(len(blks)), [AD.sqnr_db(w, AD.quantize_uniform(w, 4, b)) for b in blks], "s--", color=PAL["blue"], label="no outlier")
axs[1].set_xticks(range(len(blks)), ["all" if b is None else str(b) for b in blks]); axs[1].set(xlabel="block size (weights sharing one scale)", ylabel="4-bit SQNR (dB)"); axs[1].legend(fontsize=6)
L = AD.normalfloat_levels(4); U = np.linspace(-1, 1, 15)
axs[2].hist(w / np.abs(w).max(), 80, density=True, color=PAL["grey"], alpha=.5); axs[2].vlines(U, 0, .5, color=PAL["blue"], lw=.8, label="uniform levels (15)"); axs[2].vlines(L, .5, 1.0, color=PAL["red"], lw=.8, label="quantile levels (16)")
axs[2].set(xlabel="weight / absmax", ylabel="density / levels", yticks=[]); axs[2].legend(fontsize=6)
save(fig, out("fig04_quant.png"))
print("SQNR dB, per-tensor / block 256 / block 64:")
for b in bits: print(" bits", b, [round(AD.sqnr_db(w, AD.quantize_uniform(w, b, blk)), 1) for blk in (None, 256, 64)])
print("outlier, 4-bit: blocks", blks, "->", [round(AD.sqnr_db(wo, AD.quantize_uniform(wo, 4, b)), 1) for b in blks]); print("no outlier       ->", [round(AD.sqnr_db(w, AD.quantize_uniform(w, 4, b)), 1) for b in blks])
print("4-bit block 64 on Gaussian: uniform", round(AD.sqnr_db(w, AD.quantize_uniform(w, 4, 64)), 2), "dB   quantile code", round(AD.sqnr_db(w, AD.quantize_codebook(w, L, 64)), 2), "dB")
print("memory: fp16 2 bytes/weight; 4-bit + one fp16 scale per 64 weights = ", 4 / 8 + 2 / 64, "bytes/weight (", round(2 / (4 / 8 + 2 / 64), 2), "x smaller)")
