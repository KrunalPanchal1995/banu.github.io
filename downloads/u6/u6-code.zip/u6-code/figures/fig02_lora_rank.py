"""Fig 2: best rank-r approximation error (Eckart-Young) against what plain gradient descent on B, A finds."""
from _common import *
use_code("adapt/adapt_np")
import adapt_np as AD
rng = np.random.default_rng(0); n = 64
U, _ = np.linalg.qr(rng.normal(size=(n, n))); V, _ = np.linalg.qr(rng.normal(size=(n, n)))
targets = {"singular values decay slowly (0.85^i)": U @ np.diag(0.85 ** np.arange(n)) @ V.T * 4, "exactly rank 4": U[:, :4] @ np.diag([4, 3, 2, 1.0]) @ V[:, :4].T}
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained"); rs = [1, 2, 4, 8, 16, 32]
for ax, (name, M) in zip(axs, targets.items()):
    opt = [AD.truncated_svd_error(M, r) for r in rs]; gd = [AD.fit_low_rank_gd(M, r, steps=5000, lr=0.03, rng=np.random.default_rng(1)) for r in rs]; tot = np.linalg.norm(M)
    ax.semilogy(rs, np.maximum(opt, 1e-9), "o-", color=PAL["blue"], label="best possible (truncated SVD)"); ax.semilogy(rs, np.maximum(gd, 1e-9), "s--", color=PAL["orange"], label="gradient descent on B, A")
    ax.set(xscale="log", xlabel="LoRA rank r", ylabel="||target - B A||  (Frobenius)", title=name, ylim=(1e-4, tot * 2)); ax.legend(fontsize=6)
    print(name, "||M|| =", round(tot, 3)); print("  r:", rs); print("  optimal :", np.round(opt, 4)); print("  GD      :", np.round(gd, 4))
save(fig, out("fig02_lora_rank.png"))
