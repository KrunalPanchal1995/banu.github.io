"""Fig 3: catastrophic forgetting in a small network, and what full fine-tuning, LoRA and replay do (1-D regression, 3 seeds)."""
from _common import *
use_code("adapt/adapt_np")
import adapt_np as AD, copy
fA = lambda x: np.sin(2.2 * x) + 0.3 * x; fB = lambda x: 0.8 * np.cos(1.7 * x) - 0.5
def data(lo, hi, n, f, rng, noise=0.02): x = rng.uniform(lo, hi, (n, 1)); return x, f(x) + noise * rng.normal(size=(n, 1))
gA = np.linspace(-3, -1, 200)[:, None]; gB = np.linspace(1, 3, 200)[:, None]
def setup(seed):
    rng = np.random.default_rng(seed); XA, yA = data(-3, -1, 300, fA, rng); XB, yB = data(1, 3, 30, fB, rng)
    base = AD.Net([1, 64, 64, 1], np.random.default_rng(seed)); AD.train(base, XA, yA, 3000, 1e-2, "full", rng=rng); return base, XA, yA, XB, yB
cfgs = {"full fine-tuning": ("full", 0, 3e-3, 0), "LoRA r=2": ("lora", 2, 3e-3, 0), "LoRA r=8": ("lora", 8, 1e-2, 0), "full + replay (30 old examples)": ("full", 0, 3e-3, 1), "LoRA r=8 + replay": ("lora", 8, 1e-2, 1)}
def adapt(base, XA, yA, XB, yB, mode, r, lr, rep, seed, rec=None):
    net = copy.deepcopy(base)
    if mode == "lora": net.add_lora(r, 2 * r, np.random.default_rng(seed + 1))
    ex = (XA[:30], yA[:30]) if rep else (None, None)
    AD.train(net, XB, yB, 1500, lr, mode, rng=np.random.default_rng(seed + 2), X_extra=ex[0], y_extra=ex[1], record=rec); return net
res = {k: [] for k in cfgs}; traj = {k: [] for k in ("full fine-tuning", "LoRA r=2", "LoRA r=8")}; curves = {}; base0 = None; baseA = []
for seed in range(3):
    base, XA, yA, XB, yB = setup(seed); baseA.append(AD.mse(base, gA, fA(gA)))
    if seed == 0: base0 = base
    for k, (mode, r, lr, rep) in cfgs.items():
        rec = []; net = adapt(base, XA, yA, XB, yB, mode, r, lr, rep, seed, (lambda s, n, rec=rec: rec.append((AD.mse(n, gA, fA(gA)), AD.mse(n, gB, fB(gB))))) if k in traj else None)
        res[k].append((AD.mse(net, gA, fA(gA)), AD.mse(net, gB, fB(gB))))
        if k in traj: traj[k].append(np.array(rec))
        if seed == 0: curves[k] = net.forward(np.vstack([gA, gB]))[0]
fig = plt.figure(figsize=(8.2, 5.4), layout="constrained"); gs = fig.add_gridspec(2, 2)
ax = fig.add_subplot(gs[0, :]); xs = np.vstack([gA, gB])[:, 0]; ax.plot(xs, np.vstack([fA(gA), fB(gB)])[:, 0], "k", lw=1, label="targets (task A left, task B right)")
for k, c in [("full fine-tuning", PAL["red"]), ("LoRA r=8", PAL["orange"]), ("full + replay (30 old examples)", PAL["green"])]: ax.plot(xs[:200], curves[k][:200, 0], color=c, lw=1.8, label=k + ": task A region"); ax.plot(xs[200:], curves[k][200:, 0], color=c, lw=1.8, ls=":")
ax.plot(xs[:200], base0.forward(gA)[0][:, 0], color=PAL["blue"], ls="--", lw=1.2, label="before adaptation"); ax.set(xlabel="x", ylabel="y", ylim=(-3, 3)); ax.legend(fontsize=6, ncol=2, loc="lower right")
ax = fig.add_subplot(gs[1, 0])
for k, c in [("full fine-tuning", PAL["red"]), ("LoRA r=2", PAL["blue"]), ("LoRA r=8", PAL["orange"])]:
    T = np.array([t[:30] for t in traj[k]]); ax.loglog(np.median(T[:, :, 1], 0) + 1e-6, np.median(T[:, :, 0], 0) + 1e-6, "-", color=c, label=k)
ax.set(xlabel="error on the NEW task B (lower = learned)", ylabel="error on OLD task A (forgetting)"); ax.invert_xaxis(); ax.legend(fontsize=7)
ax = fig.add_subplot(gs[1, 1]); names = list(cfgs); a = [np.mean([r[0] for r in res[k]]) for k in names]; b = [np.mean([r[1] for r in res[k]]) for k in names]
y = np.arange(len(names)); ax.barh(y - .2, a, .4, color=PAL["red"], label="error on old task A"); ax.barh(y + .2, [max(v, 0.02) for v in b], .4, color=PAL["blue"], label="error on new task B (drawn at least 0.02 wide)")
for yy, va, vb in zip(y, a, b): ax.text(max(va, 0.02) + .08, yy - .2, f"{va:.4f}" if va < 0.01 else f"{va:.2f}", va="center", fontsize=6); ax.text(max(vb, 0.02) + .08, yy + .2, f"{vb:.4f}", va="center", fontsize=6)
ax.set_yticks(y, [n.replace(" (30 old examples)", "") for n in names], fontsize=6); ax.invert_yaxis(); ax.set(xlim=(0, 4.6), xlabel="final mean squared error (mean of 3 seeds)"); ax.legend(fontsize=5.5, loc="lower right")
save(fig, out("fig03_forgetting.png"))
print("before adaptation: A error", np.round(np.mean(baseA), 6))
for k in names: print(f"{k:34s} A {np.mean([r[0] for r in res[k]]):.4f} (min {min(r[0] for r in res[k]):.3f} max {max(r[0] for r in res[k]):.3f})   B {np.mean([r[1] for r in res[k]]):.4f}   trainable {'-'}")
for k in traj:
    T = [t for t in traj[k]]
    for thr in (0.5, 0.05):
        v = []
        for t in T:
            ok = np.where(t[:, 1] < thr)[0]; v.append(t[ok[0], 0] if len(ok) else np.nan)
        print(f"{k:18s} A error when B error first < {thr}:", np.round(v, 3))

# sensitivity to the learning rate (printed, quoted in the session text): LoRA r=2 at a larger learning rate
for lr in (3e-3, 1e-2, 3e-2):
    v = []
    for seed in range(3):
        base, XA, yA, XB, yB = setup(seed); net = adapt(base, XA, yA, XB, yB, "lora", 2, lr, 0, seed); v.append((AD.mse(net, gA, fA(gA)), AD.mse(net, gB, fB(gB))))
    print(f"LoRA r=2, learning rate {lr:g}: final A error {np.round([x[0] for x in v], 3)} mean {np.mean([x[0] for x in v]):.3f}; B error mean {np.mean([x[1] for x in v]):.4f}")
