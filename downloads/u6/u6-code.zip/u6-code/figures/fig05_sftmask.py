"""Fig 5: SFT loss masking: per-character NLL of a prompt+response string under a character n-gram model; loss over all tokens vs response only."""
from _common import *
use_code("genmodels/genmodels_np")
import genmodels_np as GM
text = open(os.path.join(KB, "Syllabus.md"), encoding="utf-8").read().lower(); text = " ".join("".join(c if c.isalpha() or c == " " else " " for c in text).split())
m = GM.CharNgram(4, 0.05).fit(text)
prompt = "instruction what is rag response "; resp = "retrieve then generate"; s = prompt + resp
pad = "\x00" * 3; t = pad + s; nll = np.array([-np.log(m.prob(t[i:i + 3], t[i + 3])) for i in range(len(s))]); mask = np.array([i >= len(prompt) for i in range(len(s))])
fig, ax = plt.subplots(figsize=(7.8, 2.9)); ax.bar(range(len(s)), nll, color=[PAL["orange"] if k else PAL["blue"] for k in mask])
ax.set_xticks(range(len(s)), [c if c != " " else "_" for c in s], fontsize=6); ax.set(ylabel="NLL of each character (nats)", xlabel="characters of: prompt (blue, masked out of the loss) + response (orange, trained on)")
ax.axhline(nll.mean(), color=PAL["grey"], ls="--"); ax.axhline(nll[mask].mean(), color=PAL["red"]); ax.text(0, nll.mean() + .15, f"mean over all = {nll.mean():.2f}", color=PAL["grey"], fontsize=7); ax.text(len(prompt) + .5, nll[mask].mean() + .15, f"response only = {nll[mask].mean():.2f}", color=PAL["red"], fontsize=7)
save(fig, out("fig05_sftmask.png")); print("chars", len(s), "prompt", int((~mask).sum()), "response", int(mask.sum()), "mean all", nll.mean().round(3), "response only", nll[mask].mean().round(3), "prompt only", nll[~mask].mean().round(3))
