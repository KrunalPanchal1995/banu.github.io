"""Fig 1: LoRA trainable-parameter fraction against rank, and total adapter size for a hypothetical stack of layers."""
from _common import *
use_code("adapt/adapt_np")
import adapt_np as AD
rs = np.array([1, 2, 4, 8, 16, 32, 64, 128, 256]); fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
for d, c in [(768, PAL["blue"]), (4096, PAL["red"])]:
    axs[0].loglog(rs, [100 * AD.lora_fraction(d, d, r) for r in rs], "o-", color=c, label=f"square layer, width d = {d}"); print(d, {int(r): round(100 * AD.lora_fraction(d, d, int(r)), 3) for r in rs})
axs[0].set(xlabel="LoRA rank r", ylabel="trainable parameters as % of the full matrix"); axs[0].legend(fontsize=7); axs[0].axhline(100, color=PAL["grey"], ls=":")
L, d = 32, 4096; rr = [4, 8, 16, 64]
full = L * 4 * d * d
for r, c in zip(rr, [PAL["green"], PAL["blue"], PAL["orange"], PAL["purple"]]):
    n = L * 4 * AD.lora_params(d, d, r); axs[1].bar(str(r), n / 1e6, color=c); axs[1].text(str(r), n / 1e6 + .5, f"{n/1e6:.1f}M", ha="center", fontsize=8)
    print("r", r, "adapter params (all 4 attention matrices, 32 layers)", n, "fraction of those matrices", n / full)
axs[1].set(xlabel="LoRA rank r", ylabel="adapter parameters (millions)", title="32 layers, d = 4096, adapters on Wq, Wk, Wv, Wo")
print("attention matrices total", full, "= %.1fM" % (full / 1e6))
save(fig, out("fig01_lora_params.png"))
