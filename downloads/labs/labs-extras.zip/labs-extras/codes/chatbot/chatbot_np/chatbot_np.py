"""A multi-turn chatbot loop with a context-window budget (Lab 6).

The model is any object with `complete(messages) -> str` (the same protocol as prompting_tools.MockLLM and a real API
client wrapped in a few lines). The chatbot keeps the whole history, but only sends what fits in the context window:
system messages and pinned messages always stay, and the OLDEST other messages are dropped first (prompting_tools.fit_context).
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "llm", "prompting_tools"))
from prompting_tools import approx_tokens, fit_context  # noqa: E402


class Chatbot:
    def __init__(self, llm, system, window=200, reserve_output=40, count=approx_tokens):
        self.llm, self.window, self.reserve, self.count = llm, window, reserve_output, count
        self.history = [{"role": "system", "content": system}]
        self.last_dropped = []

    def pin(self, text):
        """Add a user message that must never be trimmed (e.g. the user's name or a constraint)."""
        self.history.append({"role": "user", "content": text, "pin": True})

    def say(self, text):
        """Append the user turn, send the trimmed history to the model, store and return its reply."""
        self.history.append({"role": "user", "content": text})
        sent, self.last_dropped = fit_context(self.history, self.window, self.reserve, self.count)
        reply = self.llm.complete([{k: v for k, v in m.items() if k != "pin"} for m in sent])
        self.history.append({"role": "assistant", "content": reply})
        return reply

    def tokens_sent_last(self):
        sent, _ = fit_context(self.history, self.window, self.reserve, self.count)
        return sum(self.count(m["content"]) for m in sent)


def main():
    from prompting_tools import MockLLM
    bot = Chatbot(MockLLM(), "You are a helpful tutor.", window=60, reserve_output=10)
    bot.pin("My name is Asha.")
    for q in ("hello there", "what is 2+3", "tell me about transformers and attention please", "and what about beams in decoding"):
        print("user:", q, "->", bot.say(q), "| dropped:", len(bot.last_dropped))


if __name__ == "__main__":
    main()
