"""Run: python example_basic.py   (offline: uses the mock model from Unit 4)."""
import chatbot_np
chatbot_np.main()
