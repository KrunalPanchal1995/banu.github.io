"""Tests: pytest, or python test_chatbot_np.py."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import chatbot_np as C


class Echo:
    def __init__(self):
        self.seen = None

    def complete(self, messages):
        self.seen = messages
        return "ok"


def test_system_and_pin_survive_trimming():
    llm = Echo()
    bot = C.Chatbot(llm, "SYS", window=30, reserve_output=5)
    bot.pin("PINNED fact")
    for i in range(10):
        bot.say(f"message number {i} with some padding words")
    contents = [m["content"] for m in llm.seen]
    assert contents[0] == "SYS" and "PINNED fact" in contents
    assert contents[-1].startswith("message number 9")
    assert bot.last_dropped, "old turns should have been dropped"
    assert bot.tokens_sent_last() <= 30 - 5 + 10  # budget plus the one oversize-latest allowance


def test_history_is_complete_even_when_trimmed():
    bot = C.Chatbot(Echo(), "SYS", window=20, reserve_output=5)
    for i in range(6):
        bot.say(f"turn {i} padding padding")
    assert len([m for m in bot.history if m["role"] == "user"]) == 6


def test_pin_flag_not_sent_to_model():
    llm = Echo()
    bot = C.Chatbot(llm, "SYS", window=100)
    bot.pin("keep")
    bot.say("hi")
    assert all("pin" not in m for m in llm.seen)


if __name__ == "__main__":
    test_system_and_pin_survive_trimming(); test_history_is_complete_even_when_trimmed(); test_pin_flag_not_sent_to_model()
    print("ok")
