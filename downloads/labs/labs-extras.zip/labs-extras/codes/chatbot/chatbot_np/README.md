# chatbot_np

> Multi-turn chatbot loop with a context-window budget; model-agnostic (`complete(messages) -> str`).

**Topic:** chatbot | **Created for:** Lab 6 | **Status:** tested offline with the Unit 4 mock model

## What this code is for
Shows how a chat application sends the conversation to a stateless model: it re-sends history every turn, so it must trim to the context window. System and pinned messages stay; the oldest other turns go first (`prompting_tools.fit_context`).

## Capabilities
- `Chatbot(llm, system, window, reserve_output)`: holds the full history.
- `pin(text)`: a user message that is never trimmed.
- `say(text)`: one turn; returns the reply; `last_dropped` lists what was trimmed.
- `tokens_sent_last()`: approximate tokens in the last request (4 characters per token heuristic).

## Quick start
```bash
python example_basic.py
python tests/test_chatbot_np.py   # prints ok
```
To use a real model, wrap your API client in a class with `complete(messages)`; nothing else changes.
