# Lab extras

Lab 6 chatbot module and Lab 1 notebook. Run: python codes/chatbot/chatbot_np/example_basic.py
The Lab 1 notebook was written but NOT executed by the author.
