"""Fig 2: which stage is responsible for each of the 26 questions, for four configurations."""
from _common import *
use_code("capstone/campus_assistant")
import campus_assistant as C
hb, qs = C.load_handbook(), C.load_queries()
cfgs = [("BM25, never refuse", {}), ("+ light stemming", dict(stem=True)), ("+ coverage >= 0.5", dict(cover_min=0.5)), ("stemming + coverage >= 0.5", dict(stem=True, cover_min=0.5))]
labels = ["correct", "correct refusal", "wrong sentence", "wrong chunk", "refused", "answered anyway"]
col = {"correct": PAL["green"], "correct refusal": PAL["sky"], "wrong sentence": PAL["orange"], "wrong chunk": PAL["red"], "refused": PAL["purple"], "answered anyway": PAL["black"]}
fig, ax = plt.subplots(figsize=(7.8, 3.0))
for r, (name, kw) in enumerate(cfgs):
    a = C.Assistant(hb, **kw)
    for j, q in enumerate(qs):
        d = C.diagnose(a, q)
        ax.add_patch(plt.Rectangle((j, len(cfgs) - 1 - r), 0.9, 0.85, fc=col[d], ec="none"))
    counts = {l: sum(C.diagnose(a, q) == l for q in qs) for l in labels}
    print(name, {k: v for k, v in counts.items() if v})
ax.set_xlim(0, len(qs)); ax.set_ylim(0, len(cfgs)); ax.set_yticks([len(cfgs) - 1 - r + 0.42 for r in range(len(cfgs))], [c[0] for c in cfgs], fontsize=7.5)
ax.axvline(20, color=PAL["black"], lw=1); ax.set_xticks([10, 23], ["20 answerable questions", "6 unanswerable"], fontsize=7.5); ax.grid(False)
ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, fc=col[l]) for l in labels], labels=labels, ncol=6, fontsize=6.3, loc="upper center", bbox_to_anchor=(0.45, -0.12), frameon=False)
save(fig, out("fig02_outcomes.png"))
