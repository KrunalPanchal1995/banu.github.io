"""Fig 4: how wide are the error bars with a test set this small? Wilson 95% intervals for our numbers, and the interval width against n."""
from _common import *
use_code("capstone/campus_assistant"); use_code("evaluation/evaluation_np")
import campus_assistant as C, evaluation_np as EV
hb, qs = C.load_handbook(), C.load_queries()
rows = []
for name, kw in [("BM25", {}), ("+ stemming", dict(stem=True)), ("+ coverage 0.5", dict(cover_min=0.5)), ("stem + cov 0.5", dict(stem=True, cover_min=0.5))]:
    r = C.evaluate(C.Assistant(hb, **kw), qs); k = round(r["accuracy"] * r["n_answerable"]); rows.append((name, k, r["n_answerable"]))
fig, axs = plt.subplots(1, 2, figsize=(8.0, 3.0))
for i, (name, k, n) in enumerate(rows):
    lo, hi = EV.wilson(k, n); axs[0].errorbar(k / n, i, xerr=[[k / n - lo], [hi - k / n]], fmt="o", color=PAL["blue"], capsize=3)
    print(name, "accuracy %d/%d = %.2f, 95%% interval [%.2f, %.2f]" % (k, n, k / n, lo, hi))
axs[0].set_yticks(range(len(rows)), [r[0] for r in rows], fontsize=7.5); axs[0].invert_yaxis(); axs[0].set(xlabel="accuracy on the 20 answerable questions", xlim=(0.4, 1.02))
ns = np.arange(10, 401)
for p, c in ((0.9, PAL["blue"]), (0.7, PAL["orange"])):
    w = [(lambda a, b: b - a)(*EV.wilson(round(p * n), n)) for n in ns]; axs[1].plot(ns, w, color=c, label=f"true accuracy {p}")
axs[1].axvline(20, color=PAL["red"], ls=":"); axs[1].text(24, 0.5, "this test set", fontsize=7, color=PAL["red"]); axs[1].set(xlabel="number of test questions n", ylabel="width of the 95% interval"); axs[1].legend(fontsize=7)
save(fig, out("fig04_intervals.png"))
for n in (20, 50, 100, 200): print("n=%d width at p=0.9: %.2f" % (n, (lambda a, b: b - a)(*EV.wilson(round(0.9 * n), n))))
