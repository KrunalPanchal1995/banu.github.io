"""Fig 3: choose the coverage threshold on a development half, report it on the other half (honest evaluation)."""
from _common import *
use_code("capstone/campus_assistant")
import campus_assistant as C
hb, qs = C.load_handbook(), C.load_queries()
ans = [q for q in qs if q["answerable"]]; un = [q for q in qs if not q["answerable"]]
dev = ans[0::2] + un[0::2]; test = ans[1::2] + un[1::2]
ths = np.round(np.arange(0, 1.0001, 0.05), 2)
def curves(sub, **kw):
    r = [C.evaluate(C.Assistant(hb, cover_min=t, **kw), sub) for t in ths]
    return np.array([x["false_refusal"] for x in r]), np.array([x["hallucinated_on_unanswerable"] for x in r])
fig, axs = plt.subplots(1, 2, figsize=(8.2, 3.1), sharey=True)
chosen = {}
for ax, (name, kw) in zip(axs, [("without stemming", {}), ("with light stemming", dict(stem=True))]):
    fd, hd = curves(dev, **kw); ft, ht = curves(test, **kw)
    cost = fd + hd                       # equal weight to refusing a good question and answering a bad one (a choice: see text)
    k = int(np.argmin(cost + 1e-6 * ths)); chosen[name] = (ths[k], fd[k], hd[k], ft[k], ht[k])
    ax.plot(ths, fd, color=PAL["purple"], label="dev: refused answerable"); ax.plot(ths, hd, color=PAL["black"], label="dev: answered unanswerable")
    ax.plot(ths, ft, "--", color=PAL["purple"], label="test: refused answerable"); ax.plot(ths, ht, "--", color=PAL["black"], label="test: answered unanswerable")
    ax.axvline(ths[k], color=PAL["green"], lw=1); ax.set(title=name, xlabel="coverage threshold"); 
axs[0].set_ylabel("share of questions"); h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, ncol=4, fontsize=6.5, loc="outside lower center", frameon=False)
save(fig, out("fig03_threshold.png"))
print("dev has", len([q for q in dev if q["answerable"]]), "answerable +", len([q for q in dev if not q["answerable"]]), "unanswerable; test has", len([q for q in test if q["answerable"]]), "+", len([q for q in test if not q["answerable"]]))
for k, v in chosen.items(): print(k, "chosen threshold %.2f | dev: refused-answerable %.2f answered-unanswerable %.2f | test: %.2f %.2f" % v)
