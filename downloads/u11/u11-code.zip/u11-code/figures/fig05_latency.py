"""Fig 5: time per question in this process, on this CPU (a measurement of the toy service, not of any LLM)."""
import time
from _common import *
use_code("capstone/campus_assistant")
import campus_assistant as C
hb, qs = C.load_handbook(), C.load_queries()
res = {}
for name, kw in (("BM25", {}), ("BM25 + LSA fused (RRF)", dict(hybrid=True))):
    a = C.Assistant(hb, cover_min=0.5, **kw); ts = []
    for _ in range(30):
        for q in qs:
            t = time.perf_counter(); C.handle_request(a, {"question": q["q"]}); ts.append((time.perf_counter() - t) * 1e3)
    res[name] = np.array(ts)
fig, ax = plt.subplots(figsize=FIG["single"])
bins = np.linspace(0, max(np.percentile(v, 99.5) for v in res.values()), 50)
for (name, v), c in zip(res.items(), (PAL["blue"], PAL["orange"])):
    ax.hist(v, bins=bins, alpha=0.6, color=c, label=name); ax.axvline(np.percentile(v, 95), color=c, ls="--", lw=1.2)
    print(name, "n=%d  p50 %.2f ms  p95 %.2f ms  max %.2f ms" % (len(v), np.percentile(v, 50), np.percentile(v, 95), v.max()))
ax.set(xlabel="milliseconds per question (dashed line = p95)", ylabel="number of requests"); ax.legend()
save(fig, out("fig05_latency.png"))
