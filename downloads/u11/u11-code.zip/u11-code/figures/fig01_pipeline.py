"""Fig 1: the capstone pipeline as stages, with the number each stage can be measured by."""
from _common import *
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
stages = [("Handbook\n(10 text files)", "data", PAL["grey"]), ("Chunk\n400 characters", "chunk_corpus", PAL["sky"]), ("Retrieve\nBM25, top 3", "BM25 / RRF", PAL["blue"]),
          ("Select\nbest sentence", "extractive_answer", PAL["orange"]), ("Check\ncoverage and\ngrounding", "query_coverage,\ngrounded_score", PAL["green"]), ("Answer with\nsource, or refuse", "handle_request", PAL["purple"])]
measures = ["", "", "retrieval\nrecall@k", "answer\naccuracy", "refusal\nquality", "latency,\ncost"]
fig, ax = plt.subplots(figsize=(8.4, 2.9)); ax.set_xlim(0, 12.6); ax.set_ylim(0, 4); ax.axis("off"); ax.grid(False)
for i, (t, f, c) in enumerate(stages):
    x = 0.15 + i * 2.1
    ax.add_patch(FancyBboxPatch((x, 1.7), 1.7, 1.5, boxstyle="round,pad=0.04", fc=c, ec="none", alpha=0.85))
    ax.text(x + 0.85, 2.45, t, ha="center", va="center", fontsize=8.6, color="white", weight="bold")
    ax.text(x + 0.85, 1.35, f, ha="center", va="top", fontsize=7.4, family="monospace")
    if measures[i]:
        ax.text(x + 0.85, 3.6, measures[i], ha="center", va="center", fontsize=8, color=PAL["black"], style="italic")
    if i < len(stages) - 1:
        ax.add_patch(FancyArrowPatch((x + 1.75, 2.45), (x + 2.1, 2.45), arrowstyle="-|>", mutation_scale=9, color=PAL["black"]))
ax.text(6.3, 0.25, "Every stage can fail on its own, so every stage gets its own measurement (Section 3.3).", ha="center", fontsize=9)
save(fig, out("fig01_pipeline.png"))
