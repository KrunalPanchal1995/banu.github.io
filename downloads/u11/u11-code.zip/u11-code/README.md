# Capstone: a Grounded Assistant, Built, Evaluated and Deployed: code bundle

Run everything from this folder with Python 3.9+ and `pip install -r requirements.txt` (numpy, matplotlib).

- `codes/`   the importable modules with their own README, example and tests
- `figures/` the scripts that produced every figure in the PDF (run: `python figures/fig01_*.py`)

Quick test: `python codes/capstone/campus_assistant/tests/test_campus_assistant.py`  ->  prints `ok`.
MIT licence. Course site: see the Downloads page.
