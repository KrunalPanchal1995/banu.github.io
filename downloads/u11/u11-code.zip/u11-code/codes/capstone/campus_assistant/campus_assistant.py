"""Capstone worked example: a grounded question-answering assistant over a small college handbook.

Pipeline (each stage is a function you can replace):  chunk -> retrieve (BM25, optionally fused with LSA by RRF) -> pick answer
sentences from the retrieved text -> check groundedness -> answer with citations, or refuse.

It reuses code from earlier units: rag_np (Unit 5: chunking, BM25, LSA, rrf, extractive_answer) and evaluation_np (Unit 9: grounded_score).
The college in data/ is fictional.
"""
import glob
import json
import os
import re
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
for sub in (("rag", "rag_np"), ("evaluation", "evaluation_np")):
    sys.path.insert(0, os.path.join(HERE, "..", "..", *sub))
import rag_np as R  # noqa: E402
import evaluation_np as EV  # noqa: E402


def load_handbook(data_dir=None):
    d = data_dir or os.path.join(HERE, "data")
    return {os.path.basename(p)[:-4]: open(p, encoding="utf-8").read().strip() for p in sorted(glob.glob(os.path.join(d, "*.txt")))}


def load_queries(data_dir=None):
    return json.load(open(os.path.join(data_dir or os.path.join(HERE, "data"), "queries.json"), encoding="utf-8"))


def light_stem(text):
    """Strip a final plural 's' from words of 4+ letters ('Saturdays' -> 'saturday'); a crude stemmer, enough to show the effect of normalisation."""
    return re.sub(r"[A-Za-z]+", lambda m: m.group(0).lower()[:-1] if len(m.group(0)) >= 4 and m.group(0).lower().endswith("s") and not m.group(0).lower().endswith("ss") else m.group(0).lower(), text)


class Assistant:
    """cover_min: refuse if the best chunk contains fewer than this share of the question's content words (0 = never refuse on coverage).
    ground_min: refuse if the answer's grounded score against the retrieved context is below this (0 = never refuse on grounding)."""

    def __init__(self, handbook, chunk_size=400, overlap=0, k=3, hybrid=False, cover_min=0.0, ground_min=0.0, lsa_dim=24, stem=False):
        self.chunks = R.chunk_corpus(handbook, chunk_size, overlap)
        self.norm = light_stem if stem else (lambda t: t)
        texts = [self.norm(c["text"]) for c in self.chunks]
        self.bm25 = R.BM25(texts)
        self.ntexts = texts
        self.lsa = R.LSA(texts, dim=lsa_dim) if hybrid else None
        self.k, self.cover_min, self.ground_min = k, cover_min, ground_min

    def retrieve(self, question):
        question = self.norm(question)
        r1 = R.rank(self.bm25.scores(question))
        if self.lsa is None:
            return list(map(int, r1))
        return list(map(int, R.rrf([r1, R.rank(self.lsa.scores(question))])))

    def ask(self, question):
        order = self.retrieve(question)[: self.k]
        ctx = [self.chunks[i]["text"] for i in order]
        cover = R.query_coverage(self.norm(question), self.ntexts[order[0]])
        if cover < self.cover_min:
            return dict(answer=None, refused="low_coverage", sources=[], cover=cover, grounded=None)
        ans = R.extractive_answer(question, ctx, n=1)
        g = EV.grounded_score(ans, " ".join(ctx))
        if g < self.ground_min:
            return dict(answer=None, refused="not_grounded", sources=[], cover=cover, grounded=g)
        src = sorted({self.chunks[i]["doc"] for i in order if ans and ans in self.chunks[i]["text"]})
        return dict(answer=ans, refused=None, sources=src, cover=cover, grounded=g)


def evaluate(assistant, queries):
    """Returns recall@k (k = assistant.k) and recall@1 of the retriever, accuracy on answerable questions, wrong-answer rate, and refusal quality on unanswerable ones."""
    ans_q = [q for q in queries if q["answerable"]]
    un_q = [q for q in queries if not q["answerable"]]
    hit = hit1 = acc = wrong = refused_ans = 0
    for q in ans_q:
        order = assistant.retrieve(q["q"])[: assistant.k]
        hit += any(q["gold"] in assistant.chunks[i]["text"] for i in order)
        hit1 += q["gold"] in assistant.chunks[order[0]]["text"]
        out = assistant.ask(q["q"])
        if out["refused"]:
            refused_ans += 1
        elif q["key"] in out["answer"]:
            acc += 1
        else:
            wrong += 1
    refused_un = sum(assistant.ask(q["q"])["refused"] is not None for q in un_q)
    na, nu = len(ans_q), len(un_q)
    return dict(n_answerable=na, n_unanswerable=nu, retrieval_recall=hit / na, retrieval_recall_at1=hit1 / na, accuracy=acc / na, wrong_answer=wrong / na,
                false_refusal=refused_ans / na, correct_refusal=refused_un / nu, hallucinated_on_unanswerable=1 - refused_un / nu)


def diagnose(assistant, q):
    """Which stage is responsible for this question's outcome? One label per question:
    answerable: correct | wrong chunk (top-1 chunk lacks the fact) | wrong sentence (right chunk, wrong sentence) | refused
    unanswerable: correct refusal | answered anyway"""
    out = assistant.ask(q["q"])
    if not q["answerable"]:
        return "correct refusal" if out["refused"] else "answered anyway"
    if out["refused"]:
        return "refused"
    if q["key"] in out["answer"]:
        return "correct"
    top1 = assistant.retrieve(q["q"])[0]
    return "wrong sentence" if q["gold"] in assistant.chunks[top1]["text"] else "wrong chunk"


def handle_request(assistant, payload):
    """Transport-independent request handler (the FastAPI route in app_fastapi.py just calls this)."""
    q = payload.get("question") if isinstance(payload, dict) else None
    if not isinstance(q, str) or not q.strip() or len(q) > 500:
        return {"status": 422, "error": "question must be a non-empty string of at most 500 characters"}
    out = assistant.ask(q.strip())
    return {"status": 200, **out}


def main():
    hb, qs = load_handbook(), load_queries()
    for name, kw in (("BM25 only, never refuse", {}), ("hybrid, never refuse", dict(hybrid=True)),
                     ("BM25 + coverage 0.5", dict(cover_min=0.5)), ("BM25 + coverage 0.5 + grounded 0.9", dict(cover_min=0.5, ground_min=0.9))):
        print(f"{name:38s}", {k: round(v, 2) for k, v in evaluate(Assistant(hb, **kw), qs).items() if not k.startswith("n_")})


if __name__ == "__main__":
    main()
