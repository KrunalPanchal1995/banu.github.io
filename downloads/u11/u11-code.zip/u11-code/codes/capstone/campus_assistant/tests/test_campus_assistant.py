"""Tests: pytest, or python test_campus_assistant.py."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import campus_assistant as C

HB, QS = C.load_handbook(), C.load_queries()
ALL = " ".join(HB.values())


def test_every_gold_phrase_and_key_is_in_the_handbook():
    for q in QS:
        if q["answerable"]:
            assert q["gold"] in ALL and q["key"] in q["gold"], q
        else:
            assert q["gold"] is None and q["key"] is None


def test_answers_are_quotes_of_the_handbook():
    a = C.Assistant(HB)
    for q in QS:
        out = a.ask(q["q"])
        assert out["answer"] in ALL  # extractive: can only quote


def test_refusal_removes_answer_and_sources():
    out = C.Assistant(HB, cover_min=0.99).ask("What is on the cafeteria menu on Fridays?")
    assert out["answer"] is None and out["refused"] == "low_coverage" and out["sources"] == []


def test_citation_names_the_document():
    out = C.Assistant(HB).ask("When do scholarship applications close?")
    assert out["sources"] == ["scholarships"]


def test_evaluation_is_deterministic_and_bounded():
    a, b = C.evaluate(C.Assistant(HB), QS), C.evaluate(C.Assistant(HB), QS)
    assert a == b
    assert abs(a["accuracy"] + a["wrong_answer"] + a["false_refusal"] - 1) < 1e-12
    assert abs(a["correct_refusal"] + a["hallucinated_on_unanswerable"] - 1) < 1e-12


def test_request_validation():
    a = C.Assistant(HB)
    for bad in (None, {}, {"question": ""}, {"question": 5}, {"question": "x" * 501}):
        assert C.handle_request(a, bad)["status"] == 422
    assert C.handle_request(a, {"question": "How much is the application fee?"})["status"] == 200


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f()
    print("ok")
