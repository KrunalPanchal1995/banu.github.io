"""Optional HTTP service: uvicorn app_fastapi:app --port 8000 ; then POST {"question": "..."} to /ask. Needs: pip install fastapi uvicorn."""
from fastapi import FastAPI
from fastapi.responses import JSONResponse

import campus_assistant as C

app = FastAPI(title="Campus assistant (fictional college)")
assistant = C.Assistant(C.load_handbook(), cover_min=0.5)


@app.get("/health")
def health():
    return {"ok": True, "chunks": len(assistant.chunks)}


@app.post("/ask")
def ask(payload: dict):
    out = C.handle_request(assistant, payload)
    return JSONResponse(out, status_code=out.pop("status"))
