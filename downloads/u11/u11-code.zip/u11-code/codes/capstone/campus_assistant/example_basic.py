"""Run: python example_basic.py   (offline; prints the evaluation table and three sample questions)."""
import campus_assistant as C

C.main()
a = C.Assistant(C.load_handbook(), cover_min=0.5)
for q in ("When does the application window close?", "Who is the principal of the college?", "What is the cafeteria menu on Fridays?"):
    print(q, "->", a.ask(q))
