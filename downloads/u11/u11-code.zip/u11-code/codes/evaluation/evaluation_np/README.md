# evaluation_np

> BLEU, ROUGE, F1, judge-bias and kappa, groundedness checks, fairness metrics, differential-privacy noise, PII detection and RAG evaluation reports in numpy

**Topic:** evaluation  |  **Created in session:** 009  |  **Status:** draft

## What this code is for
<!-- 2-4 sentences: the concept it demonstrates and why the learner wrote it. A future AI must be able
     to decide from THIS section alone whether the module is relevant to its task. -->

## Capabilities
<!-- Bullet each public function/class: signature, inputs (with units), outputs, one-line behaviour. -->
-

## Theory in one paragraph
<!-- The equation(s) implemented, with the session/section where they are derived. Use plain-text math. -->

## Quick start
```bash
python example_basic.py        # writes example_basic.png
```

```python
# Smallest useful call
import evaluation_np
```

## Examples
| File | Shows | Output |
|------|-------|--------|
| `example_basic.py` | the core idea | `example_basic.png` |

## Inputs / outputs and units
<!-- Table: name | type/shape | units | meaning -->

## Validation
<!-- How do we know it is right? Analytic limit, benchmark value, conservation check, test file. -->

## Known limits and gotchas
-

## Dependencies
numpy, matplotlib (add more as used)

## Extending toward the open-source package
<!-- Where would this live in the final package (module path)? What API cleanup remains? -->
