"""Tests (all expected values computed by hand): pytest, or python test_evaluation_np.py."""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import evaluation_np as E

REF, CAND = "the cat sat on the mat", "the cat sit on mat"


def test_bleu_hand_cases():
    assert abs(E.bleu("the cat is on the mat", "the the the the the the the", N=1) - 2 / 7) < 1e-12        # Papineni's degenerate example: modified precision 2/7
    assert E.bleu(REF, REF) == 1.0 and E.bleu(REF, "zzz yyy") == 0.0
    assert abs(E.bleu(REF, "the cat", N=2) - math.exp(-2)) < 1e-12                                        # p1 = p2 = 1, BP = exp(1 - 6/2)
    assert E.bleu(REF, CAND, N=4) == 0.0 and E.bleu(REF, CAND, N=4, smooth=True) > 0                        # no common 3-gram -> 0 unless smoothed
    p1 = 4 / 5; p2 = 1 / 4; bp = math.exp(1 - 6 / 5); assert abs(E.bleu(REF, CAND, N=2) - bp * math.sqrt(p1 * p2)) < 1e-12


def test_rouge_hand_cases():
    p, r, f = E.rouge_n(REF, CAND, 1); assert (p, r) == (4 / 5, 4 / 6) and abs(f - 2 * (4 / 5) * (4 / 6) / (4 / 5 + 4 / 6)) < 1e-12
    p, r, f = E.rouge_n(REF, CAND, 2); assert (p, r) == (1 / 4, 1 / 5) and abs(f - 2 * .25 * .2 / .45) < 1e-12
    p, r, f = E.rouge_l(REF, CAND); assert E.lcs_len(E.toks(REF), E.toks(CAND)) == 4 and abs(f - 0.72727272) < 1e-6
    assert E.rouge_l("a b c d", "d c b a")[1] == 1 / 4                                                      # reversed order: LCS is a single word


def test_f1_and_exact_match():
    assert abs(E.token_f1("the cat sat", "the cat") - 2 * 1 * (2 / 3) / (1 + 2 / 3)) < 1e-12 and E.token_f1("a b", "c d") == 0.0
    assert E.exact_match("Paris!", "paris") == 1.0 and E.exact_match("Paris", "the Paris") == 0.0


def test_metrics_fail_on_meaning_in_known_ways():
    ref = "the model is safe"
    assert E.rouge_l(ref, "the model is not safe")[2] > 0.85 and E.bleu(ref, "the model is not safe", N=2) > 0.5      # negation: high overlap, opposite meaning
    assert E.rouge_l(ref, "this system poses no danger")[2] == 0.0 and E.bleu(ref, "this system poses no danger", N=1) == 0.0  # paraphrase: zero overlap


def test_judge_bias_and_swapping():
    assert abs(E.swapped_average_win_prob(0.0, 1.0) - 0.5) < 1e-12 and abs(E.judge_win_prob(0.0, 1.0) - 1 / (1 + math.exp(-1))) < 1e-12
    assert abs(E.swapped_average_win_prob(0.5, 1.0) - 0.5 * (1 / (1 + math.exp(-1.5)) + 1 / (1 + math.exp(0.5)))) < 1e-12
    rng = np.random.default_rng(0); n = 200000; delta, beta = 0.5, 1.0
    first = np.mean(rng.random(n) < E.judge_win_prob(delta, beta, 1.0, True)); assert abs(first - E.judge_win_prob(delta, beta)) < 0.005
    assert abs(E.swapped_average_win_prob(delta, beta) - E.sigmoid(delta)) < abs(E.judge_win_prob(delta, beta) - E.sigmoid(delta))   # swapping reduces the bias


def test_kappa_and_auc_by_hand():
    assert abs(E.cohen_kappa([1, 1, 0, 0], [1, 0, 0, 0]) - 0.5) < 1e-12 and E.cohen_kappa([1, 0, 1], [1, 0, 1]) == 1.0
    assert E.auc([3, 2], [1, 2]) == 0.875


def test_groundedness_and_altered_numbers():
    ctx = "The base model has 12 layers and a width of 768 units."
    assert E.support_score("The model has 12 layers", ctx) == 1.0 and E.support_score("Bananas are yellow fruit", ctx) == 0.0
    s_alt = "The model has 24 layers and a width of 768 units"; assert E.support_score(s_alt, ctx) > 0.8 and not E.numbers_supported(s_alt, ctx) and E.grounded_score(s_alt, ctx) == 0.0


def test_group_metrics_exact_values():
    m = E.group_metrics(0.5, -1, 1, 0.0); assert abs(m["tpr"] - 0.8413447) < 1e-6 and abs(m["fpr"] - 0.1586553) < 1e-6 and abs(m["accuracy"] - 0.8413447) < 1e-6 and abs(m["selection"] - 0.5) < 1e-12
    assert E.group_metrics(0.3, -1, 1, -50)["tpr"] == 1.0 and E.group_metrics(0.3, -1, 1, 50)["selection"] == 0.0
    g = E.parity_gaps(E.group_metrics(0.5, -1, 1, 0), E.group_metrics(0.5, -1, 1, 0)); assert all(v == 0 for v in g.values())
    a, b = E.group_metrics(0.5, -1, 1, 0), E.group_metrics(0.2, -1, 1, 0); g = E.parity_gaps(a, b); assert g["equal_opportunity"] == 0 and g["demographic_parity"] > 0.1   # same TPR, different base rate
    assert E.wilson(90, 100)[0] < 0.9 < E.wilson(90, 100)[1] and abs(E.wilson(90, 100)[0] - 0.826) < 0.002


def test_laplace_mechanism():
    rng = np.random.default_rng(0)
    for eps in (0.1, 1.0, 5.0):
        err = np.abs(E.laplace_count(100, eps, rng, size=200000) - 100).mean(); assert abs(err - 1 / eps) < 0.03 / eps
    for x in np.linspace(90, 110, 9): assert E.laplace_density_ratio_bound(0.5, x, 100, 101) <= math.exp(0.5) + 1e-12


def test_pii_detection():
    t = "Contact jane.doe@example.com or call 555-123-4567; SSN 123-45-6789. Pi is 3.14159 and room 4096."
    kinds = {k for k, v in E.find_pii(t)}; assert kinds == {"email", "phone", "ssn"} and not any(v == "3.14159" for k, v in E.find_pii(t))
    assert E.find_pii("My name is Maria Lopez and I live on Elm Street") == []                                 # names and addresses are missed


def test_reference_sentences_for_the_course_questions():
    corpus = " ".join(E.R.load_corpus().values()); Q = E.R.load_queries()["answerable"]
    found = [E.sentence_with(corpus, q["gold"]) for q in Q]; assert sum(s is not None for s in found) >= 25


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
    print("ok")
