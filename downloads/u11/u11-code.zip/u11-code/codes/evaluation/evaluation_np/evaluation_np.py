"""Evaluation and safety toolkit in plain numpy: text-overlap metrics (BLEU, ROUGE, F1, exact match), judge bias and agreement,
groundedness checks, fairness metrics, a differential-privacy noise mechanism, PII detection and a RAG evaluation helper.

See README.md. Every metric is tested against cases computed by hand.
"""
import math
import os
import re
import sys
from collections import Counter

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "rag", "rag_np"))
import rag_np as R  # noqa: E402


# ------------------------------------------------------------------ text-overlap metrics
def toks(text):
    return re.findall(r"[a-z0-9]+", text.lower())


def ngrams(t, n):
    return Counter(tuple(t[i:i + n]) for i in range(len(t) - n + 1))


def bleu(ref, cand, N=4, smooth=False):
    """Sentence BLEU (Papineni et al. 2002) against ONE reference: geometric mean of modified n-gram precisions for n = 1..N times the
    brevity penalty BP = 1 if c > r else exp(1 - r/c). Without smoothing, a zero precision gives BLEU 0; smooth=True adds 1 to numerator and
    denominator for n > 1 (Lin and Och 2004)."""
    r, c = toks(ref), toks(cand)
    if not c:
        return 0.0
    logs = 0.0
    for n in range(1, N + 1):
        cc, rc = ngrams(c, n), ngrams(r, n)
        clip = sum(min(v, rc[g]) for g, v in cc.items()); tot = max(sum(cc.values()), 0)
        if smooth and n > 1:
            clip, tot = clip + 1, tot + 1
        if clip == 0 or tot == 0:
            return 0.0
        logs += math.log(clip / tot) / N
    bp = 1.0 if len(c) > len(r) else math.exp(1 - len(r) / len(c))
    return bp * math.exp(logs)


def rouge_n(ref, cand, n=1):
    """ROUGE-N (Lin 2004): returns (precision, recall, F1) of overlapping n-grams (clipped counts)."""
    rc, cc = ngrams(toks(ref), n), ngrams(toks(cand), n); ov = sum(min(v, rc[g]) for g, v in cc.items())
    p = ov / max(sum(cc.values()), 1); rec = ov / max(sum(rc.values()), 1)
    return p, rec, (2 * p * rec / (p + rec) if p + rec else 0.0)


def lcs_len(a, b):
    d = np.zeros((len(a) + 1, len(b) + 1), int)
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            d[i, j] = d[i - 1, j - 1] + 1 if a[i - 1] == b[j - 1] else max(d[i - 1, j], d[i, j - 1])
    return int(d[-1, -1])


def rouge_l(ref, cand):
    """ROUGE-L: longest common subsequence; returns (precision, recall, F1)."""
    r, c = toks(ref), toks(cand); l = lcs_len(r, c); p, rec = l / max(len(c), 1), l / max(len(r), 1)
    return p, rec, (2 * p * rec / (p + rec) if p + rec else 0.0)


def token_f1(ref, cand):
    """Bag-of-tokens F1 (as in SQuAD): overlap counted with multiplicity."""
    rc, cc = Counter(toks(ref)), Counter(toks(cand)); ov = sum((rc & cc).values())
    if ov == 0:
        return 0.0
    p, rec = ov / sum(cc.values()), ov / sum(rc.values()); return 2 * p * rec / (p + rec)


def exact_match(ref, cand):
    return float(toks(ref) == toks(cand))


# ------------------------------------------------------------------ judges: bias and agreement
def sigmoid(x):
    return 1 / (1 + math.exp(-x))


def judge_win_prob(delta, beta, s=1.0, x_first=True):
    """P(judge says X wins) when X's true quality advantage is delta, the judge has noise scale s and a position bias beta toward the FIRST slot."""
    return sigmoid((delta + (beta if x_first else -beta)) / s)


def swapped_average_win_prob(delta, beta, s=1.0):
    """Average over both presentation orders: 0.5 * [P(win | X first) + P(win | X second)]."""
    return 0.5 * (judge_win_prob(delta, beta, s, True) + judge_win_prob(delta, beta, s, False))


def cohen_kappa(a, b):
    """Cohen's kappa for two raters' labels: (p_observed - p_chance) / (1 - p_chance)."""
    a, b = np.asarray(a), np.asarray(b); po = float((a == b).mean()); labs = np.unique(np.concatenate([a, b]))
    pe = float(sum((a == l).mean() * (b == l).mean() for l in labs)); return (po - pe) / (1 - pe) if pe < 1 else 1.0


# ------------------------------------------------------------------ groundedness
STOP = R.STOP


def content_tokens(text):
    return [t for t in toks(text) if t not in STOP]


def support_score(sentence, context):
    """Share of the sentence's content tokens that occur in the context (lexical support, 0..1)."""
    s, c = content_tokens(sentence), set(content_tokens(context))
    return sum(t in c for t in s) / len(s) if s else 1.0


def numbers_supported(sentence, context):
    """True if every number in the sentence also occurs in the context (catches altered figures that keep the wording)."""
    nums = re.findall(r"\d+(?:\.\d+)?", sentence); ctx = set(re.findall(r"\d+(?:\.\d+)?", context))
    return all(n in ctx for n in nums)


def grounded_score(sentence, context):
    """Support score, forced to 0 when a number in the sentence is not in the context."""
    return support_score(sentence, context) if numbers_supported(sentence, context) else 0.0


def auc(pos, neg):
    """Probability that a random positive scores higher than a random negative (ties count one half)."""
    return float(np.mean([(x > y) + 0.5 * (x == y) for x in pos for y in neg]))


# ------------------------------------------------------------------ fairness
def _cdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def group_metrics(prevalence, mu0, mu1, thr, sigma=1.0):
    """Exact metrics of a threshold classifier for one group: score ~ N(mu1, sigma^2) for positives and N(mu0, sigma^2) for negatives.
    Returns dict with TPR, FPR, selection rate, accuracy, precision."""
    tpr = 1 - _cdf((thr - mu1) / sigma); fpr = 1 - _cdf((thr - mu0) / sigma)
    sel = prevalence * tpr + (1 - prevalence) * fpr; acc = prevalence * tpr + (1 - prevalence) * (1 - fpr)
    return {"tpr": tpr, "fpr": fpr, "selection": sel, "accuracy": acc, "precision": prevalence * tpr / sel if sel else float("nan")}


def parity_gaps(ma, mb):
    """Demographic parity gap (selection rates), equal-opportunity gap (TPR) and the equalized-odds gap (max of TPR and FPR gaps)."""
    return {"demographic_parity": abs(ma["selection"] - mb["selection"]), "equal_opportunity": abs(ma["tpr"] - mb["tpr"]),
            "equalized_odds": max(abs(ma["tpr"] - mb["tpr"]), abs(ma["fpr"] - mb["fpr"]))}


def wilson(successes, n, z=1.96):
    p = successes / n; den = 1 + z * z / n; c = (p + z * z / (2 * n)) / den; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return c - h, c + h


# ------------------------------------------------------------------ privacy
def laplace_count(true_count, epsilon, rng, sensitivity=1.0, size=None):
    """epsilon-differentially private count: add Laplace noise of scale sensitivity/epsilon (Dwork et al. 2006). E|noise| = sensitivity/epsilon."""
    return true_count + rng.laplace(0.0, sensitivity / epsilon, size)


def laplace_density_ratio_bound(epsilon, x, y_true_a, y_true_b, sensitivity=1.0):
    """Density ratio of the noisy output x for two neighbouring true counts: never exceeds exp(epsilon) when |a - b| <= sensitivity."""
    b = sensitivity / epsilon; return math.exp((abs(x - y_true_b) - abs(x - y_true_a)) / b)


PII_PATTERNS = {"email": r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", "phone": r"(?<!\d)(?:\+?\d{1,3}[ -]?)?(?:\(?\d{3}\)?[ -]?)\d{3}[ -]?\d{4}(?!\d)", "ssn": r"(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)"}


def find_pii(text):
    """Regex-based detector for e-mail addresses, phone numbers and US-style social security numbers. Names and addresses are NOT detected."""
    out = []
    for kind, pat in PII_PATTERNS.items():
        out += [(kind, m.group(0)) for m in re.finditer(pat, text)]
    return out


# ------------------------------------------------------------------ RAG evaluation helper
def sentence_with(text, phrase):
    """The sentence of `text` containing `phrase` (the reference answer for a question whose gold phrase is known)."""
    for s in R.split_sentences(text):
        if phrase in s:
            return s
    return None


def main():
    print("BLEU-2 'the cat' vs 'the cat sat on the mat':", round(bleu("the cat sat on the mat", "the cat", N=2), 4), "(hand: exp(-2) =", round(math.exp(-2), 4), ")")
    print("ROUGE-L F1:", round(rouge_l("the cat sat on the mat", "the cat sit on mat")[2], 4))


if __name__ == "__main__":
    main()
