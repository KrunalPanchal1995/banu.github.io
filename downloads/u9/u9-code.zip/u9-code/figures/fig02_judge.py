"""Fig 2: LLM-as-judge position bias (simulation of the stated model) and why raw agreement can mislead (kappa)."""
from _common import *
use_code("evaluation/evaluation_np")
import evaluation_np as E
d = np.linspace(-3, 3, 121); beta, s = 1.0, 1.0; rng = np.random.default_rng(0); fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
axs[0].plot(d, [E.sigmoid(x / s) for x in d], "k-", label="no bias (what we want)"); axs[0].plot(d, [E.judge_win_prob(x, beta, s) for x in d], "-", color=PAL["red"], label="X always shown first, bias 1")
axs[0].plot(d, [E.swapped_average_win_prob(x, beta, s) for x in d], "-", color=PAL["blue"], label="average over both orders")
dd = np.array([-2, -1, -0.5, 0, 0.5, 1, 2]); axs[0].plot(dd, [np.mean(rng.random(40000) < E.judge_win_prob(x, beta, s)) for x in dd], "o", color=PAL["red"], ms=3); axs[0].plot(dd, [0.5 * (np.mean(rng.random(40000) < E.judge_win_prob(x, beta, s, True)) + np.mean(rng.random(40000) < E.judge_win_prob(x, beta, s, False))) for x in dd], "o", color=PAL["blue"], ms=3)
axs[0].set(xlabel="true quality advantage of X over Y", ylabel="share of comparisons the judge says X wins", ylim=(0, 1)); axs[0].legend(fontsize=6)
ps = np.linspace(0.5, 0.99, 50); kap = []; agree = []
for p in ps:
    n = 20000; a = rng.random(n) < p; b = rng.random(n) < p; agree.append((a == b).mean()); kap.append(E.cohen_kappa(a.astype(int), b.astype(int)))
axs[1].plot(ps, agree, "-", color=PAL["blue"], label="raw agreement"); axs[1].plot(ps, kap, "--", color=PAL["red"], label="Cohen's kappa"); axs[1].set(xlabel="share of 'good' labels (both raters guess independently)", ylabel="agreement measure", ylim=(-.05, 1.02)); axs[1].legend(fontsize=7)
save(fig, out("fig02_judge.png"))
print("delta=0: fixed order", round(E.judge_win_prob(0, beta, s), 3), "swapped", round(E.swapped_average_win_prob(0, beta, s), 3)); print("delta=0.5: fixed", round(E.judge_win_prob(.5, beta, s), 3), "swapped", round(E.swapped_average_win_prob(.5, beta, s), 3), "unbiased", round(E.sigmoid(.5), 3))
print("delta=1: fixed", round(E.judge_win_prob(1, beta, s), 3), "swapped", round(E.swapped_average_win_prob(1, beta, s), 3), "unbiased", round(E.sigmoid(1), 3))
i = np.argmin(abs(ps - 0.9)); print("both guess 'good' 90%: raw agreement", round(agree[i], 3), "kappa", round(kap[i], 3), "(theory agreement 0.82, kappa 0)")
