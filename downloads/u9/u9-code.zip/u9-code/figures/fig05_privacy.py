"""Fig 5: differential privacy: Laplace noise error against epsilon; and what a regex PII detector finds and misses."""
from _common import *
use_code("evaluation/evaluation_np")
import evaluation_np as E, re
rng = np.random.default_rng(0); fig, axs = plt.subplots(1, 3, figsize=(8.8, 3.0), layout="constrained"); eps = np.logspace(-1.5, 1, 12)
sim = [np.abs(E.laplace_count(1000, e, rng, size=100000) - 1000).mean() for e in eps]; axs[0].loglog(eps, 1 / eps, "-", color=PAL["blue"], label="theory 1/epsilon"); axs[0].loglog(eps, sim, "o", color=PAL["red"], ms=4, label="simulation (100,000 draws)"); axs[0].set(xlabel="privacy parameter epsilon (smaller = more private)", ylabel="mean absolute error of a count"); axs[0].legend(fontsize=6)
for e, c in [(0.1, PAL["red"]), (1.0, PAL["orange"]), (5.0, PAL["green"])]: axs[1].hist(E.laplace_count(1000, e, rng, size=20000), 80, range=(950, 1050), histtype="step", color=c, lw=1.5, label=f"epsilon = {e}")
axs[1].axvline(1000, color="k", ls=":"); axs[1].set(xlabel="noisy answer to 'how many users...?' (true 1000)", ylabel="draws"); axs[1].legend(fontsize=6)
# synthetic PII corpus
emails = ["jane.doe@example.com", "j_smith+news@mail.co.uk", "info@my-company.org"]; phones = ["555-123-4567", "(555) 123 4567", "+1 555 123 4567", "+44 20 7946 0958", "555.123.4567"]; ssns = ["123-45-6789", "987-65-4321"]
names = ["Maria Lopez", "Ahmed Khan", "Wei Zhang"]; addrs = ["12 Elm Street, Springfield", "5 Rue de la Paix, Paris"]; neg = ["version 1.2.3 released", "invoice 2023-04-15 total 1234.56", "room 4096 on floor 7", "pi is 3.14159", "call ext 4567"]
truth = [("email", e) for e in emails] + [("phone", p) for p in phones] + [("ssn", s) for s in ssns]; rows = []
for kind, v in truth: rows.append((f"Please contact me: {v} thanks", kind, v))
for n in names + addrs: rows.append((f"Customer {n} asked for a refund", "other", n))
for n in neg: rows.append((n, "none", None))
tp = {k: 0 for k in ("email", "phone", "ssn")}; fn = dict(tp); fp = dict(tp)
for text, kind, v in rows:
    found = E.find_pii(text)
    if kind in tp:
        hit = any(k == kind for k, m in found); tp[kind] += hit; fn[kind] += (not hit)
    for k, m in found:
        if k in tp and not (kind == k): fp[k] += 1
res = {k: (tp[k] / max(tp[k] + fn[k], 1), tp[k] / max(tp[k] + fp[k], 1)) for k in tp}; x = np.arange(3)
axs[2].bar(x - .2, [res[k][0] for k in tp], .4, color=PAL["blue"], label="recall (found / present)"); axs[2].bar(x + .2, [res[k][1] for k in tp], .4, color=PAL["orange"], label="precision (right / flagged)"); axs[2].set_xticks(x, list(tp)); axs[2].set(ylim=(0, 1.15)); axs[2].legend(fontsize=6)
save(fig, out("fig05_privacy.png")); print("laplace |error| at eps 0.1, 1, 5 (true 1/eps):", [round(float(np.abs(E.laplace_count(1000, e, rng, size=200000) - 1000).mean()), 3) for e in (0.1, 1, 5)])
print("PII detector on", len(rows), "snippets:", {k: (round(v[0], 2), round(v[1], 2)) for k, v in res.items()}, "| names/addresses found:", sum(bool(E.find_pii(t)) for t, k, v in rows if k == "other"), "of", sum(k == "other" for t, k, v in rows), "| false alarms on negatives:", [(t, E.find_pii(t)) for t, k, v in rows if k == "none" and E.find_pii(t)])
for text, kind, v in rows:
    if kind in tp and not any(k == kind for k, m in E.find_pii(text)): print("   MISSED:", kind, v)
