"""Fig 6: an evaluation report for the course RAG system: retrieval, answer overlap, groundedness, abstention, with intervals and a paired comparison."""
from _common import *
use_code("evaluation/evaluation_np"); use_code("rag/rag_np")
import evaluation_np as E, rag_np as R
corpus = R.load_corpus(); QQ = R.load_queries(); Q = QQ["answerable"]; full = " ".join(corpus.values()); chunks = R.chunk_corpus(corpus, 600, 120); T = [c["text"] for c in chunks]
bm, lsa = R.BM25(T), R.LSA(T, 64)
def run(score_fn, k_ctx=3):
    out = []
    for q in Q:
        ref = E.sentence_with(full, q["gold"]); order = R.rank(score_fn(q["q"])); ctx = [T[int(i)] for i in order[:k_ctx]]
        ans = R.extractive_answer(q["q"], ctx, n=2) or ""; hit = any(q["gold"] in c for c in ctx)
        out.append({"hit": float(hit), "f1": E.token_f1(ref, ans) if ref else 0.0, "rl": E.rouge_l(ref, ans)[2] if ref else 0.0, "grounded": E.grounded_score(ans, " ".join(ctx)), "contains": float(q["gold"] in ans)})
    return out
rb, rl_ = run(bm.scores), run(lsa.scores)
def col(r, k): return np.array([x[k] for x in r])
def boot(a, b, B=4000, seed=0):
    r = np.random.default_rng(seed); d = np.asarray(b) - np.asarray(a); idx = r.integers(0, len(d), (B, len(d))); m = d[idx].mean(1); return d.mean(), np.quantile(m, 0.025), np.quantile(m, 0.975)
rows = [("answer chunk in the 3 retrieved", "hit"), ("answer sentence contains the gold phrase", "contains"), ("token F1 against the reference sentence", "f1"), ("ROUGE-L F1", "rl"), ("groundedness of the answer", "grounded")]
fig, axs = plt.subplots(1, 2, figsize=(8.8, 3.3), layout="constrained", gridspec_kw={"width_ratios": [1.5, 1]}); y = np.arange(len(rows))
for off, (name, r, c) in zip((-.18, .18), [("BM25", rb, PAL["blue"]), ("LSA (dense)", rl_, PAL["orange"])]):
    m = [col(r, k).mean() for _, k in rows]; ci = [np.quantile(np.random.default_rng(1).choice(col(r, k), (3000, len(r))).mean(1), [.025, .975]) for _, k in rows]
    axs[0].barh(y + off, m, .34, xerr=[[a - c_[0] for a, c_ in zip(m, ci)], [c_[1] - a for a, c_ in zip(m, ci)]], color=c, label=name, capsize=2)
axs[0].set_yticks(y, [n for n, _ in rows], fontsize=6.5); axs[0].invert_yaxis(); axs[0].set(xlabel="mean over 30 questions (95% bootstrap interval)", xlim=(0, 1.15)); axs[0].legend(fontsize=6)
dif = [(n, *boot(col(rb, k), col(rl_, k))) for n, k in rows]; yy = np.arange(len(dif)); axs[1].errorbar([d[1] for d in dif], yy, xerr=[[d[1] - d[2] for d in dif], [d[3] - d[1] for d in dif]], fmt="o", color=PAL["purple"], capsize=3); axs[1].axvline(0, color="k", lw=.8); axs[1].set_yticks(yy, [""] * len(dif)); axs[1].invert_yaxis(); axs[1].set(xlabel="LSA minus BM25 (paired, 95% interval)")
save(fig, out("fig06_ragreport.png"))
for (n, k) in rows: print(f"{n:42s} BM25 {col(rb, k).mean():.3f}  LSA {col(rl_, k).mean():.3f}  paired diff {boot(col(rb, k), col(rl_, k))[0]:+.3f} [{boot(col(rb, k), col(rl_, k))[1]:+.3f}, {boot(col(rb, k), col(rl_, k))[2]:+.3f}]")
cov = lambda q: R.query_coverage(q, T[int(R.rank(bm.scores(q))[0])]); ca = np.array([cov(e["q"]) for e in Q]); cn = np.array([cov(e["q"]) for e in QQ["near_miss"]]); co = np.array([cov(q) for q in QQ["unanswerable"]])
print("abstention at coverage>=0.5: answers", round((ca >= .5).mean(), 3), "of answerable;", round((cn >= .5).mean(), 3), "of near-miss;", round((co >= .5).mean(), 3), "of off-topic")
print("Wilson for hit (BM25):", np.round(E.wilson(int(col(rb, 'hit').sum()), 30), 3), "contains:", np.round(E.wilson(int(col(rb, 'contains').sum()), 30), 3))
