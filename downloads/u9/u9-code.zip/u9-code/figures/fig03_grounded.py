"""Fig 3: detecting unsupported answers: lexical support alone versus support with a number check."""
from _common import *
use_code("evaluation/evaluation_np"); use_code("rag/rag_np")
import evaluation_np as E, rag_np as R, re
corpus = R.load_corpus(); Q = R.load_queries()["answerable"]; full = " ".join(corpus.values()); chunks = R.chunk_corpus(corpus, 600, 120); T = [c["text"] for c in chunks]
rng = np.random.default_rng(0); pos, negA, negB, rows = [], [], [], []
for q in Q:
    ref = E.sentence_with(full, q["gold"]); ctx = next((c for c in T if q["gold"] in c), None)
    if not ref or not ctx: continue
    other = rng.choice([s for c in rng.choice(T, 6) for s in R.split_sentences(c) if len(s.split()) > 6]); pos.append(ref)
    alt = re.sub(r"\d+", lambda m: str(int(m.group(0)) + rng.integers(2, 9)), ref) if re.search(r"\d", ref) else None
    rows.append((ctx, ref, other, alt))
sA = [E.support_score(r, c) for c, r, o, a in rows]; nA = [E.support_score(o, c) for c, r, o, a in rows]
gA = [E.grounded_score(r, c) for c, r, o, a in rows]; gnA = [E.grounded_score(o, c) for c, r, o, a in rows]
alts = [(c, r, a) for c, r, o, a in rows if a]; sB = [E.support_score(r, c) for c, r, a in alts]; nB = [E.support_score(a, c) for c, r, a in alts]; gB = [E.grounded_score(r, c) for c, r, a in alts]; gnB = [E.grounded_score(a, c) for c, r, a in alts]
def roc(p, n):
    th = np.linspace(0, 1.01, 80); return [np.mean(np.array(n) >= t) for t in th], [np.mean(np.array(p) >= t) for t in th]
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
axs[0].plot(*roc(sA, nA), color=PAL["blue"], label=f"support score (AUC {E.auc(sA, nA):.2f})"); axs[0].plot(*roc(gA, gnA), "--", color=PAL["green"], label=f"+ number check (AUC {E.auc(gA, gnA):.2f})"); axs[0].plot([0, 1], [0, 1], ":", color=PAL["grey"]); axs[0].set(title="unsupported: a sentence from elsewhere", xlabel="false alarm rate", ylabel="detection rate"); axs[0].legend(fontsize=6)
axs[1].plot(*roc(sB, nB), color=PAL["blue"], label=f"support score (AUC {E.auc(sB, nB):.2f})"); axs[1].plot(*roc(gB, gnB), "--", color=PAL["green"], label=f"+ number check (AUC {E.auc(gB, gnB):.2f})"); axs[1].plot([0, 1], [0, 1], ":", color=PAL["grey"]); axs[1].set(title="unsupported: the same sentence with a changed number", xlabel="false alarm rate"); axs[1].legend(fontsize=6)
save(fig, out("fig03_grounded.png")); print("questions with a reference sentence and context:", len(rows), "| with a number to alter:", len(alts))
print("AUC elsewhere: support", round(E.auc(sA, nA), 3), "grounded", round(E.auc(gA, gnA), 3), "| AUC altered number: support", round(E.auc(sB, nB), 3), "grounded", round(E.auc(gB, gnB), 3))
print("mean support: supported", round(np.mean(sA), 3), "elsewhere", round(np.mean(nA), 3), "altered number", round(np.mean(nB), 3))
