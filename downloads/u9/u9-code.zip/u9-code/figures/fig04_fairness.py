"""Fig 4: a classifier with good overall accuracy and unequal group outcomes; thresholds per group; small-group uncertainty."""
from _common import *
use_code("evaluation/evaluation_np")
import evaluation_np as E
A = dict(prev=0.5, mu0=-1.0, mu1=1.0, n=900); B = dict(prev=0.2, mu0=-0.6, mu1=0.6, n=100)       # group B: lower base rate, and a noisier signal (smaller separation)
def gm(g, thr): return E.group_metrics(g["prev"], g["mu0"], g["mu1"], thr)
thr = 0.0; ma, mb = gm(A, thr), gm(B, thr); overall = (A["n"] * ma["accuracy"] + B["n"] * mb["accuracy"]) / (A["n"] + B["n"]); gaps = E.parity_gaps(ma, mb)
# group-specific threshold for B that equalises TPR with A
ts = np.linspace(-3, 3, 6001); tB = ts[np.argmin([abs(gm(B, t)["tpr"] - ma["tpr"]) for t in ts])]; mb2 = gm(B, tB); overall2 = (A["n"] * ma["accuracy"] + B["n"] * mb2["accuracy"]) / (A["n"] + B["n"]); gaps2 = E.parity_gaps(ma, mb2)
fig, axs = plt.subplots(1, 3, figsize=(8.8, 3.0), layout="constrained"); names = ["accuracy", "tpr", "fpr", "selection"]; x = np.arange(4); w = .27
for i, (m, c, l) in enumerate([(ma, PAL["blue"], "group A (900 people)"), (mb, PAL["orange"], "group B (100), one threshold"), (mb2, PAL["red"], f"group B, own threshold {tB:.2f}")]): axs[0].bar(x + (i - 1) * w, [m[k] for k in names], w, color=c, label=l)
axs[0].set_xticks(x, ["accuracy", "true positive\nrate", "false positive\nrate", "selection\nrate"], fontsize=7); axs[0].set(ylim=(0, 1.15)); axs[0].legend(fontsize=5.5, loc="upper right")
ths = np.linspace(-2, 2, 81); axs[1].plot(ths, [gm(A, t)["tpr"] for t in ths], color=PAL["blue"], label="A: true positive rate"); axs[1].plot(ths, [gm(B, t)["tpr"] for t in ths], color=PAL["orange"], label="B: true positive rate"); axs[1].plot(ths, [gm(A, t)["fpr"] for t in ths], "--", color=PAL["blue"], label="A: false positive rate"); axs[1].plot(ths, [gm(B, t)["fpr"] for t in ths], "--", color=PAL["orange"], label="B: false positive rate"); axs[1].axvline(0, color=PAL["grey"], ls=":"); axs[1].set(xlabel="decision threshold", ylabel="rate"); axs[1].legend(fontsize=5.5)
rng = np.random.default_rng(1); npos = int(B["prev"] * B["n"]); est = [rng.binomial(npos, mb["tpr"]) / npos for _ in range(2000)]; lo, hi = E.wilson(round(mb["tpr"] * npos), npos)
axs[2].hist(est, 25, color=PAL["orange"], alpha=.8); axs[2].axvline(ma["tpr"], color=PAL["blue"], lw=2, label=f"group A true rate {ma['tpr']:.2f}"); axs[2].axvline(mb["tpr"], color="k", ls="--", label=f"B's true rate {mb['tpr']:.2f}"); axs[2].set(xlabel=f"group B true positive rate measured on {npos} positives", ylabel="simulated audits"); axs[2].legend(fontsize=5.5)
save(fig, out("fig04_fairness.png"))
print("one threshold 0: A", {k: round(v, 3) for k, v in ma.items()}, "\n  B", {k: round(v, 3) for k, v in mb.items()}, "\n  overall accuracy", round(overall, 3), "gaps", {k: round(v, 3) for k, v in gaps.items()})
print("B own threshold", round(tB, 3), {k: round(v, 3) for k, v in mb2.items()}, "overall acc", round(overall2, 3), "gaps", {k: round(v, 3) for k, v in gaps2.items()})
print("B TPR audit: expected positives", npos, "Wilson interval for measured", round(mb["tpr"], 3), "->", np.round((lo, hi), 3), " spread of simulated audit estimates (2.5-97.5%):", np.round(np.percentile(est, [2.5, 97.5]), 3))
