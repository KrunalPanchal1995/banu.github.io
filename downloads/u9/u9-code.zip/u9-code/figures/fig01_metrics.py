"""Fig 1: overlap metrics against meaning: identical, paraphrase, negation, word-shuffle and unrelated candidates."""
from _common import *
use_code("evaluation/evaluation_np"); use_code("rag/rag_np")
import evaluation_np as E, rag_np as R
ref = "attention lets every word look at every other word"
cands = {"identical": ref, "paraphrase": "each token can attend to all the other tokens", "negation": "attention does not let every word look at every other word", "word shuffle": "word every at look other every word let attention", "unrelated": "the capital of Australia is Canberra"}
chunks = R.chunk_corpus(R.load_corpus(), 300, 60); lsa = R.LSA([c["text"] for c in chunks], 64)
def lsa_cos(a, b): va, vb = lsa.Vt @ lsa.t.query_vec(a), lsa.Vt @ lsa.t.query_vec(b); n = np.linalg.norm(va) * np.linalg.norm(vb); return float(va @ vb / n) if n else 0.0
metrics = ["BLEU (smoothed)", "ROUGE-1 F1", "ROUGE-L F1", "token F1", "exact match", "LSA cosine"]
M = np.array([[E.bleu(ref, c, smooth=True), E.rouge_n(ref, c, 1)[2], E.rouge_l(ref, c)[2], E.token_f1(ref, c), E.exact_match(ref, c), lsa_cos(ref, c)] for c in cands.values()])
fig, ax = plt.subplots(figsize=(7.4, 3.2)); im = ax.imshow(M, cmap="Blues", vmin=0, vmax=1, aspect="auto"); ax.grid(False)
ax.set_xticks(range(len(metrics)), metrics, fontsize=7, rotation=20); ax.set_yticks(range(len(cands)), list(cands), fontsize=8)
for i in range(M.shape[0]):
    for j in range(M.shape[1]): ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center", fontsize=8, color="w" if M[i, j] > .55 else "k")
fig.colorbar(im, ax=ax, label="score (1 = identical)"); save(fig, out("fig01_metrics.png"))
for c, row in zip(cands, M): print(f"{c:13s}", dict(zip(metrics, np.round(row, 3))))
