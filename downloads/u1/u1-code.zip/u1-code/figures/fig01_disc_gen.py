"""Fig 1: discriminative (logistic regression) vs generative (class-conditional Gaussians): boundaries, samples, data efficiency."""
from _common import *
use_code("genmodels/genmodels_np")
import genmodels_np as G
M0, M1 = np.array([-1.0, 0.0]), np.array([1.5, 1.0]); S0, S1 = np.array([[1, .5], [.5, 1]]), np.array([[1, -.5], [-.5, 1]])
def draw(rng, n):
    X = np.vstack([rng.multivariate_normal(M0, S0, n), rng.multivariate_normal(M1, S1, n)]); return X, np.r_[np.zeros(n), np.ones(n)]
rng = np.random.default_rng(0); X, y = draw(rng, 60)
mod = G.fit_gaussian_classes(X, y); wb = G.fit_logistic(X, y)
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
ax = axs[0]
gx, gy = np.meshgrid(np.linspace(-4, 5, 200), np.linspace(-3.5, 4.5, 200)); P = np.c_[gx.ravel(), gy.ravel()]
ax.contour(gx, gy, (G.gaussian_predict(mod, P)).reshape(gx.shape), levels=[.5], colors=[PAL["red"]], linestyles="--")
ax.contour(gx, gy, (G.logistic_predict(wb, P)).reshape(gx.shape), levels=[.5], colors=[PAL["blue"]])
ax.plot([], [], color=PAL["red"], ls="--", label="generative boundary (Bayes rule)"); ax.plot([], [], color=PAL["blue"], label="discriminative boundary")
ax.scatter(*X[y == 0].T, s=10, color=PAL["green"], alpha=.6); ax.scatter(*X[y == 1].T, s=10, color=PAL["orange"], alpha=.6)
new = G.gaussian_sample(mod, 1, 25, np.random.default_rng(3)); ax.scatter(*new.T, marker="x", color="k", s=28, label="NEW samples from the generative model")
ax.legend(fontsize=7, loc="lower left"); ax.set(xlim=(-4, 5), ylim=(-3.5, 4.5), xlabel="x1", ylabel="x2")
ns = [3, 5, 10, 20, 50, 100, 300]; acc = {"gen": [], "disc": []}; Xt, yt = draw(np.random.default_rng(99), 5000)
for n in ns:
    a, b = [], []
    for r in range(60):
        Xa, ya = draw(np.random.default_rng(1000 * n + r), n)
        a.append((G.gaussian_predict(G.fit_gaussian_classes(Xa, ya), Xt) == yt).mean()); b.append((G.logistic_predict(G.fit_logistic(Xa, ya, steps=600), Xt) == yt).mean())
    acc["gen"].append(np.mean(a)); acc["disc"].append(np.mean(b))
axs[1].semilogx(ns, acc["gen"], "o--", color=PAL["red"], label="generative (Gaussians)"); axs[1].semilogx(ns, acc["disc"], "s-", color=PAL["blue"], label="discriminative (logistic)")
axs[1].set(xlabel="training points per class", ylabel="test accuracy (mean of 60 runs)"); axs[1].legend(fontsize=8)
save(fig, out("fig01_disc_gen.png")); print("n:", ns); print("gen :", np.round(acc["gen"], 3)); print("disc:", np.round(acc["disc"], 3))
print("full-data accuracies: gen", (G.gaussian_predict(mod, Xt) == yt).mean(), "disc", (G.logistic_predict(wb, Xt) == yt).mean())
