"""Fig 2: character n-gram language model trained on the syllabus: train vs held-out perplexity by order, plus samples."""
from _common import *
use_code("genmodels/genmodels_np")
import genmodels_np as G
text = open(os.path.join(KB, "Syllabus.md"), encoding="utf-8").read().lower()
text = " ".join("".join(c if c.isalpha() or c == " " else " " for c in text).split())
cut = int(0.8 * len(text)); tr, te = text[:cut], text[cut:]
orders = [1, 2, 3, 4, 5, 6]; ptr, pte = [], []
for n in orders:
    m = G.CharNgram(n, alpha=0.05).fit(tr); ptr.append(m.perplexity(tr)); pte.append(m.perplexity(te))
fig, ax = plt.subplots(figsize=FIG["single"])
ax.semilogy(orders, ptr, "o-", color=PAL["blue"], label="training text"); ax.semilogy(orders, pte, "s--", color=PAL["red"], label="held-out text")
ax.set(xlabel="n-gram order n (context = n-1 characters)", ylabel="perplexity (lower is better)"); ax.legend()
save(fig, out("fig02_ngram.png"))
print("chars", len(text), "train", len(tr), "test", len(te), "vocab", len(set(text)))
for n, a, b in zip(orders, ptr, pte): print(n, round(a, 2), round(b, 2))
for n in (1, 2, 4, 6): print(f"order {n}:", repr(G.CharNgram(n, 0.05).fit(tr).generate(110, np.random.default_rng(4))))

# memorisation: share of 12-character windows of a 3000-char sample that occur verbatim in the training text
for n in (1, 2, 3, 4, 6, 8):
    smp = G.CharNgram(n, 0.05).fit(tr).generate(3000, np.random.default_rng(5)); w = [smp[i:i + 12] for i in range(0, len(smp) - 12, 3)]
    print("order", n, "verbatim 12-char windows:", round(float(np.mean([x in tr for x in w])), 3))
