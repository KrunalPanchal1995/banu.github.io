"""Fig 5: 1-d GAN on a two-mode target: generated histograms at four training steps."""
from _common import *
use_code("genmodels/genmodels_np")
import genmodels_np as G
rs = np.random.default_rng(11)
real = lambda n: np.where(rs.random(n) < .5, rs.normal(-2, .4, n), rs.normal(2, .4, n))
steps = 4000; snaps_at = (0, 300, 1500, steps)
Gn, Dn, sn = G.train_gan_1d(real, steps=steps, zdim=2, hidden=24, lr=2e-3, rng=np.random.default_rng(0), snapshots=snaps_at)
xs = np.linspace(-4.5, 4.5, 400); pdf = lambda m: np.exp(-(xs - m) ** 2 / (2 * .16)) / np.sqrt(2 * np.pi * .16)
fig, axs = plt.subplots(1, 4, figsize=(8.2, 2.5), sharey=True, layout="constrained")
for ax, t in zip(axs, snaps_at):
    ax.fill_between(xs, 0.5 * pdf(-2) + 0.5 * pdf(2), color=PAL["grey"], alpha=.4, label="real density"); ax.hist(sn[t], bins=60, range=(-4.5, 4.5), density=True, color=PAL["blue"], alpha=.7, label="generated")
    ax.set(title=f"step {t}", xlabel="x")
axs[0].legend(fontsize=6); axs[0].set_ylabel("density")
save(fig, out("fig05_gan.png"))
for t in snaps_at:
    s = sn[t]; L, R = s[s < 0], s[s >= 0]; print("   per-mode mean/std: left", round(L.mean(), 2), round(L.std(), 2), " right", round(R.mean(), 2), round(R.std(), 2), "(target +-2, 0.4)")
    print(t, "mean", round(s.mean(), 2), "std", round(s.std(), 2), "frac left mode", round((s < 0).mean(), 3), "frac within 1 of a mode", round((np.minimum(abs(s + 2), abs(s - 2)) < 1).mean(), 3))
