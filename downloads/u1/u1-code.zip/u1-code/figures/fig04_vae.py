"""Fig 4: VAE on a noisy ring: samples from the prior pushed through the decoder, ELBO terms, latent map."""
from _common import *
use_code("genmodels/genmodels_np")
import genmodels_np as G
rng = np.random.default_rng(0); th = rng.uniform(0, 2 * np.pi, 400); X = np.stack([np.cos(th), np.sin(th)], 1) + 0.04 * rng.normal(size=(400, 2))
enc, dec, hist = G.train_vae(X, zdim=2, hidden=32, steps=4000, lr=5e-3, sigma2=0.02, rng=np.random.default_rng(0))
S = G.vae_sample(dec, 600, 2, np.random.default_rng(1)); r = np.linalg.norm(S, axis=1)
mu = enc.forward(X)[0][:, :2]
fig, axs = plt.subplots(1, 3, figsize=(8.2, 3.1), layout="constrained")
axs[0].scatter(*X.T, s=5, color=PAL["grey"], alpha=.6, label="data"); axs[0].scatter(*S.T, s=5, color=PAL["blue"], alpha=.7, label="decoder(z), z ~ N(0, I)")
axs[0].set(aspect="equal", xlabel="x1", ylabel="x2"); axs[0].legend(fontsize=6, loc="center")
axs[1].plot(hist[:, 1], color=PAL["orange"], label="reconstruction term"); axs[1].plot(hist[:, 2], color=PAL["purple"], label="KL term"); axs[1].set(xlabel="training step", ylabel="loss terms (per point)", yscale="log"); axs[1].legend(fontsize=7)
sc = axs[2].scatter(mu[:, 0], mu[:, 1], c=th, cmap="twilight", s=6); axs[2].set(aspect="equal", xlabel="z1 (posterior mean)", ylabel="z2"); fig.colorbar(sc, ax=axs[2], label="angle of data point")
save(fig, out("fig04_vae.png")); print("final recon", hist[-1, 1], "KL", hist[-1, 2], "sample radius mean/std", r.mean(), r.std(), "data radius", np.linalg.norm(X, axis=1).mean(), np.linalg.norm(X, axis=1).std())
