"""Fig 3: nonlinear autoencoder (1-d code) vs PCA on a noisy arc."""
from _common import *
use_code("genmodels/genmodels_np")
import genmodels_np as G
rng = np.random.default_rng(0); th = rng.uniform(-2.2, 2.2, 300); X = np.stack([np.cos(th), np.sin(th)], 1) + 0.02 * rng.normal(size=(300, 2))
enc, dec, hist = G.train_autoencoder(X, 1, 16, 3000, rng=np.random.default_rng(0))
Xh = dec.forward(enc.forward(X)[0])[0]; Xp = G.pca_reconstruct(X, 1)
mse_ae, mse_pca = ((Xh - X) ** 2).sum(1).mean(), ((Xp - X) ** 2).sum(1).mean()
z = enc.forward(X)[0][:, 0]
fig, axs = plt.subplots(1, 3, figsize=(8.2, 3.1), layout="constrained")
axs[0].scatter(*X.T, s=6, color=PAL["grey"], alpha=.6, label="data"); axs[0].scatter(*Xh.T, s=6, color=PAL["blue"], label="autoencoder (1-d code)"); axs[0].plot(*Xp[np.argsort(Xp[:, 0])].T, color=PAL["red"], label="PCA (1 component)")
axs[0].set(aspect="equal", xlabel="x1", ylabel="x2"); axs[0].legend(fontsize=6, loc="lower left")
axs[1].semilogy(hist, color=PAL["blue"]); axs[1].axhline(mse_pca, color=PAL["red"], ls="--"); axs[1].set(xlabel="training step", ylabel="reconstruction error"); axs[1].text(1000, mse_pca * 1.3, "PCA", color=PAL["red"])
axs[2].scatter(th, z, s=6, color=PAL["blue"]); axs[2].set(xlabel="true angle of the point", ylabel="learned code z")
save(fig, out("fig03_ae.png")); print("AE mse", mse_ae, "PCA mse", mse_pca, "ratio", mse_pca / mse_ae, "start", hist[0], "corr(z,angle)", np.corrcoef(z, th)[0, 1])
