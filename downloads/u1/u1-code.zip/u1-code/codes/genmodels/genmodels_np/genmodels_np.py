"""Generative-model toolkit in plain numpy: classifiers, char n-gram LM, MLP with manual backprop, autoencoder, VAE, GAN.

See README.md in this folder. All training functions take an explicit numpy Generator so results are reproducible.
"""
from collections import Counter, defaultdict

import numpy as np


# ------------------------------------------------ discriminative vs generative
def fit_gaussian_classes(X, y):
    """Generative classifier: per class a Gaussian N(mu_c, Sigma_c) and a prior. Returns dict c -> (prior, mu, Sigma)."""
    out = {}
    for c in np.unique(y):
        Xc = X[y == c]
        out[int(c)] = (len(Xc) / len(X), Xc.mean(0), np.cov(Xc.T) + 1e-6 * np.eye(X.shape[1]))
    return out


def gaussian_logpdf(X, mu, S):
    d = X.shape[1]
    diff = X - mu
    sol = np.linalg.solve(S, diff.T).T
    return -0.5 * (np.sum(diff * sol, 1) + np.linalg.slogdet(S)[1] + d * np.log(2 * np.pi))


def gaussian_predict(model, X):
    """Bayes rule: argmax_c log prior_c + log p(x | c)."""
    cs = sorted(model)
    sc = np.stack([np.log(model[c][0]) + gaussian_logpdf(X, model[c][1], model[c][2]) for c in cs], 1)
    return np.array(cs)[sc.argmax(1)]


def gaussian_sample(model, c, n, rng):
    _, mu, S = model[c]
    return rng.multivariate_normal(mu, S, size=n)


def fit_logistic(X, y, steps=2000, lr=0.5, l2=1e-3):
    """Discriminative classifier: p(y=1|x) = sigmoid(w.x + b), trained by full-batch gradient descent on the log loss."""
    w, b = np.zeros(X.shape[1]), 0.0
    for _ in range(steps):
        p = 1 / (1 + np.exp(-(X @ w + b)))
        w -= lr * (X.T @ (p - y) / len(y) + l2 * w)
        b -= lr * (p - y).mean()
    return w, b


def logistic_predict(wb, X):
    return ((X @ wb[0] + wb[1]) > 0).astype(int)


# ------------------------------------------------ character n-gram language model
class CharNgram:
    """Order-n character model with add-alpha smoothing: P(c | previous n-1 characters)."""

    def __init__(self, n, alpha=0.1):
        self.n, self.alpha = n, alpha

    def fit(self, text):
        self.vocab = sorted(set(text))
        self.counts = defaultdict(Counter)
        pad = "\x00" * (self.n - 1)
        t = pad + text
        for i in range(len(text)):
            self.counts[t[i:i + self.n - 1]][t[i + self.n - 1]] += 1
        return self

    def prob(self, ctx, ch):
        c = self.counts.get(ctx)
        tot = sum(c.values()) if c else 0
        return ((c[ch] if c else 0) + self.alpha) / (tot + self.alpha * (len(self.vocab) + 1))

    def perplexity(self, text):
        pad = "\x00" * (self.n - 1)
        t = pad + text
        ll = sum(np.log(self.prob(t[i:i + self.n - 1], t[i + self.n - 1])) for i in range(len(text)))
        return float(np.exp(-ll / len(text)))

    def generate(self, length, rng, seed_text=""):
        ctx = ("\x00" * (self.n - 1) + seed_text)[-(self.n - 1):] if self.n > 1 else ""
        out = []
        for _ in range(length):
            c = self.counts.get(ctx)
            if not c:
                ch = self.vocab[rng.integers(len(self.vocab))]
            else:
                chars, cnt = zip(*sorted(c.items()))
                p = np.array(cnt, float)
                ch = chars[rng.choice(len(chars), p=p / p.sum())]
            out.append(ch)
            ctx = (ctx + ch)[-(self.n - 1):] if self.n > 1 else ""
        return "".join(out)


# ------------------------------------------------ MLP with manual backprop
class MLP:
    """Fully connected net, tanh hidden layers, linear output. forward() returns (y, cache); backward(cache, dy) returns (dx, grads)."""

    def __init__(self, sizes, rng):
        self.W = [rng.normal(0, np.sqrt(1 / a), (a, b)) for a, b in zip(sizes[:-1], sizes[1:])]
        self.b = [np.zeros(b) for b in sizes[1:]]

    def params(self):
        return self.W + self.b

    def forward(self, x):
        acts = [x]
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            z = acts[-1] @ W + b
            acts.append(np.tanh(z) if i < len(self.W) - 1 else z)
        return acts[-1], acts

    def backward(self, acts, dy):
        dW, db = [None] * len(self.W), [None] * len(self.W)
        d = dy
        for i in reversed(range(len(self.W))):
            if i < len(self.W) - 1:
                d = d * (1 - acts[i + 1] ** 2)
            dW[i] = acts[i].T @ d
            db[i] = d.sum(0)
            d = d @ self.W[i].T
        return d, dW + db


class Adam:
    def __init__(self, params, lr=1e-2, b1=0.9, b2=0.999):
        self.p, self.lr, self.b1, self.b2, self.t = params, lr, b1, b2, 0
        self.m = [np.zeros_like(q) for q in params]
        self.v = [np.zeros_like(q) for q in params]

    def step(self, grads):
        self.t += 1
        for q, g, m, v in zip(self.p, grads, self.m, self.v):
            m *= self.b1; m += (1 - self.b1) * g
            v *= self.b2; v += (1 - self.b2) * g * g
            q -= self.lr * (m / (1 - self.b1 ** self.t)) / (np.sqrt(v / (1 - self.b2 ** self.t)) + 1e-8)


# ------------------------------------------------ autoencoder
def train_autoencoder(X, zdim=1, hidden=16, steps=3000, lr=1e-2, rng=None):
    """Nonlinear autoencoder X -> z -> X_hat, mean-squared error. Returns (enc, dec, loss_history)."""
    rng = rng or np.random.default_rng(0)
    enc, dec = MLP([X.shape[1], hidden, zdim], rng), MLP([zdim, hidden, X.shape[1]], rng)
    opt = Adam(enc.params() + dec.params(), lr)
    hist = []
    for _ in range(steps):
        z, ce = enc.forward(X)
        xh, cd = dec.forward(z)
        r = xh - X
        hist.append(float((r ** 2).sum(1).mean()))
        dz, gd = dec.backward(cd, 2 * r / len(X))
        _, ge = enc.backward(ce, dz)
        opt.step(ge + gd)
    return enc, dec, hist


def pca_reconstruct(X, k):
    mu = X.mean(0)
    U, S, Vt = np.linalg.svd(X - mu, full_matrices=False)
    return (X - mu) @ Vt[:k].T @ Vt[:k] + mu


# ------------------------------------------------ VAE
def vae_loss_grads(enc, dec, X, eps, sigma2):
    """ELBO loss for a Gaussian-decoder VAE, averaged over the batch, and gradients for enc then dec parameters.

    loss = mean_i [ ||x - x_hat||^2 / (2 sigma2) + KL(q(z|x) || N(0,I)) ],  z = mu + exp(logv/2) * eps.
    Returns (loss, recon, kl, grads_enc, grads_dec)."""
    B, zd = len(X), eps.shape[1]
    out, ce = enc.forward(X)
    mu, logv = out[:, :zd], out[:, zd:]
    std = np.exp(0.5 * logv)
    z = mu + std * eps
    xh, cd = dec.forward(z)
    r = xh - X
    recon = float((r ** 2).sum(1).mean() / (2 * sigma2))
    kl = float((0.5 * (mu ** 2 + np.exp(logv) - 1 - logv).sum(1)).mean())
    dz, gd = dec.backward(cd, r / sigma2 / B)
    dmu = dz + mu / B
    dlogv = dz * eps * 0.5 * std + 0.5 * (np.exp(logv) - 1) / B
    _, ge = enc.backward(ce, np.concatenate([dmu, dlogv], 1))
    return recon + kl, recon, kl, ge, gd


def train_vae(X, zdim=2, hidden=32, steps=4000, lr=5e-3, sigma2=0.05, rng=None):
    rng = rng or np.random.default_rng(0)
    enc, dec = MLP([X.shape[1], hidden, 2 * zdim], rng), MLP([zdim, hidden, X.shape[1]], rng)
    opt = Adam(enc.params() + dec.params(), lr)
    hist = []
    for _ in range(steps):
        loss, rec, kl, ge, gd = vae_loss_grads(enc, dec, X, rng.normal(size=(len(X), zdim)), sigma2)
        opt.step(ge + gd)
        hist.append((loss, rec, kl))
    return enc, dec, np.array(hist)


def vae_sample(dec, n, zdim, rng):
    return dec.forward(rng.normal(size=(n, zdim)))[0]


# ------------------------------------------------ GAN
def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def train_gan_1d(real_sampler, steps=3000, zdim=2, hidden=24, lr=2e-3, batch=128, rng=None, snapshots=()):
    """1-D GAN: G(z) -> x, D(x) -> logit. D minimises -log D(x) - log(1-D(G(z))); G minimises the non-saturating -log D(G(z)).
    Returns (G, D, {step: generated sample array})."""
    rng = rng or np.random.default_rng(0)
    G, D = MLP([zdim, hidden, hidden, 1], rng), MLP([1, hidden, hidden, 1], rng)
    og, od = Adam(G.params(), lr, b1=0.5), Adam(D.params(), lr, b1=0.5)
    snaps = {}
    for t in range(steps + 1):
        if t in snapshots:
            snaps[t] = G.forward(rng.normal(size=(2000, zdim)))[0][:, 0].copy()
        if t == steps:
            break
        xr = real_sampler(batch)[:, None]
        xf = G.forward(rng.normal(size=(batch, zdim)))[0]
        lr_, cr = D.forward(xr)
        lf_, cf = D.forward(xf)
        _, g1 = D.backward(cr, (sigmoid(lr_) - 1) / batch)       # d(-log sigma(l))/dl = sigma(l) - 1
        _, g2 = D.backward(cf, sigmoid(lf_) / batch)             # d(-log(1-sigma(l)))/dl = sigma(l)
        od.step([a + b for a, b in zip(g1, g2)])
        zf = rng.normal(size=(batch, zdim))
        xf, cg = G.forward(zf)
        lf_, cf = D.forward(xf)
        dx, _ = D.backward(cf, (sigmoid(lf_) - 1) / batch)       # gradient through D into the fake sample
        _, gg = G.backward(cg, dx)
        og.step(gg)
    return G, D, snaps


def main():
    rng = np.random.default_rng(0)
    text = "the model learns the pattern the model predicts the next token " * 8
    for n in (1, 2, 3):
        m = CharNgram(n).fit(text)
        print(n, "perplexity", round(m.perplexity(text), 2), "|", m.generate(40, rng))


if __name__ == "__main__":
    main()
