"""Tests: pytest, or python test_genmodels_np.py."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import genmodels_np as G


def _numgrad(f, arr, idx, h=1e-6):
    old = arr[idx]
    arr[idx] = old + h; fp = f()
    arr[idx] = old - h; fm = f()
    arr[idx] = old
    return (fp - fm) / (2 * h)


def test_mlp_backprop_matches_finite_differences():
    rng = np.random.default_rng(0)
    net = G.MLP([3, 5, 2], rng); x = rng.normal(size=(4, 3)); t = rng.normal(size=(4, 2))
    def loss():
        return 0.5 * ((net.forward(x)[0] - t) ** 2).sum()
    y, c = net.forward(x); dx, grads = net.backward(c, y - t)
    for p, g in zip(net.params(), grads):
        for _ in range(3):
            idx = tuple(rng.integers(s) for s in p.shape)
            assert abs(_numgrad(loss, p, idx) - g[idx]) < 1e-6 * (1 + abs(g[idx]))


def test_vae_loss_gradients_match_finite_differences():
    rng = np.random.default_rng(1)
    X = rng.normal(size=(6, 2)); eps = rng.normal(size=(6, 2))
    enc, dec = G.MLP([2, 7, 4], rng), G.MLP([2, 7, 2], rng)
    f = lambda: G.vae_loss_grads(enc, dec, X, eps, 0.1)[0]
    _, _, _, ge, gd = G.vae_loss_grads(enc, dec, X, eps, 0.1)
    for p, g in zip(enc.params() + dec.params(), ge + gd):
        idx = tuple(rng.integers(s) for s in p.shape)
        assert abs(_numgrad(f, p, idx) - g[idx]) < 1e-5 * (1 + abs(g[idx]))


def test_kl_is_zero_for_standard_normal_posterior():
    rng = np.random.default_rng(0)
    enc = G.MLP([2, 3, 4], rng)
    for W in enc.W: W *= 0
    for b in enc.b: b *= 0                       # encoder outputs mu = 0, logvar = 0
    dec = G.MLP([2, 3, 2], rng)
    _, _, kl, _, _ = G.vae_loss_grads(enc, dec, np.ones((3, 2)), np.zeros((3, 2)), 0.1)
    assert abs(kl) < 1e-12


def test_generative_classifier_recovers_means_and_classifies():
    rng = np.random.default_rng(0)
    X = np.vstack([rng.normal([-2, 0], 1, (200, 2)), rng.normal([2, 0], 1, (200, 2))]); y = np.r_[np.zeros(200), np.ones(200)]
    m = G.fit_gaussian_classes(X, y)
    assert np.allclose(m[0][1], [-2, 0], atol=0.3) and (G.gaussian_predict(m, X) == y).mean() > 0.9
    wb = G.fit_logistic(X, y); assert (G.logistic_predict(wb, X) == y).mean() > 0.9


def test_ngram_prob_sums_to_one_and_train_perplexity_falls_with_order():
    text = "abracadabra alakazam abracadabra " * 5
    m = G.CharNgram(3).fit(text)
    s = sum(m.prob("ab", c) for c in m.vocab) + m.alpha / (m.alpha * (len(m.vocab) + 1) + sum(m.counts["ab"].values()))  # + unseen mass
    assert abs(s - 1) < 1e-9
    p = [G.CharNgram(n).fit(text).perplexity(text) for n in (1, 2, 3, 4)]
    assert p[0] > p[1] > p[2] >= p[3] - 1e-9


def test_autoencoder_beats_pca_on_a_curve():
    rng = np.random.default_rng(0)
    th = rng.uniform(-2.2, 2.2, 300); X = np.stack([np.cos(th), np.sin(th)], 1) + 0.02 * rng.normal(size=(300, 2))
    enc, dec, hist = G.train_autoencoder(X, 1, 16, 2500, rng=np.random.default_rng(0))
    mse_ae = hist[-1]; mse_pca = ((G.pca_reconstruct(X, 1) - X) ** 2).sum(1).mean()
    assert hist[-1] < hist[0] / 10 and mse_ae < 0.5 * mse_pca


def test_gan_moves_toward_the_real_mean():
    real = lambda n: np.random.default_rng(5).normal(3.0, 0.5, n)
    rs = np.random.default_rng(9)
    Gn, Dn, snaps = G.train_gan_1d(lambda n: rs.normal(3.0, 0.5, n), steps=1500, rng=np.random.default_rng(0), snapshots=(0, 1500))
    assert abs(snaps[1500].mean() - 3.0) < 0.6 and abs(snaps[0].mean() - 3.0) > abs(snaps[1500].mean() - 3.0)


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
    print("ok")
