"""Multimodal building blocks in plain numpy: a conditional diffusion model (DDPM and DDIM sampling, classifier-free guidance),
a CLIP-style contrastive model, image/video patch tokens, log-mel audio features and word error rate.

See README.md. The diffusion denoiser is a small MLP with hand-written backpropagation (codes/genmodels/genmodels_np).
"""
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "genmodels", "genmodels_np"))
from genmodels_np import MLP, Adam  # noqa: E402


# ------------------------------------------------------------------ diffusion
def make_schedule(T=1000, b0=1e-4, b1=0.02):
    """Linear beta schedule of Ho et al. 2020 (T = 1000, 1e-4 to 0.02). Returns betas, alphas, alpha_bar."""
    betas = np.linspace(b0, b1, T)
    alphas = 1 - betas
    return betas, alphas, np.cumprod(alphas)


def q_sample(x0, t, eps, abar):
    """Forward noising in one step: x_t = sqrt(abar_t) x0 + sqrt(1 - abar_t) eps. t: integer array (one per row of x0)."""
    return np.sqrt(abar[t])[:, None] * x0 + np.sqrt(1 - abar[t])[:, None] * eps


def time_embedding(t, T, dim=16):
    """Sinusoidal embedding of the (normalised) step index with geometrically spaced frequencies."""
    freqs = np.exp(np.linspace(0, np.log(100.0), dim // 2))
    arg = 2 * np.pi * (np.asarray(t, float) / T)[:, None] * freqs[None]
    return np.concatenate([np.sin(arg), np.cos(arg)], 1)


class Denoiser:
    """eps_theta(x_t, t, c): MLP on [x_t, time embedding, one-hot class (K classes + a 'null' slot)]."""

    def __init__(self, d, K, hidden, T, rng, temb=16):
        self.d, self.K, self.T, self.temb = d, K, T, temb
        self.net = MLP([d + temb + K + 1, hidden, hidden, d], rng)

    def inputs(self, x, t, c):
        onehot = np.zeros((len(x), self.K + 1)); onehot[np.arange(len(x)), c] = 1.0
        return np.concatenate([x, time_embedding(t, self.T, self.temb), onehot], 1)

    def __call__(self, x, t, c):
        return self.net.forward(self.inputs(x, t, c))[0]


def train_denoiser(X, labels, K, T=1000, steps=6000, batch=512, lr=2e-3, hidden=96, p_uncond=0.1, rng=None, lr_final=None):
    """Train eps_theta by regressing the added noise (Ho et al. 2020, Algorithm 1) with class labels dropped to 'null' with prob p_uncond
    (the recipe of classifier-free guidance). Returns (Denoiser, loss history)."""
    rng = rng or np.random.default_rng(0)
    _, _, abar = make_schedule(T)
    den = Denoiser(X.shape[1], K, hidden, T, rng)
    opt = Adam(den.net.params(), lr)
    hist = []
    for s in range(steps):
        if lr_final is not None:
            opt.lr = lr_final + 0.5 * (lr - lr_final) * (1 + math.cos(math.pi * s / steps))     # cosine decay of the learning rate
        idx = rng.integers(0, len(X), batch)
        x0 = X[idx]; c = np.where(rng.random(batch) < p_uncond, K, labels[idx])
        t = rng.integers(0, T, batch); eps = rng.normal(size=x0.shape)
        xt = q_sample(x0, t, eps, abar)
        out, acts = den.net.forward(den.inputs(xt, t, c))
        r = out - eps
        hist.append(float((r ** 2).mean()))
        _, g = den.net.backward(acts, 2 * r / r.size)
        opt.step(g)
    return den, np.array(hist)


def guided_eps(den, x, t, c, w):
    """Classifier-free guidance (Ho and Salimans 2022): (1 + w) eps(x, c) - w eps(x, null). c = None means unconditional."""
    n = len(x); null = np.full(n, den.K)
    if c is None:
        return den(x, t, null)
    ec = den(x, t, c)
    return ec if w == 0 else (1 + w) * ec - w * den(x, t, null)


def sample_ddpm(den, n, rng, c=None, w=0.0, return_path=False):
    """Ancestral sampling (Ho et al. 2020, Algorithm 2) with sigma_t^2 = beta_t. Returns samples (and the list of states every 100 steps)."""
    T = den.T; betas, alphas, abar = make_schedule(T)
    x = rng.normal(size=(n, den.d)); path = [x.copy()]
    cc = None if c is None else np.full(n, c) if np.isscalar(c) else np.asarray(c)
    for t in range(T - 1, -1, -1):
        tt = np.full(n, t)
        eps = guided_eps(den, x, tt, cc, w)
        mean = (x - betas[t] / np.sqrt(1 - abar[t]) * eps) / np.sqrt(alphas[t])
        x = mean + (np.sqrt(betas[t]) * rng.normal(size=x.shape) if t > 0 else 0)
        if return_path and t % 100 == 0:
            path.append(x.copy())
    return (x, path) if return_path else x


def ddim_timesteps(T, steps):
    """A decreasing subsequence of `steps` step indices from T-1 to 0."""
    return np.unique(np.round(np.linspace(T - 1, 0, steps)).astype(int))[::-1]


def sample_ddim(den, n, steps, rng, c=None, w=0.0, eta=0.0, x_T=None):
    """DDIM sampling (Song et al. 2020) over a subsequence of `steps` timesteps. eta = 0 is deterministic given x_T."""
    T = den.T; _, _, abar = make_schedule(T)
    ts = ddim_timesteps(T, steps)
    x = rng.normal(size=(n, den.d)) if x_T is None else x_T.copy()
    cc = None if c is None else np.full(n, c) if np.isscalar(c) else np.asarray(c)
    for i, t in enumerate(ts):
        ab, ab_prev = abar[t], (abar[ts[i + 1]] if i + 1 < len(ts) else 1.0)
        eps = guided_eps(den, x, np.full(n, t), cc, w)
        x0 = (x - np.sqrt(1 - ab) * eps) / np.sqrt(ab)
        sigma = eta * math.sqrt((1 - ab_prev) / (1 - ab)) * math.sqrt(1 - ab / ab_prev)
        x = np.sqrt(ab_prev) * x0 + np.sqrt(max(1 - ab_prev - sigma ** 2, 0)) * eps + (sigma * rng.normal(size=x.shape) if sigma > 0 else 0)
    return x


def three_arcs(n, rng, radius=2.0, noise=0.12):
    """Toy data: three noisy arcs of a circle (classes 0, 1, 2), each spanning 100 degrees with 20-degree gaps. Returns points and class labels."""
    y = rng.integers(0, 3, n); ang = np.deg2rad(y * 120 + 10 + 100 * rng.random(n)); r = radius + noise * rng.normal(size=n)
    return np.stack([r * np.cos(ang), r * np.sin(ang)], 1), y


def class_purity(samples, labels):
    """Share of 2-D samples whose polar angle lies in the arc of the requested class (arcs: class*120+10 to class*120+110 degrees, with 10 degrees of slack)."""
    ang = np.rad2deg(np.arctan2(samples[:, 1], samples[:, 0])) % 360
    lab = np.asarray(labels) * np.ones(len(samples), int)
    lo, hi = lab * 120 + 0, lab * 120 + 120
    return float(((ang >= lo) & (ang < hi)).mean())


def sliced_wasserstein(X, Y, rng, n_proj=128):
    """Sliced 1-Wasserstein distance between two point clouds (equal sizes are used): average over random directions of the mean
    absolute difference of the sorted 1-D projections. 0 for identical clouds; larger = more different."""
    n = min(len(X), len(Y)); X, Y = X[:n], Y[:n]
    U = rng.normal(size=(X.shape[1], n_proj)); U /= np.linalg.norm(U, axis=0)
    return float(np.abs(np.sort(X @ U, 0) - np.sort(Y @ U, 0)).mean())


# ------------------------------------------------------------------ contrastive (CLIP-style)
def clip_loss_and_grads(Wx, Wt, X, Tt, tau):
    """Symmetric InfoNCE: rows and columns of the cosine-similarity matrix / tau are classified with the matching pair as the label.
    Z_x = norm(X Wx^T), Z_t = norm(Tt Wt^T). Returns (loss, dWx, dWt, similarity matrix)."""
    ax, at = X @ Wx.T, Tt @ Wt.T
    nx, nt = np.linalg.norm(ax, axis=1, keepdims=True), np.linalg.norm(at, axis=1, keepdims=True)
    Zx, Zt = ax / nx, at / nt
    S = Zx @ Zt.T / tau; N = len(X)
    def softmax(M): M = M - M.max(1, keepdims=True); E = np.exp(M); return E / E.sum(1, keepdims=True)
    Pr, Pc = softmax(S), softmax(S.T)
    loss = float(-(np.log(np.diag(Pr)).mean() + np.log(np.diag(Pc)).mean()) / 2)
    dS = ((Pr - np.eye(N)) + (Pc - np.eye(N)).T) / (2 * N)
    dZx, dZt = dS @ Zt / tau, dS.T @ Zx / tau
    dax = (dZx - Zx * (dZx * Zx).sum(1, keepdims=True)) / nx                     # backprop through x / ||x||
    dat = (dZt - Zt * (dZt * Zt).sum(1, keepdims=True)) / nt
    return loss, dax.T @ X, dat.T @ Tt, S


def make_pairs(n, K, dx, dt, rng, img_noise=0.7, protos=None, syn=3):
    """Toy image-text pairs. Image feature = unit prototype of the class + noise. Caption = bag of words: 2 words drawn from the class's `syn`
    synonyms plus 1 random distractor word. Returns X (n, dx), Tt (n, dt), class labels, prototypes."""
    protos = rng.normal(size=(K, dx)) if protos is None else protos
    protos = protos / np.linalg.norm(protos, axis=1, keepdims=True)
    y = rng.integers(0, K, n); X = protos[y] * 3 + img_noise * rng.normal(size=(n, dx)); Tt = np.zeros((n, dt))
    for i in range(n):
        for w in rng.choice(syn, 2, replace=False): Tt[i, y[i] * syn + w] += 1
        Tt[i, rng.integers(0, dt)] += 1
    return X, Tt, y, protos


def train_clip(X, Tt, k, steps, batch, tau, lr, rng):
    """Adam on the symmetric contrastive loss with linear encoders. Returns (Wx, Wt, loss history)."""
    Wx, Wt = rng.normal(0, 0.3, (k, X.shape[1])), rng.normal(0, 0.3, (k, Tt.shape[1]))
    opt = Adam([Wx, Wt], lr); hist = []
    for _ in range(steps):
        idx = rng.choice(len(X), batch, replace=False)
        loss, gx, gt, _ = clip_loss_and_grads(Wx, Wt, X[idx], Tt[idx], tau); opt.step([gx, gt]); hist.append(loss)
    return Wx, Wt, np.array(hist)


def embed(W, F):
    a = F @ W.T
    return a / np.linalg.norm(a, axis=1, keepdims=True)


# ------------------------------------------------------------------ patches and tokens
def patchify(img, P):
    """(H, W, C) image -> (N, P*P*C) flattened patches in row-major order, N = (H/P)(W/P) (Dosovitskiy et al. 2020, Section 3.1)."""
    H, W, C = img.shape
    assert H % P == 0 and W % P == 0
    return img.reshape(H // P, P, W // P, P, C).transpose(0, 2, 1, 3, 4).reshape(-1, P * P * C)


def unpatchify(patches, H, W, P, C):
    return patches.reshape(H // P, W // P, P, P, C).transpose(0, 2, 1, 3, 4).reshape(H, W, C)


def n_image_tokens(H, W, P):
    return (H // P) * (W // P)


def n_video_tokens(frames, H, W, P, tubelet=1):
    return (frames // tubelet) * n_image_tokens(H, W, P)


def attention_cost_ratio(n_tokens, n_ref):
    """Self-attention score cost grows like n^2 (Unit 2): ratio of the costs for n_tokens and n_ref."""
    return (n_tokens / n_ref) ** 2


# ------------------------------------------------------------------ audio and speech
def stft_power(x, n_fft=400, hop=160, center=True):
    """Short-time Fourier transform power spectrogram with a Hann window. Returns (frames, n_fft//2 + 1)."""
    x = np.asarray(x, float)
    if center:
        x = np.pad(x, n_fft // 2, mode="reflect")
    n = 1 + (len(x) - n_fft) // hop
    win = 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(n_fft) / n_fft)
    frames = np.stack([x[i * hop:i * hop + n_fft] * win for i in range(n)])
    return np.abs(np.fft.rfft(frames, axis=1)) ** 2


def hz_to_mel(f):
    return 2595.0 * np.log10(1.0 + np.asarray(f, float) / 700.0)


def mel_to_hz(m):
    return 700.0 * (10 ** (np.asarray(m, float) / 2595.0) - 1.0)


def mel_filterbank(sr=16000, n_fft=400, n_mels=80, fmin=0.0, fmax=None):
    """Triangular mel filters, shape (n_mels, n_fft//2 + 1); centres equally spaced on the (HTK) mel scale."""
    fmax = fmax or sr / 2
    pts = mel_to_hz(np.linspace(hz_to_mel(fmin), hz_to_mel(fmax), n_mels + 2))
    freqs = np.linspace(0, sr / 2, n_fft // 2 + 1)
    fb = np.zeros((n_mels, len(freqs)))
    for m in range(n_mels):
        lo, c, hi = pts[m], pts[m + 1], pts[m + 2]
        fb[m] = np.maximum(0, np.minimum((freqs - lo) / (c - lo), (hi - freqs) / (hi - c)))
    return fb


def log_mel(x, sr=16000, n_fft=400, hop=160, n_mels=80):
    """Log-magnitude mel spectrogram, shape (frames, n_mels): the speech-model input of Radford et al. 2022 (16 kHz, 25 ms window, 10 ms hop, 80 mels)."""
    return np.log10(np.maximum(stft_power(x, n_fft, hop) @ mel_filterbank(sr, n_fft, n_mels).T, 1e-10))


def wer(ref, hyp):
    """Word error rate: (substitutions + deletions + insertions) / number of reference words, by word-level edit distance."""
    r, h = ref.split(), hyp.split()
    d = np.zeros((len(r) + 1, len(h) + 1), int); d[:, 0] = np.arange(len(r) + 1); d[0] = np.arange(len(h) + 1)
    for i in range(1, len(r) + 1):
        for j in range(1, len(h) + 1):
            d[i, j] = min(d[i - 1, j] + 1, d[i, j - 1] + 1, d[i - 1, j - 1] + (r[i - 1] != h[j - 1]))
    return d[-1, -1] / max(len(r), 1)


def main():
    _, _, abar = make_schedule()
    print("abar at 100, 500, 1000:", np.round(abar[[99, 499, 999]], 4), " tokens 224/16:", n_image_tokens(224, 224, 16), " WER:", round(wer("the cat sat on the mat", "the cat sit on mat"), 3))


if __name__ == "__main__":
    main()


def save_denoiser(den, path):
    np.savez(path, **{f"W{i}": W for i, W in enumerate(den.net.W)}, **{f"b{i}": b for i, b in enumerate(den.net.b)}, meta=np.array([den.d, den.K, den.T, den.temb]))


def load_denoiser(path, hidden=None):
    z = np.load(path); d, K, T, temb = [int(v) for v in z["meta"]]; n = len([k for k in z.files if k.startswith("W")])
    den = Denoiser.__new__(Denoiser); den.d, den.K, den.T, den.temb = d, K, T, temb
    den.net = MLP.__new__(MLP); den.net.W = [z[f"W{i}"] for i in range(n)]; den.net.b = [z[f"b{i}"] for i in range(n)]
    return den
