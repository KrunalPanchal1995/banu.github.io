"""Train the toy conditional diffusion model used by the Unit 7 figures and the browser widget. Writes data/diffusion_toy_weights.npz.
Run: python train_diffusion_toy.py   (about 5 minutes on a laptop CPU)."""
import json
import os
import time

import numpy as np

import multimodal_np as M

HERE = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(0)
X, y = M.three_arcs(8000, rng)
t0 = time.time()
den, hist = M.train_denoiser(X, y, 3, steps=30000, batch=512, hidden=128, lr=2e-3, lr_final=2e-4, p_uncond=0.1, rng=np.random.default_rng(1))
M.save_denoiser(den, os.path.join(HERE, "data", "diffusion_toy_weights.npz"))
ref, _ = M.three_arcs(1500, np.random.default_rng(5))
smp = M.sample_ddim(den, 1500, 50, np.random.default_rng(2))
meta = {"train_seconds": round(time.time() - t0, 1), "final_loss": float(hist[-500:].mean()), "sw_ddim50_vs_data": M.sliced_wasserstein(smp, ref, np.random.default_rng(3))}
json.dump(meta, open(os.path.join(HERE, "data", "diffusion_toy_meta.json"), "w"), indent=1)
print(meta)
