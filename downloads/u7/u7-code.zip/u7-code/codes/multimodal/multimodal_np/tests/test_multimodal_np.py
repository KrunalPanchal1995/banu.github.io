"""Tests: pytest, or python test_multimodal_np.py."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import multimodal_np as M


class Oracle:
    """A perfect denoiser for a known x0: returns the TRUE noise in x_t. Any correct sampler must then recover x0."""
    def __init__(self, x0, T=1000):
        self.x0, self.d, self.K, self.T = x0, x0.shape[1], 3, T
        self.abar = M.make_schedule(T)[2]
    def __call__(self, x, t, c):
        return (x - np.sqrt(self.abar[t])[:, None] * self.x0) / np.sqrt(1 - self.abar[t])[:, None]


def test_schedule_matches_ddpm_values():
    b, a, ab = M.make_schedule()
    assert len(b) == 1000 and abs(b[0] - 1e-4) < 1e-12 and abs(b[-1] - 0.02) < 1e-12 and np.all(np.diff(ab) < 0)
    assert abs(ab[99] - 0.897) < 1e-3 and abs(ab[499] - 0.0786) < 1e-3 and abs(ab[-1] - 4.04e-5) < 1e-6


def test_forward_noising_variance_and_mean():
    rng = np.random.default_rng(0); ab = M.make_schedule()[2]
    x0 = np.ones((200000, 1)) * 2.0; t = np.full(200000, 500); xt = M.q_sample(x0, t, rng.normal(size=x0.shape), ab)
    assert abs(xt.mean() - np.sqrt(ab[500]) * 2) < 0.01 and abs(xt.var() - (1 - ab[500])) < 0.01


def test_ddpm_reverse_mean_equals_true_posterior_mean():
    b, a, ab = M.make_schedule(); rng = np.random.default_rng(1)
    x0 = rng.normal(size=(5, 2)); eps = rng.normal(size=(5, 2))
    for t in (1, 50, 700):
        xt = np.sqrt(ab[t]) * x0 + np.sqrt(1 - ab[t]) * eps
        mean = (xt - b[t] / np.sqrt(1 - ab[t]) * eps) / np.sqrt(a[t])                                       # eps-parameterised mean
        post = np.sqrt(ab[t - 1]) * b[t] / (1 - ab[t]) * x0 + np.sqrt(a[t]) * (1 - ab[t - 1]) / (1 - ab[t]) * xt  # posterior mean of q(x_{t-1} | x_t, x0)
        assert np.allclose(mean, post, atol=1e-10)


def test_ddim_with_a_perfect_denoiser_recovers_x0_for_any_number_of_steps():
    rng = np.random.default_rng(2); x0 = rng.normal(size=(6, 2)); orc = Oracle(x0)
    ab = orc.abar; xT = np.sqrt(ab[999]) * x0 + np.sqrt(1 - ab[999]) * rng.normal(size=x0.shape)
    for steps in (1, 5, 50, 1000):
        out = M.sample_ddim(orc, 6, steps, rng, x_T=xT)
        assert np.allclose(out, x0, atol=1e-6), steps


def test_ddim_is_deterministic_and_timesteps_decrease():
    ts = M.ddim_timesteps(1000, 10); assert ts[0] == 999 and ts[-1] == 0 and np.all(np.diff(ts) < 0) and len(ts) == 10
    rng = np.random.default_rng(0); den = M.Denoiser(2, 3, 16, 1000, rng); xT = rng.normal(size=(4, 2))
    assert np.allclose(M.sample_ddim(den, 4, 10, rng, x_T=xT), M.sample_ddim(den, 4, 10, np.random.default_rng(9), x_T=xT))


def test_classifier_free_guidance_formula():
    rng = np.random.default_rng(0); den = M.Denoiser(2, 3, 16, 1000, rng); x = rng.normal(size=(5, 2)); t = np.full(5, 300); c = np.array([0, 1, 2, 0, 1])
    ec, eu = den(x, t, c), den(x, t, np.full(5, 3))
    assert np.allclose(M.guided_eps(den, x, t, c, 0.0), ec) and np.allclose(M.guided_eps(den, x, t, c, 2.5), 3.5 * ec - 2.5 * eu)
    assert np.allclose(M.guided_eps(den, x, t, None, 5.0), eu)


def test_denoiser_training_reduces_loss_and_predicts_noise():
    rng = np.random.default_rng(0); th = rng.uniform(0, 2 * np.pi, 600); X = np.stack([2 * np.cos(th), 2 * np.sin(th)], 1); y = (th // (2 * np.pi / 3)).astype(int) % 3
    den, hist = M.train_denoiser(X, y, 3, steps=600, batch=256, hidden=48, rng=np.random.default_rng(1))
    assert hist[-100:].mean() < 0.8 * hist[:20].mean() and hist[-100:].mean() < 0.9
    ab = M.make_schedule()[2]
    for tt, min_corr in ((100, 0.4), (300, 0.7), (600, 0.95)):                  # harder at LOW noise (the net must know the data shape), easy at high noise
        t = np.full(600, tt); eps = rng.normal(size=X.shape); xt = M.q_sample(X, t, eps, ab)
        assert np.corrcoef(den(xt, t, y).ravel(), eps.ravel())[0, 1] > min_corr, tt


def test_sliced_wasserstein_basic_properties():
    rng = np.random.default_rng(0); X = rng.normal(size=(500, 2)); assert M.sliced_wasserstein(X, X, rng) < 1e-12
    d1, d2 = M.sliced_wasserstein(X, X + 1.0, np.random.default_rng(1)), M.sliced_wasserstein(X, X + 2.0, np.random.default_rng(1))
    assert 0 < d1 < d2 and abs(d2 / d1 - 2) < 0.05


def test_clip_gradients_match_finite_differences_and_training_aligns_pairs():
    rng = np.random.default_rng(0); X, Tt, y, _ = M.make_pairs(8, 3, 6, 9, rng)
    Wx, Wt = rng.normal(0, 0.3, (4, 6)), rng.normal(0, 0.3, (4, 9)); loss, gx, gt, _ = M.clip_loss_and_grads(Wx, Wt, X, Tt, 0.3)
    for W, g in ((Wx, gx), (Wt, gt)):
        for _ in range(3):
            i, j = rng.integers(W.shape[0]), rng.integers(W.shape[1]); old = W[i, j]; h = 1e-6
            W[i, j] = old + h; lp = M.clip_loss_and_grads(Wx, Wt, X, Tt, 0.3)[0]; W[i, j] = old - h; lm = M.clip_loss_and_grads(Wx, Wt, X, Tt, 0.3)[0]; W[i, j] = old
            assert abs((lp - lm) / (2 * h) - g[i, j]) < 1e-6 * (1 + abs(g[i, j]))
    X, Tt, y, protos = M.make_pairs(600, 4, 12, 12, np.random.default_rng(1)); Wx, Wt, hist = M.train_clip(X, Tt, 6, 300, 32, 0.1, 0.02, np.random.default_rng(2))
    assert hist[-30:].mean() < 0.6 * hist[:10].mean()
    Xte, Tte, yte, _ = M.make_pairs(300, 4, 12, 12, np.random.default_rng(3), protos=protos)
    prompts = np.zeros((4, 12)); [prompts.__setitem__((c, c * 3), 1.0) for c in range(4)]                   # a one-word caption per class
    pred = (M.embed(Wx, Xte) @ M.embed(Wt, prompts).T).argmax(1); assert (pred == yte).mean() > 0.6          # zero-shot classification above chance (0.25)


def test_patchify_roundtrip_and_token_counts():
    img = np.random.default_rng(0).random((32, 48, 3)); p = M.patchify(img, 16)
    assert p.shape == (6, 768) and np.allclose(M.unpatchify(p, 32, 48, 16, 3), img) and np.allclose(p[0], img[:16, :16].ravel())
    assert M.n_image_tokens(224, 224, 16) == 196 and M.n_video_tokens(16, 224, 224, 16) == 3136 and M.n_video_tokens(16, 224, 224, 16, tubelet=2) == 1568
    assert M.attention_cost_ratio(784, 196) == 16.0


def test_stft_log_mel_and_frame_counts():
    sr = 16000; t = np.arange(sr) / sr; x = np.sin(2 * np.pi * 1000 * t)
    P = M.stft_power(x); assert P.shape == (101, 201) and abs(P[50].argmax() * sr / 400 - 1000) < 1                # 1 s -> 101 frames; peak at 1000 Hz
    fb = M.mel_filterbank(sr, 400, 80); assert fb.shape == (80, 201) and fb.min() >= 0 and (fb.sum(1) > 0).all()
    L = M.log_mel(x); assert L.shape == (101, 80) and abs(int(np.argmax(L[50])) - 28) <= 1                      # a 1 kHz tone lights mel band 27-28 (1000 mel of 2840 mel = 35% of 80 bands)
    assert M.log_mel(np.zeros(30 * sr)).shape[0] in (3000, 3001) and abs(M.hz_to_mel(M.mel_to_hz(1234.0)) - 1234.0) < 1e-9


def test_wer_hand_cases():
    assert M.wer("the cat sat on the mat", "the cat sit on mat") == 2 / 6
    assert M.wer("a b c", "a b c") == 0 and M.wer("a b c", "") == 1 and M.wer("a b", "a b c d") == 1.0 and M.wer("a b c d", "d c b a") == 1.0


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
    print("ok")
