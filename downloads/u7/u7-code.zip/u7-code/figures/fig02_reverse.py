"""Fig 2: reverse (DDPM, 1000 steps) path from pure noise to data, and the final samples against the data."""
from _den import *
smp, path = M.sample_ddpm(den, 1500, np.random.default_rng(2), return_path=True)
fig, axs = plt.subplots(1, 6, figsize=(9.2, 1.9), layout="constrained")
for ax, (k, p) in zip(axs[:5], [(0, path[0]), (1, path[3]), (2, path[6]), (3, path[8]), (4, path[10])]):
    ax.scatter(p[:, 0], p[:, 1], s=2, color=PAL["blue"]); ax.set(xlim=(-4, 4), ylim=(-4, 4), aspect="equal", xticks=[], yticks=[], title=f"t = {[999, 699, 399, 199, 0][k] if k else 1000}")
axs[5].scatter(ref[:, 0], ref[:, 1], s=2, color=PAL["grey"], label="data"); axs[5].scatter(smp[:, 0], smp[:, 1], s=2, color=PAL["blue"], alpha=.6); axs[5].set(xlim=(-4, 4), ylim=(-4, 4), aspect="equal", xticks=[], yticks=[], title="samples vs data")
save(fig, out("fig02_reverse.png")); print("path lengths", len(path)); print("SW samples vs data", round(M.sliced_wasserstein(smp, ref, np.random.default_rng(3)), 4), "| noise vs data", round(M.sliced_wasserstein(np.random.default_rng(4).normal(size=(1500, 2)), ref, np.random.default_rng(3)), 4), "| fresh data vs data", round(M.sliced_wasserstein(M.three_arcs(1500, np.random.default_rng(9))[0], ref, np.random.default_rng(3)), 4))
