"""Fig 5: an image becomes a sequence of patch tokens; token counts and attention cost for images, video and audio."""
from _common import *
use_code("multimodal/multimodal_np")
import multimodal_np as M
yy, xx = np.mgrid[0:96, 0:96]; img = np.stack([xx / 96, yy / 96, ((xx - 48) ** 2 + (yy - 48) ** 2 < 28 ** 2) * 0.9], 2)
fig, axs = plt.subplots(1, 3, figsize=(8.6, 2.9), layout="constrained")
axs[0].imshow(img); [axs[0].axhline(v - .5, color="w", lw=.6) for v in range(0, 96, 32)]; [axs[0].axvline(v - .5, color="w", lw=.6) for v in range(0, 96, 32)]
axs[0].set(title="96x96 image, 32x32 patches: 9 tokens"); axs[0].set_xticks([]); axs[0].set_yticks([]); axs[0].grid(False)
for i in range(3):
    for j in range(3): axs[0].text(j * 32 + 16, i * 32 + 16, str(i * 3 + j + 1), color="w", ha="center", va="center", fontsize=9)
P = M.patchify(img, 32); print("patchify:", img.shape, "-> patches", P.shape, "(9 patches of 32*32*3 = 3072 numbers)"); assert np.allclose(M.unpatchify(P, 96, 96, 32, 3), img)
sides = np.array([112, 224, 336, 448, 672, 896])
for p, c in [(32, PAL["green"]), (16, PAL["blue"]), (8, PAL["red"])]: axs[1].loglog(sides, [M.n_image_tokens(s, s, p) for s in sides], "o-", color=c, label=f"patch {p}")
axs[1].set(xlabel="image side (pixels)", ylabel="image tokens"); axs[1].legend(fontsize=7)
fr = np.array([1, 4, 8, 16, 32, 64]); n224 = M.n_image_tokens(224, 224, 16)
axs[2].loglog(fr, [M.n_video_tokens(f, 224, 224, 16) for f in fr], "o-", color=PAL["purple"], label="video tokens (224px, patch 16)"); axs[2].loglog(fr, [M.n_video_tokens(f, 224, 224, 16) ** 2 for f in fr], "s--", color=PAL["orange"], label="attention pairs (tokens^2)")
axs[2].set(xlabel="number of frames", ylabel="count"); axs[2].legend(fontsize=6)
save(fig, out("fig05_tokens.png"))
print("tokens, patch 16:", {int(s): M.n_image_tokens(int(s), int(s), 16) for s in sides}); print("attention-cost ratio vs 224px:", {int(s): M.attention_cost_ratio(M.n_image_tokens(int(s), int(s), 16), n224) for s in sides})
print("video 16 frames 224px patch 16:", M.n_video_tokens(16, 224, 224, 16), "tokens;", M.n_video_tokens(16, 224, 224, 16) ** 2, "pairs; vs one image:", M.n_video_tokens(16, 224, 224, 16) ** 2 / n224 ** 2, "x; with tubelet 2:", M.n_video_tokens(16, 224, 224, 16, 2))
print("image 224/16 patch vector size", 16 * 16 * 3, "numbers")
