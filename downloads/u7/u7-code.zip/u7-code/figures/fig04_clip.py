"""Fig 4: CLIP-style contrastive learning on toy image-text pairs: alignment before/after, batch size, temperature, zero-shot classification."""
from _common import *
use_code("multimodal/multimodal_np")
import multimodal_np as M
K, dx, dt, k = 6, 24, 18, 8
Xte, Tte, yte, protos = M.make_pairs(120, K, dx, dt, np.random.default_rng(100)); order = np.argsort(yte, kind="stable"); Xte, Tte, yte = Xte[order], Tte[order], yte[order]
prompts = np.zeros((K, dt)); [prompts.__setitem__((c, c * 3), 1.0) for c in range(K)]           # one-word caption per class (its first synonym)
def evaluate(Wx, Wt):
    Zi, Zt = M.embed(Wx, Xte), M.embed(Wt, Tte); S = Zi @ Zt.T
    ret = np.mean(yte[S.argmax(1)] == yte)                                                         # image -> caption: is the best caption of the same class?
    zs = np.mean((Zi @ M.embed(Wt, prompts).T).argmax(1) == yte)                                   # zero-shot: classify by prompt similarity
    return ret, zs, S
def run(batch, tau, steps=400, seed=0, lr=0.02):
    X, Tt, y, _ = M.make_pairs(1500, K, dx, dt, np.random.default_rng(seed), protos=protos)
    return M.train_clip(X, Tt, k, steps, batch, tau, lr, np.random.default_rng(seed + 50))
fig, axs = plt.subplots(1, 4, figsize=(8.6, 2.6), layout="constrained")
r0 = np.random.default_rng(7); W0x, W0t = r0.normal(0, 0.3, (k, dx)), r0.normal(0, 0.3, (k, dt)); ret0, zs0, S0 = evaluate(W0x, W0t)
Wx, Wt, hist = run(32, 0.1); ret1, zs1, S1 = evaluate(Wx, Wt)
for ax, S, ttl in [(axs[0], S0, f"before training (zero-shot {zs0:.2f})"), (axs[1], S1, f"after 400 steps (zero-shot {zs1:.2f})")]:
    ax.imshow(S, cmap="RdBu_r", vmin=-1, vmax=1); ax.set(title=ttl, xlabel="caption", ylabel="image"); ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
print("before: retrieval", round(ret0, 3), "zero-shot", round(zs0, 3), "| after: retrieval", round(ret1, 3), "zero-shot", round(zs1, 3), "| chance 1/6 =", round(1 / 6, 3))
bs = [2, 4, 8, 16, 32, 64]; accb = []
for b in bs:
    a = [evaluate(*run(b, 0.1, seed=s)[:2])[1] for s in range(4)]; accb.append((np.mean(a), np.std(a)))
axs[2].errorbar(range(len(bs)), [a[0] for a in accb], [a[1] for a in accb], fmt="o-", color=PAL["blue"], capsize=3); axs[2].set_xticks(range(len(bs)), bs); axs[2].axhline(1 / 6, color=PAL["grey"], ls=":"); axs[2].set(xlabel="batch size (negatives = batch - 1)", ylabel="zero-shot accuracy", ylim=(0, 1))
print("batch sizes", bs, "zero-shot acc mean", np.round([a[0] for a in accb], 3), "std", np.round([a[1] for a in accb], 3))
taus = [0.02, 0.05, 0.1, 0.3, 1.0]; acct = []
for tau in taus:
    a = [evaluate(*run(32, tau, seed=s)[:2])[1] for s in range(4)]; acct.append((np.mean(a), np.std(a)))
axs[3].errorbar(range(len(taus)), [a[0] for a in acct], [a[1] for a in acct], fmt="s-", color=PAL["red"], capsize=3); axs[3].set_xticks(range(len(taus)), taus); axs[3].axhline(1 / 6, color=PAL["grey"], ls=":"); axs[3].set(xlabel="temperature tau", ylabel="zero-shot accuracy", ylim=(0, 1))
print("temperatures", taus, "zero-shot acc mean", np.round([a[0] for a in acct], 3), "std", np.round([a[1] for a in acct], 3))
print("loss start/end (batch 32, tau 0.1):", hist[:10].mean().round(3), hist[-20:].mean().round(3), " log(batch)=", np.log(32).round(3))
save(fig, out("fig04_clip.png"))
