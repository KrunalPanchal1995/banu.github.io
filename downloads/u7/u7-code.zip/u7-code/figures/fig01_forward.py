"""Fig 1: forward diffusion on three arcs: the data dissolve into noise; alpha-bar schedule."""
from _den import *
X, y = M.three_arcs(1500, np.random.default_rng(0)); ab = M.make_schedule()[2]; ts = [0, 50, 150, 300, 600, 999]
fig, axs = plt.subplots(1, 7, figsize=(9.2, 1.9), layout="constrained")
for ax, t in zip(axs, ts):
    xt = X if t == 0 else M.q_sample(X, np.full(len(X), t), np.random.default_rng(1).normal(size=X.shape), ab)
    ax.scatter(xt[:, 0], xt[:, 1], c=[COL[i] for i in y], s=2); ax.set(xlim=(-4, 4), ylim=(-4, 4), aspect="equal", xticks=[], yticks=[], title=f"t = {t}")
axs[6].plot(ab, color=PAL["red"]); axs[6].set(xlabel="t", title="alpha-bar"); axs[6].grid(True)
save(fig, out("fig01_forward.png")); print("alpha-bar at", ts, np.round(ab[ts], 4)); print("signal share sqrt(abar):", np.round(np.sqrt(ab[ts]), 3), "noise share sqrt(1-abar):", np.round(np.sqrt(1 - ab[ts]), 3))
