from _common import *
use_code("multimodal/multimodal_np")
import multimodal_np as M
den = M.load_denoiser(os.path.join(KB, "codes", "multimodal", "multimodal_np", "data", "diffusion_toy_weights.npz"))
ref, _ = M.three_arcs(1500, np.random.default_rng(5)); COL = [PAL["blue"], PAL["orange"], PAL["green"]]
