"""Fig 3: DDIM quality against the number of sampling steps (eta = 0), DDPM-1000 for reference."""
from _den import *
steps = [2, 3, 5, 10, 25, 50, 100, 250, 1000]; sw = []; samples = {}
for s in steps:
    d = M.sample_ddim(den, 1500, s, np.random.default_rng(2)); samples[s] = d; sw.append(M.sliced_wasserstein(d, ref, np.random.default_rng(3)))
ddpm = M.sliced_wasserstein(M.sample_ddpm(den, 1500, np.random.default_rng(2)), ref, np.random.default_rng(3)); noise = M.sliced_wasserstein(np.random.default_rng(4).normal(size=(1500, 2)), ref, np.random.default_rng(3)); floor = M.sliced_wasserstein(M.three_arcs(1500, np.random.default_rng(9))[0], ref, np.random.default_rng(3))
fig = plt.figure(figsize=(8.6, 3.0), layout="constrained"); gs = fig.add_gridspec(1, 4); ax = fig.add_subplot(gs[0, :2])
ax.loglog(steps, sw, "o-", color=PAL["blue"], label="DDIM (deterministic)"); ax.axhline(ddpm, color=PAL["orange"], ls="--", label="DDPM, 1000 steps"); ax.axhline(noise, color=PAL["red"], ls=":", label="pure noise"); ax.axhline(floor, color=PAL["grey"], ls=":", label="fresh real data (floor)")
ax.set(xlabel="denoising steps", ylabel="sliced Wasserstein distance to data (lower = better)"); ax.legend(fontsize=6)
for i, s in enumerate((3, 10, 50)): a = fig.add_subplot(gs[0, 2 + (i // 2)]) if i < 2 else None
a = fig.add_subplot(gs[0, 2]); a.scatter(samples[3][:, 0], samples[3][:, 1], s=2, color=PAL["red"]); a.set(title="3 steps", xlim=(-4, 4), ylim=(-4, 4), aspect="equal", xticks=[], yticks=[])
a = fig.add_subplot(gs[0, 3]); a.scatter(samples[50][:, 0], samples[50][:, 1], s=2, color=PAL["blue"]); a.set(title="50 steps", xlim=(-4, 4), ylim=(-4, 4), aspect="equal", xticks=[], yticks=[])
save(fig, out("fig03_steps.png")); print("steps", steps); print("SW", np.round(sw, 4)); print("ddpm1000", round(ddpm, 4), "noise", round(noise, 4), "floor", round(floor, 4))
