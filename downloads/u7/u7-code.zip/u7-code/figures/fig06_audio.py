"""Fig 6: audio as a spectrogram: waveform, power spectrogram and 80-band log-mel features for a synthetic chirp plus a tone burst; frame counts."""
from _common import *
use_code("multimodal/multimodal_np")
import multimodal_np as M
sr = 16000; dur = 1.5; t = np.arange(int(sr * dur)) / sr
chirp = np.sin(2 * np.pi * (200 * t + (4000 - 200) / (2 * dur) * t ** 2)); burst = np.sin(2 * np.pi * 1000 * t) * ((t > 0.5) & (t < 0.8)); x = 0.6 * chirp + 0.8 * burst
P = M.stft_power(x); L = M.log_mel(x)
fig, axs = plt.subplots(1, 3, figsize=(8.8, 2.9), layout="constrained")
axs[0].plot(t[:1600], x[:1600], color=PAL["blue"], lw=.8); axs[0].set(xlabel="time (s), first 0.1 s", ylabel="amplitude", title="waveform: 16,000 numbers per second")
im = axs[1].imshow(10 * np.log10(P.T + 1e-10), origin="lower", aspect="auto", extent=[0, dur, 0, sr / 2 / 1000], cmap="magma", vmin=-40); axs[1].set(xlabel="time (s)", ylabel="frequency (kHz)", title=f"power spectrogram {P.shape[1]} bins"); axs[1].grid(False)
axs[2].imshow(L.T, origin="lower", aspect="auto", extent=[0, dur, 0, 80], cmap="magma"); axs[2].set(xlabel="time (s)", ylabel="mel band", title=f"log-mel: {L.shape[0]} frames x {L.shape[1]}"); axs[2].grid(False)
save(fig, out("fig06_audio.png"))
print("1.5 s:", P.shape, L.shape, "| frames per second", sr // 160, "| 30 s ->", M.log_mel(np.zeros(30 * sr)).shape, "| window 25 ms =", int(0.025 * sr), "samples, hop 10 ms =", int(0.01 * sr))
print("burst at 1 kHz lights mel band", int(L[int(0.65 * 100)].argmax()), "(expected 27-28); chirp rises: band at 0.2 s", int(L[20].argmax()), "band at 1.3 s", int(L[130].argmax()))
print("raw numbers per second: waveform 16000; log-mel 100 x 80 =", 100 * 80)
for r, h in [("the cat sat on the mat", "the cat sit on mat"), ("turn left at the corner", "turn left at the corner"), ("a b c d", "d c b a"), ("hello world", "")]: print(f"WER({r!r}, {h!r}) = {M.wer(r, h):.3f}")
