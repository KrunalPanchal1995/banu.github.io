"""Fig 7: classifier-free guidance on class 0: samples for guidance weights 0, 1, 3, 7 (DDIM, 50 steps), diversity and off-manifold radius."""
from _den import *
ws = [0, 1, 3, 7]; fig, axs = plt.subplots(1, 5, figsize=(9.2, 2.1), layout="constrained"); stats = []
for ax, w in zip(axs, ws):
    d = M.sample_ddim(den, 1000, 50, np.random.default_rng(2), c=0, w=w); ax.scatter(ref[:, 0], ref[:, 1], s=1, color=PAL["grey"], alpha=.3); ax.scatter(d[:, 0], d[:, 1], s=2, color=COL[0]); ax.set(title=f"w = {w}", xlim=(-5, 5), ylim=(-5, 5), aspect="equal", xticks=[], yticks=[])
    ang = np.rad2deg(np.arctan2(d[:, 1], d[:, 0])) % 360; r = np.linalg.norm(d, axis=1); inarc = (ang > 10) & (ang < 110)
    stats.append((w, M.class_purity(d, 0), ang[inarc].std(), r.mean(), r.std(), np.mean(np.abs(r - 2) > 0.5)))
a = axs[4]; a.plot(ws, [s[2] for s in stats], "o-", color=PAL["blue"], label="spread along the arc (deg)"); a2 = a.twinx(); a2.plot(ws, [s[4] for s in stats], "s--", color=PAL["red"], label="radius spread"); a.set(xlabel="guidance w", title="diversity vs artifacts"); a.legend(fontsize=5, loc="upper center"); a2.legend(fontsize=5, loc="center right")
save(fig, out("fig07_guidance.png"))
for s in stats: print(f"w={s[0]}: purity {s[1]:.3f}, angle std {s[2]:.1f} deg (true arc 28.9), radius mean {s[3]:.2f} std {s[4]:.2f}, off-circle (|r-2|>0.5) {s[5]:.2f}")
