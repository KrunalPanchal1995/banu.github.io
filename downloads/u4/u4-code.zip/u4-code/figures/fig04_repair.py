"""Fig 4: structured output: how many typical malformed model outputs does parse_json_lenient repair? And retries: 1-(1-q)^r."""
from _common import *
use_code("llm/prompting_tools")
import prompting_tools as P, json, random
random.seed(0); schema = {"type": "object", "required": ["label", "score"], "properties": {"label": {"enum": ["positive", "negative", "neutral"]}, "score": {"type": "number", "minimum": 0, "maximum": 1}}}
def gen(): return {"label": random.choice(["positive", "negative", "neutral"]), "score": round(random.random(), 2)}
mut = {"already valid": lambda s: s, "code fence": lambda s: "```json\n" + s + "\n```", "prose around": lambda s: "Sure! Here is the JSON:\n" + s + "\nLet me know if you need more.",
       "trailing comma": lambda s: s[:-1] + ",}", "single quotes": lambda s: s.replace('"', "'"), "truncated (no closing brace)": lambda s: s[:-1],
       "unquoted keys": lambda s: s.replace('"label"', "label").replace('"score"', "score"), "wrong value (label not in enum)": lambda s: s.replace(json.loads(s)["label"], "mixed")}
res = {}
for k, f in mut.items():
    ok = valid = 0
    for _ in range(300):
        s = f(json.dumps(gen()))
        try:
            obj, rep = P.parse_json_lenient(s); ok += 1; valid += not P.validate(obj, schema)
        except ValueError: pass
    res[k] = (ok / 300, valid / 300)
fig, axs = plt.subplots(1, 2, figsize=(8.0, 3.4), layout="constrained", gridspec_kw={"width_ratios": [1.5, 1]})
names = list(res); y = np.arange(len(names))
axs[0].barh(y, [res[n][0] for n in names], color=PAL["sky"], label="parses"); axs[0].barh(y, [res[n][1] for n in names], color=PAL["blue"], height=.4, label="parses AND passes the schema")
axs[0].set_yticks(y, names, fontsize=7); axs[0].invert_yaxis(); axs[0].set(xlabel="share of 300 outputs", xlim=(0, 1.05)); axs[0].legend(fontsize=6, loc="lower right")
rr = np.arange(0, 6)
for q, c in [(0.5, PAL["red"]), (0.8, PAL["orange"]), (0.95, PAL["green"])]: axs[1].plot(rr, 1 - (1 - q) ** (rr + 1), "o-", color=c, label=f"q = {q}")
axs[1].set(xlabel="retries allowed r", ylabel="P(valid within r+1 tries)", ylim=(0, 1.02)); axs[1].legend(fontsize=7)
save(fig, out("fig04_repair.png"))
for n in names: print(f"{n:34s} parses {res[n][0]:.2f}  valid {res[n][1]:.2f}")
