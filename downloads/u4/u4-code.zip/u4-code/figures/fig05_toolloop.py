"""Fig 5: a tool-calling exchange drawn from the real log of run_tool_loop (MockLLM + calculator)."""
from _common import *
use_code("llm/prompting_tools")
import prompting_tools as P, json
reg = P.ToolRegistry(); reg.register("calculator", lambda expression: P.safe_calc(expression), {"type": "object", "required": ["expression"], "properties": {"expression": {"type": "string"}}}, "evaluate arithmetic")
q = "Please calculate 23 * (4 + 6)"; ans, log = P.run_tool_loop(P.MockLLM(), reg, q)
steps = [("user", q)] + log
fig, ax = plt.subplots(figsize=(7.6, 3.5)); ax.axis("off"); ax.set_xlim(0, 10); ax.set_ylim(0, len(steps) * 1.0 + .4)
who = {"user": (1.0, PAL["blue"]), "assistant": (5.0, PAL["green"]), "tool": (9.0, PAL["orange"])}
for x, name in [(1.0, "USER"), (5.0, "MODEL"), (9.0, "TOOL (your code)")]: ax.text(x, len(steps) + .15, name, ha="center", weight="bold", fontsize=8)
prev = None
for i, (r, c) in enumerate(steps):
    y = len(steps) - i - .35; x, col = who[r]
    import textwrap; txt = textwrap.fill(c, 34); ax.text(x, y, txt, ha="center", va="center", fontsize=6.5, bbox=dict(boxstyle="round,pad=0.3", fc="none", ec=col))
    if prev: ax.annotate("", xy=(x, y + .18), xytext=prev, arrowprops=dict(arrowstyle="->", color=PAL["grey"]))
    prev = (x, y - .18)
save(fig, out("fig05_toolloop.png")); print("final answer:", ans); [print(r, "|", c) for r, c in log]
