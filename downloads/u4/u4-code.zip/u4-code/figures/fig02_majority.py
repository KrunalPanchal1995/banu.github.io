"""Fig 2: majority voting over k independent samples: exact binomial curves, Monte Carlo check."""
from _common import *
use_code("llm/prompting_tools")
import prompting_tools as P
ks = np.arange(1, 32, 2); fig, ax = plt.subplots(figsize=FIG["single"])
for p, c in [(0.4, PAL["red"]), (0.5, PAL["grey"]), (0.55, PAL["orange"]), (0.6, PAL["blue"]), (0.7, PAL["green"]), (0.8, PAL["purple"])]:
    ax.plot(ks, [P.majority_vote_accuracy(p, k) for k in ks], "-", color=c, label=f"p = {p}")
rng = np.random.default_rng(0); kk = [1, 5, 11, 21, 31]
ax.plot(kk, [P.mc_majority_accuracy(0.6, k, 200000, rng) for k in kk], "ko", ms=4, label="simulation, p = 0.6")
ax.set(xlabel="number of samples k voted over", ylabel="accuracy of the majority answer", ylim=(0, 1.02)); ax.legend(fontsize=7, ncol=2, loc="lower right")
save(fig, out("fig02_majority.png"))
for p in (0.4, 0.5, 0.55, 0.6, 0.7, 0.8): print(p, [round(P.majority_vote_accuracy(p, k), 3) for k in (1, 5, 11, 21, 31)])
print("MC p=0.6:", [round(P.mc_majority_accuracy(0.6, k, 200000, np.random.default_rng(1)), 3) for k in kk])
