"""Fig 3: how many test items do you need to tell two prompts apart? SIMULATION of paired outcomes, true accuracies 0.70 vs 0.75."""
from _common import *
use_code("llm/prompting_tools")
import prompting_tools as P
def sim(n, rng, pa=0.70, pb=0.75, rho=0.7):
    u = rng.random(n); a = (u < pa); u2 = np.where(rng.random(n) < rho, u, rng.random(n)); b = (u2 < pb); return a.astype(float), b.astype(float)
ns = [25, 50, 100, 200, 400, 800, 1200]; power = []; fp = []
for n in ns:
    hit = 0; fa = 0; r = np.random.default_rng(n)
    for s in range(150):
        a, b = sim(n, r); d, lo, hi = P.paired_bootstrap_ci(a, b, B=400, rng=r); hit += lo > 0
        a, b = sim(n, r, pb=0.70); d, lo, hi = P.paired_bootstrap_ci(a, b, B=400, rng=r); fa += (lo > 0) or (hi < 0)
    power.append(hit / 150); fp.append(fa / 150)
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
axs[0].semilogx(ns, power, "o-", color=PAL["blue"], label="B really better (0.75 vs 0.70)"); axs[0].semilogx(ns, fp, "s--", color=PAL["red"], label="no real difference (0.70 vs 0.70)")
axs[0].axhline(0.8, color=PAL["grey"], ls=":"); axs[0].axhline(0.05, color=PAL["grey"], ls=":"); axs[0].set(xlabel="test items n", ylabel="share of experiments whose 95% CI excludes 0", ylim=(-.02, 1.02)); axs[0].legend(fontsize=6)
r = np.random.default_rng(5)
for i in range(6):
    a, b = sim(100, r); d, lo, hi = P.paired_bootstrap_ci(a, b, rng=r); axs[1].errorbar(d, i, xerr=[[d - lo], [hi - d]], fmt="o", color=PAL["blue"] if lo > 0 else PAL["grey"], capsize=3)
axs[1].axvline(0, color="k", lw=.8); axs[1].axvline(0.05, color=PAL["green"], ls="--"); axs[1].set(yticks=[], xlabel="measured gain of B over A (95% CI)", title="six test sets of 100 items")
save(fig, out("fig03_power.png")); print("n", ns); print("power", power); print("false positive", fp)

# bias check and winner's curse at n = 100 (printed, quoted in the session text)
r = np.random.default_rng(0); ds = np.array([np.subtract(*sim(100, r)[::-1]).mean() for _ in range(4000)])
print("mean measured gain over 4000 test sets of 100:", round(ds.mean(), 4), "sd", round(ds.std(), 4))
r = np.random.default_rng(1); sig = []
for _ in range(600):
    a, b = sim(100, r); d, lo, hi = P.paired_bootstrap_ci(a, b, B=400, rng=r)
    if lo > 0: sig.append(d)
print("significant share", round(len(sig) / 600, 3), "mean measured gain among the significant ones", round(float(np.mean(sig)), 3), "(true gain 0.05)")
