"""Fig 1: what fits in the context window: a conversation packed into 4096 and 2048 tokens (fit_context keeps system + newest)."""
from _common import *
use_code("llm/prompting_tools")
import prompting_tools as P
def msg(role, tokens, label): return {"role": role, "content": "x" * (4 * tokens), "label": label}
msgs = [msg("system", 150, "system prompt")]
for i in range(3): msgs += [msg("user", 40, f"example {i+1} in"), msg("assistant", 60, f"example {i+1} out")]
msgs += [msg("user", 1500, "retrieved documents")]
for i in range(7): msgs += [msg("user", 50, f"turn {i+1} user"), msg("assistant", 120, f"turn {i+1} reply")]
msgs += [msg("user", 80, "NEW question")]
col = {"system": PAL["purple"], "user": PAL["blue"], "assistant": PAL["green"]}
pinned = [dict(m, pin=True) if m["label"].startswith("example") else m for m in msgs]
fig, axs = plt.subplots(3, 1, figsize=(7.6, 4.6), sharex=True, layout="constrained")
for ax, W, ms, tag in zip(axs, (4096, 2048, 2048), (msgs, msgs, pinned), ("", "", ", examples pinned")):
    kept, dropped = P.fit_context(ms, W, reserve_output=500)
    ids = {id(m) for m in kept}; x = 0
    for m in ms:
        t = P.approx_tokens(m["content"]); keep = id(m) in ids
        ax.barh(0, t, left=x, color=col[m["role"]] if keep else "none", edgecolor=col[m["role"]], hatch=None if keep else "///", lw=1.2, alpha=1 if keep else .6)
        x += t
    ax.axvline(W - 500, color=PAL["red"], ls="--"); ax.text(W - 500, .55, " output reserve starts", color=PAL["red"], fontsize=7, ha="right")
    ax.set(yticks=[], ylim=(-.5, .75), title=f"window {W}{tag}: kept {len(kept)} of {len(ms)} messages, dropped {len(dropped)} (hatched)", )
    print(W, tag, "kept tokens", sum(P.approx_tokens(m["content"]) for m in kept), "dropped", [m["label"] for m in dropped], "total tokens", x)
axs[2].set(xlabel="tokens (approx. 4 characters each), in conversation order")
save(fig, out("fig01_budget.png"))
