"""Fig 1: BPE on a real corpus (the course Syllabus): sequence length and vocab size vs number of merges."""
from _common import *
use_code("llm/tokens_decoding")
import tokens_decoding as td
text = open(os.path.join(KB, "Syllabus.md"), encoding="utf-8").read().lower()
text = "".join(c if c.isalpha() or c == " " else " " for c in text)
words = text.split()
n_chars = sum(len(w) + 1 for w in words)
Ms = [0, 5, 10, 20, 40, 80, 160, 320]
lens, vocs = [], []
for M in Ms:
    merges, hist = td.train_bpe(text, M)
    toks = td.encode(text, merges)
    lens.append(len(toks)); vocs.append(len(set(toks)))
fig, ax = plt.subplots(figsize=FIG["single"])
ax.plot(Ms, np.array(lens) / n_chars, "o-", color=PAL["blue"], label="tokens per character")
ax.set(xlabel="number of BPE merges", ylabel="tokens / character (lower = better compression)")
ax2 = ax.twinx(); ax2.plot(Ms, vocs, "s--", color=PAL["orange"], label="vocabulary size"); ax2.set_ylabel("distinct tokens used")
ax2.grid(False)
h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels(); ax.legend(h1 + h2, l1 + l2, loc="center right")
save(fig, out("fig01_bpe.png"))
print("chars", n_chars, "words", len(words)); print(list(zip(Ms, lens, vocs)))
