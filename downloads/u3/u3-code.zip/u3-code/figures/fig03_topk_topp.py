"""Fig 3: sorted probabilities, cumulative mass, and how many tokens top-k / top-p keep in a peaked vs flat state."""
from _common import *
use_code("llm/tokens_decoding")
import tokens_decoding as td
V = 40
rank = np.arange(1, V + 1)
peaked = td.softmax(-0.45 * rank * 1.0 + 6 * (rank == 1)); flat = td.softmax(-0.08 * rank)
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], sharey=True)
for ax, p, name in [(axs[0], peaked, "peaked (confident)"), (axs[1], flat, "flat (uncertain)")]:
    ax.plot(rank, np.cumsum(p), color=PAL["blue"], label="cumulative mass")
    ax.axhline(0.9, color=PAL["red"], ls="--", label="top-p = 0.9")
    n90 = int((td.top_p_filter(p, 0.9) > 0).sum()); ax.axvline(n90, color=PAL["red"], ls=":")
    ax.axvline(10, color=PAL["orange"], ls="-.", label="top-k = 10")
    ax.set(title=f"{name}: top-p keeps {n90}", xlabel="token rank")
axs[0].set_ylabel("cumulative probability"); axs[0].legend(loc="lower right")
fig.tight_layout(); save(fig, out("fig03_topk_topp.png"))
print("peaked kept", int((td.top_p_filter(peaked, .9) > 0).sum()), "flat kept", int((td.top_p_filter(flat, .9) > 0).sum()))
