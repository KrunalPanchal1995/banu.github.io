"""Fig 2: temperature reshapes the next-token distribution; entropy vs T."""
from _common import *
use_code("llm/tokens_decoding")
import tokens_decoding as td
toks = ["the", "a", "cat", "dog", "ran", "sat", "blue", "of"]
z = np.array([3.0, 2.2, 1.6, 1.4, 0.8, 0.5, -0.5, -1.0])
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], gridspec_kw={"width_ratios": [1.5, 1]})
w = 0.27
for i, (T, c) in enumerate([(0.3, PAL["red"]), (1.0, PAL["blue"]), (2.0, PAL["green"])]):
    axs[0].bar(np.arange(len(z)) + (i - 1) * w, td.softmax(z, T), w, color=c, label=f"T = {T}")
axs[0].set_xticks(range(len(z)), toks, rotation=30); axs[0].set(ylabel="probability"); axs[0].legend()
Ts = np.logspace(-1.3, 1.2, 60); H = [td.entropy_bits(td.softmax(z, T)) for T in Ts]
axs[1].semilogx(Ts, H, color=PAL["purple"]); axs[1].axhline(np.log2(len(z)), ls=":", color=PAL["grey"])
axs[1].text(0.06, np.log2(len(z)) - 0.25, "uniform = 3 bits", color=PAL["grey"], fontsize=8)
axs[1].set(xlabel="temperature T", ylabel="entropy (bits)")
fig.tight_layout(); save(fig, out("fig02_temperature.png"))
for T in (0.3, 1, 2): print(T, np.round(td.softmax(z, T), 3), round(td.entropy_bits(td.softmax(z, T)), 3))
