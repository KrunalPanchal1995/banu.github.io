"""Fig 4: loss vs parameters at fixed FLOPs (IsoFLOP) with the compute-optimal point D = 20 N."""
from _common import *
use_code("llm/tokens_decoding")
import tokens_decoding as td
fig, ax = plt.subplots(figsize=FIG["single"])
N = np.logspace(8.5, 12, 200)
for C, c in [(1e21, PAL["green"]), (1e22, PAL["blue"]), (1e23, PAL["orange"]), (1e24, PAL["red"])]:
    D = C / (6 * N); L = td.chinchilla_loss(N, D)
    ax.semilogx(N, L, color=c, label=f"C = {C:.0e} FLOPs")
    i = L.argmin(); ax.plot(N[i], L[i], "o", color=c); print(f"C={C:.0e} N*={N[i]:.2e} D*={D[i]:.2e} D/N={D[i]/N[i]:.1f} L={L[i]:.3f}")
    N20, D20 = td.compute_optimal(C); ax.plot(N20, td.chinchilla_loss(N20, D20), "D", mfc="none", color=c)
    print(f"   D=20N point: N={N20:.2e} L={td.chinchilla_loss(N20, D20):.3f}")
ax.plot([], [], "o", color="k", label="minimum of fitted L(N, D)"); ax.plot([], [], "D", mfc="none", color="k", label="rule of thumb D = 20 N")
ax.set(xlabel="parameters N", ylabel="predicted loss L(N, D) (nats)", ylim=(1.8, 3.2)); ax.legend()
save(fig, out("fig04_scaling.png"))
