"""Fig 5: cosine similarity of toy 2-D word vectors; analogy by vector arithmetic."""
from _common import *
E = {"king": (3.0, 3.2), "queen": (3.0, 1.2), "man": (1.0, 3.0), "woman": (1.0, 1.0), "apple": (-2.5, 1.5), "pear": (-2.8, 1.0)}
V = {k: np.array(v) for k, v in E.items()}
cos = lambda u, v: float(u @ v / (np.linalg.norm(u) * np.linalg.norm(v)))
fig, ax = plt.subplots(figsize=FIG["square"])
for k, v in V.items(): ax.annotate("", xy=v, xytext=(0, 0), arrowprops=dict(arrowstyle="->", color=PAL["blue"])); ax.text(v[0] + .05, v[1] + .08, k)
a = V["king"] - V["man"] + V["woman"]; ax.plot(*a, "x", color=PAL["red"], ms=9); ax.text(a[0] + .05, a[1] - .3, "king-man+woman", color=PAL["red"], fontsize=8)
ax.set(xlim=(-3.5, 4), ylim=(-0.5, 4), xlabel="dim 1", ylabel="dim 2"); ax.set_aspect("equal")
save(fig, out("fig05_embeddings.png"))
print("cos(king,queen)", round(cos(V['king'], V['queen']), 3), "cos(apple,pear)", round(cos(V['apple'], V['pear']), 3), "cos(king,apple)", round(cos(V['king'], V['apple']), 3), "analogy err", np.linalg.norm(a - V['queen']))
