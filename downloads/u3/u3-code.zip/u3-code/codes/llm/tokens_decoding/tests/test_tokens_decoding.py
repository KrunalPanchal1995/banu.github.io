"""Tests: pytest, or python test_tokens_decoding.py."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import tokens_decoding as t


def test_softmax_sums_to_one_and_orders():
    p = t.softmax([3.0, 1.0, 0.0], T=1.0)
    assert abs(p.sum() - 1) < 1e-12 and p[0] > p[1] > p[2]


def test_temperature_limits():
    z = [2.0, 1.0, 0.0]
    assert t.softmax(z, 1e-3).argmax() == 0 and t.softmax(z, 1e-3)[0] > 0.999   # T->0 greedy
    assert np.allclose(t.softmax(z, 1e6), 1 / 3, atol=1e-3)                      # T->inf uniform


def test_top_k_top_p():
    p = np.array([0.5, 0.3, 0.15, 0.05])
    assert np.count_nonzero(t.top_k_filter(p, 2)) == 2
    q = t.top_p_filter(p, 0.8)           # 0.5+0.3 = 0.8 -> two tokens
    assert np.count_nonzero(q) == 2 and abs(q.sum() - 1) < 1e-12
    assert np.count_nonzero(t.top_p_filter(p, 1.0)) == 4


def test_bpe_reduces_length_and_is_deterministic():
    text = "low low lower newest newest widest"
    m1, _ = t.train_bpe(text, 8)
    m2, _ = t.train_bpe(text, 8)
    assert m1 == m2
    assert len(t.encode(text, m1)) < len(text.replace(" ", "")) + len(text.split())


def test_beam_beats_greedy_on_trap():
    # greedy takes token 1 (0.6) then is stuck with 0.4/0.6 splits; path via token 2 is better overall
    P = np.array([[0.0, 0.6, 0.4], [0.5, 0.25, 0.25], [0.01, 0.01, 0.98]])
    L = np.log(P + 1e-12)
    greedy = 0.0
    tok = 0
    for _ in range(2):
        j = int(np.argmax(L[tok])); greedy += L[tok, j]; tok = j
    best = t.beam_search(L, 0, 3, 2)[0][1]
    assert best > greedy


def test_compute_optimal_matches_chinchilla_scale():
    N, D = t.compute_optimal(5.76e23)
    assert 6e10 < N < 8e10 and 1.2e12 < D < 1.6e12


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
    print("ok")
