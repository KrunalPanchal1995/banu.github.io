"""BPE tokenizer trainer and decoding strategies (greedy, temperature, top-k, top-p, beam) in numpy.

See README.md in this folder for purpose, API, and runnable examples.
"""
from collections import Counter

import numpy as np


# ---------------------------------------------------------------- BPE ----
def _word_freqs(text):
    """Split on whitespace; each word becomes a tuple of characters plus an end marker '</w>'."""
    freqs = Counter(text.split())
    return {tuple(w) + ("</w>",): c for w, c in freqs.items()}


def _pair_counts(vocab):
    pairs = Counter()
    for word, c in vocab.items():
        for a, b in zip(word, word[1:]):
            pairs[(a, b)] += c
    return pairs


def _merge(vocab, pair):
    out = {}
    for word, c in vocab.items():
        new, i = [], 0
        while i < len(word):
            if i < len(word) - 1 and (word[i], word[i + 1]) == pair:
                new.append(word[i] + word[i + 1])
                i += 2
            else:
                new.append(word[i])
                i += 1
        out[tuple(new)] = c
    return out


def train_bpe(text, num_merges):
    """Learn `num_merges` BPE merges. Returns (merges, history).

    merges: ordered list of (left, right) pairs. history: list of (pair, count, vocab_size_after).
    Ties on pair count are broken by the pair itself (lexicographic), so the result is deterministic.
    """
    vocab = _word_freqs(text)
    merges, history = [], []
    for _ in range(num_merges):
        pairs = _pair_counts(vocab)
        if not pairs:
            break
        best = max(pairs, key=lambda p: (pairs[p], p))
        vocab = _merge(vocab, best)
        merges.append(best)
        symbols = {s for w in vocab for s in w}
        history.append((best, pairs[best], len(symbols)))
    return merges, history


def encode_word(word, merges):
    """Apply learned merges, in learned order, to one word. Returns a list of tokens."""
    toks = list(word) + ["</w>"]
    for a, b in merges:
        i = 0
        while i < len(toks) - 1:
            if toks[i] == a and toks[i + 1] == b:
                toks[i:i + 2] = [a + b]
            else:
                i += 1
    return toks


def encode(text, merges):
    return [t for w in text.split() for t in encode_word(w, merges)]


# ----------------------------------------------------------- decoding ----
def softmax(z, T=1.0):
    """Temperature softmax, p_i = exp(z_i/T) / sum_j exp(z_j/T). T>0. Stable (max subtracted)."""
    z = np.asarray(z, dtype=float) / T
    z = z - z.max()
    e = np.exp(z)
    return e / e.sum()


def top_k_filter(p, k):
    """Keep the k largest probabilities, zero the rest, renormalise."""
    p = np.asarray(p, dtype=float)
    if k >= len(p):
        return p / p.sum()
    keep = np.argsort(-p, kind="stable")[:k]
    q = np.zeros_like(p)
    q[keep] = p[keep]
    return q / q.sum()


def top_p_filter(p, top_p):
    """Nucleus: smallest set of highest-probability tokens whose total mass is >= top_p; renormalise."""
    p = np.asarray(p, dtype=float)
    order = np.argsort(-p, kind="stable")
    cum = np.cumsum(p[order])
    cutoff = int(np.searchsorted(cum, top_p - 1e-12) + 1)
    keep = order[:cutoff]
    q = np.zeros_like(p)
    q[keep] = p[keep]
    return q / q.sum()


def sample(logits, T=1.0, top_k=None, top_p=None, rng=None):
    """Draw one token id. T -> 0 behaves like greedy; filters are applied after temperature."""
    rng = rng or np.random.default_rng()
    p = softmax(logits, T)
    if top_k is not None:
        p = top_k_filter(p, top_k)
    if top_p is not None:
        p = top_p_filter(p, top_p)
    return int(rng.choice(len(p), p=p))


def entropy_bits(p):
    p = np.asarray(p, dtype=float)
    p = p[p > 0]
    return float(-(p * np.log2(p)).sum())


def beam_search(step_logprobs, start, beam_width, length):
    """Beam search over a first-order model.

    step_logprobs: (V, V) array, row i = log P(next | previous = i). Returns list of (tokens, logprob),
    best first. No length normalisation (so shorter-is-not-favoured only because length is fixed).
    """
    beams = [([start], 0.0)]
    for _ in range(length):
        cand = []
        for toks, lp in beams:
            row = step_logprobs[toks[-1]]
            for j in np.argsort(-row)[:beam_width]:
                cand.append((toks + [int(j)], lp + float(row[j])))
        cand.sort(key=lambda t: -t[1])
        beams = cand[:beam_width]
    return beams


# ----------------------------------------------------- scaling law ----
def chinchilla_loss(N, D, E=1.69, A=406.4, B=410.7, alpha=0.34, beta=0.28):
    """Parametric loss L(N,D) = E + A/N^alpha + B/D^beta.

    Constants are Eq. (10) of Hoffmann et al. 2022 (arXiv:2203.15556), checked against the paper's PDF.
    This is their approach-3 fit; it implies N_opt ~ C^0.46, D_opt ~ C^0.54 (so D/N grows with compute),
    while approaches 1-2 give exponents ~0.50 (the constant ~20 tokens/parameter rule of thumb).
    """
    return E + A / np.power(N, alpha) + B / np.power(D, beta)


def compute_optimal(C, a=0.5):
    """Split a compute budget C ~ 6*N*D FLOPs with D = 20*N (the ~20 tokens/parameter rule of thumb)."""
    N = np.sqrt(C / (6 * 20.0))
    return N, 20.0 * N


def main():
    text = "low low low low low lower lower newest newest newest newest newest newest widest widest widest"
    merges, hist = train_bpe(text, 10)
    for (pair, c, v) in hist:
        print(f"merge {pair!s:22} count={c:2d} vocab={v}")
    print(encode("lowest newer", merges))


if __name__ == "__main__":
    main()
