"""Fig 1: Qwen2.5-0.5B-Instruct from its real config: where the parameters are, and the exact match with the hub; weights memory by precision."""
from _common import *
use_code("serving/serving_np")
import serving_np as S
cfg = S.load_config(); b = S.param_breakdown(cfg); n = b["total"]
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
parts = [("embedding (tied with output)", b["embedding"], PAL["purple"]), ("attention", b["attention"], PAL["blue"]), ("MLP", b["mlp"], PAL["orange"]), ("norms", b["norms"], PAL["grey"])]
left = 0
for name, v, c in parts: axs[0].barh(0, v / 1e6, left=left, color=c, label=f"{name}: {v/1e6:.1f}M ({100*v/n:.1f}%)"); left += v / 1e6
axs[0].set(yticks=[], xlabel="parameters (millions)", title=f"computed total {n:,} = hub {S.hub_total():,}"); axs[0].legend(fontsize=6, loc="lower center", bbox_to_anchor=(.5, -.55))
dts = ["fp32", "bf16", "int8", "int4"]; mb = [S.weight_bytes(n, d) / 1e6 for d in dts]; axs[1].bar(dts, mb, color=[PAL["red"], PAL["blue"], PAL["green"], PAL["orange"]])
for i, v in enumerate(mb): axs[1].text(i, v + 20, f"{v:,.0f} MB", ha="center", fontsize=7)
axs[1].set(ylabel="memory for the weights (MB)", title="same model, different precision")
save(fig, out("fig01_config.png"))
print("params", b); print("shares", {k: round(v / n, 4) for k, v in b.items() if k not in ("total", "per_layer")}); print("weights MB", dict(zip(dts, np.round(mb, 1))), " file 988,097,824 bytes = 2n + ", 988097824 - 2 * n)
print("config: hidden", cfg["hidden_size"], "layers", cfg["num_hidden_layers"], "heads", cfg["num_attention_heads"], "kv heads", cfg["num_key_value_heads"], "ff", cfg["intermediate_size"], "vocab", cfg["vocab_size"], "ctx", cfg["max_position_embeddings"])
