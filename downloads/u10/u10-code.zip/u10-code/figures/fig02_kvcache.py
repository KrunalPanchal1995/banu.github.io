"""Fig 2: KV cache: bytes per token, growth with context, grouped-query attention versus full multi-head, sequences that fit."""
from _common import *
use_code("serving/serving_np")
import serving_np as S
cfg = S.load_config(); n = S.hub_total(); ctx = np.array([512, 2048, 8192, 32768]); fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
gqa, mha = S.kv_bytes_per_token(cfg), S.kv_bytes_per_token(cfg, kv_heads=cfg["num_attention_heads"])
axs[0].loglog(ctx, ctx * gqa / 1e6, "o-", color=PAL["blue"], label=f"as built: {cfg['num_key_value_heads']} KV heads ({gqa/1024:.0f} KiB/token)"); axs[0].loglog(ctx, ctx * mha / 1e6, "s--", color=PAL["red"], label=f"if full multi-head: {cfg['num_attention_heads']} KV heads ({mha/1024:.0f} KiB/token)")
axs[0].axhline(S.weight_bytes(n, "bf16") / 1e6, color=PAL["grey"], ls=":"); axs[0].text(520, S.weight_bytes(n, "bf16") / 1e6 * 1.1, "the weights themselves: 988 MB", fontsize=6.5, color=PAL["grey"])
axs[0].set(xlabel="context length (tokens)", ylabel="KV cache of ONE sequence (MB)"); axs[0].legend(fontsize=6)
mems = {"8 GB": 8e9, "24 GB": 24e9, "80 GB": 80e9}; cts = [1024, 4096, 16384, 32768]; x = np.arange(len(cts)); w = .27
for i, (name, m) in enumerate(mems.items()): axs[1].bar(x + (i - 1) * w, [S.max_concurrent_sequences(m, S.weight_bytes(n, "bf16"), c, cfg) for c in cts], w, label=name)
axs[1].set_xticks(x, [f"{c:,}" for c in cts]); axs[1].set(xlabel="context per sequence (tokens)", ylabel="sequences that fit at the same time", yscale="log"); axs[1].legend(fontsize=7, title="GPU memory", title_fontsize=7)
save(fig, out("fig02_kvcache.png"))
print("bytes/token GQA", gqa, "MHA", mha, "ratio", mha / gqa); print("KV of one 32768-token sequence MB:", 32768 * gqa / 1e6, " MHA:", 32768 * mha / 1e6)
for name, m in mems.items(): print(name, {c: S.max_concurrent_sequences(m, S.weight_bytes(n, "bf16"), c, cfg) for c in cts}, " | if MHA:", {c: int((m * .9 - S.weight_bytes(n, 'bf16')) // (mha * c)) for c in cts})
