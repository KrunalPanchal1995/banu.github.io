"""Fig 6: cost of tokens against utilisation (ILLUSTRATIVE prices), a model cascade, and drift monitoring with PSI."""
from _common import *
use_code("serving/serving_np")
import serving_np as S
cfg = S.load_config(); n = S.hub_total(); BW, FL = 1e12, 1e14; w = S.weight_bytes(n, "bf16"); kv = S.kv_bytes_per_token(cfg) * 500
tps = S.decode_throughput(n, w, kv, 32, BW, FL); gpu = 2.0; api = 0.50                        # example: $2 per GPU-hour, $0.50 per million tokens from a provider (round numbers, not quotes)
fig, axs = plt.subplots(1, 3, figsize=(8.8, 3.0), layout="constrained"); u = np.linspace(0.02, 1, 100)
axs[0].semilogy(u * 100, [S.cost_per_million_tokens(gpu, tps, x) for x in u], color=PAL["blue"], label="own GPU ($2/hour, batch 32)"); axs[0].axhline(api, color=PAL["red"], ls="--", label="pay per token ($0.50 per million)"); axs[0].set(xlabel="share of the time the GPU is busy (%)", ylabel="dollars per million tokens"); axs[0].legend(fontsize=6)
ps = np.linspace(0, 1, 101); axs[1].plot(ps * 100, [S.cascade_cost(1, 10, p) for p in ps], color=PAL["purple"]); axs[1].axhline(10, color=PAL["red"], ls="--"); axs[1].text(2, 9.0, "always the large model", fontsize=6.5, color=PAL["red"]); axs[1].set(xlabel="requests escalated to the large model (%)", ylabel="relative cost per request (small = 1, large = 10)")
rng = np.random.default_rng(0); ref = rng.normal(0, 1, 20000); shifts = np.linspace(0, 1.2, 25); axs[2].plot(shifts, [S.psi(ref, rng.normal(m, 1, 20000)) for m in shifts], "o-", color=PAL["green"], ms=3); axs[2].axhline(0.1, color=PAL["orange"], ls=":"); axs[2].axhline(0.25, color=PAL["red"], ls=":"); axs[2].text(0.02, 0.27, "0.25: shifted", fontsize=6.5, color=PAL["red"]); axs[2].text(0.02, 0.12, "0.1: watch", fontsize=6.5, color=PAL["orange"]); axs[2].set(xlabel="shift of the input mean (in standard deviations)", ylabel="population stability index")
save(fig, out("fig06_cost_monitor.png"))
print("decode throughput batch 32 (illustrative hardware):", round(tps), "tokens/s;  $/M tokens at 100%, 50%, 20% busy:", [round(S.cost_per_million_tokens(gpu, tps, x), 3) for x in (1, .5, .2)])
be_u = gpu / (tps * 3600) * 1e6 / api; print("utilisation at which own GPU = $0.50/M:", round(be_u, 4)); print("break-even monthly tokens (GPU $1460/month vs $0.5/M):", S.break_even_tokens_per_month(1460, api) / 1e9, "billion")
print("cascade: escalate 10%, 20%, 50%:", [S.cascade_cost(1, 10, p) for p in (.1, .2, .5)]); print("PSI at shift 0, 0.3, 0.5, 1.0:", [round(S.psi(ref, rng.normal(m, 1, 20000)), 3) for m in (0, .3, .5, 1.0)])
