"""Fig 4: serving simulation: static batching versus continuous batching: latency percentiles and throughput against load."""
from _common import *
use_code("serving/serving_np")
import serving_np as S
cfg = S.load_config(); n = S.hub_total(); BW, FL = 1e12, 1e14; w = S.weight_bytes(n, "bf16"); kv = S.kv_bytes_per_token(cfg) * 500
st = lambda b: S.decode_step_time(w, kv, 2 * n, b, BW, FL); rates = [5, 20, 80, 120, 160, 240, 320, 400, 480]; res = {"static": [], "continuous": []}
for pol in res:
    for lam in rates:
        lat, th, mb = S.simulate(pol, lam, 3000, 32, st, mean_out=60, rng=np.random.default_rng(int(lam))); res[pol].append((np.percentile(lat, 50), np.percentile(lat, 95), th, mb))
fig, axs = plt.subplots(1, 3, figsize=(8.8, 3.0), layout="constrained")
for pol, c, ls in (("static", PAL["red"], "--"), ("continuous", PAL["blue"], "-")):
    r = np.array(res[pol]); axs[0].semilogy(rates, r[:, 1], ls, marker="o", color=c, ms=4, label=pol); axs[1].plot(rates, r[:, 2], ls, marker="o", color=c, ms=4, label=pol); axs[2].plot(rates, r[:, 3], ls, marker="o", color=c, ms=4, label=pol)
axs[0].set(xlabel="requests arriving per second", ylabel="95th-percentile latency (s)"); axs[1].set(xlabel="requests arriving per second", ylabel="tokens generated per second"); axs[2].set(xlabel="requests arriving per second", ylabel="average batch size"); axs[0].legend(fontsize=7)
save(fig, out("fig04_batching.png"))
print("step time (ms) at batch 1, 8, 32:", [round(st(b) * 1000, 3) for b in (1, 8, 32)])
for pol in res: print(pol, "p50", np.round([r[0] for r in res[pol]], 2), "p95", np.round([r[1] for r in res[pol]], 2), "tok/s", np.round([r[2] for r in res[pol]]), "batch", np.round([r[3] for r in res[pol]], 1))
print("rates", rates)
