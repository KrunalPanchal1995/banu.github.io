"""Fig 5: the real RAG web service: measured latency and throughput on this machine."""
from _common import *
use_code("serving/serving_np")
import importlib.util, sys
spec = importlib.util.spec_from_file_location("bench_service", os.path.join(KB, "codes", "serving", "serving_np", "bench_service.py")); bs = importlib.util.module_from_spec(spec); spec.loader.exec_module(bs)
r = bs.run(port=8793, n_seq=300, n_threads=8, per_thread=60); a, c = np.array(r["seq_ms"]), np.array(r["conc_ms"])
fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
axs[0].hist(a, 40, color=PAL["blue"], alpha=.8, label="one client at a time"); axs[0].hist(c, 40, color=PAL["orange"], alpha=.7, label="8 clients at once")
for q, ls in ((50, "-"), (95, "--"), (99, ":")): axs[0].axvline(np.percentile(a, q), color=PAL["blue"], ls=ls, lw=1)
axs[0].set(xlabel="end-to-end latency per request (ms)", ylabel="requests"); axs[0].legend(fontsize=7)
lab = ["p50", "p95", "p99"]; x = np.arange(3); axs[1].bar(x - .2, [np.percentile(a, q) for q in (50, 95, 99)], .4, color=PAL["blue"], label="one client"); axs[1].bar(x + .2, [np.percentile(c, q) for q in (50, 95, 99)], .4, color=PAL["orange"], label="8 clients")
axs[1].set_xticks(x, lab); axs[1].set(ylabel="latency (ms)"); axs[1].legend(fontsize=7)
save(fig, out("fig05_service.png"))
print("sequential: p50 %.2f p95 %.2f p99 %.2f ms; %.0f requests/s" % (*[np.percentile(a, q) for q in (50, 95, 99)], r["seq_throughput"])); print("8 clients: p50 %.2f p95 %.2f p99 %.2f ms; %.0f requests/s" % (*[np.percentile(c, q) for q in (50, 95, 99)], r["conc_throughput"]))
print("answered share", round(r["answered_share"], 3), "validation status codes", r["validation_status"])
