"""Fig 3: decoding is memory-bound: tokens/s against batch size for the real model on an ILLUSTRATIVE accelerator (1 TB/s, 100 TFLOP/s)."""
from _common import *
use_code("serving/serving_np")
import serving_np as S
cfg = S.load_config(); n = S.hub_total(); BW, FL = 1e12, 1e14; bs = np.array([1, 2, 4, 8, 16, 32, 64, 128, 256, 512]); fig, axs = plt.subplots(1, 2, figsize=FIG["panel2"], layout="constrained")
cases = [("bf16 weights, 100-token context", "bf16", 100, PAL["blue"], "-"), ("bf16 weights, 1000-token context", "bf16", 1000, PAL["orange"], "--"), ("4-bit weights, 100-token context", "int4", 100, PAL["green"], "-"), ("4-bit weights, 1000-token context", "int4", 1000, PAL["red"], "--")]
for name, dt, ctx, c, ls in cases:
    w = S.weight_bytes(n, dt); kv = S.kv_bytes_per_token(cfg) * ctx; axs[0].loglog(bs, [S.decode_throughput(n, w, kv, b, BW, FL) for b in bs], ls, color=c, label=name)
    print(f"{name:36s} tokens/s at batch 1, 8, 32, 128, 512:", [round(S.decode_throughput(n, w, kv, b, BW, FL)) for b in (1, 8, 32, 128, 512)], " critical batch", round(S.critical_batch(n, w, kv, BW, FL), 1) if S.critical_batch(n, w, kv, BW, FL) != float("inf") else "inf")
axs[0].axhline(FL / (2 * n), color=PAL["grey"], ls=":"); axs[0].text(1.1, FL / (2 * n) * 0.6, "compute ceiling", fontsize=6.5, color=PAL["grey"]); axs[0].set(xlabel="batch size (sequences decoded together)", ylabel="decode throughput (tokens/s, all sequences)"); axs[0].legend(fontsize=5.5, loc="lower right")
w = S.weight_bytes(n, "bf16"); kv = S.kv_bytes_per_token(cfg) * 100; t = [S.decode_step_time(w, kv, 2 * n, b, BW, FL) * 1000 for b in bs]; axs[1].loglog(bs, t, "o-", color=PAL["blue"], label="time of one decoding step (ms)")
axs[1].loglog(bs, [(w + b * kv) / BW * 1000 for b in bs], ":", color=PAL["orange"], label="memory time"); axs[1].loglog(bs, [b * 2 * n / FL * 1000 for b in bs], ":", color=PAL["red"], label="compute time")
axs[1].set(xlabel="batch size", ylabel="milliseconds per step"); axs[1].legend(fontsize=6)
save(fig, out("fig03_roofline.png"))
p = S.prefill_time(n, 1000, FL, 0.5); print("prefill 1000 prompt tokens:", round(p * 1000, 2), "ms; decode step at batch 1:", round(t[0], 3), "ms (bf16, ctx 100)"); print("memory time at batch 1:", w / BW * 1000, "ms; compute per token:", 2 * n / FL * 1e6, "us; KV read per sequence ctx 100/1000 us:", S.kv_bytes_per_token(cfg) * 100 / BW * 1e6, S.kv_bytes_per_token(cfg) * 1000 / BW * 1e6)
