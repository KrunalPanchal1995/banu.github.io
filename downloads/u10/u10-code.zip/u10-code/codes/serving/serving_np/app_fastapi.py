"""A RAG question-answering web service (FastAPI) over the course text: retrieval by BM25, extractive answer, an abstention rule,
input validation, request logging and a health check. Run:  uvicorn app_fastapi:app --port 8000
Endpoints: GET /health, POST /ask {"question": "...", "k": 3}.  The 'generator' is extractive (no LLM): replace answer_fn to plug in a real model."""
import logging
import os
import sys
import time

from fastapi import FastAPI
from pydantic import BaseModel, Field

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "rag", "rag_np"))
import rag_np as R  # noqa: E402

log = logging.getLogger("rag-service"); logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
app = FastAPI(title="Course RAG service", version="1.0")
_chunks = R.chunk_corpus(R.load_corpus(), 600, 120)
_bm25 = R.BM25([c["text"] for c in _chunks])
MIN_COVERAGE = 0.4                                                  # abstain below this share of question words found in the best chunk (Unit 5)


class Ask(BaseModel):
    question: str = Field(min_length=3, max_length=500)             # validated BEFORE any work is done
    k: int = Field(default=3, ge=1, le=8)


@app.get("/health")
def health():
    return {"status": "ok", "chunks": len(_chunks)}


@app.post("/ask")
def ask(req: Ask):
    t0 = time.perf_counter()
    order = R.rank(_bm25.scores(req.question))[: req.k]; ctx = [_chunks[int(i)]["text"] for i in order]
    cov = R.query_coverage(req.question, ctx[0])
    answer = R.extractive_answer(req.question, ctx, n=2) if cov >= MIN_COVERAGE else None
    ms = (time.perf_counter() - t0) * 1000
    log.info("ask k=%d coverage=%.2f answered=%s latency_ms=%.2f", req.k, cov, answer is not None, ms)
    return {"answer": answer or "I don't know: the course text does not seem to contain this.", "answered": answer is not None, "coverage": round(cov, 3), "sources": [c[:160] for c in ctx], "latency_ms": round(ms, 2)}
