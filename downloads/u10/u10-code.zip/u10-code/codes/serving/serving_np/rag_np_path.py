"""Puts codes/rag/rag_np on sys.path (helper for bench_service.py)."""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "rag", "rag_np"))
