"""Start the FastAPI service in a subprocess and measure it: sequential latency percentiles and throughput with concurrent clients.
Run: python bench_service.py   (about 30 seconds). Results are specific to the machine they run on."""
import json
import os
import subprocess
import sys
import threading
import time

import numpy as np
import requests

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import rag_np_path  # noqa: F401,E402  (sets up the rag_np import path)
import rag_np as R  # noqa: E402


def run(port=8791, n_seq=300, n_threads=8, per_thread=60):
    p = subprocess.Popen([sys.executable, "-m", "uvicorn", "app_fastapi:app", "--port", str(port), "--log-level", "warning"], cwd=HERE)
    base = f"http://127.0.0.1:{port}"
    try:
        for _ in range(100):
            try:
                if requests.get(base + "/health", timeout=1).json()["status"] == "ok":
                    break
            except Exception:
                time.sleep(0.2)
        qs = [e["q"] for e in R.load_queries()["answerable"]] + R.load_queries()["unanswerable"] + [e["q"] for e in R.load_queries()["near_miss"]]
        s = requests.Session(); lat, answered = [], 0
        for i in range(n_seq):
            t0 = time.perf_counter(); r = s.post(base + "/ask", json={"question": qs[i % len(qs)], "k": 3}); lat.append((time.perf_counter() - t0) * 1000); answered += r.json()["answered"]
        bad = [requests.post(base + "/ask", json={"question": "x"}).status_code, requests.post(base + "/ask", json={"question": "y" * 600}).status_code, requests.post(base + "/ask", json={"question": "valid question here", "k": 99}).status_code]
        lat_c = []; lock = threading.Lock(); t_start = time.perf_counter()
        def worker(tid):
            ss = requests.Session()
            for i in range(per_thread):
                t0 = time.perf_counter(); ss.post(base + "/ask", json={"question": qs[(tid * 7 + i) % len(qs)], "k": 3}); d = (time.perf_counter() - t0) * 1000
                with lock: lat_c.append(d)
        th = [threading.Thread(target=worker, args=(i,)) for i in range(n_threads)]; [t.start() for t in th]; [t.join() for t in th]; wall = time.perf_counter() - t_start
        return {"seq_ms": lat, "answered_share": answered / n_seq, "validation_status": bad, "conc_ms": lat_c, "conc_throughput": len(lat_c) / wall, "n_threads": n_threads, "seq_throughput": n_seq / (sum(lat) / 1000)}
    finally:
        p.terminate(); p.wait(timeout=10)


if __name__ == "__main__":
    r = run(); a, c = np.array(r["seq_ms"]), np.array(r["conc_ms"])
    print("sequential: p50 %.1f ms, p95 %.1f ms, p99 %.1f ms, %.0f requests/s" % (np.percentile(a, 50), np.percentile(a, 95), np.percentile(a, 99), r["seq_throughput"]))
    print("%d concurrent clients: p50 %.1f ms, p95 %.1f ms, %.0f requests/s" % (r["n_threads"], np.percentile(c, 50), np.percentile(c, 95), r["conc_throughput"]))
    print("answered share", round(r["answered_share"], 3), "| validation status codes (short, too long, k=99):", r["validation_status"])
