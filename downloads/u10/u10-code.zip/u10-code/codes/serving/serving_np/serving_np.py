"""Serving and deployment arithmetic: parameter and KV-cache counts from a real model config, a roofline latency model, a batching
simulation, cost formulas, drift monitoring (PSI) and latency percentiles.

See README.md. data/qwen2.5-0.5b-instruct-config.json is the real config of Qwen/Qwen2.5-0.5B-Instruct fetched from the Hugging Face hub;
data/hub_reported.json holds the parameter count the hub reports for it. Hardware numbers are PARAMETERS of the model, not claims about any product.
"""
import json
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DTYPE_BYTES = {"fp32": 4.0, "bf16": 2.0, "fp16": 2.0, "int8": 1.0, "int4": 0.5}


def load_config(path=None):
    return json.load(open(path or os.path.join(HERE, "data", "qwen2.5-0.5b-instruct-config.json")))


def hub_total():
    return json.load(open(os.path.join(HERE, "data", "hub_reported.json")))["hub_total_parameters"]


# ------------------------------------------------------------------ parameter and memory counts
def param_breakdown(cfg):
    """Parameters of a Qwen2-style decoder from its config: token embedding (tied with the output layer), per layer attention (q, k, v with bias, o without),
    gated MLP (gate, up, down), two RMS-norm weights, plus the final norm. Returns a dict of counts."""
    d, ff, L = cfg["hidden_size"], cfg["intermediate_size"], cfg["num_hidden_layers"]
    h, kv, V = cfg["num_attention_heads"], cfg["num_key_value_heads"], cfg["vocab_size"]; hd = d // h
    bias = cfg.get("attention_bias", True)                       # Qwen2 has biases on q, k, v; set "attention_bias": False for models without
    attn = (d * h * hd + (h * hd if bias else 0)) + 2 * (d * kv * hd + (kv * hd if bias else 0)) + (h * hd * d)
    mlp = 3 * d * ff; norm = 2 * d
    emb = V * d * (1 if cfg.get("tie_word_embeddings") else 2)
    return {"embedding": emb, "attention": L * attn, "mlp": L * mlp, "norms": L * norm + d, "total": emb + L * (attn + mlp + norm) + d, "per_layer": attn + mlp + norm}


def weight_bytes(n_params, dtype, group=64):
    """Memory for the weights. int4 includes one 16-bit scale per `group` weights (Unit 6): 0.5 + 2/group bytes per weight."""
    if dtype == "int4":
        return n_params * (0.5 + 2.0 / group)
    return n_params * DTYPE_BYTES[dtype]


def kv_bytes_per_token(cfg, dtype="bf16", kv_heads=None):
    """Bytes of key+value cache per token: 2 (K and V) x layers x kv_heads x head_dim x bytes. kv_heads=None uses the config (grouped-query attention)."""
    hd = cfg["hidden_size"] // cfg["num_attention_heads"]; kv = kv_heads if kv_heads is not None else cfg["num_key_value_heads"]
    return 2 * cfg["num_hidden_layers"] * kv * hd * DTYPE_BYTES[dtype]


def max_concurrent_sequences(mem_bytes, weights_b, ctx_tokens, cfg, dtype="bf16", overhead_frac=0.1):
    """How many sequences of ctx_tokens fit: (memory x (1 - overhead) - weights) / (KV bytes per sequence)."""
    free = mem_bytes * (1 - overhead_frac) - weights_b
    return max(int(free // (kv_bytes_per_token(cfg, dtype) * ctx_tokens)), 0)


# ------------------------------------------------------------------ roofline latency model
def decode_step_time(n_params_bytes, kv_bytes_total, flops_per_token, batch, bandwidth, peak_flops):
    """Time of one decode iteration for `batch` sequences: the larger of the memory time (read the weights once plus every sequence's KV cache)
    and the compute time (2 x params FLOPs per token per sequence). bandwidth in bytes/s, peak_flops in FLOP/s."""
    mem = (n_params_bytes + batch * kv_bytes_total) / bandwidth; comp = batch * flops_per_token / peak_flops
    return max(mem, comp)


def decode_throughput(n_params, weight_b, kv_per_seq, batch, bandwidth, peak_flops):
    """Tokens per second summed over the batch."""
    return batch / decode_step_time(weight_b, kv_per_seq, 2 * n_params, batch, bandwidth, peak_flops)


def critical_batch(n_params, weight_b, kv_per_seq, bandwidth, peak_flops):
    """Batch size at which compute time equals memory time: B* = weight_b / (bandwidth) / (2 n_params/peak - kv_per_seq/bandwidth), when positive."""
    den = 2 * n_params / peak_flops - kv_per_seq / bandwidth
    return float("inf") if den <= 0 else (weight_b / bandwidth) / den


def prefill_time(n_params, prompt_tokens, peak_flops, utilisation=0.5):
    """Prompt processing is compute-bound: about 2 n_params FLOPs per prompt token at a fraction of peak."""
    return 2 * n_params * prompt_tokens / (peak_flops * utilisation)


# ------------------------------------------------------------------ cost
def cost_per_million_tokens(gpu_dollars_per_hour, tokens_per_second, utilisation=1.0):
    """Dollars per 10^6 generated tokens when the GPU is busy a fraction `utilisation` of the time."""
    return gpu_dollars_per_hour / (tokens_per_second * utilisation * 3600) * 1e6


def break_even_tokens_per_month(gpu_dollars_per_month, api_dollars_per_million):
    """Monthly token volume above which a dedicated GPU (fixed monthly cost) beats paying per token."""
    return gpu_dollars_per_month / api_dollars_per_million * 1e6


def cascade_cost(c_small, c_large, p_escalate):
    """Expected cost per request when every request goes to the small model and a fraction p_escalate is also sent to the large one."""
    return c_small + p_escalate * c_large


# ------------------------------------------------------------------ batching simulation
def simulate(policy, arrival_rate, n_requests, max_batch, step_time, mean_out=60, rng=None, max_wait=0.05, arr=None, out=None):
    """Event-driven simulation of one model replica. Requests arrive as a Poisson process (arrival_rate per second) and need a random number of
    output tokens (geometric, mean mean_out). step_time(batch) is the duration of one decode iteration.
    'static': wait until max_batch requests are queued (or max_wait after the first), then run until the LONGEST finishes.
    'continuous': at every iteration, finished sequences leave and queued ones join (iteration-level scheduling).
    Returns (latencies, throughput tokens/s, mean batch)."""
    rng = rng or np.random.default_rng(0)
    arr = np.cumsum(rng.exponential(1 / arrival_rate, n_requests)) if arr is None else np.asarray(arr, float)       # arrival times and output lengths can be injected (for tests)
    out = rng.geometric(1 / mean_out, n_requests) if out is None else np.asarray(out, int)
    n_requests = len(arr)
    done = np.zeros(n_requests); t = 0.0; nxt = 0; queue = []; batches = []
    if policy == "static":
        while nxt < n_requests or queue:
            if not queue:
                t = max(t, arr[nxt])
            while nxt < n_requests and arr[nxt] <= t:
                queue.append(nxt); nxt += 1
            deadline = arr[queue[0]] + max_wait
            while len(queue) < max_batch and nxt < n_requests and arr[nxt] <= deadline:      # keep waiting for more requests until full or the deadline
                t = max(t, arr[nxt]); queue.append(nxt); nxt += 1
            if len(queue) < max_batch:
                t = max(t, deadline)                                                          # batch launched at the deadline, not full
            batch = queue[:max_batch]; queue = queue[max_batch:]
            steps = int(out[batch].max()); t += steps * step_time(len(batch)); batches.append(len(batch))
            for i in batch:
                done[i] = t
    else:
        active = {}
        while nxt < n_requests or queue or active:
            if not active and not queue:
                t = max(t, arr[nxt])
            while nxt < n_requests and arr[nxt] <= t:
                queue.append(nxt); nxt += 1
            while queue and len(active) < max_batch:
                i = queue.pop(0); active[i] = int(out[i])
            t += step_time(len(active)); batches.append(len(active))
            for i in list(active):
                active[i] -= 1
                if active[i] == 0:
                    done[i] = t; del active[i]
    lat = done - arr
    return lat, float(out.sum() / done.max()), float(np.mean(batches))


# ------------------------------------------------------------------ monitoring
def percentile(x, q):
    return float(np.percentile(np.asarray(x, float), q))


def psi(expected, actual, bins=10):
    """Population stability index between a reference sample and a new sample, using bins from the reference quantiles:
    sum over bins of (a_i - e_i) ln(a_i / e_i). Common reading (a rule of thumb, not a law): < 0.1 stable, 0.1-0.25 shifting, > 0.25 shifted."""
    edges = np.quantile(expected, np.linspace(0, 1, bins + 1)); edges[0], edges[-1] = -np.inf, np.inf
    e = np.histogram(expected, edges)[0] / len(expected); a = np.histogram(actual, edges)[0] / len(actual)
    e, a = np.clip(e, 1e-6, None), np.clip(a, 1e-6, None)
    return float(np.sum((a - e) * np.log(a / e)))


def slo_violations(latencies, slo_seconds):
    return float(np.mean(np.asarray(latencies) > slo_seconds))


def main():
    cfg = load_config(); b = param_breakdown(cfg)
    print("parameters", b["total"], "hub", hub_total(), "match", b["total"] == hub_total(), "| KV bytes/token", kv_bytes_per_token(cfg), "| weights bf16 MB", round(weight_bytes(b["total"], "bf16") / 1e6, 1))


if __name__ == "__main__":
    main()
