"""Tests: pytest, or python test_serving_np.py."""
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import serving_np as S

CFG = S.load_config()


def test_parameter_count_matches_the_hub_exactly():
    b = S.param_breakdown(CFG)
    assert b["total"] == S.hub_total() == 494032768 and b["embedding"] == 151936 * 896 and b["per_layer"] == 14912384
    assert abs(b["embedding"] / b["total"] - 0.2756) < 1e-3 and b["total"] == b["embedding"] + b["attention"] + b["mlp"] + b["norms"]


def test_param_breakdown_without_attention_bias():
    c = dict(CFG, attention_bias=False); d, h, kv = 896, 14, 2; hd = 64
    assert S.param_breakdown(CFG)["total"] - S.param_breakdown(c)["total"] == 24 * (h * hd + 2 * kv * hd)


def test_weights_file_size_and_dtype_memory():
    n = S.hub_total(); assert S.weight_bytes(n, "bf16") == 2 * n and 988097824 - S.weight_bytes(n, "bf16") == 32288            # the file is 2 bytes/param plus a header
    assert S.weight_bytes(n, "int8") == n and abs(S.weight_bytes(n, "int4") / S.weight_bytes(n, "bf16") - 0.53125 / 2) < 1e-12


def test_kv_cache_and_grouped_query_saving():
    assert S.kv_bytes_per_token(CFG) == 12288 and S.kv_bytes_per_token(CFG, kv_heads=14) == 86016
    assert S.kv_bytes_per_token(CFG, kv_heads=14) / S.kv_bytes_per_token(CFG) == 7.0 and S.kv_bytes_per_token(CFG, "int8") == 6144
    assert S.max_concurrent_sequences(8e9, 988e6, 4096, CFG) == int((8e9 * 0.9 - 988e6) // (12288 * 4096)) and S.max_concurrent_sequences(1e9, 988e6, 4096, CFG) == 0


def test_roofline_memory_bound_then_compute_bound():
    n = 494e6; w = 2 * n; kv = 12288 * 1000; bw, fl = 1e12, 1e14
    t1, t2 = S.decode_step_time(w, kv, 2 * n, 1, bw, fl), S.decode_step_time(w, kv, 2 * n, 8, bw, fl)
    assert abs(t1 - (w + kv) / bw) < 1e-12 and t2 < 1.2 * t1                                                  # batch 8 costs barely more than batch 1: weights are read once
    assert S.critical_batch(n, w, kv, bw, fl) == float("inf")                                                 # 1000-token contexts: KV reads (12.3 us/seq) exceed compute (9.9 us/seq): never compute-bound
    kv100 = 12288 * 100; bstar = S.critical_batch(n, w, kv100, bw, fl); assert 100 < bstar < 130
    below, above = int(bstar) - 10, int(bstar) + 30
    assert abs(S.decode_step_time(w, kv100, 2 * n, below, bw, fl) - (w + below * kv100) / bw) < 1e-12 and abs(S.decode_step_time(w, kv100, 2 * n, above, bw, fl) - above * 2 * n / fl) < 1e-12
    th = [S.decode_throughput(n, w, kv, b, bw, fl) for b in (1, 4, 16, 64, 256, 1024)]; assert all(x < y for x, y in zip(th, th[1:])) and th[-1] < fl / (2 * n) * 1.0001   # never above the compute ceiling
    assert abs(S.prefill_time(n, 1000, fl, 0.5) - 2 * n * 1000 / (fl * 0.5)) < 1e-15
    assert S.decode_throughput(n, S.weight_bytes(n, "int4"), kv, 1, bw, fl) > 3.5 * S.decode_throughput(n, w, kv, 1, bw, fl) * 0.9    # 4-bit weights speed up memory-bound decoding


def test_cost_formulas():
    assert abs(S.cost_per_million_tokens(2.0, 1000, 1.0) - 2.0 / 3600 / 1000 * 1e6) < 1e-12 and abs(S.cost_per_million_tokens(2.0, 1000, 0.5) - 2 * S.cost_per_million_tokens(2.0, 1000, 1.0)) < 1e-12
    assert S.break_even_tokens_per_month(1500, 0.5) == 3e9 and S.cascade_cost(1, 10, 0.2) == 3.0


def test_batching_simulation_continuous_beats_static_under_load():
    st = lambda b: 0.001 + 0.0002 * b; rng = lambda: np.random.default_rng(3)
    lo_s, _, _ = S.simulate("static", 1.0, 400, 16, st, rng=rng()); lo_c, _, _ = S.simulate("continuous", 1.0, 400, 16, st, rng=rng())
    assert abs(np.median(lo_c) - 60 * 0.0012) < 0.1 and np.median(lo_c) < np.median(lo_s) + 0.01                              # light load: a single request takes about out*step_time
    hs, ths, bs_ = S.simulate("static", 60.0, 3000, 16, st, rng=rng()); hc, thc, bc = S.simulate("continuous", 60.0, 3000, 16, st, rng=rng())
    assert np.percentile(hc, 95) < np.percentile(hs, 95) and thc > 0.95 * ths and bc > 1
    assert (hc > 0).all() and (hs > 0).all()


def test_psi_and_percentiles():
    rng = np.random.default_rng(0); a, b = rng.normal(0, 1, 20000), rng.normal(0, 1, 20000)
    assert S.psi(a, b) < 0.01 and S.psi(a, rng.normal(1.0, 1, 20000)) > 0.25 and 0.1 < S.psi(a, rng.normal(0.3, 1, 20000)) < 0.25 or S.psi(a, rng.normal(0.3, 1, 20000)) > 0.05
    assert S.percentile([1, 2, 3, 4, 5], 50) == 3 and S.slo_violations([0.1, 0.2, 0.9, 1.5], 1.0) == 0.25


if __name__ == "__main__":
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            v()
    print("ok")
